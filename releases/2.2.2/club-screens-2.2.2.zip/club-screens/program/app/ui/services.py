# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: фоновые службы главного окна — сторож (heartbeat), очередь без интернета, утренняя сводка,
проверка обновлений (latest.json из репозитория, запасной путь — GitHub Releases; раз в день + кнопка) и «Пропустить ближайший съём» в трее."""
import logging
import os
import subprocess
import sys
from datetime import date, datetime, timedelta

from PySide6.QtCore import QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QMessageBox

from .. import APP_NAME, __version__, sentcheck, summary, updater, watchdog
from ..config import base_dir
from .common import Task, app_icon

log = logging.getLogger("club")
SERVICE_SEC = 60
QUEUE_EVERY_MIN = 10
NO_UPDATE_BEFORE_RUN_MIN = 10     # не обновляться, если до планового съёма меньше 10 минут


class ServicesMixin:
    def setup_services(self, autostart=True):
        self.update_info = None
        self._svc_busy = False
        self._last_flush = datetime.now()
        self._hb_on = False
        self.svc_timer = QTimer(self)
        self.svc_timer.timeout.connect(self._service_tick)
        if not autostart:
            return
        self.svc_timer.start(SERVICE_SEC * 1000)
        wd = self.cfg.get("watchdog") or {}
        if wd.get("enabled", True) and not getattr(sys, "frozen", False):
            self._hb_on = True
            self.hb_timer = QTimer(self)
            self.hb_timer.timeout.connect(self.heartbeat)
            self.hb_timer.start(watchdog.HEARTBEAT_SEC * 1000)
            self.heartbeat()
            try:
                watchdog.spawn(base_dir(), int(wd.get("hang_sec", 300) or 300))
            except Exception:  # noqa: BLE001
                log.warning("Сторож не запущен", exc_info=True)
        QTimer.singleShot(90_000, lambda: self.check_updates(manual=False))

    # ----- сторож
    def heartbeat(self, stopped=False):
        if not self._hb_on:
            return
        try:
            watchdog.beat(watchdog.hb_path(base_dir()), stopped=stopped)
        except OSError:
            log.debug("heartbeat", exc_info=True)

    def stop_services(self):
        self.svc_timer.stop()
        if self._hb_on:
            self.hb_timer.stop()
            self.heartbeat(stopped=True)      # штатный выход — сторож не перезапускает

    # ----- раз в минуту: очередь, сводка, обновления
    def _service_tick(self):
        try:
            self.sent_check_tick()        # 2.2.2: лёгкая проверка «скрины ушли?» — раз в минуту, без запросов
        except Exception:  # noqa: BLE001
            log.debug("sent_check", exc_info=True)
        if self._svc_busy or self.quitting or self.job.lock.locked():
            return
        now = datetime.now()
        lp = summary.last_sent_path(self.job._root())
        if summary.standalone_due(self.cfg, now, summary.get_last_sent(lp)):
            self._bg(self.job.send_summary_if_due)
            return
        if now - self._last_flush >= timedelta(minutes=QUEUE_EVERY_MIN) and len(self.job.queue(self.cfg)):
            self._last_flush = now
            self._bg(self.job.flush_queue)
            return
        if updater.should_check(self.cfg):
            self.check_updates(manual=False)

    def _bg(self, fn):
        self._svc_busy = True

        def end(*_):
            self._svc_busy = False
        Task(fn, end, end, name="service")

    # ----- 2.2.2: «Проверять в :05, что скрины ушли»
    def sent_check_tick(self, now=None):
        """→ вердикт проверки (для тестов). Тревога — своим окном поверх всех, трей — красный."""
        cfg = self.cfg
        if not sentcheck.settings(cfg)["enabled"] or getattr(self, "quitting", False):
            return None
        now = now or datetime.now()
        sch = self.scheduler
        minute = (cfg.get("schedule") or {}).get("minute", 0)
        rows = summary.read(summary.log_path(self.job._root()))
        target, verdict = sentcheck.decide(
            now, minute, rows, running=bool(sch.running), started_at=getattr(sch, "started_at", None),
            skipped=getattr(sch, "skipped", ()), busy=self.job.lock.locked(),
            checked=getattr(self, "_sent_checked", None))
        if verdict is None or verdict == "pending":
            if verdict == "pending" and getattr(self, "_sent_pending_logged", None) != target:
                self._sent_pending_logged = target
                log.info("Проверка %s: цикл ещё идёт (ждёт повтора) — проверю после его итога",
                         target.strftime("%H:%M"))
            return verdict
        self._sent_checked = target
        if verdict == "skip":
            log.info("Проверка %s: пропущено (съём пропущен по просьбе, расписание остановлено или "
                     "программа запущена позже)", target.strftime("%H:%M"))
        elif verdict == "ok":
            log.info("Проверка %s: скрины сняты и отправлены", target.strftime("%H:%M"))
        else:
            self.show_sent_alert(verdict)
        return verdict

    def show_sent_alert(self, v):
        from .sentalert import SentAlert
        if getattr(self, "sent_alert", None) is None:
            self.sent_alert = SentAlert(on_resend=self.resend_latest, on_send_now=lambda: self.send_now(True),
                                        on_close=lambda by_user: self._set_tray_alarm(False))
        self.sent_alert.show_alert(v["text"], v["detail"], v.get("reason"),
                                   can_resend=self._has_latest_shots(),
                                   sound=sentcheck.settings(self.cfg)["sound"])
        self._set_tray_alarm(True, v["text"])

    def clear_sent_alert(self):
        """Отправка прошла — тревога снимается сама."""
        a = getattr(self, "sent_alert", None)
        if a is not None and a.isVisible():
            log.info("Отправка прошла — тревога «скрины не ушли» снята")
            a.dismiss(by_user=False)
        self._set_tray_alarm(False)

    def _set_tray_alarm(self, on, text=""):
        if getattr(self, "_tray_alarm", False) == on or not getattr(self, "tray", None):
            self._tray_alarm = on
            return
        self._tray_alarm = on
        self.tray.setIcon(app_icon(badge="#d50000") if on else app_icon())
        if on:
            self.tray.setToolTip(f"{APP_NAME}: {text}")

    # ----- трей: пропустить ближайший съём
    def add_skip_action(self, menu, before):
        self.tray_skip = QAction("Пропустить ближайший съём", self)
        self.tray_skip.setCheckable(True)
        self.tray_skip.triggered.connect(self.toggle_skip)
        menu.insertAction(before, self.tray_skip) if before else menu.addAction(self.tray_skip)
        menu.aboutToShow.connect(self._update_skip_action)

    def _update_skip_action(self):
        s = self.scheduler
        on = s.skipping
        self.tray_skip.setChecked(on)
        self.tray_skip.setEnabled(bool(s.running and s.next_target))
        t = s.next_target.strftime("%H:%M") if s.next_target else ""
        self.tray_skip.setText(f"Пропустить ближайший съём ({t})" if t else "Пропустить ближайший съём")

    def toggle_skip(self, on=None):
        if on is None:
            on = not self.scheduler.skipping
        t = self.scheduler.skip_next(on)
        if self.tray:
            self.tray.showMessage(APP_NAME, f"Съём в {t:%H:%M} будет пропущен" if t else
                                  "Ближайший съём снова по расписанию")
        return t

    # ----- обновления
    def check_updates(self, manual=True):
        u = self.cfg.get("updates") or {}
        if not manual and not updater.should_check(self.cfg):
            return
        if not manual:
            u["last_check"] = date.today().isoformat()
            self.cfg["updates"] = u
            try:
                self.save_config(quiet=True)
            except Exception:  # noqa: BLE001
                pass
        repo = u.get("repo") or updater.DEFAULT_REPO

        def done(info):
            self.update_info = info
            if hasattr(self, "page_settings") and hasattr(self.page_settings, "show_update"):
                self.page_settings.show_update(info)
            if info:
                log.info("Доступна новая версия %s", info["version"])
                if manual:
                    self.offer_update(info)
                elif self.tray:
                    self.tray.showMessage(APP_NAME, f"Доступна версия {info['version']} — "
                                          "Настройки → «Проверить обновления»")
            elif manual:
                QMessageBox.information(self, APP_NAME, f"У вас последняя версия ({__version__}).")

        def fail(err):
            log.warning("Проверка обновлений: %s", err)
            if manual:
                QMessageBox.warning(self, APP_NAME, f"Не удалось проверить обновления: {err}")
        Task(lambda: updater.check(repo, __version__), done, fail, name="update-check")

    def update_blocked(self):
        """Причина не обновляться сейчас (или "")."""
        if self.job.lock.locked() or self.busy:
            return "сейчас идёт съём или отправка"
        t = self.scheduler.next_target if self.scheduler.running else None
        if t and t - datetime.now() < timedelta(minutes=NO_UPDATE_BEFORE_RUN_MIN):
            return f"скоро плановый съём ({t:%H:%M})"
        return ""

    def offer_update(self, info):
        why = self.update_blocked()
        if why:
            QMessageBox.information(self, APP_NAME, f"Новая версия {info['version']} есть, но {why}. "
                                    "Попробуйте через несколько минут.")
            return
        r = QMessageBox.question(self, APP_NAME,
                                 f"Доступна версия {info['version']} (у вас {__version__}).\n\n{info['notes'][:600]}\n\n"
                                 "Установить сейчас? Программа закроется на минуту и откроется снова. Настройки, "
                                 "вход в ВК и шаблоны сохранятся; откат — «ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat».")
        if r != QMessageBox.StandardButton.Yes:
            return
        root = os.path.dirname(base_dir())

        def got(path):
            why2 = self.update_blocked()
            if why2:
                QMessageBox.information(self, APP_NAME, f"Обновление скачано, но {why2}. Повторите позже.")
                return
            bat = updater.write_apply_bat(root, path, os.getpid(), info["version"])
            log.info("Устанавливаю обновление %s", info["version"])
            if sys.platform == "win32":
                subprocess.Popen(["cmd", "/c", bat], cwd=root, close_fds=True,
                                 creationflags=0x00000010)     # CREATE_NEW_CONSOLE
            self.quit()

        Task(lambda: updater.download(info, os.path.join(root, "update")), got,
             lambda e: QMessageBox.warning(self, APP_NAME, f"Обновление не установлено: {e}"), name="update-dl")
