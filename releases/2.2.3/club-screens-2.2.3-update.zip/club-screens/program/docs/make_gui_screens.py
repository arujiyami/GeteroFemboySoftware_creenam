# Original-Author: Владислав С.
# Created: 2026-10-28
"""Снимки окон программы (Qt) для инструкции + проверка, что кнопки мастера видны.

  QT_QPA_PLATFORM=offscreen python docs/make_gui_screens.py              — снимки в docs/build/*.png
  QT_SCALE_FACTOR=1.5 python docs/make_gui_screens.py --check scale_150  — только проверка (и снимки в build/scale_150)
  python docs/make_gui_screens.py --check dark --theme dark              — то же в тёмной теме (light/dark/contrast)

Windows и ВК заменены заглушками: окна Oasys/iVMS — список «как в Windows», ВК — локальная копия страниц
(docs/fake_vk_doc; тестовые заглушки — tests/fake_vk). Ни в какие учётные записи не входит."""
import copy
import functools
import http.server
import os
import re
import shutil
import sys
import tempfile
import threading
import time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from app.ui.browser import chromium_flags  # noqa: E402

os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = chromium_flags("--no-sandbox")

from PIL import Image  # noqa: E402

import app.config as config  # noqa: E402
from app import winmatch  # noqa: E402
from app.config import DEFAULTS, deep_merge  # noqa: E402
from illustrations import base  # noqa: E402

TMP = tempfile.mkdtemp(prefix="club_demo_")
config.base_dir = lambda: TMP  # шаблоны и скриншоты демо — во временной папке
FAILS = []


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name, info, flush=True)
    if not cond:
        FAILS.append(name)



def _scroll_to(ps, widget, top=12):
    """Прокрутить «Основные» так, чтобы widget был сверху."""
    from PySide6.QtCore import QPoint
    sa = ps.main_scroll
    y = widget.mapTo(sa.widget(), QPoint(0, 0)).y()
    sa.verticalScrollBar().setValue(max(0, y - top))


def _section(ps, title):
    from PySide6.QtWidgets import QLabel
    for lbl in ps.findChildren(QLabel):
        if lbl.objectName() == "sectionTitle" and lbl.text() == title:
            return lbl.parentWidget()
    raise LookupError(title)


def settings_screens(main, cfg, grab, pump):
    """2.1.6: снимки раздела «Настройки» (разделы с подсказками, всё сохраняется само)."""
    ps = main.page_settings
    old_size = main.size()
    main.resize(1060, 800)
    pump(0.3)
    ps.tabs.setCurrentIndex(0)
    ps.set_advanced_open(False)
    _scroll_to(ps, _section(ps, "Расписание"))
    grab(main, "adv_schedule.png")
    _scroll_to(ps, _section(ps, "Перед съёмом"))
    grab(main, "adv_capture.png")
    _scroll_to(ps, _section(ps, "Отправка в ВК"))
    grab(main, "adv_vk.png")
    _scroll_to(ps, _section(ps, "Очистка снимков"))
    grab(main, "adv_cleanup.png")
    _scroll_to(ps, _section(ps, "Надёжность и обновления"))
    grab(main, "adv_reliable.png")
    ps.set_advanced_open(True)
    pump(0.2)
    _scroll_to(ps, ps.adv_toggle)
    grab(main, "adv_more.png")
    ps.set_advanced_open(False)
    ps.tabs.setCurrentIndex(1)
    grab(main, "adv_sources.png")
    ps.tabs.setCurrentIndex(0)
    ps.main_scroll.verticalScrollBar().setValue(0)
    # ничего не вылезает вправо: нет горизонтальной прокрутки, подписи не обрезаны
    sa = ps.main_scroll
    check("настройки: без горизонтальной прокрутки", sa.widget().minimumSizeHint().width() <= sa.viewport().width(),
          f"{sa.widget().minimumSizeHint().width()} ≤ {sa.viewport().width()}")
    main.resize(old_size)
    pump(0.2)
    check("настройки: без горизонтальной прокрутки и в обычном размере окна",
          sa.widget().minimumSizeHint().width() <= sa.viewport().width(),
          f"{sa.widget().minimumSizeHint().width()} ≤ {sa.viewport().width()} ({main.width()}x{main.height()})")


def settings_checks(main, cfg, ps):
    from PySide6.QtCore import QTime
    from PySide6.QtGui import QKeySequence
    from PySide6.QtWidgets import QLabel, QPushButton, QSlider
    titles = [w.text() for w in ps.findChildren(QLabel) if w.objectName() == "sectionTitle"]
    check("настройки: разделы с заголовками",
          all(t in titles for t in ("Расписание", "Перед съёмом", "Во время съёма", "Проверка Oasys",
                                    "Отправка в ВК", "Очистка снимков")) and ps.adv_toggle.text() == "Дополнительно",
          str(titles))
    check("настройки: кнопки «Сохранить» нет, есть «Сбросить по умолчанию…»",
          not any(b.text() == "Сохранить" for b in ps.findChildren(QPushButton))
          and ps.reset_btn.text().startswith("Сбросить по умолчанию"))
    check("настройки: ползунок отсчёта 0…60 с, шаг 1, по умолчанию 60, 75 %, без флажка",
          isinstance(ps.countdown_seconds, QSlider) and not hasattr(ps, "countdown_enabled")
          and ps.countdown_seconds.value() == 60 and ps.countdown_opacity.value() == 75
          and (ps.countdown_seconds.minimum(), ps.countdown_seconds.maximum(), ps.countdown_seconds.singleStep())
          == (0, 60, 1) and ps.countdown_seconds.value_label.text() == "за 60 секунд",
          f"{ps.countdown_seconds.value()} {ps.countdown_opacity.value()} {ps.countdown_seconds.value_label.text()}")
    check("настройки: блокировать заранее 5 с (0…15), ждать Oasys 10 с (3…30)",
          ps.lock_early.value() == 5 and (ps.lock_early.minimum(), ps.lock_early.maximum()) == (0, 15)
          and ps.oasys_check.isChecked() and ps.oasys_wait.value() == 10
          and (ps.oasys_wait.minimum(), ps.oasys_wait.maximum()) == (3, 30) and ps.lock_watchdog.maximum() == 30)
    check("настройки: пауза музыки выключена, «включать обратно» отмечено и неактивно",
          not ps.media_pause.isChecked() and ps.media_resume.isChecked() and not ps.media_resume.isEnabled()
          and ps.media_pause.text() == "Ставить видео на паузу на время съёма"
          and ps.media_resume.text() == "После снимков включать обратно")
    check("настройки: старых полей уведомлений нет",
          not hasattr(ps, "notify_minutes") and not hasattr(main, "notify_before") and "notifications" not in cfg)
    hk = ps.lock_hotkey.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
    check("настройки: блокировка ввода включена, Ctrl+Alt+Q, сторож 30 секунд",
          ps.lock_enabled.isChecked() and hk == "Ctrl+Alt+Q" and ps.lock_watchdog.value() == 30
          and ps.lock_watchdog.suffix() == " секунд", hk)
    check("настройки: уборка включена, 24 часа, 12:30",
          ps.cleanup_enabled.isChecked() and ps.cleanup_hours.value() == 24 and ps.cleanup_hours.suffix() == " часа"
          and ps.cleanup_time.time().toString("HH:mm") == "12:30", ps.cleanup_time.time().toString("HH:mm"))
    ps.cleanup_time.setTime(QTime(3, 5))
    ps.media_pause.setChecked(True)
    check("настройки: уборка и пауза музыки применяются сразу",
          cfg["cleanup"]["time"] == "03:05" and cfg["media_pause"] == {"enabled": True, "resume": True}
          and ps.media_resume.isEnabled(), str((cfg["cleanup"], cfg["media_pause"])))
    ps.cleanup_time.setTime(QTime(12, 30))
    ps.media_pause.setChecked(False)
    ps.lock_hotkey.setKeySequence(QKeySequence("Ctrl+Shift+U"))
    ps.countdown_seconds.setValue(90)          # ползунок не даёт больше 60
    ps.countdown_opacity.setValue(60)
    applied = cfg["countdown"] == {"seconds": 60, "opacity": 60}     # сразу
    ps.countdown_seconds.setValue(15)
    applied = applied and cfg["countdown"]["seconds"] == 15
    main._on_nav(2)                            # переход в раздел заново не откатывает
    applied = applied and ps.countdown_seconds.value() == 15
    ps.countdown_seconds.setValue(60)
    ps.flush_live()
    check("настройки: сочетание и обратный отсчёт применяются сразу и сохраняются (15 с, не 60)",
          applied and cfg["input_lock"]["hotkey"] == "Ctrl+Shift+U"
          and cfg["countdown"] == {"seconds": 60, "opacity": 60} and ps.saved_label.text().startswith("✓ Сохранено"),
          str((cfg["input_lock"], cfg["countdown"], ps.saved_label.text())))
    ps.lock_hotkey.setKeySequence(QKeySequence("Shift+U"))
    try:
        ps._collect_capture()
        bad = False
    except ValueError as e:
        bad = "слишком простое" in str(e)
    check("настройки: слишком простое сочетание не принимается", bad and cfg["input_lock"]["hotkey"] == "Ctrl+Shift+U")
    ps.load()

def win(hwnd, title, exe, w=1920, h=1040, **kw):
    d = {"hwnd": hwnd, "title": title, "pid": hwnd, "exe": exe, "visible": True, "iconic": False, "tool": False,
         "cloaked": False, "owned": False, "width": w, "height": h}
    d.update(kw)
    return d


class StubBackend:
    """Окна «как в Windows»: у Oasys заголовок «OASys …», процесс OASys.Admin.exe и мелкое служебное окно."""
    ivms_open = True

    def all_windows(self):
        out = [win(1, "OASys — Администратор", "OASys.Admin.exe"),
               win(5, "OASys", "OASys.Admin.exe", 0, 0, visible=False),
               win(6, "Уведомление", "OASys.Admin.exe", 300, 80, tool=True),
               win(7, "Скриншоты клуба", "python.exe", 1000, 700)]
        if self.ivms_open:
            out.append(win(2, "iVMS-4200", "iVMS-4200.Framework.C.exe"))
        return out

    def find_window(self, title_regex="", process_regex="", exclude_title_regex="", match="any", name=""):
        best = winmatch.pick_window(self.all_windows(), title_regex, process_regex, exclude_title_regex, match, 7)
        return best["hwnd"] if best else None

    def list_windows(self):
        return [(w["hwnd"], w["title"], w["exe"]) for w in self.all_windows()]


def serve(directory=None):
    # 2.1.9: для снимков — аккуратные обезличенные страницы (docs/fake_vk_doc); те же id и классы,
    # что у тестовых заглушек tests/fake_vk, которые остаются для тестов.
    fake = directory or os.path.join(HERE, "fake_vk_doc")

    class Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):  # noqa: N802
            if re.match(r"^/im/convo/\d+", self.path):
                self.path = "/convo.html"
            elif self.path.startswith("/login"):
                self.path = "/login_qr.html"
            elif self.path.startswith("/im") or self.path in ("/", ""):
                self.path = "/im.html"
            return super().do_GET()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Handler, directory=fake))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def main():
    check_only = "--check" in sys.argv
    out = os.path.join(HERE, "build", sys.argv[sys.argv.index("--check") + 1]) if check_only \
        else os.path.join(HERE, "build")
    os.makedirs(out, exist_ok=True)
    from PySide6.QtCore import QPoint, QRect
    from PySide6.QtWidgets import QApplication

    from app.logsetup import setup_logging
    from app.ui.common import ensure_font
    app = QApplication(sys.argv[:1])
    look = sys.argv[sys.argv.index("--theme") + 1] if "--theme" in sys.argv else "light"
    ensure_font(app, {"app": {"theme": look}})
    setup_logging(os.path.join(TMP, "demo.log"))
    from app.ui.main_window import MainWindow

    def pump(sec=0.5):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.02)

    def wait_for(cond, sec=20):
        end = time.time() + sec
        while time.time() < end and not cond():
            pump(0.1)
        return cond()

    def grab(widget, name):
        pump(0.3)
        pm = widget.grab()
        path = os.path.join(out, name)
        pm.save(path)
        print("снимок", name, pm.width(), pm.height(), flush=True)

    def next_visible(w, where):
        btn = w.next_btn
        r = QRect(btn.mapTo(main, QPoint(0, 0)), btn.size())
        check(f"«{btn.text()}» видна: {where}", btn.isVisible() and main.rect().contains(r),
              f"кнопка {r.getRect()} окно {main.width()}x{main.height()}")

    shots = os.path.join(TMP, "screenshots")
    os.makedirs(shots)
    oasys, _ = base(4)
    ivms, _ = base(1)
    p1 = os.path.join(shots, "2026-10-28_03-00_10_Oasys.png")
    p2 = os.path.join(shots, "2026-10-28_03-00_20_iVMS-4200.png")
    oasys.save(p1)
    ivms.save(p2)
    os.makedirs(os.path.join(TMP, "templates"))
    base(3)[0].crop((4, 60, 38, 96)).save(os.path.join(TMP, "templates", "oasys_karta_kluba_button.png"))

    srv = serve()
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    cfg = deep_merge(copy.deepcopy(DEFAULTS), {
        "vk_browser": {"profile_dir": os.path.join(TMP, "profile"), "home_url": url + "/", "im_url": url + "/im",
                       "chat_url": url + "/im/convo/{peer_id}", "login_cookies": []},
        "app": {"theme": look}})
    main = MainWindow(cfg, os.path.join(TMP, "config.yaml"), StubBackend, autostart_jobs=False, admin=True)
    main.job.capture_preview = lambda: ({"Oasys": [p1], "iVMS-4200": [p2]}, {})
    main.resize(900, 650)
    main.show()
    check("мастер открылся сам (не настроено)", wait_for(lambda: main.wizard is not None, 5))
    w = main.wizard
    from PySide6.QtWidgets import QAbstractButton as _B, QLabel as _L
    _vis = [x.text() for x in w.findChildren(_L) + w.findChildren(_B)]
    check("мастер: автора не видно", not any("Разработано" in t or "Grok" in t for t in _vis))
    w.club.setText("Мой клуб")
    pump()
    next_visible(w, "приветствие")
    grab(main, "wiz_1.png")
    w.next()
    wait_for(lambda: main.browser.current_url().startswith(url), 10)
    pump(1.5)
    w.timer.stop()
    from PySide6.QtCore import QUrl
    main.browser.view.setUrl(QUrl(url + "/login"))   # снимок «жду входа» — со страницей входа (QR-код)
    wait_for(lambda: main.browser.current_url().startswith(url + "/login"), 10)
    pump(2.0)
    w.on_login({"state": "logged_out"})
    check("вход: «Далее» выключена до входа", not w.next_btn.isEnabled())
    grab(main, "wiz_2_wait.png")
    main.browser.view.setUrl(QUrl(url + "/im"))
    wait_for(lambda: main.browser.current_url().startswith(url + "/im"), 10)
    pump(1.0)
    w.timer.start(2500)
    ok = wait_for(lambda: w.next_btn.isEnabled(), 25)
    check("вход: «✔ Вы вошли как …»", ok and "Вы вошли как" in w.vk_status.text(), w.vk_status.text())
    pump(1.0)
    next_visible(w, "вход ВК")
    grab(main, "wiz_2.png")
    w.next()
    check("беседа: в архиве беседа не выбрана — поле пустое", w.link.text() == "", w.link.text())
    check("беседа: без ссылки «Далее» выключена", not w.next_btn.isEnabled(), w.chat_status.text())
    w.link.setText("https://vk.com/im/convo/2000000001")
    check("беседа: «Далее» доступна сразу по ссылке", w.next_btn.isEnabled(), w.chat_status.text())
    w.link.setText("что-то не то")
    check("беседа: неверная ссылка → «Далее» выключена", not w.next_btn.isEnabled(), w.chat_status.text())
    w.link.setText("vk.com/im/convo/2000000001")
    check("беседа: ссылка без https тоже работает", w.next_btn.isEnabled() and
          cfg["vk"]["peer_id"] == 2000000001, w.chat_status.text())
    w._toggle_list()  # список — по желанию; для снимка откроем его
    wait_for(lambda: w.chat_list.count() >= 1 and not w.loading_chats, 30)
    pump(0.5)
    check("беседа: список загрузился", w.chat_list.count() >= 1, w.list_status.text())
    check("беседа: название взято из списка", "Камеры | Мой клуб" in w.chat_status.text(), w.chat_status.text())
    next_visible(w, "беседа")
    grab(main, "wiz_3.png")
    w.next()
    ok = wait_for(lambda: "Найдено программ" in w.prog_status.text(), 10)
    check("программы: Oasys и iVMS найдены среди запущенных", ok and "2 из 2" in w.prog_status.text(),
          w.prog_status.text())
    next_visible(w, "программы")
    grab(main, "wiz_3b.png")
    w.next()
    ok = wait_for(lambda: "найдено" in w.win_status.text(), 10)
    check("Oasys: окно найдено по процессу OASys.Admin.exe", ok, w.win_status.text())
    next_visible(w, "Oasys")
    grab(main, "wiz_4.png")
    StubBackend.ivms_open = False
    w.next()
    ok = wait_for(lambda: "не найден" in w.win_status.text(), 10)
    check("iVMS: понятная ошибка, если окна нет", ok, w.win_status.text())
    next_visible(w, "iVMS (ошибка)")
    grab(main, "wiz_5_missing.png")
    StubBackend.ivms_open = True
    base(1)[0].crop((966, 511, 996, 539)).save(os.path.join(TMP, "templates", "ivms_fullscreen_button.png"))
    w.show_page(w.index)
    wait_for(lambda: "найдено" in w.win_status.text(), 10)
    grab(main, "wiz_5.png")
    w.next()
    w.test_capture()
    wait_for(lambda: w.send_test_btn.isEnabled(), 10)
    check("проверка: снимки показаны, можно отправить пробно", w.send_test_btn.isEnabled())
    from app.ui.common import set_status
    set_status(w.test_status, "✔ Отправлено в беседу «Камеры | Мой клуб». "
                              "Проверьте ВКонтакте.", "ok")
    next_visible(w, "проверка")
    grab(main, "wiz_6.png")
    w.next()
    next_visible(w, "готово")
    grab(main, "wiz_7.png")
    w.autostart.setChecked(False)  # в демо не трогаем автозапуск
    w.finish()
    check("мастер закрыт, настройка сохранена", main.wizard is None and cfg["app"]["setup_done"])
    check("браузер вернулся в раздел «ВКонтакте»", main.browser.holder.parent() is not None)
    main.scheduler.stop()
    if check_only:
        main.show_section("settings")      # 2.1.6: настройки — и в крупном масштабе
        settings_screens(main, cfg, grab, pump)
        main.quit()
        srv.shutdown()
        return finish()

    main.resize(1000, 700)
    type(main.scheduler).running = property(lambda s: True)
    main.scheduler.next_target = datetime(2026, 10, 28, 4, 0)
    main.job.last_result = {"time": datetime(2026, 10, 28, 3, 0), "ok": True, "sent": True, "paths": [p1, p2],
                            "errors": {}, "send_error": None, "send_result": "verified"}
    main.show_section("home")
    main.refresh()
    grab(main, "main_ok.png")
    main.job.last_result = {"time": datetime(2026, 10, 28, 3, 0), "ok": True, "sent": True, "paths": [p1],
                            "errors": {"iVMS-4200": "iVMS-4200 не найден — откройте программу iVMS-4200 (окно должно "
                                                    "быть открыто, не только значок в трее)."},
                            "send_error": None, "partial": True}
    main.refresh()
    grab(main, "main_error.png")
    type(main.scheduler).running = property(lambda s: False)
    main.job.last_result = None
    main.refresh()
    grab(main, "main_stopped.png")
    main.show_section("vk")
    pump(1.0)
    # в демо нет настоящих cookie входа ВК (login_cookies пуст) — состояние входа берём как после мастера
    cfg["vk"].update(login_ok=True, account_name="Иван Иванов")
    main._update_login_label()
    grab(main, "vk_tab.png")
    main.on_needs_user("ВК просит пройти проверку «Я не робот». Пройдите её на странице ниже, затем нажмите "
                       "«Отправить сейчас».")
    pump(0.5)
    grab(main, "vk_need.png")
    import logging
    log = logging.getLogger("club")
    for m in ("Планировщик запущен. Следующий запуск: 28.10 03:00", "Плановый запуск 03:00",
              "Oasys: скриншот 1920x1032 (window)", "iVMS-4200: скриншот 1920x1080 (monitor)",
              "Картинки прикреплены: 2026-10-28_03-00_10_Oasys.png, 2026-10-28_03-00_20_iVMS-4200.png",
              "Сообщение отправлено (verified)", "Цикл завершён: успешно", "Следующий запуск: 28.10 04:00"):
        log.info(m)
    main.show_section("log")
    pump(1.0)
    grab(main, "adv_log.png")
    main.show_section("settings")
    settings_screens(main, cfg, grab, pump)
    # 2.1.2: окно «О программе» в меню трея
    from app import AUTHOR_LINE, CONTRIBUTOR_LINE
    from PySide6.QtWidgets import QAbstractButton, QLabel
    vis = [x.text() for x in main.findChildren(QLabel) + main.findChildren(QAbstractButton) if x.isVisibleTo(main)]
    check("окно программы: автора не видно (только в «О программе»)",
          not any(AUTHOR_LINE in t or "Разработано" in t or CONTRIBUTOR_LINE in t or "Grok" in t for t in vis),
          [t for t in vis if "Разработано" in t or "Grok" in t])
    check("подвал окна: версия и кнопка «О программе»",
          main.version_label.text() == "версия " + __import__("app").__version__
          and main.about_button.text() == "О программе" and main.about_button.isVisibleTo(main))
    tray_menu = main._build_tray_menu()
    tray_items = [a.text() for a in tray_menu.actions()]
    check("меню трея: «О программе»", "О программе" in tray_items, str(tray_items))
    ah = main.about_html()
    check("«О программе»: обратный отсчёт за 60 секунд, без уведомлений Windows",
          "За 60 секунд" in ah and "обратный отсчёт" in ah and "Уведомление возле часов" not in ah, ah)
    check("«О программе»: «Как работает», версия, авторы",
          "Как работает" in ah and "12:30" in ah and "Ctrl+Alt+Q" in ah and "2.2.3" in ah
          and ah.index(AUTHOR_LINE) < ah.index(CONTRIBUTOR_LINE), ah)
    about = main.make_about_box()
    about.show()
    grab(about, "about.png")
    about.close()
    # 2.1.4/2.1.5: обратный отсчёт (ползунок 0…60 с), блокировка ввода заранее, проверка Oasys
    ps = main.page_settings
    settings_checks(main, cfg, ps)
    main.job.lock.acquire()
    main.job.phase, main.job.input_locked = "capture", True
    main.busy = True
    c, t, sub = main.status()
    check("статус во время съёмки — с сочетанием разблокировки",
          sub == "Снимаю экран — ввод заблокирован. Разблокировать: Ctrl+Shift+U", sub)
    main.job.phase, main.job.input_locked, main.busy = None, False, False
    main.job.lock.release()
    from datetime import timedelta
    from PySide6.QtCore import Qt
    real_platform = sys.platform
    type(main.scheduler).running = property(lambda s: True)
    was_active = main.isActiveWindow()
    import app.ui.main_window as mw
    mw.sys.platform = "win32"   # подсказка о разблокировке показывается только в Windows
    try:
        shown = main.show_countdown(datetime.now() + timedelta(seconds=59.5))
    finally:
        mw.sys.platform = real_platform
    ov = main.countdown
    check("обратный отсчёт: окошко показано, «Съём скриншотов через 0:5…»",
          shown and ov is not None and ov.isVisible() and ov.text.startswith("Съём скриншотов через 0:5"),
          getattr(ov, "text", None))
    check("обратный отсчёт: подсказка о разблокировке и непрозрачность из настроек",
          "Разблокировать: Ctrl+Shift+U" in ov.hint and ov.opacity == 60, f"{ov.hint} {ov.opacity}")
    scr = QApplication.primaryScreen().availableGeometry()
    g = ov.frameGeometry()
    check("обратный отсчёт: правый нижний угол, небольшое окошко",
          g.right() <= scr.right() and g.bottom() <= scr.bottom() and g.right() > scr.right() - 40
          and g.bottom() > scr.bottom() - 40 and g.width() < 480, str(g.getRect()))
    check("обратный отсчёт: не забирает фокус и мышь",
          main.isActiveWindow() == was_active and not ov.isActiveWindow()
          and bool(ov.windowFlags() & Qt.WindowType.WindowTransparentForInput)
          and bool(ov.windowFlags() & Qt.WindowType.WindowDoesNotAcceptFocus))
    from app.scheduler import countdown_hint
    ov.opacity = 75
    check("обратный отсчёт: строка «Мышь и клавиатура заблокируются через N с» (за 5 с до съёмки)",
          ov.lock_at is not None and "Мышь и клавиатура заблокируются через 5" in ov.hint, ov.hint)
    ov.hotkey = "Ctrl+Alt+Q"                 # в инструкции — сочетание по умолчанию
    ov.hint = countdown_hint("Ctrl+Alt+Q", 54.5)
    ov._resize()
    ov.update()
    pump(0.3)
    ov.grab().save(os.path.join(out, "countdown_overlay.png"))   # для схемы в инструкции
    main._exclude(True)          # перед съёмкой окошко убирается
    check("обратный отсчёт: исчезает перед съёмкой", not ov.isVisible() and not ov.active)
    main._exclude(False)
    main.show_countdown(datetime.now() + timedelta(seconds=30))
    main.job.lock.acquire()
    main._tick()
    check("обратный отсчёт: убирается, если цикл уже идёт («Отправить сейчас»)", not ov.isVisible())
    main.job.lock.release()
    cfg["countdown"]["enabled"] = False
    check("обратный отсчёт: выключен в настройках — не показывается",
          not main.show_countdown(datetime.now() + timedelta(seconds=30)) and not ov.isVisible())
    type(main.scheduler).running = property(lambda s: False)
    check("обратный отсчёт: при «Стоп» не показывается",
          not main.show_countdown(datetime.now() + timedelta(seconds=30)))
    cfg["input_lock"]["hotkey"] = "Ctrl+Alt+Q"
    cfg["countdown"] = {"enabled": True, "seconds": 60, "opacity": 75}
    ps.load()
    # выделение кнопки поверх «замороженного» экрана
    from app.ui.capture import CaptureOverlay
    shot = base(3)[0].resize((1280, 689))
    canvas = Image.new("RGB", (1280, 800), "#222")
    canvas.paste(shot, (0, 60))
    ov = CaptureOverlay(canvas, (0, 0, 1280, 800))
    ov.resize(1280, 800)
    ov.show()
    from PySide6.QtCore import QPointF
    sx = ov.width() / 1280
    ov.start, ov.end = QPointF(4 * sx, (60 + 72) * sx).toPoint(), QPointF(46 * sx, (60 + 120) * sx).toPoint()
    ov.update()
    grab(ov, "selector.png")
    ov.close()
    main.quit()
    srv.shutdown()
    return finish()


def finish():
    shutil.rmtree(TMP, ignore_errors=True)
    print("ИТОГО:", "все проверки пройдены" if not FAILS else f"ошибки: {FAILS}", flush=True)
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
