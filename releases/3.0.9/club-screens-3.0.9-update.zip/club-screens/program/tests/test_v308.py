# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.8: ожидание подтверждения ВК после «Отправить» — 40 с вместо 20 (реальный ВК 01.11 02:39: ~40 с)."""
import unittest

import yaml

from app import __version__
from app.config import DEFAULTS, _migrate_ack_wait_308, migrate
from app.vk_browser import DeliveryUnconfirmed, merged_settings
from tests.test_v306 import AckPending, drive


class AckWait308(unittest.TestCase):
    def test_version(self):
        self.assertEqual(__version__, "3.0.9")

    def test_defaults(self):
        self.assertEqual(merged_settings({})["ack_wait_sec"], 40)
        self.assertEqual(DEFAULTS["vk_browser"]["ack_wait_sec"], 40)
        with open("config.yaml", encoding="utf-8") as f:
            self.assertEqual(yaml.safe_load(f)["vk_browser"]["ack_wait_sec"], 40)

    def test_migration_only_old_default(self):
        for old, new, note in ((20, 40, True), (25, 25, False), (40, 40, False), (None, None, False)):
            vb = {"ack_wait_sec": old}
            self.assertEqual(bool(_migrate_ack_wait_308(vb)), note)
            self.assertEqual(vb["ack_wait_sec"], new)

    def test_full_migrate(self):
        import copy
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk_browser"]["ack_wait_sec"] = 20
        migrate(cfg)
        self.assertEqual(cfg["vk_browser"]["ack_wait_sec"], 40)

    def test_ack_at_38s_no_warning(self):
        fl = AckPending._fl(AckPending(), 38)
        fl.s = merged_settings({})
        with self.assertNoLogs("club", level="WARNING") if hasattr(self, "assertNoLogs") else _null():
            r, t = drive(fl.verify(None, 2))
        self.assertEqual(r, "verified")
        self.assertGreater(t, 20)

    def test_budget_unchanged(self):
        s = merged_settings({})
        self.assertGreaterEqual(float(s.get("ack_pending_max_sec", 60)), float(s["ack_wait_sec"]))


class _null:
    def __enter__(self): return self
    def __exit__(self, *a): return False


if __name__ == "__main__":
    unittest.main()


# ---------- 3.0.8: второй вид кнопки вида iVMS («cam  Editing...») и «Cancel» на окно-вопрос ----------
import os  # noqa: E402
import tempfile  # noqa: E402

from app import recorder  # noqa: E402
from app.steps import Context, StepRunner  # noqa: E402


class ViewBackend:
    def __init__(self, found=(), dialog="none"):
        self.found = dict(found)      # имя файла -> (x, y)
        self.clicks, self.located, self.dialog_calls = [], [], []
        self.dialog = dialog

    def window_rect(self, hwnd):
        return (0, 0, 1920, 1040)

    def locate(self, path, rect, conf):
        self.located.append(os.path.basename(path))
        return self.found.get(os.path.basename(path))

    def click(self, x, y, double=False):
        self.clicks.append((x, y, double))

    def process_windows(self, hwnd):
        return {hwnd}

    def cancel_new_dialog(self, hwnd, before, wait):
        self.dialog_calls.append((hwnd, set(before), wait))
        return self.dialog


class ViewStep308(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        for n in ("step05.png", "step05_alt.png"):
            open(os.path.join(self.dir, n), "wb").close()
        self.step = {"type": "click_image", "template": "step05.png", "alt_templates": ["step05_alt.png"],
                     "view_step": True, "double": True,
                     "fallback": {"type": "click_xy", "x": 100, "y": 100, "units": "pixels", "double": True}}

    def run_step(self, be, step=None):
        r = StepRunner(be, lambda p: os.path.join(self.dir, p), sleep=lambda s: None)
        ctx = Context({"name": "iVMS-4200"})
        ctx.hwnd = 7
        r.run_step(step or self.step, ctx)
        return ctx

    def test_main_template(self):
        be = ViewBackend({"step05.png": (50, 60)})
        ctx = self.run_step(be)
        self.assertEqual(be.clicks, [(50, 60, True)])
        self.assertGreaterEqual(len(be.dialog_calls), 1)
        self.assertEqual(ctx.warnings, [])

    def test_alt_template_editing(self):
        be = ViewBackend({"step05_alt.png": (40, 90)}, dialog="cancelled")
        ctx = self.run_step(be)
        self.assertEqual(be.located, ["step05.png", "step05_alt.png"])
        self.assertEqual(be.clicks, [(40, 90, True)])
        self.assertEqual(ctx.warnings, [])

    def test_not_found_no_blind_click(self):
        be = ViewBackend()
        ctx = self.run_step(be)
        self.assertEqual(be.clicks, [])          # запасные координаты НЕ нажимаются
        self.assertEqual(len(ctx.warnings), 1)
        self.assertIn("вид камер не найден", ctx.warnings[0])

    def test_dialog_without_cancel_warns(self):
        be = ViewBackend({"step05.png": (1, 1)}, dialog="no_cancel")
        ctx = self.run_step(be)
        self.assertIn("Cancel", ctx.warnings[0])

    def test_plain_step_keeps_fallback(self):
        step = {k: v for k, v in self.step.items() if k not in ("alt_templates", "view_step")}
        be = ViewBackend()
        ctx = self.run_step(be, step)
        self.assertEqual(be.clicks, [(100, 100, True)])
        self.assertEqual(be.dialog_calls, [])
        self.assertEqual(ctx.warnings, [])

    def test_recorder_helpers(self):
        steps = [{"type": "click_image", "template": "a.png", "double": True}, {"type": "wait"},
                 {"type": "click_image", "template": "b.png", "double": True},
                 {"type": "click_image", "template": "c.png"}]
        self.assertEqual(recorder.guess_view_step(steps), 2)
        self.assertEqual(recorder.alt_path("rec/step05.png"), "rec/step05_alt.png")
        crop = os.path.join(self.dir, "crop.png")
        open(crop, "wb").write(b"x")
        st = dict(steps[2])
        dst = recorder.attach_alt(st, crop, os.path.join(self.dir, "b.png"), lambda p: os.path.basename(p))
        self.assertTrue(os.path.isfile(dst))
        self.assertEqual(st["alt_templates"], ["b_alt.png"])
        self.assertTrue(st["view_step"])
        self.assertIn("Editing", recorder.describe(st))

    def test_one_click_recorder_stops(self):
        class Hook:
            def start(self):
                return True

            def stop(self):
                pass

        class Be:
            def window_rect(self, h):
                return (0, 0, 500, 500)

            def record_hook_factory(self, m, k):
                return Hook()

            def grab(self, rect):
                from PIL import Image
                return Image.new("RGB", (rect[2], rect[3]))

        stopped = []
        rec = recorder.Recorder(Be(), 1, os.path.join(self.dir, "alt"), on_stop=lambda: stopped.append(1),
                                max_clicks=1)
        rec.start()
        rec.on_mouse(recorder.WM_LBUTTONDOWN, 0, 100, 100)
        self.assertEqual(rec.reason, "one_click")
        rec.on_mouse(recorder.WM_LBUTTONDOWN, 0, 120, 100)
        self.assertEqual(rec.count, 1)

    def test_job_step_warnings(self):
        from app.job import JobRunner, caption_with_notes
        j = JobRunner.__new__(JobRunner)
        j.warnings, got = {}, []
        j.on_warning = lambda n, t: got.append(t)
        ctx = Context({"name": "iVMS-4200"})
        ctx.warnings.append("вид камер не найден на экране (картинки a.png) — вслепую не щёлкаю")

        class R:
            contexts = {"iVMS-4200": ctx}
        j._step_warnings(R(), "iVMS-4200")
        self.assertEqual(len(got), 1)
        self.assertIn("⚠ iVMS-4200: вид камер не найден на экране", caption_with_notes("", j.warnings))
