# Original-Author: Владислав С.
# Created: 2026-10-30
"""3.0.1: остановка записи без Ctrl+Alt (удалённый рабочий стол), панель, простой, блокировка ввода."""
import os
import tempfile
import time
import unittest

from PIL import Image

from app import recorder
from app.inputlock import InputBlocker


class BE:
    def window_rect(self, hwnd):
        return (100, 50, 800, 600)

    def grab(self, rect):
        im = Image.new("RGB", (int(rect[2]), int(rect[3])), "gray")
        im.paste((255, 255, 255), (0, 0, int(rect[2]) // 2, int(rect[3])))   # 3.0.9: с деталями
        return im

    def record_hook_factory(self, m, k):
        class H:
            def start(self):
                return True

            def stop(self):
                pass
        return H()


def make(**kw):
    t = [0.0]
    stops = []
    r = recorder.Recorder(BE(), 1, tempfile.mkdtemp(), on_stop=lambda: stops.append(1), clock=lambda: t[0], **kw)
    r.start()
    return r, t, stops


class V301(unittest.TestCase):
    def tearDown(self):
        recorder.ACTIVE.clear()

    def test_injected_recorded_and_f9_stops(self):
        r, t, stops = make()
        self.assertTrue(recorder.ACTIVE.is_set())
        r.on_mouse(0x0201, 0x01, 150, 200)                      # удалённый щелчок (INJECTED)
        r.on_key(0x0100, 0x1B, 0x10)                            # удалённая клавиша (INJECTED)
        self.assertTrue(r.on_key(0x0100, 0x78, 0x10))          # F9 через удалённый стол — стоп
        time.sleep(0.2)
        self.assertEqual(stops, [1])
        self.assertFalse(recorder.ACTIVE.is_set())
        self.assertEqual([s["type"] for s in r.steps()], ["click_image", "press"])
        self.assertEqual(r.reason, "hotkey")

    def test_pause_key_configurable(self):
        r, _, stops = make(alt_stop="pause")
        self.assertFalse(r.on_key(0x0100, 0x78, 0))            # F9 теперь обычная клавиша
        self.assertTrue(r.on_key(0x0100, 0x13, 0))
        time.sleep(0.1)
        self.assertEqual(stops, [1])
        self.assertEqual(recorder.stop_key_text("pause"), "Pause")

    def test_panel_clicks_excluded(self):
        r, _, _ = make(exclude=lambda: [(400, 50, 200, 40)])
        r.on_mouse(0x0201, 0, 450, 60)          # по панели — не пишется и не «вне окна»
        r.on_mouse(0x0201, 0, 300, 300)
        r.finish("button")
        self.assertEqual(r.count, 1)
        self.assertEqual(r.ignored, 0)

    def test_idle_autostop_and_button_once(self):
        r, t, stops = make()
        t[0] = 60
        self.assertFalse(r.tick())
        r.on_key(0x0100, 0x1B, 0)
        t[0] = 179
        self.assertFalse(r.tick())
        t[0] = 181
        self.assertTrue(r.tick())
        r.finish("button")                      # повторно — ничего
        time.sleep(0.1)
        self.assertEqual(stops, [1])
        self.assertEqual(r.reason, "idle")

    def test_cancel_no_callback(self):
        r, _, stops = make()
        r.cancel()
        time.sleep(0.1)
        self.assertEqual(stops, [])
        self.assertFalse(recorder.ACTIVE.is_set())
        self.assertTrue(r.cancelled)

    def test_input_lock_not_during_recording(self):
        made = []

        def factory(m, k):
            made.append(1)
            return BE().record_hook_factory(m, k)
        r, _, _ = make()
        b = InputBlocker(factory)
        self.assertFalse(b.start())
        self.assertEqual(made, [])
        r.stop()
        self.assertTrue(b.start())
        b.release()

    def test_wait_not_recording(self):
        self.assertTrue(recorder.wait_not_recording())
        recorder.ACTIVE.set()
        sl = []
        self.assertFalse(recorder.wait_not_recording(timeout=3, sleep=sl.append))
        self.assertEqual(len(sl), 3)

    def test_howto_mentions_stop(self):
        for w in ("«Стоп»", "F9", "удалённый", "2 минуты"):
            self.assertIn(w, recorder.HOWTO)

    def test_panel_widget(self):
        from PySide6.QtWidgets import QApplication
        QApplication.instance() or QApplication([])
        from app.ui.recorder_ui import RecordingPanel, RecorderDialog
        hit = []
        p = RecordingPanel(lambda: hit.append("stop"), lambda: hit.append("cancel"))
        p.set_state(3, 75)
        self.assertIn("3 шагов · 1:15", p.text.text())
        p.place()
        self.assertEqual(len(p.rects), 1)
        d = RecorderDialog(None, None, {"name": "x", "kind": "ivms", "steps": []})
        self.assertEqual(d.stop_key.currentData(), "f9")
        d.reject()


if __name__ == "__main__":
    unittest.main()
