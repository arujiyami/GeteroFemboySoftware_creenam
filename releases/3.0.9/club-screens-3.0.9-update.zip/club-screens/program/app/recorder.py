# Original-Author: Владислав С.
# Created: 2026-10-30
"""3.0.1: остановка — кнопка «Стоп» на панели записи, меню трея, F9 (настраивается), Ctrl+Alt+S или 2 мин простоя.
2.2.5: «Записать сценарий съёмки» — щелчки, двойные щелчки и клавиши администратора в окне программы
(координаты относительно окна + маленькая картинка вокруг каждого щелчка для надёжности) → обычные шаги.
Запись останавливается сочетанием клавиш (по умолчанию Ctrl+Alt+S). Записи хранятся только в config.yaml и
в папке recordings на этом компьютере, в архивы программы не попадают."""
import logging
import os
import threading
import time

log = logging.getLogger("club")

WM_LBUTTONDOWN, WM_RBUTTONDOWN = 0x0201, 0x0204
WM_KEYDOWN, WM_SYSKEYDOWN, WM_KEYUP, WM_SYSKEYUP = 0x0100, 0x0104, 0x0101, 0x0105
INJECTED_MOUSE, INJECTED_KEY = 0x01, 0x10
VK_CTRL = {0x11, 0xA2, 0xA3}
VK_ALT = {0x12, 0xA4, 0xA5}
VK_SHIFT = {0x10, 0xA0, 0xA1}
STOP_VK = ord("S")
STOP_TEXT = "Ctrl+Alt+S"
# 3.0.1: по удалённому рабочему столу Ctrl+Alt+… часто не доходит — запасная клавиша без Alt (настраивается)
DEFAULT_ALT_STOP = "f9"
ALT_STOP_CHOICES = ("f9", "f8", "f10", "f12", "pause", "scrolllock")
EXTRA_VK = {"pause": 0x13, "scrolllock": 0x91}
IDLE_STOP_SEC = 120
ACTIVE = threading.Event()       # идёт запись: блокировка ввода не включается, плановая съёмка ждёт
DOUBLE_SEC = 0.5
MIN_WAIT, MAX_WAIT = 0.3, 5.0
CROP = (200, 60)         # 3.0.9: было 80×36 — на тёмном списке iVMS выходило почти пустое пятно (395 Б)
MIN_CROP_STD = 6.0       # картинка без деталей (сплошной фон) — не шаблон, щелчок по координатам

NAMES = {0x1B: "esc", 0x0D: "enter", 0x09: "tab", 0x20: "space", 0x08: "backspace", 0x2E: "delete",
         0x2D: "insert", 0x24: "home", 0x23: "end", 0x21: "pageup", 0x22: "pagedown", 0x25: "left",
         0x26: "up", 0x27: "right", 0x28: "down"}
NAMES.update({0x6F + i: f"f{i}" for i in range(1, 25)})
NAMES_REV_DEFAULT = 0x78   # F9


def stop_vk(name):
    name = str(name or DEFAULT_ALT_STOP).strip().lower()
    if name in EXTRA_VK:
        return EXTRA_VK[name]
    for vk, n in NAMES.items():
        if n == name:
            return vk
    return NAMES_REV_DEFAULT


def stop_key_text(name):
    name = str(name or DEFAULT_ALT_STOP).strip().lower()
    return {"pause": "Pause", "scrolllock": "Scroll Lock"}.get(name, name.upper())


def wait_not_recording(timeout=300, sleep=time.sleep):
    """Плановая съёмка: подождать конца записи сценария (не дольше timeout). True — записи нет."""
    if not ACTIVE.is_set():
        return True
    log.warning("Идёт запись сценария съёмки — снимок подождёт её окончания")
    waited = 0.0
    while ACTIVE.is_set() and waited < timeout:
        sleep(1.0)
        waited += 1.0
    return not ACTIVE.is_set()


def key_name(vk):
    if vk in NAMES:
        return NAMES[vk]
    if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:
        return chr(vk).lower()
    return None


def events_to_steps(events, crops=None, double_sec=DOUBLE_SEC):
    """events — [{'kind': 'click', 't', 'x', 'y'} (x, y — от левого верхнего угла окна) |
    {'kind': 'key', 't', 'keys': [...]}]; crops — {номер события: путь к картинке}. → список шагов."""
    crops = crops or {}
    merged = []
    for i, e in enumerate(events):
        prev = merged[-1] if merged else None
        if (e["kind"] == "click" and prev and prev["kind"] == "click" and not prev.get("double")
                and e["t"] - prev["t_end"] <= double_sec and abs(e["x"] - prev["x"]) <= 6
                and abs(e["y"] - prev["y"]) <= 6):
            prev["double"] = True
            prev["t_end"] = e["t"]
            continue
        merged.append(dict(e, idx=i, t_end=e["t"]))
    steps = []
    last = None
    for e in merged:
        if last is not None:
            gap = round(min(MAX_WAIT, e["t"] - last), 1)
            if gap >= MIN_WAIT:
                steps.append({"type": "wait", "seconds": gap})
        last = e["t_end"]
        if e["kind"] == "key":
            keys = list(e["keys"])
            steps.append({"type": "press", "key": keys[0]} if len(keys) == 1 else {"type": "hotkey", "keys": keys})
            continue
        xy = {"type": "click_xy", "x": int(e["x"]), "y": int(e["y"]), "units": "pixels"}
        if e.get("double"):
            xy["double"] = True
        crop = crops.get(e["idx"])
        if crop:
            st = {"type": "click_image", "template": crop, "region": "window", "confidence": 0.8,
                  "offset": [0, 0], "fallback": xy}
            if e.get("double"):
                st["double"] = True
            steps.append(st)
        else:
            steps.append(xy)
    return steps


def scenario(recorded, old_steps=None):
    """Полный сценарий: окно вперёд и развернуть, записанные шаги, пауза, снимок (как был раньше)."""
    shot = None
    for st in old_steps or []:
        if isinstance(st, dict) and st.get("type") == "screenshot":
            shot = dict(st)
    shot = shot or {"type": "screenshot", "mode": "window"}
    return ([{"type": "activate_window"}, {"type": "maximize"}, {"type": "wait", "seconds": 1}]
            + list(recorded) + [{"type": "wait", "seconds": 2}, shot])


def describe(step):
    """Строка для списка шагов в окне записи."""
    t = step.get("type")
    if t == "wait":
        return f"Пауза {step.get('seconds', 1)} с"
    if t == "press":
        return f"Клавиша {str(step.get('key', '')).upper()}"
    if t == "hotkey":
        return "Клавиши " + "+".join(str(k).capitalize() for k in step.get("keys", []))
    if t in ("click_xy", "click_image"):
        xy = step if t == "click_xy" else (step.get("fallback") or {})
        what = "Двойной щелчок" if step.get("double") or xy.get("double") else "Щелчок"
        extra = " + картинка" if t == "click_image" else ""
        if t == "click_image" and step.get("alt_templates"):
            extra = " + 2 картинки (обычный вид и «Editing»)"
        return f"{what} в точке {xy.get('x')}, {xy.get('y')} от угла окна{extra}"
    if t == "screenshot":
        return "Снимок"
    if t == "activate_window":
        return "Окно вперёд"
    if t == "maximize":
        return "Развернуть окно"
    if t == "select_view":
        return "Выбрать вид по названию"
    return str(t)


def safe_name(name):
    return "".join(c if c.isalnum() else "_" for c in str(name))[:40] or "source"


class Recorder:
    """Запись в окне hwnd. on_stop() вызывается (из потока перехватчика) после сочетания клавиш остановки."""

    def __init__(self, backend, hwnd, folder, on_stop=None, clock=time.monotonic, alt_stop=DEFAULT_ALT_STOP,
                 exclude=None, idle_sec=IDLE_STOP_SEC, max_clicks=0):
        self.max_clicks = max_clicks    # 3.0.8: 1 — запомнить один щелчок (второй вид кнопки) и остановиться
        self.alt_vk = stop_vk(alt_stop)
        self.exclude = exclude          # → [(left, top, w, h)] — панель записи: щелчки по ней не пишутся
        self.idle_sec = idle_sec
        self.reason = ""
        self.cancelled = False
        self.started = None
        self.last = None
        self.backend = backend
        self.hwnd = hwnd
        self.folder = folder
        self.on_stop = on_stop
        self.clock = clock
        self.events = []
        self.crops = {}
        self.ignored = 0
        self.mods = set()
        self.hook = None
        self.rect = None
        self._lock = threading.Lock()
        self._stopped = False

    def start(self):
        self.rect = self.backend.window_rect(self.hwnd)
        os.makedirs(self.folder, exist_ok=True)
        for f in os.listdir(self.folder):
            if f.startswith("step") and f.endswith(".png"):
                try:
                    os.remove(os.path.join(self.folder, f))
                except OSError:
                    pass
        self.started = self.last = self.clock()
        self.hook = self.backend.record_hook_factory(self.on_mouse, self.on_key)
        ok = self.hook.start()
        if ok:
            ACTIVE.set()
        log.info("Запись сценария: %s", "началась" if ok else "не удалось поставить перехватчик")
        return ok

    def stop(self):
        self._stopped = True
        ACTIVE.clear()
        hook, self.hook = self.hook, None
        if hook:
            try:
                hook.stop()
            except Exception:  # noqa: BLE001
                log.debug("recorder hook stop", exc_info=True)

    def finish(self, reason="stop"):
        """Остановить запись (кнопка «Стоп», меню трея, клавиши, простой). on_stop — один раз, в отдельном потоке."""
        if self._stopped:
            return
        self.reason = reason
        self._stopped = True
        ACTIVE.clear()
        log.info("Запись сценария остановлена: %s", reason)
        if self.on_stop:
            threading.Thread(target=self.on_stop, daemon=True).start()

    def cancel(self):
        self.cancelled = True
        self.reason = "cancel"
        self.stop()

    @property
    def count(self):
        return sum(1 for e in self.events if e["kind"] in ("click", "key"))

    def elapsed(self):
        return 0.0 if self.started is None else self.clock() - self.started

    def tick(self):
        """Раз в секунду из окна: автоостановка после простоя. True — запись остановлена сейчас."""
        if self._stopped or self.last is None:
            return False
        if self.clock() - self.last >= self.idle_sec:
            self.finish("idle")
            return True
        return False

    def _excluded(self, x, y):
        try:
            for (l, t, w, h) in (self.exclude() if self.exclude else []):
                if l <= x < l + w and t <= y < t + h:
                    return True
        except Exception:  # noqa: BLE001
            pass
        return False

    # события приходят из потока перехватчика: только записать, тяжёлое — в отдельном потоке
    def on_mouse(self, msg, flags, x=0, y=0):
        # 3.0.1: события с флагом INJECTED (удалённый рабочий стол: Stardesk и т.п.) тоже пишутся —
        # сама программа во время записи ничего не нажимает
        if self._stopped or msg != WM_LBUTTONDOWN:
            return False
        if self._excluded(x, y):
            return False
        self.last = self.clock()
        left, top, w, h = self.rect
        if not (left <= x < left + w and top <= y < top + h):
            self.ignored += 1
            return False
        with self._lock:
            idx = len(self.events)
            self.events.append({"kind": "click", "t": self.clock(), "x": x - left, "y": y - top})
        # 3.0.9: картинка снимается СРАЗУ, в перехватчике — до того, как программа отреагирует на щелчок
        # (раньше — в потоке, и часто снимался уже изменившийся экран: меню закрылось, окно-вопрос и т.п.)
        self._crop(idx, x, y)
        if self.max_clicks and sum(1 for e in self.events if e["kind"] == "click") >= self.max_clicks:
            self.finish("one_click")
        return False

    def on_key(self, msg, vk, flags):
        if self._stopped:
            return False
        down = msg in (WM_KEYDOWN, WM_SYSKEYDOWN)
        for group, name in ((VK_CTRL, "ctrl"), (VK_ALT, "alt"), (VK_SHIFT, "shift")):
            if vk in group:
                (self.mods.add if down else self.mods.discard)(name)
                return False
        if not down:
            return False
        if vk == self.alt_vk or (vk == STOP_VK and {"ctrl", "alt"} <= self.mods):
            self.finish("hotkey")
            return True
        self.last = self.clock()
        name = key_name(vk)
        if not name:
            return False
        keys = [m for m in ("ctrl", "alt", "shift") if m in self.mods] + [name]
        with self._lock:
            self.events.append({"kind": "key", "t": self.clock(), "keys": keys})
        return False

    def _crop(self, idx, x, y):
        try:
            w, h = CROP
            img = self.backend.grab((int(x - w // 2), int(y - h // 2), w, h))
            if not crop_has_detail(img):
                log.info("Запись: картинка у щелчка %d без деталей — шаг будет по координатам", idx + 1)
                return
            path = os.path.join(self.folder, f"step{idx + 1:02d}.png")
            img.save(path)
            self.crops[idx] = path
        except Exception:  # noqa: BLE001
            log.debug("recorder crop", exc_info=True)

    def steps(self, rel=None):
        """Шаги из записанного. rel(путь) — как записать путь картинки в config (относительно программы)."""
        # 3.0.6: дождаться ВСЕХ картинок шагов (раньше — 0.2 с, и медленный снимок экрана мог не успеть:
        # сценарий сохранялся без step*.png). Берём только реально записанные файлы.
        end = time.monotonic() + 3
        for th in list(self.__dict__.get("_crop_threads", [])):
            th.join(max(0.0, end - time.monotonic()))
        crops = {i: (rel(p) if rel else p) for i, p in self.crops.items() if os.path.isfile(p)}
        return events_to_steps(list(self.events), crops)


def crop_has_detail(img):
    """Есть ли на картинке что узнавать (не сплошной фон)."""
    try:
        from PIL import ImageStat
        return max(ImageStat.Stat(img.convert("L")).stddev) >= MIN_CROP_STD
    except Exception:  # noqa: BLE001
        return True


# ---------- 3.0.8: второй вид кнопки (строка вида iVMS «cam  Editing...») ----------
ALT_HOWTO = ("Второй вид кнопки (необязательно, 1 минута). Если камеры в iVMS случайно переставили, строка "
             "вида меняется: «cam» → «cam  Editing...», и программа её не узнаёт. Запишите, как она выглядит "
             "в этом состоянии:\n"
             "1. В iVMS перетащите любую камеру на другое место — у вида появится «Editing...».\n"
             "2. Выберите в списке шаг-щелчок по виду и нажмите «Второй вид (Editing)».\n"
             "3. Окно iVMS выйдет вперёд — ОДИН раз щёлкните по строке вида (по названию). Запись остановится сама.\n"
             "4. Нажмите «Сохранить». Потом дважды щёлкните по виду в iVMS и нажмите Cancel — камеры вернутся.\n"
             "С двумя картинками программа найдёт вид в обоих состояниях, вслепую по координатам по нему не щёлкает, "
             "а на вопрос iVMS о несохранённых изменениях сама нажимает «Cancel».")


def guess_view_step(steps):
    """Номер шага, для которого скорее всего нужен второй вид: последний двойной щелчок по картинке
    (выбор вида), иначе последний щелчок по картинке. None — таких нет."""
    idx = [i for i, st in enumerate(steps or []) if isinstance(st, dict) and st.get("type") == "click_image"]
    dbl = [i for i in idx if steps[i].get("double")]
    return (dbl or idx or [None])[-1]


def alt_path(template):
    """step05.png → step05_alt.png (рядом с основной картинкой)."""
    root, ext = os.path.splitext(str(template))
    return f"{root}_alt{ext or '.png'}"


def attach_alt(step, crop_abs, template_abs, rel):
    """Положить картинку второго вида рядом с основной и отметить шаг как «вид» (2 картинки,
    без щелчка вслепую, «Cancel» на окно-вопрос). rel(путь) → как записать в config."""
    import shutil
    dst = alt_path(template_abs)
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
    shutil.copyfile(crop_abs, dst)
    step["alt_templates"] = [rel(dst)]
    step["view_step"] = True
    return dst


# ---------- 3.0.9: кнопка Cancel окна-вопроса iVMS ----------
CANCEL_HOWTO = ("Кнопка Cancel (iVMS, 1 минута). Если камеры переставили, при выборе вида iVMS спрашивает, "
                "сохранить ли изменения. Программа должна нажать Cancel — запишите, как выглядит эта кнопка:\n"
                "1. В iVMS перетащите камеру на другое место, затем дважды щёлкните по виду — появится вопрос.\n"
                "2. Нажмите «Записать кнопку Cancel» и ОДИН раз щёлкните по Cancel в этом окне.\n"
                "Камеры вернутся на место, а программа будет нажимать Cancel сама.")


def cancel_rel(name):
    return f"templates/{safe_name(name)}_cancel.png"


def attach_cancel(src, crop_abs, resolve):
    """Положить картинку кнопки Cancel в templates/ (не удаляется при перезаписи сценария)."""
    import shutil
    rel = cancel_rel(src.get("name", ""))
    dst = resolve(rel)
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
    shutil.copyfile(crop_abs, dst)
    src["cancel_template"] = rel
    return rel


def cancel_state_text(src, resolve):
    t = src.get("cancel_template")
    return "Cancel: записана" if t and os.path.isfile(resolve(t)) else "Cancel: не записана"


# ---------- 3.0.0: состояние, сброс, папки записей ----------
HOWTO = ("Как записать сценарий для камер (1–2 минуты):\n"
         "1. Откройте программу камер (например iVMS-4200) и оставьте её окно на экране.\n"
         "2. Нажмите «Начать запись» — окно программы камер выйдет вперёд.\n"
         "3. Щёлкайте так, как сделали бы сами, чтобы получить нужную раскладку камер "
         "(например вкладка Main View → двойной щелчок по своему виду).\n"
         "4. Если нужно — нажмите кнопку полного экрана. Снимок делать не надо, программа сделает его сама.\n"
         "5. Нажмите «Стоп» на маленькой панели «Идёт запись» (она поверх всех окон и в запись не попадает) "
         f"или клавишу F9 / {STOP_TEXT} — запись остановится, и сразу пройдёт пробный запуск с картинкой. "
         "Работает и через удалённый рабочий стол. Без действий 2 минуты запись остановится сама.\n"
         "6. Если на картинке всё правильно — нажмите «Сохранить». Если нет — «Начать запись» ещё раз.")


def recordings_root(name):
    return os.path.join("recordings", safe_name(name))


def new_session_folder(name, now=None):
    return os.path.join(recordings_root(name), time.strftime("%Y%m%d_%H%M%S", time.localtime(now)))


def remove_tree(path):
    import shutil
    if path and os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)


def keep_only(root_abs, keep_abs):
    """Удалить старые записи этой программы, кроме keep."""
    if not os.path.isdir(root_abs):
        return
    for f in os.listdir(root_abs):
        p = os.path.join(root_abs, f)
        if os.path.abspath(p) != os.path.abspath(keep_abs or ""):
            if os.path.isdir(p):
                remove_tree(p)
            else:
                try:
                    os.remove(p)
                except OSError:
                    pass


def builtin_steps(src):
    """Встроенные шаги программы (как в новой установке)."""
    from .config import DEFAULTS
    import copy
    for d in DEFAULTS.get("sources") or []:
        if d.get("kind") == src.get("kind") and src.get("kind") not in (None, "", "custom"):
            return copy.deepcopy(d.get("steps") or [])
    return copy.deepcopy(src.get("default_steps") or src.get("steps") or [])


def state_text(src):
    if not src.get("recorded"):
        return "Стандартный"
    n = len(src.get("steps") or [])
    when = src.get("recorded_at") or ""
    return f"Записанный, {n} шагов" + (f", {when}" if when else "")


def mark_saved(src, steps, now=None):
    import copy
    if not src.get("recorded"):
        src["default_steps"] = copy.deepcopy(src.get("steps") or [])
    src["steps"] = copy.deepcopy(steps)
    src["recorded"] = True
    src["recorded_at"] = time.strftime("%d.%m.%Y %H:%M", time.localtime(now))


def reset(src, resolve):
    """Удалить запись и вернуть встроенный способ съёмки."""
    import copy
    if src.get("kind") in (None, "", "custom"):
        steps = copy.deepcopy(src.get("default_steps") or src.get("steps") or [])
    else:
        steps = builtin_steps(src)
    src["steps"] = steps
    for k in ("recorded", "default_steps", "recorded_at"):
        src.pop(k, None)
    if src.get("kind") == "ivms":
        src.setdefault("view_preset", "cam")
    remove_tree(resolve(recordings_root(src.get("name", ""))))
