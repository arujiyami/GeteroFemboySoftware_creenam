# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.8: «страница входа лагает, постоянно меняя размер» — подгонка масштаба сходится за ограниченное число
вызовов setZoomFactor даже на «перестраивающейся» странице; ступени и гистерезис; темы оформления
(«Как в Windows» по реестру — подставным, контраст по WCAG, смена темы на лету, выбор в настройках)."""
import copy
import json
import os
import tempfile
import time
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from app.ui import theme  # noqa: E402
from app.ui.zoomfit import (HYSTERESIS, LATE_MS, MAX_FITS, SETTLE_MS, STEPS, ZOOM_MAX, ZOOM_MIN,  # noqa: E402
                            fit_zoom, quantize)

try:
    from PySide6.QtCore import Signal
    from PySide6.QtWidgets import QApplication, QWidget
    HAVE_QT = True
except Exception:  # noqa: BLE001
    HAVE_QT = False


def reflow(view_w, zoom):
    """Модель «отзывчивой» страницы входа: шире 1000 CSS px — широкая раскладка (900×500), уже — узкая
    (420×760). Раскладка зависит от масштаба — именно это раскачивало подгонку в 2.1.7."""
    return (900, 500) if view_w / zoom > 1000 else (420, 760)


class Quantize(unittest.TestCase):
    def test_steps(self):
        self.assertEqual(STEPS, (0.6, 0.67, 0.75, 0.8, 0.9, 1.0))
        self.assertEqual(quantize(0.77), 0.75)
        self.assertEqual(quantize(0.8), 0.8)
        self.assertEqual(quantize(0.5), 0.6)
        self.assertEqual(quantize(1.3), 1.0)
        for z in (0.61, 0.7, 0.85, 0.99):
            self.assertIn(fit_zoom(1.0, 1000 * z, 1000 * z, 984, 984), STEPS)

    def test_hysteresis(self):
        # нужно 0,9 при текущих 0,92 (меньше 5 %) — не трогаем; 0,8 при 0,9 — меняем
        self.assertEqual(fit_zoom(0.92, 900, 600, 984, 650), 0.92)
        self.assertLess(HYSTERESIS, 0.1)
        self.assertEqual(fit_zoom(0.9, 820, 600, 984, 650), 0.8)

    def test_shrink_only(self):
        self.assertEqual(fit_zoom(0.75, 1600, 1000, 420, 600, shrink_only=True), 0.75)
        self.assertEqual(fit_zoom(0.75, 1600, 1000, 420, 600), ZOOM_MAX)

    def test_pure_reflow_converges(self):
        """Повторные замеры одной страницы (без смены окна): не больше двух смен, потом стоит."""
        for vw, vh in ((900, 600), (860, 600), (1000, 700), (700, 500), (1366, 640), (1200, 560)):
            z, changes, seen = 1.0, 0, []
            for _ in range(30):
                w, h = reflow(vw, z)
                nz = fit_zoom(z, vw, vh, w, h, shrink_only=True)
                if nz != z:
                    changes += 1
                z = nz
                seen.append(z)
            self.assertLessEqual(changes, 2, (vw, vh, seen))
            self.assertEqual(len(set(seen[-10:])), 1, (vw, vh, seen))
            self.assertTrue(ZOOM_MIN <= z <= ZOOM_MAX)


if HAVE_QT:
    class FakePage:
        def __init__(self, view):
            self.view = view
            self.measures = 0

        def runJavaScript(self, js, world, cb):  # noqa: N802
            self.measures += 1
            w, h = self.view.content(self.view.width(), self.view.zoom)
            cb(json.dumps({"w": w, "h": h, "n": 40, "cw": self.view.width() / self.view.zoom,
                           "ch": self.view.height() / self.view.zoom}))

    class FakeView(QWidget):
        """Вместо QWebEngineView: считает вызовы setZoomFactor, страница — модель reflow()."""
        loadStarted = Signal()
        loadFinished = Signal(bool)
        urlChanged = Signal(object)

        def __init__(self, content=reflow):
            super().__init__()
            self.zoom = 1.0
            self.set_calls = []
            self.content = content
            self._page = FakePage(self)

        def zoomFactor(self):  # noqa: N802
            return self.zoom

        def setZoomFactor(self, z):  # noqa: N802
            self.set_calls.append(z)
            self.zoom = z

        def page(self):
            return self._page


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class Reflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def pump(self, ms):
        end = time.monotonic() + ms / 1000
        while time.monotonic() < end:
            self.app.processEvents()
            time.sleep(0.005)

    def make(self, w=900, h=600, **kw):
        from app.ui.zoomfit import ZoomFitter
        v = FakeView(**{k: kw.pop(k) for k in list(kw) if k == "content"})
        v.resize(w, h)
        v.show()
        self.pump(50)
        f = ZoomFitter(v, **kw)
        return v, f

    def load(self, v):
        v.loadStarted.emit()
        v.loadFinished.emit(True)
        self.pump(SETTLE_MS + LATE_MS + 300)

    def test_converges_with_bounded_calls(self):
        v, f = self.make()
        self.load(v)
        first = list(v.set_calls)
        self.assertTrue(first, "страница входа не уменьшилась")
        self.assertLessEqual(len(first), MAX_FITS)
        w, h = reflow(v.width(), v.zoom)
        self.assertLessEqual((h + 16) * v.zoom, v.height() + 1)     # влезает
        # 2.1.7 мерила раз в 1,5 с и после каждого «шевеления» — теперь это ничего не меняет
        for i in range(25):
            f.schedule(0, "load")
            self.pump(10)
            v.resize(900 + (i % 3), 600 - (i % 2))                  # дрожание на пару пикселей
            self.pump(5)
        self.pump(400)
        self.assertEqual(v.set_calls, first, "масштаб менялся без причины")
        self.assertLessEqual(v._page.measures, 1 + 2 + 25)

    def test_dom_growth_bounded(self):
        """Страница всё время растёт (анимация, подгрузка) — смен масштаба не больше MAX_FITS на загрузку."""
        grow = {"h": 500}

        def content(w, z):
            grow["h"] += 120
            return 420, grow["h"]
        v, f = self.make(content=content)
        self.load(v)
        for _ in range(20):
            f.schedule(0, "load")
            self.pump(20)
        self.assertLessEqual(len(v.set_calls), MAX_FITS)
        # уменьшает, но не качает туда-обратно
        self.assertEqual(v.set_calls, sorted(v.set_calls, reverse=True))

    def test_real_resize_refits_both_ways(self):
        v, f = self.make(860, 600)
        self.load(v)
        small = v.zoom
        self.assertLess(small, 1.0)
        v.resize(1600, 1000)
        self.pump(700)
        self.assertEqual(v.zoom, 1.0)
        v.resize(800, 520)
        self.pump(700)
        self.assertLess(v.zoom, 1.0)
        self.assertLessEqual(len(v.set_calls), 2 + MAX_FITS)

    def test_inactive_and_hold_and_manual(self):
        state = {"active": True, "hold": False}
        v, f = self.make(860, 600, active=lambda: state["active"], hold=lambda: state["hold"])
        self.load(v)
        self.assertLess(v.zoom, 1.0)
        state["hold"] = True               # сценарий по странице — ровно 100 %
        f.schedule(0, "refit")
        self.pump(50)
        self.assertEqual(v.zoom, 1.0)
        state["hold"] = False
        f.set_manual(1.25)                 # кнопки «+» — ровно так, подгонка выключена
        self.assertEqual(v.zoom, 1.25)
        self.load(v)
        v.resize(700, 500)
        self.pump(500)
        self.assertEqual(v.zoom, 1.25)
        f.set_manual(0)                    # «По размеру окна»
        self.pump(200)
        self.assertLess(v.zoom, 1.0)
        state["active"] = False            # вошли в ВК — обычный масштаб
        f.schedule(0, "refit")
        self.pump(50)
        self.assertEqual(v.zoom, 1.0)


class Themes(unittest.TestCase):
    def test_windows_registry(self):
        self.assertTrue(theme.windows_prefers_dark(lambda: 0))
        self.assertFalse(theme.windows_prefers_dark(lambda: 1))

        def missing():
            raise OSError("нет ключа")
        self.assertFalse(theme.windows_prefers_dark(missing))
        self.assertEqual(theme.resolve("system", lambda: 0), "dark")
        self.assertEqual(theme.resolve("system", lambda: 1), "light")
        self.assertEqual(theme.resolve("всякое", lambda: 0), "dark")
        self.assertEqual(theme.resolve("light", lambda: 0), "light")
        self.assertEqual(theme.resolve("contrast"), "contrast")
        self.assertEqual([k for k, _ in theme.THEMES], ["system", "light", "dark", "contrast"])

    def test_wcag_contrast(self):
        for name in ("light", "dark", "contrast"):
            for accent, _ in theme.ACCENTS:
                p = theme.palette(name, accent)
                for fg, bg in (("text", "bg"), ("text", "card"), ("text2", "card"),
                               ("title", "bg"), ("link", "card"), ("on_accent", "accent"),
                               ("side_text", "side"), ("side_sel_text", "side_sel"),
                               ("ok", "ok_bg"), ("warn", "warn_bg"), ("bad", "bad_bg"),
                               ("tip_text", "tip_bg")):
                    self.assertGreaterEqual(theme.contrast(p[fg], p[bg]), 4.5, (name, accent, fg, bg))
                # text3 — только недоступное и подсказка в пустом поле (по WCAG без требований) — но различимо
                for fg, bg in (("border_strong", "card"), ("focus", "card"), ("text3", "card")):
                    self.assertGreaterEqual(theme.contrast(p[fg], p[bg]), 3.0, (name, accent, fg, bg))

    @unittest.skipUnless(HAVE_QT, "нет PySide6")
    def test_live_apply(self):
        app = QApplication.instance() or QApplication([])
        calls = []
        theme.on_change(lambda: calls.append(theme.P["name"]))
        try:
            theme.apply(app, "dark", "teal")
            dark_qss = app.styleSheet()
            self.assertEqual(theme.P["name"], "dark")
            self.assertIn(theme.P["bg"], dark_qss)
            theme.apply(app, "light", "blue")
            self.assertNotEqual(app.styleSheet(), dark_qss)
            self.assertEqual(theme.P["name"], "light")
            self.assertEqual(calls[-2:], ["dark", "light"])
            self.assertEqual(theme.apply_from_config({"app": {"theme": "contrast"}}, app), "contrast")
        finally:
            theme._listeners.pop()
            theme.apply(app, "light", "blue")


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class SettingsLook(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_theme_choice_saved_and_applied(self):
        from app.config import DEFAULTS, load_config
        from app.ui.settings import SettingsPage
        from tests.test_live_settings import StubMain
        d = tempfile.mkdtemp()
        path = os.path.join(d, "config.yaml")
        cfg = copy.deepcopy(DEFAULTS)
        self.assertEqual((cfg["app"]["theme"], cfg["app"]["accent"]), ("system", "blue"))
        main = StubMain(cfg, path)
        page = SettingsPage(main)
        page.load()
        try:
            # «Внешний вид» — первый раздел
            from PySide6.QtWidgets import QLabel
            titles = [lb.text() for lb in page.findChildren(QLabel) if lb.objectName() == "sectionTitle"]
            self.assertEqual(titles[0], "Внешний вид")
            self.assertTrue(page.theme_buttons["system"].isChecked())
            page.theme_buttons["dark"].click()
            self.assertEqual(theme.P["name"], "dark")           # сразу, без «Сохранить»
            page.accent.setCurrentIndex(page.accent.findData("orange"))
            self.assertEqual(theme.STATE["accent"], "orange")
            end = time.monotonic() + 2.5
            while time.monotonic() < end and not os.path.exists(path):
                self.app.processEvents()
                time.sleep(0.01)
            saved = load_config(path)
            self.assertEqual((saved["app"]["theme"], saved["app"]["accent"]), ("dark", "orange"))
            page.theme_buttons["contrast"].click()
            self.assertFalse(page.accent.isEnabled())
        finally:
            theme.apply(self.app, "light", "blue")
            page.deleteLater()
