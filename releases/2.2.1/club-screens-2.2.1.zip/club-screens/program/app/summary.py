# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: журнал съёмов (logs/cycles.jsonl) и утренняя сводка «За ночь отправлено 9 из 10, в 03:00 Oasys
не загрузился». Сводка необязательна (summary.enabled, по умолчанию выключена); уходит подписью к
ближайшей обычной отправке после summary.time, а если отправки нет — одним коротким сообщением."""
import datetime as dt
import json
import os

KEEP_LINES = 600
WINDOW_HOURS = 6        # сводку после 09:00 ещё можно отправить до 15:00, позже — уже не «утренняя»


def log_path(root):
    return os.path.join(root, "logs", "cycles.jsonl")


def record(path, when, ok, sent, planned=True, queued=False, warnings=None, error=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    row = {"t": when.strftime("%Y-%m-%d %H:%M"), "ok": bool(ok), "sent": bool(sent), "planned": bool(planned),
           "queued": bool(queued), "warn": dict(warnings or {}), "err": (error or "")[:200]}
    lines = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            lines = f.read().splitlines()[-(KEEP_LINES - 1):]
    lines.append(json.dumps(row, ensure_ascii=False))
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def read(path):
    out = []
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    r = json.loads(line)
                    r["dt"] = dt.datetime.strptime(r["t"], "%Y-%m-%d %H:%M")
                    out.append(r)
                except (ValueError, KeyError):
                    pass
    return out


def _at(now, hhmm):
    try:
        h, m = (int(x) for x in str(hhmm).split(":")[:2])
    except ValueError:
        h, m = 9, 0
    return now.replace(hour=h % 24, minute=m % 60, second=0, microsecond=0)


def due(cfg, now, last_sent=""):
    """Пора добавить сводку: включена, уже после summary.time (не позже WINDOW_HOURS) и сегодня ещё не было."""
    s = cfg.get("summary") or {}
    if not s.get("enabled"):
        return False
    at = _at(now, s.get("time", "09:00"))
    return at <= now < at + dt.timedelta(hours=WINDOW_HOURS) and str(last_sent or "")[:10] != \
        now.strftime("%Y-%m-%d")


def standalone_due(cfg, now, last_sent="", grace_min=65):
    """Обычной отправки после summary.time так и не было (расписание остановлено, всё сломалось) —
    через grace_min минут сводка уходит одним коротким сообщением."""
    s = cfg.get("summary") or {}
    return due(cfg, now, last_sent) and now >= _at(now, s.get("time", "09:00")) + dt.timedelta(minutes=grace_min)


def last_sent_path(root):
    return os.path.join(root, "state", "summary_last.txt")


def get_last_sent(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def set_last_sent(path, now):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(now.strftime("%Y-%m-%d %H:%M"))


def text(rows, now, hhmm="09:00"):
    """Сводка за последние сутки до now (только плановые съёмы)."""
    start = _at(now, hhmm) - dt.timedelta(days=1)
    night = [r for r in rows if r.get("planned", True) and start <= r["dt"] < now]
    if not night:
        return "За ночь съёмов не было (программа была выключена?)"
    sent = sum(1 for r in night if r["sent"])
    parts = [f"За ночь отправлено {sent} из {len(night)}"]
    for r in night:
        tm = r["dt"].strftime("%H:%M")
        for w in (r.get("warn") or {}).values():
            parts.append(f"в {tm} {w.split(' (')[0]}")
        if r.get("queued") and not r["sent"]:
            parts.append(f"в {tm} не было интернета")
        elif not r["sent"]:
            parts.append(f"в {tm} не отправлено")
    out = parts[0] + (", " + ", ".join(dict.fromkeys(parts[1:])) if len(parts) > 1 else "")
    return out[:600]
