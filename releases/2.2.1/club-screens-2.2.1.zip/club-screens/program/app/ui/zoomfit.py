# Original-Author: Владислав С.
# Created: 2026-10-29
"""Масштаб видимой страницы ВК: страница входа (с QR-кодом) целиком в окне, без «дёрганья».

2.1.8 — исправлено «страница входа лагает, постоянно меняя размер». Причина в 2.1.7: масштаб пересчитывался
раз в 1,5 секунды и после каждого изменения размера; страница ВК при другом масштабе перестраивается (другая
ширина в CSS-пикселях → другая раскладка, полосы прокрутки появляются/исчезают), замер давал другой ответ —
и масштаб качался туда-обратно. Теперь:
  * подгонка один раз после загрузки страницы (с паузой SETTLE_MS) и только при настоящем изменении размера
    окна (пауза DEBOUNCE_MS, изменение не меньше RESIZE_MIN_PX); никакого опроса, изменения страницы
    (DOM, прокрутка) не учитываются;
  * место — по размеру виджета в пикселях окна, содержимое — по размаху элементов в CSS-пикселях
    (не зависит от масштаба и центровки страницы);
  * масштаб — только ступенями STEPS, меняется, если отличается больше чем на HYSTERESIS; после загрузки —
    только в сторону уменьшения; не больше MAX_FITS смен на одну загрузку;
  * кнопки «− / 100 % / +» и «По размеру окна» под страницей: выбранный вручную масштаб запоминается
    и подгонку отключает.
Пока по странице идёт сценарий (hold()) — всегда 100 %: сценарий щёлкает по координатам."""
import json
import logging

from PySide6.QtCore import QEvent, QObject, QTimer

log = logging.getLogger("club")

ZOOM_MIN = 0.6
ZOOM_MAX = 1.0
STEPS = (0.6, 0.67, 0.75, 0.8, 0.9, 1.0)                       # подгонка — только этими ступенями
MANUAL_STEPS = (0.5, 0.6, 0.67, 0.75, 0.8, 0.9, 1.0, 1.1, 1.25, 1.5)   # кнопки «−» / «+»
HYSTERESIS = 0.05       # разница меньше 5 % — масштаб не трогаем
MAX_FITS = 3            # не больше 3 смен масштаба на одну загрузку страницы
DEBOUNCE_MS = 300       # после изменения размера окна — подождать, пока его перестанут тянуть
RESIZE_MIN_PX = 8       # изменение размера меньше — не считается
SETTLE_MS = 600         # после загрузки — дать странице дорисоваться
LATE_MS = 2500          # и ещё одна проверка позже (форма входа ВК дорисовывается не сразу)
REFIT_MS = DEBOUNCE_MS  # (совместимость с 2.1.7)
LONG_PAGE = 3.0         # содержимое выше окна больше чем в 3 раза — это лента/переписка, а не вход: не уменьшаем

# Размер содержимого в CSS-пикселях. Берём «листья» (у элемента нет вложенных элементов) и картинки/QR/поля:
# большие пустые обёртки во всю высоту окна (height: 100vh) не мешают понять, сколько места нужно на деле.
MEASURE_JS = r"""
(function () {
  var de = document.documentElement, b = document.body;
  if (!de || !b) return null;
  var cw = de.clientWidth, ch = de.clientHeight, W = 0, H = 0, L = 1e9, T = 1e9, n = 0;
  var els = b.getElementsByTagName('*');
  var media = {IMG: 1, CANVAS: 1, SVG: 1, svg: 1, INPUT: 1, BUTTON: 1, VIDEO: 1, IFRAME: 1, TEXTAREA: 1, SELECT: 1};
  for (var i = 0; i < els.length && i < 6000; i++) {
    var e = els[i];
    if (!(media[e.tagName] || e.children.length === 0)) continue;
    var r = e.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    if (!media[e.tagName] && !(e.textContent || '').trim()) {
      if (r.width >= cw * 0.9 || r.height >= ch * 0.9) continue;      // пустой фон во всё окно
    }
    var cs = window.getComputedStyle(e);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.position === 'fixed' && r.top >= ch) continue;
    W = Math.max(W, r.right + window.scrollX);
    H = Math.max(H, r.bottom + window.scrollY);
    L = Math.min(L, r.left + window.scrollX);
    T = Math.min(T, r.top + window.scrollY);
    n++;
  }
  // строкой JSON: объект JS в Python приходит не во всех версиях Qt
  // размах содержимого (от самого левого/верхнего элемента): страница по центру при другом масштабе
  // сдвигается, но размах тот же
  if (!n) { L = 0; T = 0; }
  return JSON.stringify({cw: cw, ch: ch, w: Math.max(W - Math.max(L, 0), 1), h: Math.max(H - Math.max(T, 0), 1),
                         right: W, bottom: H, sw: de.scrollWidth, sh: de.scrollHeight, n: n});
})()
"""


def quantize(z, steps=STEPS):
    """Ближайшая ступень не больше z (чтобы содержимое точно влезло); меньше самой маленькой — она."""
    best = steps[0]
    for st in steps:
        if st <= z + 1e-9:
            best = st
    return best


def fit_zoom(current, view_w, view_h, content_w, content_h, lo=ZOOM_MIN, hi=ZOOM_MAX, margin=16,
             steps=STEPS, hysteresis=HYSTERESIS, shrink_only=False):
    """Новый масштаб. view_* — место под страницу в пикселях окна (от масштаба не зависит), content_* — размах
    содержимого в CSS-пикселях. Масштаб z помещает содержимое, если (content + margin) * z <= view.
    Ответ — ступень из steps в [lo, hi]; если она отличается от current не больше чем на hysteresis (доля),
    остаётся current. shrink_only — только уменьшать (повторный замер той же страницы).
    Длинные страницы (лента, переписка — в LONG_PAGE раз выше окна) не уменьшаем: там hi."""
    try:
        cur = float(current)
        if not cur > 0:
            cur = 1.0
    except (TypeError, ValueError):
        cur = 1.0
    try:
        vw, vh = float(view_w), float(view_h)
        need_w = float(content_w) + margin
        need_h = float(content_h) + margin
        if vw <= 0 or vh <= 0 or need_w <= 0 or need_h <= 0:
            raise ValueError
        if need_h > vh * LONG_PAGE:
            target = hi
        else:
            target = min(vw / need_w, vh / need_h)
    except (TypeError, ValueError, ZeroDivisionError):
        return max(lo, min(hi, cur))
    z = quantize(max(lo, min(hi, target)), tuple(st for st in steps if lo - 1e-9 <= st <= hi + 1e-9) or (lo,))
    if shrink_only and z > cur:
        return cur
    if abs(z - cur) <= hysteresis * cur + 1e-9:
        return cur
    return z


class ZoomFitter(QObject):
    """Масштаб view (QWebEngineView). active() — можно ли подгонять (вход не выполнен), hold() — нужен ровно
    100 % (по странице идёт сценарий). manual — масштаб, выбранный кнопками (0 — подгонять самим)."""

    def __init__(self, view, active=lambda: True, parent=None, hold=lambda: False, manual=0.0, on_zoom=None):
        super().__init__(parent or view)
        self.view = view
        self.active = active
        self.hold = hold
        self.manual = float(manual or 0.0)
        self.on_zoom = on_zoom            # fn(масштаб) — для подписи «80 %» у кнопок
        self.last = None                  # последний замер (для журнала и тестов)
        self.fits = 0                     # сколько раз сменили масштаб сами (всего)
        self.calls = 0                    # сколько раз вызывали setZoomFactor (всего)
        self.budget = MAX_FITS            # смен масштаба, оставшихся на эту загрузку
        self.fit_size = None              # размер окна страницы при последней подгонке
        self._why = "load"
        self._own = False
        self._pending = False
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.fit)
        view.installEventFilter(self)
        # вторая, поздняя проверка после загрузки: ВК дорисовывает форму входа не сразу (только уменьшение,
        # в пределах MAX_FITS — качаться нечему)
        self._late = QTimer(self)
        self._late.setSingleShot(True)
        self._late.timeout.connect(lambda: self.schedule(0, "load"))
        try:
            view.loadStarted.connect(self._load_started)
            view.loadFinished.connect(self._load_finished)
            view.urlChanged.connect(lambda _u: self.schedule(SETTLE_MS, "load"))
        except AttributeError:
            pass

    # ---------------------------------------------------------------- события
    def _load_started(self):
        self.budget = MAX_FITS

    def _load_finished(self, _ok=True):
        self.schedule(SETTLE_MS, "load")
        self._late.start(LATE_MS)

    def eventFilter(self, obj, ev):  # noqa: N802 (Qt)
        if obj is self.view and not self._own:
            t = ev.type()
            if t == QEvent.Type.Resize:
                sz = self._size()
                if self.fit_size is None or (abs(sz[0] - self.fit_size[0]) >= RESIZE_MIN_PX
                                             or abs(sz[1] - self.fit_size[1]) >= RESIZE_MIN_PX):
                    self.schedule(DEBOUNCE_MS, "resize")
            elif t == QEvent.Type.Show and (self._pending or self.fit_size is None):
                self.schedule(DEBOUNCE_MS, self._why)
        return False

    def _size(self):
        try:
            return self.view.width(), self.view.height()
        except RuntimeError:
            return 0, 0

    def schedule(self, ms=DEBOUNCE_MS, why="refit"):
        """Подогнать через ms. why: «load» (после загрузки — только уменьшать), «resize» (окно поменяли — в обе
        стороны, разрешает ещё одну смену), «refit» (вход/выход, конец сценария — в обе стороны)."""
        if why in ("resize", "refit"):
            self.budget = max(self.budget, 1)
        if not (self._timer.isActive() and self._why in ("resize", "refit")):
            self._why = why
        self._timer.start(int(ms))

    # ---------------------------------------------------------------- масштаб
    def zoom(self):
        try:
            return float(self.view.zoomFactor())
        except RuntimeError:
            return 1.0

    def _set(self, z):
        cur = self.zoom()
        if abs(z - cur) < 0.001:
            return False
        self._own = True
        try:
            self.view.setZoomFactor(z)
            self.calls += 1
        except RuntimeError:
            return False
        finally:
            self._own = False
        if self.on_zoom:
            self.on_zoom(z)
        return True

    def reset(self):
        """Обычный масштаб 100 % (идёт сценарий — он щёлкает по координатам страницы)."""
        self._timer.stop()
        self._late.stop()
        self._set(1.0)

    def set_manual(self, z):
        """Масштаб кнопками: z > 0 — ровно такой (и без подгонки), 0 — снова подгонять по размеру окна."""
        self.manual = float(z or 0.0)
        self.fit_size = None
        if self.manual:
            self._timer.stop()
            if not self.hold():
                self._set(self.manual)
        else:
            self.budget = MAX_FITS
            self.schedule(0, "refit")

    def fit(self):
        try:
            if self.hold():
                self._set(1.0)
                return
            if self.manual:
                self._set(self.manual)
                return
            if not self.active():
                self._set(1.0)
                return
            if not self.view.isVisible() or self.view.width() < 50 or self.view.height() < 50:
                self._pending = True
                return
            self._pending = False
            if self.budget <= 0:
                return
            why = self._why
            self.view.page().runJavaScript(MEASURE_JS, 0, lambda m, why=why: self._apply(m, why))
        except RuntimeError:          # страницу уже выгрузили
            pass

    def _apply(self, m, why="load"):
        if isinstance(m, str):
            try:
                m = json.loads(m)
            except ValueError:
                return
        if not isinstance(m, dict) or not m.get("n"):
            return
        if self.manual or self.hold() or not self.active():
            return
        cur = self.zoom()
        vw, vh = self._size()
        self.fit_size = (vw, vh)
        # Нужен весь блок до его низа (над ним шапка страницы), а не только его высота
        try:
            ch = max(float(m.get("h") or 0), float(m.get("bottom") or 0))
        except (TypeError, ValueError):
            ch = m.get("h")
        z = fit_zoom(cur, vw, vh, m.get("w"), ch or m.get("h"), shrink_only=(why == "load"))
        self.last = dict(m, zoom=z, view_w=vw, view_h=vh, why=why)
        if z != cur and self.budget > 0 and self._set(z):
            self.budget -= 1
            self.fits += 1
            log.debug("Масштаб страницы ВК: %.0f%% (место %sx%s, содержимое %sx%s, %s)", z * 100, vw, vh,
                      int(m["w"]), int(m["h"]), why)
