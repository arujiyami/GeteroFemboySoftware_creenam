# Original-Author: Владислав С.
# Created: 2026-10-28
"""Авторство: хэш исходного автора, вторая копия, запасная строка в «О программе», заголовки файлов."""
import ast
import hashlib
import os
import unittest
from unittest import mock

import app.about as about
from app import AUTHOR_LINE
from app.config import DEFAULTS

PROGRAM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(PROGRAM)
NAME = "Владислав С."


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


class Hash(unittest.TestCase):
    def test_constant_and_hash(self):
        self.assertEqual(about.ORIGINAL_AUTHOR, NAME)
        self.assertEqual(about.ORIGINAL_AUTHOR_SHA256, sha(NAME))
        self.assertEqual(about.ORIGINAL_AUTHOR_SHA256,
                         "2234eca2d3e3aa6dffc9e49407e61cb8b8b714c1239cd939c39db6855e534249")
        self.assertEqual(about.AUTHOR_LINE_SHA256, sha(AUTHOR_LINE))

    def test_notice_has_hash_and_date(self):
        with open(os.path.join(ROOT, "NOTICE.txt"), encoding="utf-8") as f:
            text = f.read()
        self.assertIn(about.ORIGINAL_AUTHOR_SHA256, text)
        self.assertIn("Created: 2026-10-28", text)
        self.assertIn("Original-Author: " + NAME, text)

    def test_second_copy_matches(self):
        import base64
        from app.buildinfo import ORIGIN
        self.assertEqual(sha(base64.b64decode(ORIGIN).decode("utf-8")), about.ORIGINAL_AUTHOR_SHA256)


class Fallback(unittest.TestCase):
    def test_intact_shows_only_author(self):
        self.assertTrue(about.author_intact())
        self.assertEqual(about.author_lines(), [AUTHOR_LINE])
        self.assertNotIn("Оригинальный автор", about.about_html(DEFAULTS))

    def test_edited_line_shows_original(self):
        lines = about.author_lines("Разработано Кем-то Другим")
        self.assertEqual(lines, ["Разработано Кем-то Другим", "Оригинальный автор: " + NAME])

    def test_edited_constant_uses_second_copy(self):
        with mock.patch.object(about, "AUTHOR_LINE", "Разработано Другим"), \
                mock.patch.object(about, "ORIGINAL_AUTHOR", "Другой"):
            html = about.about_html(DEFAULTS)
        self.assertIn("Оригинальный автор: " + NAME, html)
        self.assertNotIn("Оригинальный автор: Другой", html)

    def test_never_crashes(self):
        with mock.patch.object(about, "ORIGINAL_AUTHOR", "Другой"), \
                mock.patch("app.buildinfo.ORIGIN", "!!!не base64!!!"):
            self.assertEqual(about.author_lines("x"), ["x"])      # копий нет — просто без строки
            about.about_html(DEFAULTS)
        with mock.patch.object(about, "original_author", side_effect=RuntimeError):
            self.assertEqual(about.author_lines("x"), ["x"])
        self.assertEqual(about.author_lines(""),
                         ["Оригинальный автор: " + NAME])


class Headers(unittest.TestCase):
    def files(self, ext):
        for d, ds, fs in os.walk(ROOT):
            ds[:] = [x for x in ds if x not in ("browser_profile", "__pycache__", ".git", "dist", "build", "logs",
                                                  "screenshots", ".venv")]
            for f in fs:
                if f.endswith(ext):
                    yield os.path.join(d, f)

    def test_py_headers(self):
        for p in self.files(".py"):
            with open(p, encoding="utf-8") as f:
                head = f.read(300)
            self.assertIn("# Original-Author: " + NAME, head, p)
            self.assertRegex(head, r"# Created: 2026-(10-(28|29|30|31)|11-0[1-3])\n", p)

    def test_bat_headers_ascii(self):
        for p in self.files(".bat"):
            with open(p, "rb") as f:
                head = f.read(200)
            self.assertIn(b"rem Original-Author: Vladislav S.", head, p)
            self.assertIn(b"rem Created: 2026-10-28", head, p)
            self.assertTrue(head.lower().startswith(b"@echo off"), p)

    def test_version_file(self):
        path = os.path.join(PROGRAM, "version_info.txt")
        with open(path, encoding="utf-8") as f:
            text = f.read()
        tree = ast.parse(text)               # PyInstaller читает его как выражение Python
        self.assertEqual(len(tree.body), 1)
        for s in ("StringStruct('CompanyName', '%s')" % NAME, "StringStruct('FileVersion', '3.0.12')",
                  "StringStruct('LegalCopyright', '© 2026 %s')" % NAME, "filevers=(3, 0, 12, 0)"):
            self.assertIn(s, text)
        with open(os.path.join(PROGRAM, "build_exe.bat"), encoding="utf-8") as f:
            self.assertIn("--version-file version_info.txt", f.read())


class CreditOnlyInAbout(unittest.TestCase):
    """2.1.9: автор виден только в окне «О программе», не в самом окне программы и не в мастере."""

    def test_about_has_credits(self):
        import copy
        from app import CONTRIBUTOR_LINE, __version__
        from app.about import about_html
        from app.config import DEFAULTS
        h = about_html(copy.deepcopy(DEFAULTS))
        self.assertIn(AUTHOR_LINE, h)
        self.assertIn(CONTRIBUTOR_LINE, h)
        self.assertIn(__version__, h)
        self.assertLess(h.index(AUTHOR_LINE), h.index(CONTRIBUTOR_LINE))

    def test_ui_sources_do_not_show_credit(self):
        ui = os.path.join(PROGRAM, "app", "ui")
        for name in os.listdir(ui):
            if name.endswith(".py"):
                with open(os.path.join(ui, name), encoding="utf-8") as f:
                    src = f.read()
                self.assertNotIn("AUTHOR_LINE", src, name)
                self.assertNotIn("CONTRIBUTOR_LINE", src, name)
                self.assertNotIn("Разработано", src, name)
                self.assertNotIn("Grok", src, name)

    def test_main_window_has_about_button(self):
        with open(os.path.join(PROGRAM, "app", "ui", "main_window.py"), encoding="utf-8") as f:
            src = f.read()
        self.assertIn('QPushButton("О программе")', src)
        self.assertIn("about_btn.clicked.connect(self.show_about)", src)


if __name__ == "__main__":
    unittest.main()
