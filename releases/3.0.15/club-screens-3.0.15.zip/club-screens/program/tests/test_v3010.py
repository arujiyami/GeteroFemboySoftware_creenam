# Original-Author: Владислав С.
# Created: 2026-11-01
"""3.0.10: записанный при съёмке сценария щелчок по Cancel не повторяется наугад; подписи без тавтологий."""
import os
import tempfile
import unittest

from app import __version__, recorder
from app.steps import Context, StepRunner
from tests.test_v309 import Be

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class RecordedCancel(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        for n in ("step02.png", "step04.png", "step05.png"):
            open(os.path.join(self.dir, n), "wb").close()

    def run_steps(self, be, steps):
        r = StepRunner(be, lambda p: os.path.join(self.dir, p), sleep=lambda s: None)
        ctx = Context({"name": "iVMS-4200", "kind": "ivms"})
        ctx.hwnd = 7
        r.run_steps(steps, ctx)
        return ctx

    VIEW = {"type": "click_image", "template": "step02.png", "double": True,
            "fallback": {"type": "click_xy", "x": 118, "y": 196, "units": "pixels", "double": True}}
    CANCEL = {"type": "click_image", "template": "step04.png",
              "fallback": {"type": "click_xy", "x": 1070, "y": 549, "units": "pixels"}}
    FULL = {"type": "click_image", "template": "step05.png",
            "fallback": {"type": "click_xy", "x": 1836, "y": 977, "units": "pixels"}}
    WAIT = {"type": "wait", "seconds": 1}

    def test_recorded_cancel_skipped_after_dialog_closed(self):
        be = Be({"step02.png": (10, 10), "step05.png": (1836, 977)}, dialog="cancelled")
        self.run_steps(be, [self.VIEW, self.WAIT, self.CANCEL, self.WAIT, self.FULL])
        self.assertNotIn((1070, 549, False), be.clicks)
        self.assertIn((1836, 977, False), be.clicks)

    def test_without_dialog_recorded_cancel_skipped(self):   # 3.0.11: было — щелчок по камерам
        be = Be({"step02.png": (10, 10)}, dialog="none")
        self.run_steps(be, [self.VIEW, self.CANCEL])
        self.assertNotIn((1070, 549, False), be.clicks)

    def test_only_next_step_skipped(self):
        be = Be({"step02.png": (10, 10)}, dialog="cancelled")
        self.run_steps(be, [self.VIEW, self.CANCEL, self.FULL])
        self.assertNotIn((1070, 549, False), be.clicks)
        self.assertIn((1836, 977, False), be.clicks)       # следующий шаг — снова по запасным координатам


class Texts(unittest.TestCase):
    def test_version(self):
        self.assertEqual(__version__, "3.0.15")

    def read(self, rel):
        with open(os.path.join(HERE, rel), encoding="utf-8") as f:
            return f.read()

    def test_no_tautology(self):
        for rel in ("app/ui/wizard.py", "app/ui/settings.py", "app/ui/recorder_ui.py", "app/recorder.py",
                    "app/steps.py", "app/errdoc.py"):
            t = self.read(rel)
            for bad in ("Кнопка Cancel / второй вид", "Записать кнопку Cancel", "Cancel: записана"):
                self.assertNotIn(bad, t, rel)

    def test_new_labels(self):
        self.assertIn('"Cancel и второй вид…"', self.read("app/ui/settings.py"))
        self.assertIn('"Cancel и второй вид"', self.read("app/ui/wizard.py"))
        ui = self.read("app/ui/recorder_ui.py")
        self.assertIn('"Записать Cancel"', ui)
        self.assertIn('"Записать второй вид"', ui)
        self.assertEqual(recorder.cancel_state_text({}, lambda p: p), "Cancel не записан")


if __name__ == "__main__":
    unittest.main()
