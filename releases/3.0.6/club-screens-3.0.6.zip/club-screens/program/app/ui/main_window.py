# Original-Author: Владислав С.
# Created: 2026-10-28
"""Главное окно: слева разделы «Главная», «ВКонтакте», «Настройки», «Журнал»; мастер — внутри этого же окна."""
import glob
import logging
import os
import queue
import sys
import threading
from datetime import datetime

from PySide6.QtCore import QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont, QFontMetrics, QPainter
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QMainWindow,
                               QMenu, QMessageBox, QPlainTextEdit, QPushButton, QStackedWidget, QSystemTrayIcon,
                               QVBoxLayout, QWidget)

from .. import APP_NAME, __version__, elevation
from ..about import about_html
from ..config import base_dir, is_configured, load_config, migrate, resolve_path, save_config, validate
from ..friendly import humanize
from ..job import JobRunner, set_browser
from ..logsetup import LOG_QUEUE
from ..inputlock import hotkey_text, release_all
from ..scheduler import HourlyScheduler, countdown_settings, early_settings, lock_at, next_run
from .browser import VKBrowser
from .services import ServicesMixin
from . import theme
from .common import (BLUE, GREEN, GREY, ORANGE, RED, GuiCall, Task, app_icon, big_button, exclude_from_capture,
                     label, link_button, open_path, set_image, set_status, set_tone, tone_color, tone_of)

log = logging.getLogger("club")
THUMB = (300, 180)
NAV = (("home", "🏠  Главная"), ("vk", "💬  ВКонтакте"), ("settings", "⚙  Настройки"), ("log", "📄  Журнал"))


from ..job import booking_photo_for, latest_shots  # noqa: E402  (2.2.1: общая с «Отправить последние скрины»)


RESEND_TEXT = "Отправить последние скрины"


def result_text(r):
    """Текст «Последняя отправка» и цвет."""
    when = r["time"].strftime("%d.%m %H:%M")
    if r.get("sent") and not r.get("errors"):
        text, color = f"✔ {when} — отправлено успешно", GREEN
        if r.get("verified") is False or r.get("send_result") in ("unverified", "mismatch"):
            text = f"✔ {when} — похоже, отправлено (проверьте беседу)"
    elif r.get("sent"):
        text, color = f"⚠ {when} — отправлено не всё", ORANGE
    elif r.get("queued"):
        text, color = (f"⏳ {when} — нет интернета, снимки ждут в очереди ({r['queued']}) "
                       "и уйдут сами, когда связь вернётся", ORANGE)
    else:
        text, color = f"✖ {when} — не удалось отправить", RED
    problems = list((r.get("errors") or {}).values())
    warnings = list((r.get("warnings") or {}).values())
    if warnings and color == GREEN:
        color = ORANGE
        text = text.replace("✔", "⚠", 1)
    problems += ["Нужно ваше действие: " + w for w in warnings]
    if r.get("send_error"):
        problems.append(r["send_error"])
    if problems:
        text += "\n" + "\n".join("• " + p for p in dict.fromkeys(problems))
    if r.get("interim"):
        text += "\nПовторю через минуту (не больше 2 попыток в час)."
    return text, color


class Dot(QWidget):
    def __init__(self):
        super().__init__()
        self.color = GREY
        self.setFixedSize(34, 34)

    def set_color(self, c):
        self.color = c
        self.update()

    def paintEvent(self, _):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QColor(tone_color(tone_of(self.color))))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(4, 4, 26, 26)


class Thumb(QLabel):
    def __init__(self):
        super().__init__()
        self.path = None
        self.setFixedSize(*THUMB)
        self.setObjectName("thumb")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Открыть снимок")

    def mousePressEvent(self, _):  # noqa: N802
        if self.path and os.path.exists(self.path):
            open_path(self.path)


class MainWindow(ServicesMixin, QMainWindow):
    def __init__(self, cfg, cfg_path, backend_factory, start_minimized=False, autostart_jobs=True,
                 browser=None, admin=None):
        super().__init__()
        self.cfg = cfg
        self.cfg_path = cfg_path
        self.backend_factory = backend_factory
        self.admin = elevation.is_admin() if admin is None else admin
        self.gui = GuiCall()
        self.busy = False
        self.quitting = False
        self.tray = None
        self.wizard = None
        self._hidden_for_capture = False
        self.capture_warning = None
        self._cfg_mtime = self._file_mtime()
        self._tray_hint_shown = False
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(app_icon())
        theme.apply_from_config(cfg)     # 2.1.8: тема оформления (общий стиль всего приложения)

        self.browser = browser or VKBrowser(lambda: self.cfg, self)
        set_browser(self.browser)
        self.job = JobRunner(lambda: self.cfg, backend_factory, root=None)
        self.job.on_start = lambda: self.gui(self._on_cycle_start)
        self.job.on_result = lambda r: self.gui(lambda: self._on_result(r))
        self.job.on_capture = self._capture_hook
        self.job.on_phase = lambda ph: self.gui(self._on_phase)
        self.prewarm_state = None   # (None | "preparing" | "ready", время отправки)
        self.job.on_warning = lambda name, text: self.gui(lambda: self.on_capture_warning(name, text))
        # 2.1.5: плановый цикл стартует за early_sec секунд до съёмки (блокировка ввода, Oasys вперёд,
        # «Карта клуба»), снимок — ровно в ЧЧ:00
        self.scheduler = HourlyScheduler(lambda target: self.job.run_cycle(True, capture_at=target),
                                         lambda: self.cfg["schedule"],
                                         early_seconds=lambda: early_settings(self.cfg),
                                         prewarm=lambda target: self.gui(lambda: self.prewarm(target)),
                                         countdown=lambda target: self.gui(lambda: self.show_countdown(target)),
                                         countdown_seconds=self._countdown_seconds,
                                         cleanup=self.job.cleanup,
                                         cleanup_settings=lambda: self.cfg.get("cleanup") or {},
                                         catch_up=self._catch_up)
        self.countdown = None      # окошко обратного отсчёта (создаётся при первом показе)
        self.browser.needsUser.connect(self.on_needs_user)
        self.browser.loginChanged.connect(self._on_login_changed)
        if hasattr(self.browser, "zoomPrefChanged"):     # 2.1.8: масштаб страницы ВК кнопками — запомнить
            self.browser.set_zoom_pref(self._ini_value("vk_zoom", 0.0), emit=False)
            self.browser.zoomPrefChanged.connect(lambda z: self._ini_set("vk_zoom", z))
        self.browser.loggedOut.connect(self._on_logged_out)

        self.outer = QStackedWidget()
        self.setCentralWidget(self.outer)
        self.outer.addWidget(self._build_main())
        self.wizard_holder = QWidget()
        QVBoxLayout(self.wizard_holder).setContentsMargins(0, 0, 0, 0)
        self.outer.addWidget(self.wizard_holder)
        self.restore_view()

        self._fit_to_screen()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(400)
        if self.cfg["app"].get("use_tray", True) and QSystemTrayIcon.isSystemTrayAvailable():
            self._setup_tray()

        configured = is_configured(self.cfg)
        if autostart_jobs and configured and self.cfg["schedule"].get("enabled", True):
            self.scheduler.start()
        self.browser.go_chat() if self.cfg["vk"].get("peer_id") else self.browser.go(
            self.browser.settings()["home_url"])
        self.refresh()
        if not configured:
            QTimer.singleShot(200, self.open_wizard)
        self.setup_services(autostart_jobs)      # 2.2.0: сторож, очередь, сводка, обновления
        self.start_hidden = bool(configured and (start_minimized or self.cfg["app"].get("start_minimized"))
                                 and self.tray)

    # ================= построение =================
    # 2.1.7: окно (и мастер настройки в нём) — по размеру экрана: ~90 % рабочей области, не меньше разумного
    # минимума, размер и «на весь экран» запоминаются в window.ini рядом с config.yaml
    SCREEN_SHARE = 0.9
    MAX_DEFAULT_W = 1440

    def _screen_rect(self):
        scr = self.screen() if hasattr(self, "screen") and self.screen() else QApplication.primaryScreen()
        return scr.availableGeometry() if scr else None

    def _state_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(self.cfg_path)), "window.ini") if self.cfg_path else None

    def _fit_to_screen(self):
        scr = self._screen_rect()
        w, h = 1000, 700
        if scr:
            w = min(int(scr.width() * self.SCREEN_SHARE), self.MAX_DEFAULT_W)
            h = int(scr.height() * self.SCREEN_SHARE)
        self.setMinimumSize(QSize(min(820, w), min(560, h)))
        self.resize(w, h)
        if scr:
            self.move(scr.x() + (scr.width() - w) // 2, scr.y() + (scr.height() - h) // 2)
        self._restore_window_state()

    def _restore_window_state(self):
        path = self._state_path()
        if not path or not os.path.exists(path):
            return
        try:
            from PySide6.QtCore import QSettings
            st = QSettings(path, QSettings.Format.IniFormat)
            geo = st.value("geometry")
            if geo is not None and self.restoreGeometry(geo):
                scr = self._screen_rect()
                if scr and not scr.intersects(self.frameGeometry()):   # экран отключили — вернуть на текущий
                    self.move(scr.topLeft())
        except Exception:  # noqa: BLE001
            log.debug("window.ini не прочитан", exc_info=True)

    def _ini_value(self, key, default=0.0):
        path = self._state_path()
        if not path or not os.path.exists(path):
            return default
        try:
            from PySide6.QtCore import QSettings
            return float(QSettings(path, QSettings.Format.IniFormat).value(key, default))
        except Exception:  # noqa: BLE001
            return default

    def _ini_set(self, key, value):
        path = self._state_path()
        if not path:
            return
        try:
            from PySide6.QtCore import QSettings
            st = QSettings(path, QSettings.Format.IniFormat)
            st.setValue(key, value)
            st.sync()
        except Exception:  # noqa: BLE001
            log.debug("window.ini не записан", exc_info=True)

    def save_window_state(self):
        path = self._state_path()
        if not path:
            return
        try:
            from PySide6.QtCore import QSettings
            st = QSettings(path, QSettings.Format.IniFormat)
            st.setValue("geometry", self.saveGeometry())
            st.sync()
        except Exception:  # noqa: BLE001
            log.debug("window.ini не записан", exc_info=True)

    def ensure_big(self, share=None):
        """Шаг входа ВК: окно не меньше ~90 % экрана (если пользователь не развернул его сам)."""
        if self.isMaximized() or self.isFullScreen():
            return False
        scr = self._screen_rect()
        if not scr:
            return False
        share = share or self.SCREEN_SHARE
        w = max(self.width(), min(int(scr.width() * share), self.MAX_DEFAULT_W))
        h = max(self.height(), int(scr.height() * share))
        if (w, h) == (self.width(), self.height()):
            return False
        self.resize(w, h)
        g = self.frameGeometry()
        x = min(max(g.x(), scr.x()), scr.right() - g.width())
        y = min(max(g.y(), scr.y()), scr.bottom() - g.height())
        self.move(max(scr.x(), x), max(scr.y(), y))
        return True

    def _build_main(self):
        root = QWidget()
        lay = QHBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        side = QFrame()
        side.setObjectName("side")
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 18, 0, 12)
        t = QLabel("📷 " + APP_NAME)
        t.setObjectName("sideTitle")
        t.setWordWrap(False)              # 2.1.7: название в одну строку
        t.setContentsMargins(12, 0, 8, 0)
        sl.addWidget(t)
        self.side_title = t
        f = QFont(self.font())
        f.setPointSizeF(12.5)
        f.setWeight(QFont.Weight.DemiBold)
        side.setFixedWidth(max(208, QFontMetrics(f).horizontalAdvance(t.text()) + 36))
        sl.addSpacing(12)
        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        for key, text in NAV:
            it = QListWidgetItem(text)
            it.setData(Qt.ItemDataRole.UserRole, key)
            self.nav.addItem(it)
        self.nav.currentRowChanged.connect(self._on_nav)
        sl.addWidget(self.nav, 1)
        # 2.1.9: внизу — только версия и кнопка «О программе» (авторы — в окне «О программе»)
        foot = QHBoxLayout()
        foot.setContentsMargins(8, 4, 6, 2)
        foot.setSpacing(8)
        ver = QLabel(f"версия {__version__}")
        ver.setObjectName("sideMuted")
        foot.addWidget(ver)
        foot.addStretch(1)
        about_btn = QPushButton("О программе")
        about_btn.setObjectName("aboutBtn")
        about_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        about_btn.setToolTip("Версия, как работает программа, авторы")
        about_btn.clicked.connect(self.show_about)
        foot.addWidget(about_btn)
        sl.addLayout(foot)
        self.version_label = ver
        self.about_button = about_btn
        lay.addWidget(side)

        self.pages = QStackedWidget()
        self.pages.setObjectName("page")
        self.page_home = self._build_home()
        self.page_vk = self._build_vk()
        from .settings import SettingsPage
        self.page_settings = SettingsPage(self)
        self.page_log = self._build_log()
        for p in (self.page_home, self.page_vk, self.page_settings, self.page_log):
            self.pages.addWidget(p)
        lay.addWidget(self.pages, 1)
        self.nav.setCurrentRow(0)
        return root

    def _build_home(self):
        w = QWidget()
        w.setObjectName("page")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(26, 20, 26, 14)
        self.title_lbl = label("", "title")
        lay.addWidget(self.title_lbl)
        lay.addWidget(label("Главная: работает ли отправка, когда следующая и как прошла последняя.", "pageDesc"))
        lay.addSpacing(4)
        self.chat_lbl = label("", "muted")
        lay.addWidget(self.chat_lbl)
        card = QFrame()
        card.setObjectName("statusCard")    # 2.1.8: цвет карточки — по состоянию (зелёный/жёлтый/красный)
        self.status_card = card
        cl = QHBoxLayout(card)
        cl.setContentsMargins(16, 14, 16, 14)
        self.dot = Dot()
        cl.addWidget(self.dot, 0, Qt.AlignmentFlag.AlignTop)
        box = QVBoxLayout()
        self.status_lbl = QLabel("")
        self.status_lbl.setObjectName("statusText")
        self.sub_lbl = label("", "statusSub")
        box.addWidget(self.status_lbl)
        box.addWidget(self.sub_lbl)
        cl.addLayout(box, 1)
        lay.addSpacing(10)
        lay.addWidget(card)
        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.vk_chip = label("", "chip", wrap=False)
        self.admin_chip = label("", "chip", wrap=False)
        self.admin_chip.setToolTip(elevation.status_text(self.admin))
        for c in (self.vk_chip, self.admin_chip):
            c.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
            chips.addWidget(c)
        chips.addStretch(1)
        lay.addSpacing(8)
        lay.addLayout(chips)
        row = QHBoxLayout()
        self.toggle_btn = big_button("▶  Старт", GREEN, self.toggle)
        self.send_btn = big_button("Отправить сейчас", BLUE, lambda: self.send_now(True))
        # 2.2.1: повторно отправить уже снятые скрины (без нового съёма) — «ручная попытка»
        self.resend_btn = big_button(RESEND_TEXT, BLUE, self.resend_latest)
        self.resend_btn.setToolTip("Отправить в беседу последние снятые скриншоты ещё раз, не делая новых")
        row.addWidget(self.toggle_btn)
        row.addSpacing(10)
        row.addWidget(self.send_btn)
        row.addSpacing(10)
        row.addWidget(self.resend_btn)
        row.addStretch(1)
        lay.addSpacing(10)
        lay.addLayout(row)
        self.admin_lbl = label(elevation.status_text(self.admin), "ok" if self.admin else "wait")
        self.admin_lbl.setVisible(not self.admin and sys.platform == "win32")   # «запущено без прав» — подробно
        lay.addSpacing(6)
        lay.addWidget(self.admin_lbl)
        self._update_admin_chip()
        lay.addSpacing(12)
        lay.addWidget(label("Последняя отправка", "subTitle"))
        self.last_lbl = label("", "lastText")
        lay.addWidget(self.last_lbl)
        trow = QHBoxLayout()
        self.thumbs = [Thumb(), Thumb()]
        for th in self.thumbs:
            trow.addWidget(th)
        trow.addStretch(1)
        lay.addLayout(trow)
        # 3.0.6: «Состояние брони (фото)» — снимок экрана перед Esc в Oasys (в ВК не отправляется)
        self.bron_title = label("Состояние брони (фото)", "muted")
        self.bron_title.setToolTip("Снимок экрана перед тем, как программа закрыла окна Oasys клавишей Esc. "
                                   "Если в этот момент оформлялась бронь — её данные видны здесь. В ВК не уходит.")
        lay.addSpacing(6)
        lay.addWidget(self.bron_title)
        brow = QHBoxLayout()
        self.bron_thumb = Thumb()
        self.bron_thumb.setToolTip("Открыть фото состояния брони")
        brow.addWidget(self.bron_thumb)
        brow.addStretch(1)
        lay.addLayout(brow)
        self.bron_title.setVisible(False)
        self.bron_thumb.setVisible(False)
        lay.addStretch(1)
        foot = QHBoxLayout()
        for text, fn in (("Настроить заново", self.open_wizard), ("Папка скриншотов", self.open_shots),
                         ("Открыть ВКонтакте", lambda: self.show_section("vk"))):
            foot.addWidget(link_button(text, fn))
            foot.addSpacing(12)
        foot.addStretch(1)
        lay.addLayout(foot)
        return w

    def _build_vk(self):
        w = QWidget()
        w.setObjectName("page")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(12, 10, 12, 8)
        head = QHBoxLayout()
        head.addWidget(label("ВКонтакте", "title", wrap=False))
        head.addSpacing(12)
        desc = label("Сайт ВК внутри программы: через него уходят снимки. Войдите один раз — дальше всё само.",
                     "pageDesc")
        head.addWidget(desc, 1, Qt.AlignmentFlag.AlignVCenter)
        lay.addLayout(head)
        lay.addSpacing(4)
        bar = QHBoxLayout()
        for text, tip, fn in (("←", "Назад", self.browser.back),
                              ("⟳", "Обновить страницу", self.browser.reload),
                              ("💬 Беседа", "Открыть беседу для скриншотов",
                               lambda: (self.browser.ensure_view(), self.browser.go_chat())),
                              ("ВК", "Главная страница ВК",
                               lambda: self.browser.go(self.browser.settings()["home_url"], load=True))):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            bar.addWidget(b)
        bar.addStretch(1)
        chk = QPushButton("Проверить вход")
        chk.clicked.connect(lambda: self.check_login(show=True))
        bar.addWidget(chk)
        lay.addLayout(bar)
        self.vk_login_lbl = label("", "muted")
        lay.addWidget(self.vk_login_lbl)
        self.vk_need_lbl = label("", "wait")
        self.vk_need_lbl.hide()
        lay.addWidget(self.vk_need_lbl)
        self.vk_view_box = QVBoxLayout()
        lay.addLayout(self.vk_view_box, 1)
        note = label("Настоящий сайт ВКонтакте внутри программы. Пароль программа не видит и не хранит.", "muted")
        note.setToolTip("Войдите как обычно: логин, пароль и код вводите сами (или по QR-коду). Профиль браузера "
                        "хранится только на этом компьютере; не передавайте папку browser_profile (и файл "
                        "config.yaml) никому.")
        lay.addWidget(note)
        return w

    def _build_log(self):
        w = QWidget()
        w.setObjectName("page")
        lay = QVBoxLayout(w)
        lay.setContentsMargins(26, 20, 26, 14)       # 2.1.7: как на «Главной»
        lay.setSpacing(12)
        row = QHBoxLayout()
        row.setSpacing(8)
        tl = QVBoxLayout()
        tl.setSpacing(2)
        tl.addWidget(label("Журнал", "title"))
        tl.addWidget(label("Что программа делала и когда: отправки, ошибки, предупреждения.", "pageDesc"))
        row.addLayout(tl)
        row.addStretch(1)
        for text, fn in (("Только снять (без отправки)", lambda: self.send_now(False)),
                         ("Папка скриншотов", self.open_shots), ("Файл журнала", self.open_log)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b, 0, Qt.AlignmentFlag.AlignVCenter)
        lay.addLayout(row)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(3000)
        self.log_view.setObjectName("logView")
        lay.addWidget(self.log_view, 1)
        return w

    # ================= веб-страница ВК: одна на всю программу =================
    def place_view(self, layout, load=True):
        """Перенести страницу ВК в другое место окна (мастер / раздел «ВКонтакте»).
        Сама страница создаётся только здесь, когда её действительно видно (экономия памяти)."""
        layout.addWidget(self.browser.holder, 1)
        self.browser.holder.show()
        if load:
            self.browser.ensure_view()

    def restore_view(self):
        self.place_view(self.vk_view_box, load=False)
        self.update_view_memory()

    def vk_section_open(self):
        return bool(self.isVisible() and not self.isMinimized() and not self.wizard
                    and self.pages.currentIndex() == 1)

    def update_view_memory(self):
        """Страница ВК нужна только пока открыт раздел «ВКонтакте» (или шаг входа в мастере)."""
        if self.wizard and getattr(self.wizard, "view_here", False) and self.isVisible():
            self.browser.ensure_view()
        elif self.vk_section_open():
            self.browser.ensure_view()
        elif self.browser.save_memory:
            self.browser.unload_view()

    def _on_phase(self):
        self._update_status()
        self._show_last()

    # ================= навигация =================
    def _on_nav(self, row):
        self.pages.setCurrentIndex(max(0, row))
        self.update_view_memory()
        if row == 1:
            self.check_login()
        elif row == 2:
            # 2.1.6: переход в «Настройки» ничего не сбрасывает — поля и так совпадают с cfg (всё сохраняется само)
            self.page_settings.flush_live()
            self.page_settings.refresh_autostart()

    def show_section(self, key):
        self.show_window()
        if self.wizard:
            return
        for i, (k, _) in enumerate(NAV):
            if k == key:
                self.nav.setCurrentRow(i)

    # ================= обновление =================
    def _tick(self):
        lines = []
        try:
            while len(lines) < 500:
                lines.append(LOG_QUEUE.get_nowait())
        except queue.Empty:
            pass
        if lines:
            self.log_view.appendPlainText("\n".join(lines))
        self.check_config_file()
        self._update_status()
        if self.countdown is not None and self.countdown.active and not self._countdown_allowed():
            self.hide_countdown()    # «Стоп», отсчёт выключили в настройках, «Нужно ваше действие»…

    def refresh(self):
        club = self.cfg["app"].get("club_name") or ""
        self.title_lbl.setText(club or APP_NAME)
        self.setWindowTitle(f"{APP_NAME} — {club}" if club else APP_NAME)
        vk = self.cfg["vk"]
        if vk.get("sender") == "group_api":
            who = "Отправляет: сообщество (ключ доступа сообщества)"
        else:
            who = f"Отправляет: {vk.get('account_name') or 'ваш профиль ВК'} — через браузер программы"
        self.chat_lbl.setText(f"Беседа: {vk.get('peer_title') or vk.get('peer_id')}\n{who}")
        self._show_last()
        self._update_login_label()
        self._update_status()

    def status(self):
        """(цвет, заголовок, пояснение) для главного экрана."""
        if self.busy or self.job.lock.locked():
            phase = self.job.phase
            if phase == "send":
                return ORANGE, "Отправляю в беседу…", ("Отправляю в беседу… можно продолжать работу. "
                                                        "Это идёт в фоне и мышь не трогает.")
            if phase == "retry_wait":
                return ORANGE, "Жду повтора", ("Не получилось — повторю через минуту. "
                                               "Что случилось — ниже, в «Последняя отправка».")
            if self.job.input_locked:
                return ORANGE, "Снимаю экран", (f"Снимаю экран — ввод заблокирован. "
                                                f"Разблокировать: {self.unlock_hotkey()}")
            return ORANGE, "Снимаю экран", "Снимаю экран — не трогайте мышь пару секунд."
        if not is_configured(self.cfg):
            return GREY, "Не настроено", "Нажмите «Настроить заново» и пройдите шаги мастера."
        if self.job.hold:
            return ORANGE, "Нужно ваше действие", (
                self.job.hold + "\nОткройте раздел «ВКонтакте» слева. Пока вы этого не сделаете, плановые "
                "отправки пропускаются, чтобы не раздражать ВК. Потом нажмите «Отправить сейчас».")
        if self.scheduler.running:
            target = self.scheduler.next_target or next_run(datetime.now(), self.cfg["schedule"].get("minute", 0))
            pw = self.prewarm_state
            if pw and pw[1] == target:
                if pw[0] == "preparing":
                    return GREEN, "Работает", f"Браузер готовится к отправке в {target:%H:%M}"
                return GREEN, "Работает", f"Браузер готов к отправке в {target:%H:%M}"
            return GREEN, "Работает", f"Следующая отправка в {target:%H:%M}"
        return RED, "Остановлено", "Нажмите «Старт», чтобы отправлять скриншоты каждый час."

    def _update_status(self):
        color, text, sub = self.status()
        if self.status_lbl.text() != text or self.sub_lbl.text() != sub:
            self.status_lbl.setText(text)
            self.sub_lbl.setText(sub)
            self.dot.set_color(color)
            st = tone_of(color)
            theme.repolish(self.status_lbl, state=st)
            theme.repolish(self.status_card, state=st)
            if self.scheduler.running:
                self.toggle_btn.setText("■  Стоп")
                set_tone(self.toggle_btn, RED)
            else:
                self.toggle_btn.setText("▶  Старт")
                set_tone(self.toggle_btn, GREEN)
            if self.tray:
                self.tray.setToolTip(f"{APP_NAME}: {text.lower()}")
                self.tray_toggle.setText("Стоп" if self.scheduler.running else "Старт")
        idle = not (self.busy or self.job.lock.locked())
        self.send_btn.setEnabled(idle)
        can_resend = idle and self._has_latest_shots()
        if getattr(self, "resend_btn", None) is not None:
            self.resend_btn.setEnabled(can_resend)
        if getattr(self, "tray_resend", None) is not None:
            self.tray_resend.setEnabled(can_resend)

    def _show_last(self):
        r = self.job.last_result
        if r:
            text, color = result_text(r)
            paths = r.get("paths") or []
        else:
            paths = latest_shots(resolve_path(self.cfg["storage"]["screenshots_dir"]))
            if paths:
                text = f"Последние снимки: {datetime.fromtimestamp(os.path.getmtime(paths[-1])):%d.%m %H:%M}"
            else:
                text = "Пока ничего не отправлялось."
            color = None
        self.last_lbl.setText(text)
        theme.repolish(self.last_lbl, state=tone_of(color) if color else "")
        for i, th in enumerate(self.thumbs):
            p = paths[i] if i < len(paths) else None
            th.path = p
            set_image(th, p, THUMB, "")
        bron = booking_photo_for(paths) if paths else None
        self.bron_thumb.path = bron
        self.bron_title.setVisible(bool(bron))
        self.bron_thumb.setVisible(bool(bron))
        if bron:
            set_image(self.bron_thumb, bron, THUMB, "")

    def _set_busy(self, busy):
        self.busy = busy
        self._update_status()

    # ================= обратный отсчёт перед съёмкой (своё окошко, не уведомление Windows) =================
    def unlock_hotkey(self):
        return hotkey_text((self.cfg.get("input_lock") or {}).get("hotkey"))

    def _catch_up(self, slot):
        """3.0.3: догнать пропущенный плановый запуск, если час ещё не отправлен (ни программой, ни вручную,
        ни в беседе). Обычный цикл: не больше 2 попыток, удалённое сообщение повтор не вызывает."""
        if self.job.hour_already_sent(self.cfg, slot, "догоняющий запуск"):
            return
        log.warning("Съёмка за %s с опозданием (час ещё не отправлен) — снимаю и отправляю сейчас",
                    slot.strftime("%H:%M"))
        self.job.run_cycle(True, late_for=slot)

    def _countdown_seconds(self):
        """Читается планировщиком каждые полсекунды — изменение ползунка действует сразу."""
        return countdown_settings(self.cfg)[0]

    def _countdown_allowed(self):
        """Отсчёт нужен, только если плановая съёмка действительно будет."""
        return (countdown_settings(self.cfg)[0] > 0 and not self.job.hold and not self.job.lock.locked()
                and not self.busy and is_configured(self.cfg) and self.scheduler.running)

    def show_countdown(self, target):
        """«Съём скриншотов через 0:59» в правом нижнем углу: не забирает фокус, мышь проходит насквозь,
        на снимки не попадает. Исчезает перед самой съёмкой."""
        if not self._countdown_allowed():
            return False
        _, opacity = countdown_settings(self.cfg)
        lk = self.cfg.get("input_lock") or {}
        hotkey = self.unlock_hotkey() if (lk.get("enabled", True) and sys.platform == "win32") else None
        if self.countdown is None:
            from .countdown import CountdownOverlay
            self.countdown = CountdownOverlay(opacity=opacity)
        # окошко считает до съёмки (ЧЧ:00), а исчезает в момент блокировки ввода — за early_sec секунд до неё;
        # вторая строка: «Мышь и клавиатура заблокируются через N с»
        return self.countdown.start(target, "", opacity, lock_at=lock_at(target, early_settings(self.cfg)),
                                    hotkey=hotkey)

    def hide_countdown(self):
        if self.countdown is not None and self.countdown.active:
            self.countdown.stop()

    def _on_cycle_start(self):
        self.hide_countdown()        # «Отправить сейчас» или плановый запуск — отсчёт больше не нужен
        self._set_busy(True)

    # ================= заранее открыть беседу перед плановой отправкой =================
    def prewarm(self, target):
        """За N минут до отправки: одна загрузка беседы в фоне (та же, что нужна для отправки).
        Тихо: сообщаем только о настоящей проблеме (нет входа, капча, блокировка) — «Нужно ваше действие»."""
        vk = self.cfg["vk"]
        from ..lightmode import active as light_active
        if light_active():      # «Лёгкий режим»: беседа не держится открытой заранее
            return
        if (vk.get("sender") == "group_api" or not vk.get("peer_id") or self.job.hold or self.busy
                or self.job.lock.locked() or not is_configured(self.cfg)):
            return
        self.prewarm_state = ("preparing", target)
        self._update_status()
        keep = (target - datetime.now()).total_seconds() + float(self.cfg["schedule"].get("max_delay_sec", 600)) + 60

        def done(result, error):
            if error is None:
                self.prewarm_state = ("ready", target)
            else:
                self.prewarm_state = None
                log.warning("Не удалось заранее открыть беседу: %s", getattr(error, "text", error))
            self._update_status()
        self.browser.prewarm(self.browser.flows().prewarm(vk["peer_id"], vk.get("chat_search_title") or ""), done, keep)

    def _on_result(self, r):
        self.prewarm_state = None
        self._set_busy(False)
        self._show_last()
        if r.get("resend"):
            ok = r.get("ok")
            log.info("«Отправить последние скрины»: итог на экране — %s", "отправлено, ВК подтвердил" if ok else
                     "не отправлено (%s)" % (r.get("send_error") or "ошибка"))
            self._resend_feedback(None, "✔ Отправлено" if ok else "✖ Не ушло — см. строку ниже", 10000)
        if r.get("sent"):
            self.clear_sent_alert()           # 2.2.2: отправка прошла — тревога снимается сама
        elif getattr(self, "sent_alert", None) is not None:
            self.sent_alert.set_busy(False)
        if not r.get("ok") and self.tray and not self.isVisible():
            problems = list((r.get("errors") or {}).values()) + ([r["send_error"]] if r.get("send_error") else [])
            self.tray.showMessage(APP_NAME, ("\n".join(problems) or "Не удалось отправить скриншоты")[:250],
                                  QSystemTrayIcon.MessageIcon.Warning)
        elif r.get("warnings") and self.tray:
            self.tray.showMessage(APP_NAME, ("Нужно ваше действие: " + "\n".join(r["warnings"].values()))[:250],
                                  QSystemTrayIcon.MessageIcon.Warning)

    def on_capture_warning(self, name, text):
        """Источник (Oasys) так и не загрузился: снимок отправится «как есть» с пометкой. Проверьте программу."""
        log.warning("Нужно ваше действие: %s — проверьте, что %s работает", text, name)
        self.capture_warning = text
        self._update_status()

    # ================= ВК: вход и «нужно ваше действие» =================
    def _update_login_label(self, name=None):
        vk = self.cfg["vk"]
        if vk.get("sender") == "group_api":
            text, kind = "Отправка через сообщество — вход не нужен", "muted"
        elif vk.get("login_ok") or self.browser.logged_in:
            name = name or vk.get("account_name")
            text, kind = (f"✔ Вы вошли как {name}" if name else "✔ Вы вошли"), "ok"
        else:
            text, kind = "Вы не вошли — войдите в ВК прямо здесь, на странице ниже", "wait"
        set_status(self.vk_login_lbl, text, kind)
        chip = {"ok": ("ok", "✔ ВК: вход выполнен"), "wait": ("warn", "⚠ ВК: нужно войти")}.get(
            kind, ("idle", "ВК: через сообщество"))
        self.vk_chip.setText(chip[1])
        theme.repolish(self.vk_chip, state=chip[0])

    def _update_admin_chip(self):
        if self.admin:
            st, text = "ok", "✔ Запущено от администратора"
        elif sys.platform == "win32":
            st, text = "warn", "⚠ Без прав администратора"
        else:
            st, text = "idle", "Права администратора — только в Windows"
        self.admin_chip.setText(text)
        theme.repolish(self.admin_chip, state=st)

    def _on_login_changed(self, ok):
        """Cookie сессии появились/пропали. Это лишь подсказка: сохранённый «вход выполнен» (login_ok)
        отсюда НЕ сбрасывается — ВК меняет cookie на ходу (удалил → поставил новую), а страница может быть
        выгружена для экономии памяти. Сбрасывает вход только настоящая проверка загруженной страницы
        (_login_result) или отправка, которая упёрлась в страницу входа (_on_logged_out)."""
        self.browser.refit()     # вошли — обычный масштаб страницы; вышли — подогнать страницу входа
        if ok:
            self.check_login()
            return
        log.debug("Cookie сессии ВК не видно — сохранённый вход не трогаю")
        self._update_login_label()
        if self.wizard and self.browser.view_loaded:
            self.check_login()

    def _on_logged_out(self):
        """Отправка/список бесед открыли страницу входа ВК — вход действительно пропал."""
        self._forget_login("ВК показал страницу входа")

    def _forget_login(self, why):
        vk = self.cfg["vk"]
        if vk.get("sender") == "group_api" or not vk.get("login_ok"):
            return
        log.warning("Вход ВК пропал (%s) — войдите заново: «Настроить заново» → «Вход ВК»", why)
        vk["login_ok"] = False
        self.save_config(quiet=True)
        self._update_login_label()
        self.refresh()

    def check_login(self, show=False, on_done=None):
        """Прочитать со страницы, кто вошёл. Без лишней навигации."""
        if self.browser.busy:
            if on_done:
                on_done(None)
            return
        if not self.browser.view_loaded:
            # страница выгружена (экономия памяти): вход узнаём по cookie профиля, страницу не создаём
            st = {"state": "ok" if self.browser.logged_in else "unknown", "name": ""}
            QTimer.singleShot(0, lambda: self._login_result(st, show, on_done))
            return

        def done(st, err):
            if err is not None or not st:
                log.debug("Проверка входа: %s", err)
                if on_done:
                    on_done(None)
                return
            self._login_result(st, show, on_done)
        self.browser.run_flow(self.browser.flows().login_status(navigate=False, settle=0), done, work=False)

    def _login_result(self, st, show=False, on_done=None):
        state = st.get("state")
        vk = self.cfg["vk"]
        if state == "ok":
            name = st.get("name") or vk.get("account_name") or ""
            if not vk.get("login_ok") or (name and name != vk.get("account_name")):
                log.info("Вход ВК в программе выполнен%s", f": {name}" if name else "")
                vk.update(login_ok=True, account_name=name)
                self.save_config(quiet=True)
            self.job.clear_hold()
            self.vk_need_lbl.hide()
        elif state == "logged_out" and st.get("confirmed_logout") and self.browser.view_loaded:
            # только настоящая проверка загруженной страницы ВК: видна форма входа и нет cookie сессии
            self._forget_login("на странице ВК форма входа, cookie сессии нет")
        elif state == "logged_out":
            log.debug("Проверка входа: признаков входа не видно, но и формы входа нет — сохранённый вход оставляю")
        self._update_login_label(st.get("name"))
        self.refresh_chat_line()
        if show:
            msgs = {"ok": "✔ Вы вошли" + (f" как {st.get('name')}" if st.get("name") else ""),
                    "blocked": "ВК ограничил страницу — следуйте указаниям ВК на странице.",
                    "captcha": "ВК просит пройти проверку («Я не робот») — пройдите её на странице."}
            QMessageBox.information(self, "Вход ВК", msgs.get(state, "Вы не вошли. Войдите в ВК на странице."))
        if self.wizard:
            self.wizard.on_login(st)
        if on_done:
            on_done(st)

    def debug_send(self, with_pictures=False):
        """Settings → «Проверить отправку по шагам» (кнопку «Отправить» не нажимает)."""
        if self.browser.busy or self.job.lock.locked():
            QMessageBox.information(self, APP_NAME, "Сейчас идёт отправка — попробуйте через минуту.")
            return
        vk = self.cfg["vk"]
        if not vk.get("peer_id"):
            QMessageBox.information(self, APP_NAME, "Сначала выберите беседу (мастер настройки).")
            return
        paths = latest_shots(resolve_path(self.cfg["storage"]["screenshots_dir"]))[-2:] if with_pictures else None
        if with_pictures and not paths:
            QMessageBox.information(self, APP_NAME, "Скриншотов ещё нет — проверю без картинок.")
        self.show_section("vk")
        log.info("Проверка отправки по шагам (без отправки)")

        def done(rep, err):
            lines = list(rep or [])
            if err is not None:
                lines.append("✖ " + humanize(err))
            QMessageBox.information(self, "Проверка отправки по шагам",
                                    "\n".join(lines[-14:]) or "Готово. Подробности — в журнале.")
        self.browser.run_flow(self.browser.flows().debug_send(vk["peer_id"], paths, vk.get("peer_title") or ""),
                              done, work=False, deadline=150)

    def refresh_chat_line(self):
        vk = self.cfg["vk"]
        if vk.get("sender") != "group_api":
            who = f"Отправляет: {vk.get('account_name') or 'ваш профиль ВК'} — через браузер программы"
            self.chat_lbl.setText(f"Беседа: {vk.get('peer_title') or vk.get('peer_id')}\n{who}")

    def on_needs_user(self, text):
        """ВК чего-то хочет от человека: показываем страницу и объясняем, что сделать."""
        log.warning("Нужно ваше действие: %s", text)
        self.vk_need_lbl.setText("Нужно ваше действие: " + text)
        self.vk_need_lbl.show()
        if self.wizard:
            self.show_window()
            return
        self.show_section("vk")
        if self.tray:
            self.tray.showMessage(APP_NAME, ("Нужно ваше действие: " + text)[:250],
                                  QSystemTrayIcon.MessageIcon.Warning)

    # ================= съёмка: наше окно не должно попасть в кадр =================
    def _capture_hook(self, on):
        """Из рабочего потока перед/после съёмки."""
        try:
            self.gui(lambda: self._exclude(on), wait=5)
        except Exception:  # noqa: BLE001
            log.debug("capture hook", exc_info=True)

    def _exclude(self, on):
        if on:
            self.hide_countdown()    # окошко отсчёта — никогда не в кадре
        al = getattr(self, "sent_alert", None)   # 2.2.2: тревога — тоже никогда не в кадре
        if al is not None:
            if on and al.isVisible() and not exclude_from_capture(al, True):
                al._hidden_for_capture = True
                al.hide()
            elif not on and getattr(al, "_hidden_for_capture", False):
                al._hidden_for_capture = False
                al.show()
        if not self.isVisible() and not self._hidden_for_capture:
            return
        if on:
            if not exclude_from_capture(self, True):
                self._hidden_for_capture = True  # старая Windows: просто прячем окно на время съёмки
                self.hide()
                QApplication.processEvents()
        else:
            exclude_from_capture(self, False)
            if self._hidden_for_capture:
                self._hidden_for_capture = False
                self.showNormal()

    def hide_for_capture(self):
        """Для «Обвести кнопку»: окно убираем совсем, чтобы не мешало выделять."""
        self._was_visible = self.isVisible()
        self.hide()
        QApplication.processEvents()

    def show_after_capture(self):
        if getattr(self, "_was_visible", True):
            self.show_window()

    # ================= действия =================
    def _file_mtime(self):
        try:
            return os.stat(self.cfg_path).st_mtime_ns if self.cfg_path else None
        except OSError:
            return None

    def _write_cfg(self):
        save_config(self.cfg, self.cfg_path)
        self._cfg_mtime = self._file_mtime()   # своя запись — не «изменение снаружи»

    def check_config_file(self):
        """2.1.5: config.yaml поменяли в Блокноте, пока программа работает, — перечитать сразу
        (раньше правка не действовала до перезапуска и затиралась при следующем сохранении)."""
        m = self._file_mtime()
        if m is None or m == self._cfg_mtime:
            return False
        self._cfg_mtime = m
        try:
            new = load_config(self.cfg_path)
            migrate(new)
            errors = validate(new)
        except Exception as e:  # noqa: BLE001
            log.warning("config.yaml изменён, но не читается — оставляю прежние настройки: %s", e)
            return False
        if errors:
            log.warning("config.yaml изменён, но с ошибками — оставляю прежние настройки: %s", "; ".join(errors))
            return False
        self.cfg.clear()
        self.cfg.update(new)          # тот же словарь: окно настроек, планировщик и съёмка видят новое сразу
        log.info("config.yaml изменён — новые настройки применены")
        try:
            self.page_settings.load()
            self.refresh()
        except Exception:  # noqa: BLE001
            log.debug("перечитать настройки", exc_info=True)
        return True

    def save_config(self, quiet=False):
        self._write_cfg()
        if not quiet:
            log.info("Настройки сохранены")
            if self.cfg["schedule"].get("enabled", True) and is_configured(self.cfg):
                self.scheduler.start()
            self.refresh()

    def toggle(self):
        if self.scheduler.running:
            self.stop_schedule()
        else:
            self.start_schedule()

    def start_schedule(self):
        if not is_configured(self.cfg):
            self.open_wizard()
            return
        self.cfg["schedule"]["enabled"] = True
        self.scheduler.start()
        self._write_cfg()
        log.info("Расписание запущено")
        self._update_status()

    def stop_schedule(self):
        self.cfg["schedule"]["enabled"] = False
        self.scheduler.stop()
        self.prewarm_state = None
        if self.browser.warm and not self.browser._busy:
            self.browser._drop_work_view()
        self._write_cfg()
        log.info("Расписание остановлено")
        self._update_status()

    def send_now(self, send=True):
        if send and not is_configured(self.cfg):
            self.open_wizard()
            return
        if self.busy or self.job.lock.locked():
            return
        self._set_busy(True)
        threading.Thread(target=lambda: self.job.run_cycle(send, manual=True), name="manual", daemon=True).start()

    def _has_latest_shots(self):
        try:
            return bool(self.job.latest_paths(self.cfg))
        except Exception:  # noqa: BLE001
            return False

    def resend_latest(self):
        """2.2.1: «Отправить последние скрины» — без нового съёма, тот же путь отправки и проверки."""
        if not is_configured(self.cfg):
            self.open_wizard()
            return
        log.info("Нажата кнопка «Отправить последние скрины»")
        if self.busy or self.job.lock.locked():
            log.warning("«Отправить последние скрины»: сейчас идёт другая отправка или съёмка — подождите")
            self._resend_feedback("⏳ Сейчас идёт другая отправка — нажмите позже", None)
            return
        if not self._has_latest_shots():
            log.warning("«Отправить последние скрины»: в папке скриншотов нет последних снимков")
            self._resend_feedback("Снимков пока нет — сначала «Отправить сейчас»", None)
            return
        self._set_busy(True)
        # 3.0.4: видно, что кнопка сработала: надпись на кнопке и строка «Последняя отправка»
        self._resend_feedback("⏳ Отправляю последние скрины в беседу…", "Отправляю…")
        log.info("«Отправить последние скрины»: запускаю отправку")
        threading.Thread(target=self.job.resend_latest, name="resend", daemon=True).start()

    def _resend_feedback(self, text, button=None, restore_ms=0):
        try:
            if text:
                self.last_lbl.setText(text)
            btn = getattr(self, "resend_btn", None)
            if btn is not None and button:
                btn.setText(button)
                if restore_ms:
                    QTimer.singleShot(restore_ms, lambda: btn.setText(RESEND_TEXT))
        except Exception:  # noqa: BLE001
            log.debug("resend feedback", exc_info=True)

    def open_shots(self):
        path = resolve_path(self.cfg["storage"]["screenshots_dir"])
        os.makedirs(path, exist_ok=True)
        open_path(path)

    def open_log(self):
        path = resolve_path(self.cfg["storage"]["log_file"])
        if os.path.exists(path):
            open_path(path)

    def run_bg(self, fn, done=None, fail=None, source=None):
        """Фоновая задача; ошибка — понятным текстом в окне."""
        def default_fail(err):
            log.error("%s", err)
            QMessageBox.warning(self, APP_NAME, humanize(err, source))
        return Task(fn, done, fail or default_fail)

    # ================= мастер =================
    def open_wizard(self):
        self.show_window()
        if self.wizard:
            return
        from .wizard import WizardWidget
        self.wizard = WizardWidget(self)
        self.wizard_holder.layout().addWidget(self.wizard)
        self.outer.setCurrentIndex(1)

    def close_wizard(self, finished=False):
        if not self.wizard:
            return
        self.wizard.stop()
        self.restore_view()
        self.outer.setCurrentIndex(0)
        self.wizard.setParent(None)
        self.wizard.deleteLater()
        self.wizard = None
        self.page_settings.load()
        self.refresh()
        if finished:
            self.start_schedule()
            self.nav.setCurrentRow(0)

    # ================= трей, показ и закрытие =================
    def _setup_tray(self):
        self.tray = QSystemTrayIcon(app_icon(), self)
        self.tray.setToolTip(APP_NAME)
        menu = self.tray_menu = self._build_tray_menu()
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(lambda reason: self.show_window()
                                    if reason in (QSystemTrayIcon.ActivationReason.Trigger,
                                                  QSystemTrayIcon.ActivationReason.DoubleClick) else None)
        self.tray.show()

    def _build_tray_menu(self):
        menu = QMenu()
        a_open = QAction("Открыть", self)
        a_open.triggered.connect(self.show_window)
        self.tray_toggle = QAction("Старт", self)
        self.tray_toggle.triggered.connect(self.toggle)
        a_send = QAction("Отправить сейчас", self)
        a_send.triggered.connect(lambda: self.send_now(True))
        a_about = QAction("О программе", self)
        a_about.triggered.connect(self.show_about)
        a_quit = QAction("Выход", self)
        a_quit.triggered.connect(self.quit)
        self.tray_resend = QAction("Отправить последние скрины", self)
        self.tray_resend.triggered.connect(self.resend_latest)
        # 3.0.1: остановить запись сценария съёмки (видно только во время записи)
        self.tray_stop_rec = QAction("Остановить запись", self)
        self.tray_stop_rec.triggered.connect(self.stop_recording)
        self.tray_stop_rec.setVisible(False)
        menu.addAction(self.tray_stop_rec)
        for a in (a_open, self.tray_toggle, a_send, self.tray_resend):
            menu.addAction(a)
        menu.addSeparator()
        self.add_skip_action(menu, None)
        menu.addSeparator()
        menu.addAction(a_about)
        menu.addAction(a_quit)
        return menu

    def stop_recording(self):
        rec = getattr(self, "active_recorder", None)
        if rec is not None:
            rec.finish("tray")

    def about_html(self):
        """«О программе»: «Как работает» по текущим настройкам, версия, авторы (помощник — мельче)."""
        return about_html(self.cfg)

    def show_about(self):
        self.make_about_box().exec()

    def make_about_box(self):
        box = QMessageBox(self)
        box.setWindowTitle("О программе")
        box.setIcon(QMessageBox.Icon.Information)
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setText(self.about_html())
        # 2.2.4: краткое описание всех функций — docs/Как работает программа.md рядом с программой
        doc = os.path.join(os.path.dirname(base_dir()), "docs", "Как работает программа.md")
        if os.path.exists(doc):
            b = box.addButton("Как работает программа", QMessageBox.ButtonRole.ActionRole)
            try:
                b.clicked.disconnect()          # не закрывать «О программе» по этой кнопке
            except (RuntimeError, TypeError):
                pass
            b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(doc)))
        box.addButton(QMessageBox.StandardButton.Ok)
        return box

    def show_window(self):
        if self.isMinimized():
            self.showNormal()
        self.show()
        self.raise_()
        self.activateWindow()
        self.update_view_memory()

    def changeEvent(self, e):  # noqa: N802
        super().changeEvent(e)
        from PySide6.QtCore import QEvent
        if e.type() == QEvent.Type.WindowStateChange:
            QTimer.singleShot(0, self.update_view_memory)
        elif e.type() == QEvent.Type.ActivationChange and self.isActiveWindow():
            self.follow_system_theme()

    def follow_system_theme(self):
        """Тема «Как в Windows»: если в Windows переключили светлый/тёмный режим — подхватить (при активации окна)."""
        if theme.STATE.get("mode") == "system" and theme.resolve("system") != theme.P.get("name"):
            theme.apply()

    def closeEvent(self, e):  # noqa: N802
        if self.quitting:
            e.accept()
            return
        self.save_window_state()
        if self.tray:
            e.ignore()
            self.hide()
            self.update_view_memory()
            log.info("Окно скрыто в трей — программа продолжает работать")
            if not self._tray_hint_shown:
                self._tray_hint_shown = True
                self.tray.showMessage(APP_NAME, "Программа работает в фоне. Значок — возле часов.",
                                      QSystemTrayIcon.MessageIcon.Information, 4000)
            return
        ans = QMessageBox.question(self, "Выход", "Закрыть программу? Скриншоты перестанут отправляться.\n"
                                                  "(Нет — свернуть окно)")
        if ans == QMessageBox.StandardButton.Yes:
            e.ignore()
            self.quit()
        else:
            e.ignore()
            self.showMinimized()

    def quit(self):
        if self.quitting:
            return
        self.quitting = True
        log.info("Выход из программы")
        self.save_window_state()
        try:
            self.page_settings.flush_live()     # ползунки, сдвинутые за полсекунды до выхода
        except Exception:  # noqa: BLE001
            log.debug("flush_live", exc_info=True)
        self.scheduler.stop()
        self.job.stop_event.set()
        self.timer.stop()
        self.stop_services()
        if self.wizard:
            self.wizard.stop()
        release_all("exit")
        if self.tray:
            self.tray.hide()
        if self.countdown is not None:
            self.countdown.stop()
        set_browser(None)
        self.close()
        try:
            self.browser.close()
        except Exception:  # noqa: BLE001
            log.exception("Закрытие браузера")
        QApplication.quit()


def capture_button(main, source, on_done):
    """«Обвести кнопку»: прячем окно, показываем программу-источник, даём выделить кнопку.
    on_done(PIL.Image | None, ошибка | None) — в потоке окна."""
    from .capture import CaptureOverlay, find_source_window, prepare_capture
    main.hide_for_capture()

    def fail(err):
        main.show_after_capture()
        on_done(None, err)

    def ready(res):
        rect, shot = res
        ov = CaptureOverlay(shot, rect)
        main._overlay = ov

        def finished(img):
            main._overlay = None
            main.show_after_capture()
            on_done(img, None)
        ov.finished.connect(finished)
        ov.open()
    Task(lambda: prepare_capture(main.backend_factory(), source, find_source_window), ready, fail, "capture")
