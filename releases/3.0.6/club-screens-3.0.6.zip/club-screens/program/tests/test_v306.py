# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.6: разбор отправки 01.11 00:00 на компьютере клуба.
Попытка 1: вторая картинка не загрузилась (ВК: li.ComposerAttaches__itemLoading + Loader--retry «Повторить
попытку»), а программа сочла её загруженной и нажала «Отправить» — ВК повис в «Сообщение обрабатывается».
Попытка 2 дошла, но подтверждение ВК пришло позже 20 с — цикл ошибочно считался неудачным.
Проверка :07 — превью не скачались (ReadTimeout) → ложная тревога."""
import copy
import os
import unittest
from datetime import datetime
from unittest import mock

from app import vk_browser
from app.config import DEFAULTS
from app.vk_browser import DeliveryUnconfirmed, merged_settings
from tests.test_login_detect import run_script


def drive(gen):
    """Мини-исполнитель шагов Flows на виртуальном времени: → (результат, время)."""
    t, val = 0.0, None
    try:
        op = next(gen)
        while True:
            if op[0] == "clock":
                val = t
            elif op[0] == "sleep":
                t += float(op[1])
                val = None
            else:
                val = None
            op = gen.send(val)
    except StopIteration as e:
        return e.value, t


def flows(js, probe=None, s=None):
    fl = vk_browser.Flows.__new__(vk_browser.Flows)
    fl.s = merged_settings(s or {})
    fl.last_own_msg = None
    fl.calls = []

    def _js(name, **k):
        fl.calls.append(name)
        return js(name, k)
        yield

    def _probe(keys, box=None):
        return probe() if probe else {"c": {}}
        yield
    fl.js, fl.probe = _js, _probe
    return fl


class RealDom(unittest.TestCase):
    """Настоящий Qt WebEngine, разметка — как в разборе ВК 01.11 00:00 (обезличенный фрагмент)."""

    @classmethod
    def setUpClass(cls):
        cls.r = run_script("send_probe.py", timeout=120)

    def test_loading_item_without_testid_is_loading(self):
        self.assertEqual(self.r["itemloading"]["att"]["items"], ["ok", "loading"])

    def test_retry_loader_is_error(self):
        self.assertEqual(self.r["itemretry"]["att"]["items"], ["ok", "error"])

    def test_processing_button_is_busy_and_in_area(self):
        st = self.r["busy"]["send"]
        self.assertEqual((st["found"], st["in_box"], st["busy"]), (True, True, True))
        # раньше кнопка «--loading» отбрасывалась как микрофон, и «кнопкой» становилась чужая вне области
        self.assertIn("в области", self.r["busy"]["diag"]["matched"]["send_button"])

    def test_ready(self):
        self.assertEqual(self.r["ready"]["att"]["items"], ["ok", "ok"])
        self.assertFalse(self.r["ready"]["send"]["busy"])


class ClickWaits(unittest.TestCase):
    def test_settle_then_waits_for_button(self):
        st = {"t": 0}

        def js(name, a):
            if name == "send_state":
                st["t"] += 1
                return {"found": True, "in_box": True, "busy": st["t"] < 5}
            if name == "click_send":
                return "clicked"
            if name == "composer_state":
                return {"prev": 0, "text": 0, "composer": True}
            return None
        fl = flows(js)
        r, t = drive(fl.click_send(0))
        self.assertEqual(r, "button")
        self.assertGreaterEqual(t, 2.5 + 4 * 0.5)       # пауза после загрузки + ожидание кнопки
        self.assertLess(fl.calls.index("send_state"), fl.calls.index("click_send"))
        self.assertNotIn("enter", fl.calls)

    def test_processing_after_click_no_enter(self):
        def js(name, a):
            if name == "send_state":
                return {"found": True, "busy": "click_send" in fl.calls}
            if name == "click_send":
                return "clicked"
            if name == "composer_state":
                return {"prev": 2, "text": 0, "composer": True}
            return None
        fl = flows(js)
        r, _ = drive(fl.click_send(0))
        self.assertEqual(r, "button")
        self.assertNotIn("enter", fl.calls)


class AckPending(unittest.TestCase):
    def _fl(self, ok_after):
        now = datetime.now()
        tm = now.hour * 60 + now.minute
        st = {"n": 0}

        def js(name, a):
            if name == "hour_photos":
                st["n"] += 1
                ok = st["n"] * 0.7 >= ok_after
                img = {"src": "https://x/1.jpg"}
                return {"msgs": [{"own": True, "t": tm, "imgs": [img, img], "st": "ok" if ok else "pending"}]}
            return None
        return flows(js, probe=lambda: {"c": {"attachment_preview": 0}})

    def test_slow_server_ack_waited(self):
        r, t = drive(self._fl(35).verify(None, 2))       # 01.11 00:02: подтверждение пришло позже 20 с
        self.assertEqual(r, "verified")
        self.assertGreater(t, 20)

    def test_gives_up_after_max(self):
        with self.assertRaises(DeliveryUnconfirmed):
            drive(self._fl(999).verify(None, 2))


class FreshCheckAfterUnconfirmed(unittest.TestCase):
    def make(self, vk):
        import shutil
        import tempfile
        from app.job import JobRunner
        from tests.test_steps_job import FakeBackend
        root = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, root, True)
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["peer_id"] = 2000000001
        cfg["schedule"]["attempts"] = 2
        job = JobRunner(lambda: cfg, lambda: FakeBackend(), vk_factory=lambda c: vk, root=root,
                        now=lambda: datetime(2026, 11, 1, 0, 0), sleep=lambda s: None)
        job.online = lambda: True
        return job

    def test_found_later_counts_as_sent(self):
        from tests.test_steps_job import FakeVK

        class VK(FakeVK):
            sends = 0
            checks = 0

            def send_photos(self, *a):
                VK.sends += 1
                raise DeliveryUnconfirmed()

            def already_sent(self, *a, **k):
                VK.checks += 1
                return VK.checks >= 2, "своё сообщение, сходство 1.00/1.00"   # перед повтором — нет, после — есть
        job = self.make(VK())
        self.assertTrue(job.run_cycle())
        self.assertEqual(VK.sends, 2)
        self.assertTrue(job.last_result.get("sent"))
        self.assertFalse(job.last_result.get("send_error"))


class PreviewDownloadRetry(unittest.TestCase):
    def test_retries_timeout(self):
        import requests

        from app import dupcheck
        resp = mock.Mock(content=b"img")
        resp.raise_for_status = lambda: None
        with mock.patch("requests.get", side_effect=[requests.ReadTimeout(), resp]) as g, \
                mock.patch("app.dupcheck.time.sleep"):
            self.assertEqual(dupcheck._download("https://x"), b"img")
        self.assertEqual(g.call_count, 2)
        self.assertGreater(g.call_args_list[1].kwargs["timeout"], g.call_args_list[0].kwargs["timeout"])


if __name__ == "__main__":
    unittest.main()


class Steering4(unittest.TestCase):
    def test_hourdone_frozen(self):
        import tempfile
        from app import hourdone
        root = tempfile.mkdtemp(); h = datetime(2026, 11, 1, 0)
        a = [os.path.join(root, n) for n in ("a.png", "b.png")]
        for f in a:
            open(f, "wb").write(b"x")
        hourdone.mark(root, h, hourdone.PROGRAM, paths=a)
        hourdone.mark(root, h, hourdone.MANUAL, paths=[os.path.join(root, "n1.png"), os.path.join(root, "n2.png")])
        self.assertEqual(hourdone.done(root, h), "program")
        self.assertEqual(sorted(hourdone.sent_paths(root, h)), sorted(a))

    def test_clock_skew(self):
        from app import dupcheck
        self.assertTrue(dupcheck._in_hour(23 * 60 + 59, 0, 59, True, False))
        self.assertFalse(dupcheck._in_hour(23 * 60 + 58, 0, 59, True, False))
        self.assertTrue(dupcheck._in_hour(60, 0, 59, False, True))
        self.assertFalse(dupcheck._in_hour(61, 0, 59, False, True))

    def test_recorder_waits_crops(self):
        import tempfile, threading, time as _t
        from app import recorder
        r = recorder.Recorder.__new__(recorder.Recorder)
        d = tempfile.mkdtemp(); r.crops = {}; r.events = []
        p = os.path.join(d, "step01.png")
        def slow():
            _t.sleep(0.6); open(p, "wb").write(b"x"); r.crops[0] = p
        th = threading.Thread(target=slow); r._crop_threads = [th]; th.start()
        r.crops[1] = os.path.join(d, "missing.png")
        with mock.patch.object(recorder, "events_to_steps", lambda ev, cr: cr):
            self.assertEqual(r.steps(), {0: p})


class BookingPhoto(unittest.TestCase):
    """3.0.6: каждый час перед Oasys — фото экрана «состояние брони» и Esc; фото не уходит в ВК."""

    def test_photo_then_esc_and_excluded(self):
        import tempfile
        from app import job as jobmod
        from tests.test_steps_job import FakeBackend
        root = tempfile.mkdtemp()
        cfg = {"storage": {"screenshots_dir": root}}
        j = jobmod.JobRunner(lambda: cfg, None, root=root)
        b = FakeBackend()
        b.grab_screen = lambda: b.grab(b.virtual_screen())
        with mock.patch.object(jobmod.time, "sleep", lambda s: None):
            j._booking_photo(cfg, b, {"name": "Oasys", "window": {"title_regex": "Oasys"}}, 1, "2026-11-01_00-00")
        kinds = [a[0] for a in b.actions]
        self.assertEqual(kinds[0], "grab")
        self.assertEqual([a for a in b.actions if a[0] == "press"], [("press", "esc")] * 2)
        bron = j.booking_photo
        self.assertTrue(os.path.isfile(bron) and jobmod.is_booking_photo(bron))
        shot = os.path.join(root, "2026-11-01_00-00_11_Oasys.png")
        open(shot, "wb").write(b"x")
        self.assertEqual(jobmod.latest_shots(root), [shot])
        self.assertEqual(jobmod.booking_photo_for([shot]), bron)
        from app.cleanup import shot_stamp
        self.assertTrue(shot_stamp(os.path.basename(bron)))   # обычная очистка его видит
