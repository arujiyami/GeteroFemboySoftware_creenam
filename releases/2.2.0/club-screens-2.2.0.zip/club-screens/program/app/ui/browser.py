# Original-Author: Владислав С.
# Created: 2026-10-28
"""Встроенный браузер программы: один постоянный профиль ВК и одна страница на всю программу.

* Профиль хранится в program\\browser_profile (куки, хранилище, кэш) — вход сохраняется между запусками.
  Это ваш вход во ВКонтакте: не передавайте папку browser_profile.
* Строка браузера (user agent) — стандартная Qt WebEngine, никаких «маскировок».
* Отправка выполняется сценариями app/vk_browser.Flows: здесь только «исполнитель» их операций.
* Память (vk_browser.save_memory, «Экономить память», по умолчанию да): страницы создаются только
  когда нужны. Видимая — когда вы открыли раздел «ВКонтакте» или шаг мастера «Вход ВК»; уходите
  из раздела или прячете окно в трей — страница выгружается. Рабочая — на время отправки (или
  загрузки списка бесед) и сразу закрывается, процесс страницы завершается. Без страниц программа
  почти не занимает памяти. Профиль (вход, cookie) живёт всё время — это только файлы.
* Две страницы на одном профиле (вход общий):
  - view/page — то, что вы видите в разделе «ВКонтакте» и в мастере;
  - work_view/work_page — «рабочая» страница для отправки и списка бесед. Она живёт в отдельном
    маленьком окне без рамки за пределами экрана: для Chromium оно всегда «видно» (страница
    рисуется, таймеры не засыпают), а вам — нет. Окно не берёт фокус, не попадает на панель
    задач и на снимки экрана. Поэтому отправка идёт полностью в фоне — мышь и клавиатура не нужны,
    окно программы может быть спрятано в трей."""
import json
import logging
import os
import threading
import time

from PySide6.QtCore import QEvent, QObject, QPoint, QPointF, Qt, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QMouseEvent
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineScript, QWebEngineSettings
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QSizePolicy

from ..config import resolve_path
from .zoomfit import MANUAL_STEPS, ZoomFitter
from ..logincheck import LOGOUT_DEBOUNCE_SEC, CookieTracker
from ..vk_browser import (BrowserUnavailable, Flows, decode_js_result, merged_settings, rotate_shots)

log = logging.getLogger("club")

CHROMIUM_FLAGS = ("--disable-background-timer-throttling --disable-renderer-backgrounding "
                  "--disable-backgrounding-occluded-windows --disable-features=CalculateNativeWinOcclusion")
# «Экономить память» (vk_browser.save_memory, по умолчанию да): один процесс страниц на всё, без видеокарты
LOW_MEMORY_FLAGS = "--renderer-process-limit=1 --disable-gpu --disable-extensions --disable-spell-checking"
HTTP_CACHE_MB = 50
JS_TIMEOUT_SEC = 20
WORK_SIZE = (1280, 900)
WORK_POS = (-32000, -32000)  # за пределами всех мониторов
VK_HOSTS = ("vk.com", "vk.ru", "vk.me", "vkontakte.ru")


def chromium_flags(existing="", save_memory=True, light=False):
    """Флаги Chromium: страница не «засыпает», когда окно скрыто (нужно для отправки из трея);
    save_memory — ещё и ограничения памяти (LOW_MEMORY_FLAGS); light — «Лёгкий режим» (app/lightmode.py)."""
    from ..lightmode import LIGHT_FLAGS
    have = existing.split()
    want = CHROMIUM_FLAGS.split() + (LOW_MEMORY_FLAGS.split() if save_memory else []) + \
        (LIGHT_FLAGS.split() if light else [])
    add = [f for f in dict.fromkeys(want) if f not in have]
    out = []
    for f in have + add:  # несколько --disable-features=… склеиваем в один
        if f.startswith("--disable-features=") and any(o.startswith("--disable-features=") for o in out):
            i = next(i for i, o in enumerate(out) if o.startswith("--disable-features="))
            feats = out[i].split("=", 1)[1].split(",") + f.split("=", 1)[1].split(",")
            out[i] = "--disable-features=" + ",".join(dict.fromkeys(x for x in feats if x))
        else:
            out.append(f)
    return " ".join(out).strip()


def is_vk_host(host):
    host = (host or "").lstrip(".").lower()
    return any(host == h or host.endswith("." + h) for h in VK_HOSTS)


class VKPage(QWebEnginePage):
    """Страница ВК: подставляет наши файлы в окно выбора файла, не открывает новых окон."""

    def __init__(self, profile, parent=None):
        super().__init__(profile, parent)
        self.armed_files = None
        self.files_taken = False

    def chooseFiles(self, mode, old_files, accepted_mime_types):  # noqa: N802 (Qt)
        if self.armed_files:
            files = list(self.armed_files)
            if mode == QWebEnginePage.FileSelectionMode.FileSelectOpen:
                files = files[:1]
            self.files_taken = True
            self.armed_files = None
            log.debug("Окно выбора файла: подставлены %d файл(а)", len(files))
            return files
        return super().chooseFiles(mode, old_files, accepted_mime_types)

    def createWindow(self, _type):  # noqa: N802 (Qt) — ссылки «в новом окне» открываем здесь же
        return self

    def javaScriptConsoleMessage(self, level, message, line, source):  # noqa: N802 (Qt)
        if level == QWebEnginePage.JavaScriptConsoleMessageLevel.ErrorMessageLevel and "club" in message:
            log.debug("JS: %s", message[:300])


class FlowRunner(QObject):
    """Выполняет сценарий-генератор (Flows) асинхронно в потоке окна, без блокировки интерфейса."""

    def __init__(self, browser, gen, on_done, work=True, deadline=None, on_deadline=None):
        super().__init__(browser)
        self.b, self.gen, self.on_done = browser, gen, on_done
        self.page = browser.work_page if work else browser.page
        self.view = browser.work_view if work else browser.view
        self.work = work
        self._token = 0
        self._finished = False
        self.deadline, self.on_deadline = deadline, on_deadline

    def start(self):
        if self.deadline:
            QTimer.singleShot(int(float(self.deadline) * 1000), self._expired)
        self._step(None, None)

    def _expired(self):
        """Общий тайм-аут: в сценарий «бросается» ошибка — он сохраняет сведения и завершается."""
        if self._finished:
            return
        exc = self.on_deadline() if self.on_deadline else TimeoutError("тайм-аут сценария")
        log.warning("Сценарий не уложился в %s с — прерываю", self.deadline)
        self.cancel(exc)
        # если сценарий «завис» и в своём обработчике — через 15 с завершаем принудительно
        QTimer.singleShot(15000, lambda: (not self._finished) and self._finish(None, exc))

    def cancel(self, exc):
        self._resume(None, exc, self._token)

    def _resume(self, value, error, token):
        if token != self._token or self._finished:
            return  # устаревший ответ (тайм-аут уже сработал)
        self._token += 1
        self._step(value, error)

    def _step(self, value, error):
        try:
            op = self.gen.throw(error) if error is not None else self.gen.send(value)
        except StopIteration as e:
            return self._finish(e.value, None)
        except Exception as e:  # noqa: BLE001
            return self._finish(None, e)
        token = self._token
        try:
            self._do(op, token)
        except Exception as e:  # noqa: BLE001
            QTimer.singleShot(0, lambda err=e: self._resume(None, err, token))

    def _finish(self, result, error):
        self._finished = True
        self.on_done(result, error)
        self.deleteLater()

    def _later(self, value, token, ms=0):
        QTimer.singleShot(int(ms), lambda: self._resume(value, None, token))

    def _do(self, op, token):
        b, kind = self.b, op[0]
        if kind == "sleep":
            return self._later(None, token, max(0.0, float(op[1])) * 1000)
        if kind == "clock":
            return self._later(time.monotonic(), token)
        if kind == "cookies":
            log.debug("Cookie ВК по доменам (только имена): %s", b.cookie_jar.names_by_domain())
            return self._later(dict(b.cookies), token)
        if kind == "visible":
            return self._later(b.view_visible(self.view), token)
        if kind == "arm_files":
            self.page.armed_files = list(op[1]) if op[1] else None
            if op[1]:
                self.page.files_taken = False
            return self._later(None, token)
        if kind == "files_taken":
            return self._later(bool(self.page.files_taken), token)
        if kind == "click_real":
            return self._later(b.real_click(op[1], op[2], self.view), token)
        if kind == "shot":
            return self._later(b.save_shot(op[1], self.view), token)
        if kind == "save_text":
            return self._later(b.save_text(op[1], op[2]), token)
        if kind == "log":
            log.info("%s", op[1])
            return self._later(None, token)
        if kind == "load":
            return self._load(op[1], float(op[2] or 45), token)
        if kind == "js":
            return self._js(op[1], token)
        raise ValueError(f"неизвестная операция {kind}")

    def _load(self, url, timeout, token):
        page = self.page
        state = {"done": False}

        def finished(ok):
            if state["done"]:
                return
            state["done"] = True
            try:
                page.loadFinished.disconnect(finished)
            except (RuntimeError, TypeError):
                pass
            self._resume(bool(ok), None, token)

        page.loadFinished.connect(finished)
        QTimer.singleShot(int(timeout * 1000), lambda: finished(False))
        page.load(QUrl(url))

    def _js(self, code, token):
        state = {"done": False}

        def callback(raw):
            if state["done"]:
                return
            state["done"] = True
            self._resume(decode_js_result(raw), None, token)

        QTimer.singleShot(JS_TIMEOUT_SEC * 1000, lambda: callback(None))
        self.page.runJavaScript(code, QWebEngineScript.ScriptWorldId.ApplicationWorld, callback)


class VKBrowser(QObject):
    """Единственный браузер программы (профиль + страница + вид)."""

    loginChanged = Signal(bool)       # появился/пропал вход (куки remixsid); пропажа — с задержкой 10 с
    loggedOut = Signal()              # ВК точно показал страницу/форму входа (не по cookie)
    needsUser = Signal(str)           # «Нужно ваше действие» — текст для человека
    _request = Signal(object)         # из рабочего потока → поток окна
    zoomPrefChanged = Signal(float)   # масштаб выбрали кнопками (0 — «По размеру окна»), чтобы запомнить

    def __init__(self, cfg_getter, parent=None):
        super().__init__(parent)
        self.cfg_getter = cfg_getter
        s = self.settings()
        self.profile_dir = resolve_path(s.get("profile_dir") or "browser_profile")
        os.makedirs(self.profile_dir, exist_ok=True)
        self.profile = QWebEngineProfile("club-vk", self)
        self.profile.setPersistentStoragePath(os.path.join(self.profile_dir, "storage"))
        self.profile.setCachePath(os.path.join(self.profile_dir, "cache"))
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        from ..lightmode import active as light_active
        if light_active():      # «Лёгкий режим»: маленький кэш в памяти вместо 50 МБ на диске
            self.profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.MemoryHttpCache)
            self.profile.setHttpCacheMaximumSize(8 * 1024 * 1024)
        else:
            self.profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
            self.profile.setHttpCacheMaximumSize(HTTP_CACHE_MB * 1024 * 1024)
        try:
            self.profile.setSpellCheckEnabled(False)
        except Exception:  # noqa: BLE001
            pass
        if (s.get("user_agent") or "").strip():
            self.profile.setHttpUserAgent(s["user_agent"].strip())
        # cookie ВК по (домену, имени, пути) — с самого запуска профиля; значения не храним
        self.cookie_jar = CookieTracker()
        self._logout_timer = QTimer(self)
        self._logout_timer.setSingleShot(True)
        self._logout_timer.timeout.connect(self._confirm_logout)
        self._logged = None
        store = self.profile.cookieStore()
        store.cookieAdded.connect(self._cookie_added)
        store.cookieRemoved.connect(self._cookie_removed)
        store.loadAllCookies()

        self.fitter = None
        self.page = self.view = None              # видимая страница — по требованию (ensure_view)
        self.work_page = self.work_view = self.work_host = None  # рабочая — на время сценария
        self._pending_url = None
        from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget
        self.holder = QWidget()                  # постоянное место видимой страницы в окне
        self.holder.setMinimumSize(320, 240)
        hl = QVBoxLayout(self.holder)
        hl.setContentsMargins(0, 0, 0, 0)
        self.placeholder = QLabel("Страница ВКонтакте загружается…")
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder.setObjectName("muted")
        hl.addWidget(self.placeholder, 1)
        self.zoom_pref = 0.0                     # 0 — подгонять по размеру окна; иначе масштаб кнопками
        self._build_zoom_bar(hl)
        self._busy = False
        self._queue = []
        # «Заранее открыта»: фоновая страница с беседой оставлена до ближайшей отправки (см. prewarm)
        self.warm = False
        self._warm_gen = 0
        self._request.connect(self._on_request, Qt.ConnectionType.QueuedConnection)
        self._gui_thread = threading.get_ident()
        if not self.save_memory:
            self.ensure_view()

    @property
    def save_memory(self):
        return bool(self.settings().get("save_memory", True))

    def _make_page(self):
        page = VKPage(self.profile, self)
        st = page.settings()
        A = QWebEngineSettings.WebAttribute
        st.setAttribute(A.JavascriptCanOpenWindows, False)
        st.setAttribute(A.PlaybackRequiresUserGesture, True)
        st.setAttribute(A.FocusOnNavigationEnabled, False)
        for name in ("PluginsEnabled", "PdfViewerEnabled", "WebGLEnabled", "Accelerated2dCanvasEnabled",
                     "AutoLoadIconsForPage", "ScreenCaptureEnabled", "WebRTCPublicInterfacesOnly"):
            attr = getattr(A, name, None)
            if attr is not None:
                st.setAttribute(attr, name == "WebRTCPublicInterfacesOnly")
        try:
            page.featurePermissionRequested.connect(
                lambda url, feature, p=page: p.setFeaturePermission(
                    url, feature, QWebEnginePage.PermissionPolicy.PermissionDeniedByUser))
        except AttributeError:
            pass
        return page

    # ------------------------------------------------------------ видимая страница (по требованию)
    @property
    def view_loaded(self):
        return self.view is not None

    def ensure_view(self):
        """Создать видимую страницу (раздел «ВКонтакте» / мастер), если её нет. Возвращает view."""
        if self.view is not None:
            return self.view
        self.page = self._make_page()
        self.view = QWebEngineView(self.holder)
        self.view.setPage(self.page)
        self.view.setMinimumSize(320, 240)
        self.view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        # 2.1.7: страница входа (с QR-кодом) подгоняется под размер окна, после входа — обычные 100 %
        # 2.1.8: подгонка один раз после загрузки и при изменении размера окна; кнопки «− / 100 % / +»
        self.fitter = ZoomFitter(self.view, self.fit_active, hold=self._flow_holds, manual=self.zoom_pref,
                                 on_zoom=self._show_zoom)
        self.holder.layout().insertWidget(self.holder.layout().indexOf(self.zoom_bar), self.view, 1)
        self.placeholder.hide()
        self.view.show()
        url, self._pending_url = self._pending_url, None
        self.page.load(QUrl(url or self.default_url()))
        log.debug("Страница ВК в окне создана")
        return self.view

    # ------------------------------------------------------------ масштаб страницы (кнопки под ней)
    def _build_zoom_bar(self, layout):
        from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget
        bar = self.zoom_bar = QWidget()
        bar.setObjectName("zoomBar")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(8, 4, 8, 4)
        bl.setSpacing(6)
        cap = QLabel("Масштаб страницы:")
        cap.setObjectName("muted")
        bl.addWidget(cap)

        def btn(text, tip, slot, checkable=False):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.setCheckable(checkable)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(slot)
            bl.addWidget(b)
            return b
        self.zoom_out_btn = btn("−", "Мельче (Ctrl + колесо мыши — тоже можно)", lambda: self.zoom_step(-1))
        self.zoom_out_btn.setFixedWidth(40)
        self.zoom_label = btn("100 %", "Нажмите — обычный масштаб 100 %", lambda: self.set_zoom_pref(1.0))
        self.zoom_label.setMinimumWidth(72)
        self.zoom_in_btn = btn("+", "Крупнее", lambda: self.zoom_step(+1))
        self.zoom_in_btn.setFixedWidth(40)
        self.zoom_fit_btn = btn("По размеру окна", "Программа сама уменьшит страницу входа, чтобы QR-код "
                                "поместился целиком. Подгоняет один раз после загрузки и при изменении окна.",
                                lambda: self.set_zoom_pref(0.0), checkable=True)
        self.zoom_fit_btn.setChecked(True)
        bl.addStretch(1)
        layout.addWidget(bar)

    def _show_zoom(self, z=None):
        if z is None:
            z = self.view.zoomFactor() if self.view is not None else 1.0
        self.zoom_label.setText(f"{round(float(z) * 100)} %")
        self.zoom_fit_btn.setChecked(not self.zoom_pref)

    def zoom_step(self, d):
        cur = self.view.zoomFactor() if self.view is not None else (self.zoom_pref or 1.0)
        if d > 0:
            nxt = next((st for st in MANUAL_STEPS if st > cur + 0.005), MANUAL_STEPS[-1])
        else:
            nxt = next((st for st in reversed(MANUAL_STEPS) if st < cur - 0.005), MANUAL_STEPS[0])
        self.set_zoom_pref(nxt)

    def set_zoom_pref(self, z, emit=True):
        """Масштаб видимой страницы: z > 0 — ровно такой (запоминается), 0 — «По размеру окна»."""
        try:
            z = float(z or 0.0)
        except (TypeError, ValueError):
            z = 0.0
        if z and not (MANUAL_STEPS[0] - 0.001 <= z <= MANUAL_STEPS[-1] + 0.001):
            z = 0.0
        self.zoom_pref = z
        if self.fitter is not None:
            self.fitter.set_manual(z)
        self._show_zoom(z or None)
        if emit:
            self.zoomPrefChanged.emit(z)

    def _flow_holds(self):
        return bool(self._busy and getattr(self, "_flow_on_view", False))

    def fit_active(self):
        """Подгонять масштаб видимой страницы: только пока вход в ВК не выполнен и по ней не идёт сценарий."""
        if self._busy and getattr(self, "_flow_on_view", False):
            return False
        return not self.logged_in

    def refit(self):
        f = getattr(self, "fitter", None)
        if f is not None and self.view is not None:
            f.schedule(0, "refit")

    def unload_view(self):
        """Выгрузить видимую страницу (экономия памяти). Вход сохраняется — он в профиле."""
        if self.view is None or (self._busy and getattr(self, "_flow_on_view", False)):
            return False
        try:
            u = self.view.url().toString()
            if u and u != "about:blank":
                self._pending_url = u
        except RuntimeError:
            pass
        page, view = self.page, self.view
        self.page = self.view = None
        self.fitter = None
        self._dispose(page, view)
        self.placeholder.setText("Страница ВКонтакте выгружена, чтобы не занимать память. "
                                 "Откройте раздел «ВКонтакте» — она загрузится снова.")
        self.placeholder.show()
        log.debug("Страница ВК в окне выгружена (экономия памяти)")
        return True

    @staticmethod
    def _dispose(page, view, host=None):
        """Закрыть страницу: сначала пустой адрес, затем удалить страницу, потом вид (и окно)."""
        try:
            if view is not None:
                view.hide()
            if page is not None:
                try:
                    page.setLifecycleState(QWebEnginePage.LifecycleState.Active)
                except Exception:  # noqa: BLE001
                    pass
                page.triggerAction(QWebEnginePage.WebAction.Stop)
                page.deleteLater()
            if view is not None:
                view.deleteLater()
            if host is not None:
                host.deleteLater()
        except RuntimeError:
            pass

    def default_url(self):
        cfg = self.cfg_getter()
        peer = (cfg.get("vk") or {}).get("peer_id")
        s = self.settings()
        if peer and self.logged_in:
            return s["chat_url"].format(peer_id=int(peer))
        return s["home_url"]

    def current_url(self):
        if self.view is not None:
            return self.view.url().toString()
        return self._pending_url or ""

    def back(self):
        if self.view is not None:
            self.view.back()

    def reload(self):
        if self.view is not None:
            self.view.reload()
        else:
            self.ensure_view()

    # ------------------------------------------------------------ рабочая страница (на время сценария)
    def _drop_work_view(self):
        self.warm = False
        if self.work_view is None:
            return
        page, view, host = self.work_page, self.work_view, self.work_host
        self.work_page = self.work_view = self.work_host = None
        self._dispose(page, view, host)
        log.debug("Фоновая страница ВК закрыта")

    def _make_work_view(self):
        """Рабочая страница в отдельном окне за краем экрана (см. описание модуля)."""
        from PySide6.QtWidgets import QVBoxLayout, QWidget
        if self.work_view is not None:
            return
        self.work_page = self._make_page()
        host = QWidget(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint
                       | Qt.WindowType.WindowDoesNotAcceptFocus | Qt.WindowType.WindowTransparentForInput)
        host.setObjectName("vkWorkHost")
        host.setWindowTitle("ВК (фоновая отправка)")
        host.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        host.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        lay = QVBoxLayout(host)
        lay.setContentsMargins(0, 0, 0, 0)
        self.work_view = QWebEngineView(host)
        self.work_view.setPage(self.work_page)
        self.work_view.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        lay.addWidget(self.work_view)
        host.resize(*WORK_SIZE)
        host.move(*WORK_POS)
        self.work_host = host
        self.show_work_host()
        try:
            self.work_page.setLifecycleState(QWebEnginePage.LifecycleState.Active)
        except Exception:  # noqa: BLE001
            pass
        try:
            self.work_page.setVisible(True)
        except Exception:  # noqa: BLE001
            pass

    def show_work_host(self):
        """Окно рабочей страницы всегда «показано» (за краем экрана), не берёт фокус и не снимается."""
        self._make_work_view()
        h = self.work_host
        if not h.isVisible():
            h.move(*WORK_POS)
            h.show()
            h.move(*WORK_POS)
        try:
            from .common import exclude_from_capture
            exclude_from_capture(h, True)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------ сведения
    def settings(self):
        return merged_settings(self.cfg_getter())

    def flows(self):
        return Flows(self.settings())

    @property
    def cookies(self):
        """{имя: True} cookie сессии на vk.com / vk.ru (для проверки входа; без значений)."""
        return self.cookie_jar.names(session_only=True)

    @property
    def logged_in(self):
        names = self.settings().get("login_cookies") or []
        return self.cookie_jar.has_session(names)

    def view_visible(self, view=None):
        view = view or self.view
        if view is None:
            return False
        w = view.window()
        return bool(view.isVisible() and w is not None and not w.isMinimized())

    @property
    def busy(self):
        return self._busy

    # ------------------------------------------------------------ куки
    @staticmethod
    def _cookie_parts(c):
        return (c.domain() or "", bytes(c.name()).decode("latin-1", "replace"), c.path() or "/")

    def _cookie_added(self, c):
        if not is_vk_host(c.domain()):
            return
        self.cookie_jar.add(*self._cookie_parts(c))  # значения не храним и не пишем в журнал
        self._emit_login()

    def _cookie_removed(self, c):
        if not is_vk_host(c.domain()):
            return
        self.cookie_jar.remove(*self._cookie_parts(c))
        self._emit_login()

    def _emit_login(self):
        """Вход появился — сообщаем сразу. Пропал — только если cookie сессии нет и через
        LOGOUT_DEBOUNCE_SEC секунд (ВК обновляет cookie так: сначала удаляет, потом ставит новую)."""
        if self.logged_in:
            self._logout_timer.stop()
            if self._logged is not True:
                self._logged = True
                log.debug("Cookie сессии ВК есть: %s", self.cookie_jar.names_by_domain())
                self.loginChanged.emit(True)
        elif self._logged is True and not self._logout_timer.isActive():
            self._logout_timer.start(int(LOGOUT_DEBOUNCE_SEC * 1000))

    def _confirm_logout(self):
        if self.logged_in or self._logged is not True:
            return  # за 10 с cookie сессии вернулась — ничего не было
        self._logged = False
        log.debug("Cookie сессии ВК нет уже %d с: %s", LOGOUT_DEBOUNCE_SEC, self.cookie_jar.names_by_domain())
        self.loginChanged.emit(False)

    # ------------------------------------------------------------ действия
    def go(self, url, load=False):
        """Открыть адрес на видимой странице. Если страница выгружена — запомнить адрес на потом
        (load=True — создать страницу сразу)."""
        if self.view is None and not load:
            self._pending_url = url
            return
        if self.view is None:
            self._pending_url = url
            self.ensure_view()
            return
        self.view.setUrl(QUrl(url))

    def go_chat(self):
        cfg = self.cfg_getter()
        peer = (cfg.get("vk") or {}).get("peer_id")
        s = self.settings()
        self.go(s["chat_url"].format(peer_id=int(peer)) if peer else s["im_url"], load=self.view is not None)

    def real_click(self, x, y, view=None):
        """Щелчок «как от пользователя» внутри страницы: событие Qt прямо в виджет страницы.
        Настоящую мышь не двигает и фокус не забирает (для рабочей страницы — в окне за краем экрана)."""
        view = view or self.work_view
        if view is None or not self.view_visible(view):
            return False
        target = view.focusProxy() or view
        pos = QPointF(float(x), float(y))
        glob = QPointF(target.mapToGlobal(QPoint(int(x), int(y))))
        for t in (QEvent.Type.MouseButtonPress, QEvent.Type.MouseButtonRelease):
            ev = QMouseEvent(t, pos, glob, Qt.MouseButton.LeftButton,
                             Qt.MouseButton.LeftButton if t == QEvent.Type.MouseButtonPress else Qt.MouseButton.NoButton,
                             Qt.KeyboardModifier.NoModifier)
            from PySide6.QtCore import QCoreApplication
            QCoreApplication.sendEvent(target, ev)
        return True

    def log_dir(self):
        d = os.path.dirname(resolve_path(self.cfg_getter()["storage"]["log_file"]))
        os.makedirs(d, exist_ok=True)
        return d

    def save_text(self, kind, text):
        """Сведения для разбора (без cookie и текстов сообщений) в logs\\vk_<что>_<время>.html."""
        try:
            path = os.path.join(self.log_dir(), f"vk_{kind}_{time.strftime('%Y%m%d_%H%M%S')}.html")
            with open(path, "w", encoding="utf-8") as f:
                f.write(str(text or ""))
            rotate_shots(self.log_dir(), self.settings().get("keep_error_shots", 20), "vk_*.html")
            log.info("Сведения о странице ВК для разбора: %s", path)
            return path
        except Exception:  # noqa: BLE001
            log.debug("save_text", exc_info=True)
            return None

    def save_shot(self, kind, view=None):
        """Снимок страницы ВК в logs\\vk_<что>_<время>.png (для разбора ошибок)."""
        view = view or self.work_view or self.view
        if view is None:
            return None
        try:
            path = os.path.join(self.log_dir(), f"vk_{kind}_{time.strftime('%Y%m%d_%H%M%S')}.png")
            if view.size().width() < 50:
                view.resize(1100, 800)
            if not view.grab().save(path):
                return None
            rotate_shots(self.log_dir(), self.settings().get("keep_error_shots", 20))
            return path
        except Exception:  # noqa: BLE001
            log.debug("снимок страницы ВК", exc_info=True)
            return None

    # ------------------------------------------------------------ сценарии
    def run_flow(self, gen, on_done, work=True, deadline=None, on_deadline=None):
        """Выполнить сценарий в потоке окна; on_done(результат, ошибка). Сценарии идут по очереди.
        work=True — на рабочей (фоновой) странице, False — на видимой странице раздела «ВКонтакте».
        deadline — общий тайм-аут в секундах (по истечении в сценарий бросается on_deadline())."""
        self._queue.append((gen, on_done, work, deadline, on_deadline, False))
        self._next()

    def prewarm(self, gen, on_done, keep_sec):
        """Заранее открыть беседу на фоновой странице и оставить её до отправки (не дольше keep_sec).
        Одна загрузка страницы — та же, что всё равно нужна для отправки. on_done(результат, ошибка)."""
        def done(result, error):
            if error is None:
                self.warm = True
                self._warm_gen += 1
                gen_id = self._warm_gen
                QTimer.singleShot(int(max(30.0, float(keep_sec)) * 1000), lambda: self._expire_warm(gen_id))
            else:
                QTimer.singleShot(0, self._drop_work_view)
                if getattr(error, "confirmed", False):
                    self.loggedOut.emit()
                if getattr(error, "needs_user", False):
                    self.needsUser.emit(getattr(error, "text", str(error)))
            on_done(result, error)
        self._queue.append((gen, done, True, 120, None, True))
        self._next()

    def _expire_warm(self, gen_id):
        """Отправка так и не понадобилась (остановили, пропуск) — закрыть заранее открытую страницу."""
        if self.warm and gen_id == self._warm_gen and not self._busy:
            log.info("Заранее открытая страница ВК не понадобилась — закрываю")
            self._drop_work_view()

    def _next(self):
        if self._busy or not self._queue:
            return
        gen, on_done, work, deadline, on_deadline, keep = self._queue.pop(0)
        if work:
            self.show_work_host()
        else:
            self.ensure_view()
        self._busy = True
        self._flow_on_view = not work
        if not work and getattr(self, "fitter", None) is not None:
            self.fitter.reset()          # сценарий щёлкает по координатам страницы — нужен масштаб 100 %

        def done(result, error):
            self._busy = False
            self._flow_on_view = False
            if not work:
                self.refit()     # сценарий закончился — вернуть выбранный масштаб или подогнать заново
            if work and not keep:
                self.warm = False   # отправка/проверка использовала заранее открытую страницу
            try:
                on_done(result, error)
            finally:
                # рабочая страница закрывается сразу после сценария (если дальше в очереди её не ждут),
                # кроме заранее открытой беседы — она ждёт ближайшую отправку
                if work and not keep and self.save_memory and not any(q[2] for q in self._queue):
                    QTimer.singleShot(0, self._drop_work_view)
                QTimer.singleShot(0, self._next)
        FlowRunner(self, gen, done, work, deadline, on_deadline).start()

    def run_blocking(self, flow_factory, timeout, deadline=None, on_deadline=None):
        """Из рабочего потока: выполнить сценарий в окне и дождаться результата (или ошибки).
        deadline — сценарий прерывается сам (с сохранением сведений); timeout — запасной предел ожидания."""
        if threading.get_ident() == self._gui_thread:
            raise RuntimeError("run_blocking нельзя вызывать из потока окна")
        box = {"event": threading.Event(), "factory": flow_factory, "deadline": deadline,
               "on_deadline": on_deadline}
        self._request.emit(box)
        wait = timeout if not deadline else max(float(timeout), float(deadline) + 25)
        if not box["event"].wait(wait):
            box["abandoned"] = True
            raise BrowserUnavailable("Браузер программы не ответил вовремя — отправка отменена. "
                                     "Посмотрите раздел «ВКонтакте».")
        if box.get("error") is not None:
            raise box["error"]
        return box.get("result")

    @Slot(object)
    def _on_request(self, box):
        def done(result, error):
            box["result"], box["error"] = result, error
            if error is not None and getattr(error, "confirmed", False):
                self.loggedOut.emit()
            if error is not None and getattr(error, "needs_user", False):
                self.needsUser.emit(getattr(error, "text", str(error)))
            box["event"].set()
        try:
            gen = box["factory"]()
        except Exception as e:  # noqa: BLE001
            return done(None, e)
        self.run_flow(gen, done, deadline=box.get("deadline"), on_deadline=box.get("on_deadline"))

    def close(self):
        """Аккуратно закрыть страницу до профиля (иначе Qt предупреждает о «живой» странице)."""
        import shiboken6
        for page, view, host in ((self.page, self.view, None),
                                 (self.work_page, self.work_view, self.work_host)):
            for obj in (page, view, host):   # сначала страница, потом вид
                try:
                    if obj is not None and shiboken6.isValid(obj):
                        if obj is host:
                            obj.hide()
                        shiboken6.delete(obj)
                except RuntimeError:
                    pass
        self.page = self.view = self.work_page = self.work_view = self.work_host = None


def debug_json(obj):
    return json.dumps(obj, ensure_ascii=False)[:500]
