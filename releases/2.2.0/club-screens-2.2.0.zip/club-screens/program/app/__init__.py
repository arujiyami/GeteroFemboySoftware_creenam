# Original-Author: Владислав С.
# Created: 2026-10-28
"""Скриншоты клуба: ежечасные скриншоты Oasys и камер с отправкой в беседу ВКонтакте."""
__version__ = "2.2.0"
APP_NAME = "Скриншоты клуба"
# Авторы (окно «О программе», README, PDF, AUTHORS.txt)
AUTHOR_LINE = "Разработано Владиславом С."
CONTRIBUTOR_LINE = "Помогал с кодом — Grok Bot"
