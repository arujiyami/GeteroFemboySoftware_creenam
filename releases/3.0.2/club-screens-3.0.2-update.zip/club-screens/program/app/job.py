# Original-Author: Владислав С.
# Created: 2026-10-28
"""Один цикл: снять все источники, сохранить, отправить одним сообщением, с повторами."""
import logging
import os
import re
import threading
import time
from datetime import datetime

from .cleanup import mark_failed, run_cleanup, shot_stamp
from .config import base_dir, resolve_path
from .scheduler import run_with_retries
from . import hourdone, lightmode, offqueue, summary
from .friendly import humanize
from .inputlock import InputBlocker, effective_watchdog
from .mediapause import MediaPauser, media_settings
from .steps import StepError, StepRunner
from .vision import is_blank
from .vk import VKClient


def latest_shots(folder):
    """Файлы последнего запуска в папке скриншотов (по общему префиксу «дата_время»)."""
    import glob
    files = [f for f in glob.glob(os.path.join(folder, "*.*"))
             if f.lower().endswith((".png", ".jpg")) and "_test" not in os.path.basename(f)]
    if not files:
        return []
    files.sort(key=os.path.getmtime)
    stamp = os.path.basename(files[-1])[:16]
    return sorted(f for f in files if os.path.basename(f)[:16] == stamp)


def _stamp_time(stamp):
    try:
        return datetime.strptime(stamp[:16], "%Y-%m-%d_%H-%M") if stamp else None
    except ValueError:
        return None

log = logging.getLogger("club")
# Первый (быстрый) проход проверки готовности при запуске вручную: не дольше стольких секунд
QUICK_READY_SEC = 2.0
# Запас на снимок Oasys и iVMS-4200 (шаги iVMS — около 8 с) для сторожа блокировки
CAPTURE_MARGIN_SEC = 12
IMAGE_EXT = (".png", ".jpg", ".jpeg")


def safe_name(name):
    return re.sub(r"[^\w\-]+", "_", name, flags=re.UNICODE).strip("_") or "source"


def save_image(img, folder, stamp, index, name, fmt="png", quality=92):
    os.makedirs(folder, exist_ok=True)
    ext = "jpg" if fmt.lower() in ("jpg", "jpeg") else "png"
    path = os.path.join(folder, f"{stamp}_{index:02d}_{safe_name(name)}.{ext}")
    if ext == "jpg":
        img.convert("RGB").save(path, "JPEG", quality=int(quality))
    else:
        img.save(path, "PNG", optimize=False)
    return path


def format_caption(template, now, club=""):
    if not template:
        return ""
    try:
        return template.format(date=now.strftime("%d.%m.%Y"), time=now.strftime("%H:%M"), club=club)
    except (KeyError, IndexError, ValueError):
        return template


def make_group_client(cfg):
    """Необязательный режим: отправка от имени сообщества по ключу сообщества (vk.sender: group_api)."""
    vk = cfg["vk"]
    return VKClient(vk.get("group_token", ""), vk.get("api_version", "5.199"), vk.get("api_host", "api.vk.com"))


_BROWSER = None


def set_browser(browser):
    """Встроенный браузер окна программы (app/ui/browser.VKBrowser) — через него идут отправки."""
    global _BROWSER
    _BROWSER = browser


def get_browser():
    return _BROWSER


def make_sender(cfg):
    """Чем отправлять: по умолчанию — встроенный браузер программы с вашим входом в ВК."""
    if (cfg.get("vk") or {}).get("sender") == "group_api":
        return make_group_client(cfg)
    from .vk_browser import BrowserUnavailable, BrowserVKSender
    if _BROWSER is None:
        raise BrowserUnavailable("Браузер программы не запущен — откройте окно «Скриншоты клуба».")
    return BrowserVKSender(_BROWSER, cfg)


def lock_watchdog_sec(cfg):
    """Сторож одной блокировки: хватает на ранний старт + съёмку Oasys и iVMS, но не больше 30 секунд."""
    from .scheduler import early_settings
    lk = cfg.get("input_lock") or {}
    return effective_watchdog(lk.get("watchdog_sec", 30), early_settings(cfg), 0, CAPTURE_MARGIN_SEC)


def caption_with_notes(caption, warnings):
    """Подпись + пометки «Oasys не загрузился — снимок может быть неактуален» (если есть)."""
    notes = [w.split(" (")[0] for w in (warnings or {}).values() if w]
    notes = list(dict.fromkeys(notes))
    if not notes:
        return caption
    text = "\n".join("⚠ " + n for n in notes)
    return f"{caption}\n{text}" if caption else text


class JobRunner:
    def __init__(self, cfg_getter, backend_factory, vk_factory=make_sender, root=None,
                 now=datetime.now, stop_event=None, sleep=None):
        self.cfg_getter = cfg_getter
        self.backend_factory = backend_factory
        self.vk_factory = vk_factory
        self.root = root
        self.now = now
        self.stop_event = stop_event or threading.Event()
        self.sleep = sleep
        self.lock = threading.Lock()
        self.errors = {}          # имя источника -> исключение (последняя попытка)
        self.last_result = None   # итог последнего цикла (см. _finish)
        self.on_result = None     # callback(result) после каждого цикла
        self.on_start = None      # callback() перед началом цикла
        # callback(True/False) до и после съёмки: окно программы прячется от снимков экрана
        self.on_capture = None
        # «Нужно ваше действие»: капча/блокировка/нет входа. Пока стоит — плановые отправки
        # пропускаются (чтобы не долбить ВК). Снимается отправкой вручную или пробной отправкой.
        self.hold = None
        # Что сейчас происходит: None | "capture" (съёмка — мышь не трогать) | "send" (фоновая отправка)
        # | "retry_wait" (ждём повтора). on_phase(phase) — при каждой смене.
        self.phase = None
        self.on_phase = None
        # Блокировка мыши/клавиатуры на время съёмки (только съёмка, не отправка): True, пока стоит
        self.input_locked = False
        self.input_blocker = None
        # 2.1.5: источники, которые так и не загрузились (снимок «как есть»): имя -> текст пометки;
        # on_warning(имя, текст) — сразу показать предупреждение в окне/трее
        self.warnings = {}
        self.on_warning = None
        # Плановый запуск с ранним стартом: время снимка (ЧЧ:00), пока цикл готовится
        self.capture_at = None
        # Уборка старых файлов: не одновременно с циклом. Цикл ждёт конца уборки (она быстрая),
        # уборка при идущем цикле пропускается. Файлы текущей и последней отправки не трогаются.
        self.cleanup_lock = threading.Lock()
        self.active_stamp = None
        self.last_stamp = None
        # 2.1.6: музыка и видео на паузу на время съёма (необязательно; любая ошибка — только в журнал)
        self.media = MediaPauser()
        # 2.2.0: проверка связи для очереди без интернета (подменяется в тестах)
        self.online = offqueue.is_online

    def _wait_cleanup(self):
        """Если сейчас идёт уборка — дождаться её конца (обычно доли секунды)."""
        if self.cleanup_lock.acquire(timeout=120):
            self.cleanup_lock.release()

    def _root(self):
        return self.root or base_dir()

    def queue(self, cfg=None):
        cfg = cfg or self.cfg_getter()
        q = cfg.get("offline_queue") or {}
        return offqueue.OfflineQueue(os.path.join(self._root(), "state", "queue.json"), q.get("max_cycles", 12))

    def protected_stamps(self):
        stamps = {self.active_stamp, self.last_stamp} | self.queue().stamps()   # очередь уборка не трогает
        for p in (self.last_result or {}).get("paths") or []:
            stamps.add(shot_stamp(os.path.basename(p)))
        return {x for x in stamps if x}

    def cleanup(self):
        """Уборка по настройкам. None — пропущено, потому что идёт цикл (съёмка, отправка или ожидание
        повтора); иначе (файлов, байт)."""
        if self.lock.locked():
            return None
        with self.cleanup_lock:
            if self.lock.locked():
                return None
            return run_cleanup(self.cfg_getter(), lambda p: resolve_path(p, self.root), self.protected_stamps())

    def set_phase(self, phase):
        self.phase = phase
        if self.on_phase:
            try:
                self.on_phase(phase)
            except Exception:  # noqa: BLE001
                log.debug("on_phase", exc_info=True)

    def _wait(self, seconds):
        if self.sleep:
            self.sleep(seconds)
            return False
        return self.stop_event.wait(seconds)

    def _sleep_clock(self):
        """Своя пауза (в тестах) — и часы, которые идут вместе с ней, иначе ожидание Oasys крутилось бы вхолостую."""
        if self.sleep is None:
            return time.sleep, time.monotonic
        state = {"t": time.monotonic()}

        def sleep(sec):
            self.sleep(sec)
            state["t"] += max(0.0, float(sec or 0))
        return sleep, lambda: state["t"]

    def _runner(self, cfg, backend, capture_at=None, quick=False, on_not_ready=None):
        from .readiness import ready_settings
        enabled, timeout = ready_settings(cfg)
        sleep, clock = self._sleep_clock()
        runner = StepRunner(backend, lambda p: resolve_path(p, self.root), sleep=sleep, clock=clock,
                            ready_timeout=timeout, capture_at=capture_at, now=self.now,
                            on_not_ready=on_not_ready, ready_check=enabled)
        if quick:
            runner.ready_budget = QUICK_READY_SEC
        return runner

    def _save_images(self, cfg, name, idx, images, stamp, done):
        st = cfg["storage"]
        folder = resolve_path(st["screenshots_dir"], self.root)
        for old in done.get(name) or []:     # пересъёмка: прежний снимок заменяется
            try:
                os.remove(old)
            except OSError:
                pass
        fmt, q = st.get("image_format", "png"), st.get("jpeg_quality", 92)
        if lightmode.active():     # «Лёгкий режим»: меньше и легче
            images = [lightmode.shrink(i) for i in images]
            fmt, q = "jpg", min(int(q), lightmode.JPEG_QUALITY)
        done[name] = [save_image(img, folder, stamp, idx * 10 + n, name, fmt, q) for n, img in enumerate(images)]

    def _check_shot(self, runner, name, images):
        """После съёмки iVMS, до отправки: загрузился ли источник с проверкой готовности (Oasys).
        "" — да (или проверки у источника нет), иначе причина."""
        ctx = runner.contexts.get(name)
        if ctx is None or not ctx.ready_steps:
            return ""
        if ctx.not_ready:
            return ctx.not_ready
        from .readiness import image_problem
        step = ctx.ready_steps[-1]
        tpl = step.get("template")
        try:
            return image_problem(images[-1] if images else None, resolve_path(tpl, self.root) if tpl else None,
                                 float(step.get("confidence", 0.8)))
        except Exception as e:  # noqa: BLE001
            log.debug("проверка снимка", exc_info=True)
            return f"не удалось проверить снимок: {e}"

    def capture_sources(self, sources, backend, stamp, done, capture_at=None):
        """Снимает источники, которых ещё нет в done (name -> [пути]).

        2.1.5: мышь и клавиатура блокируются в начале (при плановом запуске — за early_sec секунд до
        capture_at), Oasys выводится вперёд и открывается «Карта клуба»; в capture_at — снимок Oasys, затем
        iVMS, и блокировка сразу снимается. Потом, ещё до отправки, проверяется, загрузился ли Oasys; если нет —
        он переснимается (блокировка — только на время пересъёмки, не дольше сторожа). Не загрузился и тогда —
        отправляется то, что есть, с пометкой «Oasys не загрузился — снимок может быть неактуален»."""
        cfg = self.cfg_getter()
        runner = self._runner(cfg, backend, capture_at=capture_at, quick=True)
        prev = None
        blocker = None
        recheck = []
        self.set_phase("capture")
        self._capture_hook(True)
        media_paused = False
        try:
            blocker = self._lock_input(cfg, backend)
            media_paused = self._media_pause(cfg)
            if cfg["schedule"].get("restore_foreground", True):
                try:
                    prev = backend.foreground()
                except Exception:  # noqa: BLE001
                    prev = None
            for idx, src in enumerate(sources, 1):
                name = src.get("name", f"source{idx}")
                if name in done:
                    continue
                try:
                    images = runner.run_source(src)
                    if images and all(is_blank(im) for im in images) and not runner.contexts[name].ready_steps:
                        raise StepError(f"{name}: снимок получился чёрным (компьютер заблокирован или спит?)")
                    self.errors.pop(name, None)
                    self._save_images(cfg, name, idx, images, stamp, done)
                    log.info("%s: готово (%d шт.)", name, len(images))
                    problem = self._check_shot(runner, name, images)
                    if problem:
                        recheck.append((idx, src, problem, images))
                except Exception as e:  # noqa: BLE001
                    self.errors[name] = e
                    log.error("%s: ошибка: %s", name, e)
            if blocker is not None:
                blocker.release("done")   # снимки сделаны — ввод сразу возвращается
                blocker = None
            if media_paused:
                media_paused = False
                self._media_resume(cfg)   # и музыка/видео — обратно, ещё до проверки и отправки
            for idx, src, problem, first in recheck:
                self._recapture(cfg, backend, src, idx, problem, stamp, done, first)
        finally:
            if blocker is not None:
                blocker.release("done")   # всегда, даже при ошибке съёмки
            if media_paused:
                self._media_resume(cfg)
            if prev:
                try:
                    backend.set_foreground(prev)
                except Exception:  # noqa: BLE001
                    pass
            self._capture_hook(False)

    def _recapture(self, cfg, backend, src, idx, problem, stamp, done, first=None):
        """Переснять источник, который не загрузился к первому снимку. Блокировка — только на это время;
        не дождались (ready timeout) — блокировка снимается сразу, снимок «как есть» + пометка."""
        from .readiness import NOT_READY_NOTE
        name = src.get("name", f"source{idx}")
        log.warning("%s: снимок под вопросом (%s) — переснимаю", name, problem)
        state = {"blocker": None}

        def not_ready(_name, reason):
            b = state["blocker"]
            if b is not None:
                b.release("not_ready")    # дальше ждать бесполезно — ввод возвращаем сразу
            log.warning("%s: не загрузился (%s) — снимаю как есть, ввод разблокирован", name, reason)

        runner = self._runner(cfg, backend, on_not_ready=not_ready)
        images = None
        try:
            state["blocker"] = self._lock_input(cfg, backend)
            images = runner.run_source(src)
            problem = self._check_shot(runner, name, images)
        except Exception as e:  # noqa: BLE001
            problem = humanize(e, name) if not isinstance(e, StepError) else str(e)
            log.error("%s: пересъёмка не удалась: %s", name, e)
        finally:
            if state["blocker"] is not None:
                state["blocker"].release("done")
        if images:
            self._save_images(cfg, name, idx, images, stamp, done)
        shots = done.get(name) or []
        final = images or first
        if final and all(is_blank(im) for im in final):
            # чёрный кадр и после пересъёмки — компьютер заблокирован или спит: это ошибка, как раньше
            for old in shots:
                try:
                    os.remove(old)
                except OSError:
                    pass
            done.pop(name, None)
            self.errors[name] = StepError(f"{name}: снимок получился чёрным (компьютер заблокирован или спит?)")
            log.error("%s: ошибка: %s", name, self.errors[name])
            return
        if problem:
            note = NOT_READY_NOTE if str(name).strip().lower() == "oasys" else \
                f"{name} не загрузился — снимок может быть неактуален"
            self.warnings[name] = f"{note} ({problem})"
            log.warning("%s", self.warnings[name])
            if self.on_warning:
                try:
                    self.on_warning(name, self.warnings[name])
                except Exception:  # noqa: BLE001
                    log.debug("on_warning", exc_info=True)
        else:
            self.warnings.pop(name, None)
            log.info("%s: переснят — теперь загружен", name)

    def _lock_input(self, cfg, backend):
        """Заблокировать мышь и клавиатуру пользователя на время съёмки (если включено и есть Windows).
        Возвращает InputBlocker или None. Сочетание клавиш снимает блокировку, сторож — тоже
        (не дольше 30 секунд на одну блокировку, что бы ни случилось)."""
        lk = cfg.get("input_lock") or {}
        factory = getattr(backend, "input_hook_factory", None)
        if not lk.get("enabled", True) or factory is None:
            return None
        try:
            blocker = InputBlocker(factory, lk.get("hotkey") or "Ctrl+Alt+Q", lock_watchdog_sec(cfg),
                                   on_release=self._input_released)
        except ValueError as e:
            log.warning("Блокировка ввода выключена: %s", e)
            return None
        if not blocker.start():
            return None
        self.input_blocker = blocker
        self.input_locked = True
        self.set_phase(self.phase)   # обновить подсказку в окне
        return blocker

    def _media_pause(self, cfg):
        """2.1.6: если включено в настройках — поставить на паузу играющие музыку и видео.
        Не дольше ~1 с; ошибки не выходят наружу. True — пауза запрашивалась (значит, потом resume)."""
        try:
            on, _resume = media_settings(cfg)
            if not on:
                return False
            self.media.pause()
            return True
        except Exception as e:  # noqa: BLE001
            log.info("Пауза музыки и видео пропущена: %s", e)
            return False

    def _media_resume(self, cfg):
        """Включить обратно только то, что сами ставили на паузу (если так выбрано). Не ждёт."""
        try:
            _on, resume = media_settings(cfg)
            if resume:
                self.media.resume()
            else:
                self.media.forget()
        except Exception as e:  # noqa: BLE001
            log.info("Включить музыку и видео обратно не удалось: %s", e)

    def _input_released(self, reason):
        self.input_locked = False
        self.input_blocker = None
        if reason in ("hotkey", "watchdog", "not_ready"):
            self.set_phase(self.phase)

    def _capture_hook(self, on):
        if self.on_capture:
            try:
                self.on_capture(on)
            except Exception:  # noqa: BLE001
                log.debug("on_capture", exc_info=True)

    def capture_preview(self):
        """Снять все включённые источники один раз, без отправки и повторов.
        Возвращает (done: имя -> [пути], errors: имя -> понятный текст)."""
        if not self.lock.acquire(blocking=False):
            raise RuntimeError("Предыдущий запуск ещё не закончен")
        self._wait_cleanup()
        try:
            cfg = self.cfg_getter()
            sources = [s for s in cfg.get("sources") or [] if s.get("enabled", True)]
            self.errors = {}
            self.warnings = {}
            done = {}
            stamp = self.now().strftime("%Y-%m-%d_%H-%M-%S") + "_test"
            self.capture_sources(sources, self.backend_factory(), stamp, done)
            errs = {n: humanize(e, n) for n, e in self.errors.items()}
            for n, w in self.warnings.items():
                errs.setdefault(n, w)
            return done, errs
        finally:
            self.set_phase(None)
            self.lock.release()

    def send_paths(self, paths, caption=None):
        """Отправить готовые картинки одним сообщением (для пробной отправки)."""
        cfg = self.cfg_getter()
        vk_cfg = cfg["vk"]
        if caption is None:
            caption = format_caption(vk_cfg.get("caption", ""), self.now(), cfg["app"].get("club_name", ""))
        self.set_phase("send")
        try:
            result = self.vk_factory(cfg).send_photos(vk_cfg["peer_id"], paths, caption)
        except Exception as e:
            self._maybe_hold(e)
            raise
        finally:
            self.set_phase(None)
        self.clear_hold()
        return result

    def latest_paths(self, cfg=None):
        """2.2.1: последний съём (пара Oasys + iVMS) в папке скриншотов — для «Отправить последние скрины»."""
        cfg = cfg or self.cfg_getter()
        return latest_shots(resolve_path(cfg["storage"]["screenshots_dir"], self.root))

    def resend_latest(self):
        """2.2.1: отправить последние снятые скрины ещё раз, БЕЗ нового съёма — «ручная попытка».
        Та же отправка и проверка доставки, что у планового цикла; одна попытка. Возвращает True при успехе."""
        if not self.lock.acquire(blocking=False):
            log.warning("Отправить последние скрины: идёт другой запуск — пропуск")
            return False
        self._wait_cleanup()
        cfg = self.cfg_getter()
        paths = self.latest_paths(cfg)
        stamp = shot_stamp(os.path.basename(paths[0])) if paths else None
        when = _stamp_time(stamp) or self.now()
        self._result = {"time": when, "ok": False, "sent": False, "paths": paths, "errors": {},
                        "send_error": None, "partial": False, "warnings": {}, "resend": True}
        if self.on_start:
            try:
                self.on_start()
            except Exception:  # noqa: BLE001
                pass
        ok = False
        try:
            if not paths:
                log.warning("Отправить последние скрины: снимков пока нет")
                self._result["send_error"] = "Снимков пока нет — сначала нажмите «Отправить сейчас»."
            else:
                self.active_stamp = stamp
                log.info("Ручная отправка последних скринов (без нового съёма), съём %s: %s", when.strftime("%d.%m %H:%M"),
                         ", ".join(os.path.basename(p) for p in paths))
                vk_cfg = cfg["vk"]
                caption = format_caption(vk_cfg.get("caption", ""), when, cfg.get("app", {}).get("club_name", ""))
                caption = (caption + "\n" if caption else "") + "(повторная отправка вручную)"
                self.set_phase("send")
                try:
                    self._result["send_result"] = self.vk_factory(cfg).send_photos(vk_cfg["peer_id"], paths, caption)
                except Exception as e:  # noqa: BLE001
                    self._maybe_hold(e)
                    self._result["send_error"] = humanize(e)
                    if getattr(e, "kind", "") == "unconfirmed":
                        self._result["warnings"]["ВКонтакте"] = "проверьте беседу — не видно, дошло ли сообщение"
                    log.error("Ручная отправка последних скринов не удалась: %s", e)
                else:
                    self.clear_hold()
                    self._result["sent"] = True
                    ok = True
                    hourdone.mark(self._root(), self.now(), hourdone.MANUAL, "последние скрины")
                    log.info("Ручная отправка последних скринов: успешно (%s)", self._result.get("send_result"))
        finally:
            self.set_phase(None)
            self.active_stamp = None
            self.lock.release()
        self._result["ok"] = ok
        self.last_result = self._result
        if paths:
            try:
                summary.record(summary.log_path(self._root()), when, ok, self._result.get("sent"), planned=False,
                               queued=False, warnings=self._result.get("warnings"),
                               error=self._result.get("send_error"), shots=len(paths))
            except Exception:  # noqa: BLE001
                log.debug("журнал съёмов", exc_info=True)
        if self.on_result:
            try:
                self.on_result(self._result)
            except Exception:  # noqa: BLE001
                log.exception("on_result")
        return ok

    def hour_already_sent(self, cfg, when, why=""):
        """2.2.4: час уже закрыт (отметка программы/ручной отправки) или в беседе за этот час уже есть
        своё сообщение с этими скринами → True (повтор/тревога не нужны). Решение — в журнал с причинами."""
        hour = when.replace(minute=0, second=0, microsecond=0)
        by = hourdone.done(self._root(), hour, cfg)
        if by:
            log.info("Проверка %s (%s): час уже отправлен (%s) — повторять не нужно", hour.strftime("%H:00"), why,
                     {"program": "программой", "manual": "вручную кнопкой", "chat": "найдено в беседе"}.get(by, by))
            return True
        if not hourdone.settings(cfg)["chat_check"]:
            return False
        try:
            client = self.vk_factory(cfg)
        except Exception:  # noqa: BLE001
            return False
        fn = getattr(client, "already_sent", None)
        if fn is None:
            return False
        paths = self.latest_paths(cfg)
        t0 = time.monotonic()
        try:
            found, reason = fn(cfg["vk"]["peer_id"], paths, hour, now=self.now())
        except Exception as e:  # noqa: BLE001
            found, reason = False, f"ошибка проверки ({e})"
        log.info("Проверка беседы %s (%s, %.1f с): %s — %s", hour.strftime("%H:00"), why, time.monotonic() - t0,
                 "скрины уже есть" if found else "не найдено", reason)
        if found:
            hourdone.mark(self._root(), hour, hourdone.CHAT, reason)
        return bool(found)

    def chat_presence(self, cfg, when):
        """3.0.2: проверка в :05/:07/:10 — есть ли В БЕСЕДЕ своё сообщение с последними скринами за этот час.
        Отметке часа (hours_done) не доверяет: сообщение могли удалить. Ничего не отправляет.
        → (found/missing/failed, причина)."""
        from . import dupcheck
        hour = when.replace(minute=0, second=0, microsecond=0)
        try:
            client = self.vk_factory(cfg)
        except Exception as e:  # noqa: BLE001
            return dupcheck.FAILED, f"браузер недоступен ({e})"
        fn = getattr(client, "presence", None)
        if fn is None:
            old = getattr(client, "already_sent", None)
            if old is None:
                return dupcheck.FAILED, "проверка беседы недоступна"

            def fn(*a, **k):
                found, why = old(*a, **k)
                return (dupcheck.FOUND if found else dupcheck.MISSING), why
        t0 = time.monotonic()
        try:
            st, reason = fn(cfg["vk"]["peer_id"], self.latest_paths(cfg), hour, now=self.now())
        except Exception as e:  # noqa: BLE001
            st, reason = dupcheck.FAILED, f"ошибка проверки ({e})"
        log.info("Проверка беседы на месте ли скрины %s (%.1f с): %s — %s", hour.strftime("%H:00"),
                 time.monotonic() - t0, {"found": "на месте", "missing": "НЕТ в беседе",
                                         "failed": "проверить не удалось"}.get(st, st), reason)
        return st, reason

    def _maybe_hold(self, e):
        if getattr(e, "needs_user", False):
            self.hold = humanize(e)
            log.warning("Плановые отправки приостановлены до вашего действия: %s", self.hold)

    def clear_hold(self):
        if self.hold:
            log.info("Плановые отправки возобновлены")
        self.hold = None

    def _summary_due(self, cfg):
        now = self.now()
        if not summary.due(cfg, now, summary.get_last_sent(summary.last_sent_path(self._root()))):
            return ""
        return summary.text(summary.read(summary.log_path(self._root())), now,
                            (cfg.get("summary") or {}).get("time", "09:00"))

    def send_summary_if_due(self):
        """Сводка отдельным коротким сообщением — если обычной отправки после summary.time так и не было."""
        cfg = self.cfg_getter()
        now = self.now()
        lp = summary.last_sent_path(self._root())
        if not summary.standalone_due(cfg, now, summary.get_last_sent(lp)) or self.hold:
            return False
        if not self.lock.acquire(blocking=False):
            return False
        try:
            text = summary.text(summary.read(summary.log_path(self._root())), now,
                                (cfg.get("summary") or {}).get("time", "09:00"))
            summary.set_last_sent(lp, now)      # одна попытка в день: без повторов и задвоений
            self.vk_factory(cfg).send_text(cfg["vk"]["peer_id"], text)
            log.info("Утренняя сводка отправлена отдельным сообщением")
            return True
        except Exception as e:  # noqa: BLE001
            log.warning("Утренняя сводка не отправлена: %s", e)
            return False
        finally:
            self.lock.release()

    def flush_queue(self):
        """Связь вернулась, а до планового съёма далеко: отправить накопленное (старое первым, ≤10 картинок)."""
        cfg = self.cfg_getter()
        q = self.queue(cfg)
        if not len(q) or self.hold or not (cfg.get("offline_queue") or {}).get("enabled", True):
            return None
        if not self.online() or not self.lock.acquire(blocking=False):
            return None
        try:
            self._wait_cleanup()
            items = q.take(offqueue.VK_LIMIT)
            if not items:
                q.remove([])
                return None
            self.set_phase("send")
            paths = [p for e in items for p in e["paths"]]
            self.vk_factory(cfg).send_photos(cfg["vk"]["peer_id"], paths, offqueue.caption(items))
            q.remove(e["stamp"] for e in items)
            log.info("Связь вернулась — из очереди отправлено съёмов: %d", len(items))
            return len(items)
        except Exception as e:  # noqa: BLE001
            log.warning("Очередь пока не отправлена: %s", e)
            self._maybe_hold(e)
            return False
        finally:
            self.set_phase(None)
            self.lock.release()

    def run_cycle(self, send=True, manual=False, capture_at=None):
        """Полный цикл с повторами. Возвращает True при успехе.
        manual=True — запуск кнопкой (снимает паузу «Нужно ваше действие»).
        capture_at — плановый запуск с ранним стартом: цикл начался раньше, снимок — ровно в capture_at."""
        if send and self.hold and not manual:
            log.warning("Плановая отправка пропущена: нужно ваше действие — %s", self.hold)
            return False
        if not self.lock.acquire(blocking=False):
            log.warning("Предыдущий запуск ещё не закончен — пропуск")
            return False
        self._wait_cleanup()
        from . import recorder
        recorder.wait_not_recording()     # 3.0.1: во время записи сценария съёмка ждёт её окончания
        self.capture_at = capture_at
        self._result = {"time": capture_at or self.now(), "ok": False, "sent": False, "paths": [], "errors": {},
                        "send_error": None, "partial": False, "warnings": {}}
        if self.on_start:
            try:
                self.on_start()
            except Exception:  # noqa: BLE001
                pass
        try:
            ok = self._run_cycle(send, manual, capture_at)
        except Exception as e:  # noqa: BLE001
            log.exception("Цикл прерван ошибкой")
            self._result["send_error"] = humanize(e)
            ok = False
        finally:
            self.set_phase(None)
            self.active_stamp = None
            self.capture_at = None
            self.lock.release()
        self._result["ok"] = ok
        self.last_result = self._result
        if send and ok and self._result.get("sent") and not self._result.get("queued") \
                and not self._result.get("already"):
            hourdone.mark(self._root(), self._result["time"], hourdone.MANUAL if manual else hourdone.PROGRAM)
        if send:
            try:
                r = self._result
                summary.record(summary.log_path(self._root()), r["time"], ok, r.get("sent"), planned=not manual,
                               queued=bool(r.get("queued")), warnings=r.get("warnings"), error=r.get("send_error") or "; ".join(str(v) for v in (r.get("errors") or {}).values()),
                               shots=len(r.get("paths") or []))
            except Exception:  # noqa: BLE001
                log.debug("журнал съёмов", exc_info=True)
        if self.on_result:
            try:
                self.on_result(self._result)
            except Exception:  # noqa: BLE001
                log.exception("on_result")
        return ok

    def _run_cycle(self, send, manual=False, capture_at=None):
        cfg = self.cfg_getter()
        sched = cfg["schedule"]
        sources = [s for s in cfg.get("sources") or [] if s.get("enabled", True)]
        if not sources:
            log.error("Нет включённых источников")
            return False
        started = capture_at or self.now()
        stamp = started.strftime("%Y-%m-%d_%H-%M")
        self.active_stamp = self.last_stamp = stamp   # эти файлы уборка не трогает
        done = {}
        attempts = min(2, max(1, int(sched.get("attempts", 2))))  # не больше 2 попыток в час
        if manual:
            attempts = 1  # кнопка «Отправить сейчас»: одна попытка, итог сразу
        self.errors = {}
        self.warnings = {}
        res = getattr(self, "_result", None) or {}
        state = {"attempt": 0}
        backend = self.backend_factory()

        def attempt():
            state["attempt"] += 1
            last = state["attempt"] >= attempts
            if send and state["attempt"] > 1 and self.hour_already_sent(cfg, started, "перед повтором"):
                res["sent"] = True
                res["send_error"] = None
                res["already"] = True
                return True
            log.info("Попытка %d из %d", state["attempt"], attempts)
            # ранний старт — только у первой попытки; повтор через 3 минуты снимает сразу
            at = capture_at if state["attempt"] == 1 else None
            self.capture_sources(sources, backend, stamp, done, capture_at=at)
            res["warnings"] = dict(self.warnings)
            complete = len(done) == len(sources)
            if not send:
                return complete
            if not done or not (complete or (last and sched.get("send_partial", True))):
                return False
            paths = [p for s in sources for p in done.get(s.get("name"), [])]
            vk_cfg = cfg["vk"]
            res["paths"] = paths
            self.set_phase("send")
            caption = caption_with_notes(format_caption(vk_cfg.get("caption", ""), started,
                                                        cfg.get("app", {}).get("club_name", "")), self.warnings)
            oq = cfg.get("offline_queue") or {}
            queue = self.queue(cfg)
            extra = queue.take(offqueue.VK_LIMIT - len(paths)) if oq.get("enabled", True) else []
            extra = [e for e in extra if e["stamp"] != stamp]
            if extra:
                caption = (caption + "\n" if caption else "") + offqueue.caption(extra, started.strftime("%H:%M"))
            send_paths = [p for e in extra for p in e["paths"]] + paths
            summ = self._summary_due(cfg)
            if summ:
                caption = (caption + "\n" if caption else "") + summ
            try:
                client = self.vk_factory(cfg)
                res["send_result"] = client.send_photos(vk_cfg["peer_id"], send_paths, caption)
            except Exception as e:
                if (oq.get("enabled", True) and not manual and getattr(e, "retry", True) is not False
                        and not getattr(e, "needs_user", False) and not self.online()):
                    # 2.2.0: нет интернета — снимки ждут в очереди; повторять отправку сейчас бессмысленно
                    for d in queue.add(stamp, started, paths):
                        log.warning("Очередь переполнена — съём %s больше не ждёт отправки", d["time"])
                    res["queued"] = len(queue)
                    res["send_error"] = None
                    log.warning("Нет связи с ВКонтакте (%s) — снимки оставлены в очереди (%d съёмов)", e,
                                res["queued"])
                    return True
                res["send_error"] = humanize(e)
                if getattr(e, "kind", "") == "unconfirmed":
                    res.setdefault("warnings", {})["ВКонтакте"] = "проверьте беседу — не видно, дошло ли сообщение"
                self._maybe_hold(e)
                raise
            if extra:
                queue.remove(e["stamp"] for e in extra)
                res["flushed"] = len(extra)
                log.info("Из очереди отправлено съёмов: %d", len(extra))
            if summ:
                summary.set_last_sent(summary.last_sent_path(self._root()), self.now())
            self.clear_hold()
            res["sent"] = True
            res["send_error"] = None
            res["partial"] = not complete
            if not complete:
                log.warning("Отправлено частично: не удалось снять %s",
                            ", ".join(s["name"] for s in sources if s["name"] not in done))
            return True

        interval = max(180, int(sched.get("retry_interval_sec", 180) or 180))  # не чаще раза в 3 минуты
        def interim(e=None):
            """Промежуточный итог: ошибка видна сразу, а не через 3 минуты, после повтора."""
            if e is not None and not res.get("send_error"):
                res["send_error"] = humanize(e)
            self.last_result = dict(res, ok=False, interim=True,
                                    errors={n: humanize(x, n) for n, x in self.errors.items()})
            self.set_phase("retry_wait")

        def on_error(i, e):
            log.error("Попытка %d: %s", i, e)
            if i < attempts and getattr(e, "retry", True) is not False:
                interim(e)

        def attempt_or_wait():
            ok_ = attempt()
            if not ok_ and state["attempt"] < attempts:
                interim()
            return ok_

        ok = run_with_retries(attempt_or_wait, attempts, interval, wait=self._wait, on_error=on_error)
        if not res.get("paths"):
            res["paths"] = [p for s in sources for p in done.get(s.get("name"), [])]
        res["errors"] = {n: humanize(e, n) for n, e in self.errors.items()}
        res["hold"] = self.hold
        if send and not ok and done:
            # неудачная отправка: эти скриншоты хранятся 3 дня (их можно отправить вручную)
            mark_failed(resolve_path(cfg["storage"]["screenshots_dir"], self.root), stamp)
        log.info("Цикл завершён: %s", "успешно" if ok else "С ОШИБКОЙ")
        return ok
