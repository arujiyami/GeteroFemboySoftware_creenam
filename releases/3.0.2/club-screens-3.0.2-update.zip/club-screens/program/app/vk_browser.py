# Original-Author: Владислав С.
# Created: 2026-10-28
"""Отправка скриншотов от вашего профиля ВКонтакте через браузер, встроенный в окно программы.

Никаких токенов и сторонних приложений: внутри окна «Скриншоты клуба» открыт обычный vk.com
(движок Chromium из Qt WebEngine) с отдельным профилем в папке browser_profile. Вы один раз входите
в ВК сами, а дальше программа раз в час открывает беседу, прикрепляет картинки и нажимает «Отправить».

Здесь — только логика, без Qt: действия описаны «сценариями» (генераторами), которые по очереди
выдают простые операции («открыть адрес», «выполнить JS», «подождать», …). Выполняет их
app/ui/browser.py во встроенном браузере, а тесты — на поддельной странице.
"""
import base64
import glob
import json
import logging
import mimetypes
import os
import random
import re
import time

from .logincheck import decide

log = logging.getLogger("club")

CHAT_BASE = 2000000000

# Добавлены в 2.1.3 (новый интерфейс ВК); при обновлении дописываются и в старый config.yaml.
NEW_LOGGED_IN_SELECTORS = ['a[href="/im"]', 'a[href^="/im?"]', 'a[href^="/im/"]', 'nav [href*="/feed"]',
                           'a[href="/feed"]', 'a[href="/friends"]', '[data-testid*="profile-menu"]',
                           '[aria-label="Профиль"]', '#l_pr', '#l_nwsf']

# Селекторы по умолчанию. Их можно поменять в config.yaml (vk_browser.selectors), если ВК сменит дизайн.
# Для каждого ключа — список вариантов; используется первый, который нашёлся на странице.
DEFAULT_SELECTORS = {
    "composer": ['[data-testid="vkme_composer_input"]', '[contenteditable="true"][role="textbox"]', '.ComposerInput [contenteditable="true"]',
                 '.im_editable[contenteditable="true"]', 'div[contenteditable="true"]',
                 'textarea[placeholder*="ообщение"]', 'textarea'],
    "file_input": ['input[type="file"][data-testid="vkme_composer_attach_input"]', 'input[type="file"][accept*="image"]', 'input[type="file"]'],
    "attach_button": ['[data-testid="vkme_composer_attach_button"]', '[aria-label="Загрузить файл"]',
                      '[aria-label="Прикрепить"]', '[aria-label*="рикрепить"]', '[aria-label="Attach"]',
                      'button[aria-label*="ttach"]'],
    "attach_photo_item": ['text="Фото или видео"', 'text="Фотография"', 'text="Фото"', 'text="Photo or video"'],
    # Превью, загрузка и «удалить» ищутся ТОЛЬКО внутри области ввода сообщения (см. L.box в JS):
    # закреплённые сообщения и фото в истории беседы не считаются.
    "attachment_preview": ['[data-testid="vkme_composer_attach_item"]', '[class*="ttach"] img', '[class*="AttachPhoto"]', '[class*="ttachments"] [class*="hoto"]',
                           '[class*="ttach"] [style*="background-image"]', '.page_preview_photo', 'img[src^="blob:"]'],
    "upload_progress": ['[role="progressbar"]', '[class*="rogress"]', '[class*="pinner"]'],
    "attachment_remove": ['[data-testid="vkme_composer_attach_remove"]', '[aria-label="Удалить"]', '[aria-label="Удалить вложение"]', '[aria-label="Remove"]',
                          '[class*="ttach"] [class*="emove"]', '[class*="ttach"] [class*="elete"]'],
    "send_button": ['[data-testid="vkme_composer_send"]', '[aria-label="Отправить сообщение"]',
                    '[class*="ConvoComposer__sendButton"]', 'role=button[name="Отправить"]', '[aria-label="Отправить"]', '[aria-label="Send"]',
                    'role=button[name="Send"]'],
    "history_photos": ['.AttachPhotos__link img.PhotoItem__img', '[class*="ConvoHistory"] img[src*="userapi"]', '[class*="ConvoMessage"] img[src*="userapi"]',
                       '.im-mess-stack img[src*="userapi"]', '.im-mess .page_post_thumb_wrap'],
    "outgoing_message": ['[class*="ConvoMessage--out"]', '[class*="Message--out"]', '.im-mess--out'],
    "upload_error": ['text=/Не удалось загрузить|Ошибка загрузки/i'],
    "captcha": ['img[src*="captcha"]', 'iframe[src*="captcha"]', '[class*="aptcha"] input',
                'text=/Я не робот|Введите код с картинки|Подтвердите, что вы не робот/i'],
    "blocked_text": ['text=/Страница заблокирована|страница была заблокирована|Ваша страница взломана'
                     '|Страница временно заморожена|подозрительная активность/i'],
    "login_form": ['input[name="login"]', '#index_email', '[data-testid="enter-another-way"]',
                   'button:has-text("Войти")', 'text="Войти другим способом"'],
    # Признаки входа. Новый дизайн ВК: ссылки левого меню на /im, /feed, /friends и кнопка-аватар профиля.
    "logged_in": ['#top_profile_link', '[data-testid="header-profile-menu-button"]', '#l_msg']
                 + NEW_LOGGED_IN_SELECTORS,
    "profile_name": ['.top_profile_name', '[data-testid="header-profile-menu-button"] img[alt]',
                     '#top_profile_link img[alt]', '[data-testid*="profile-menu"] img[alt]',
                     '[aria-label="Профиль"] img[alt]'],
    "chat_list_item": ['a[href*="/im/convo/"]', 'a[href*="im?sel="]', 'a[href*="sel="]'],
    "chat_search": ['input[placeholder*="Поиск"]', 'input[type="search"]', 'input[placeholder*="Search"]'],
    "chat_not_found": ['text=/Беседа не найдена|Чат не найден|Вы не состоите в этой беседе|нет доступа к беседе/i'],
}

# 2.2.3: по реальной разметке ВК (vk.ru/im, октябрь 2026)
PRIORITY_SELECTORS = {
    "composer": ['[data-testid="vkme_composer_input"]'],
    "file_input": ['input[type="file"][data-testid="vkme_composer_attach_input"]'],
    "attach_button": ['[data-testid="vkme_composer_attach_button"]'],
    "attachment_preview": ['[data-testid="vkme_composer_attach_item"]'],
    "attachment_remove": ['[data-testid="vkme_composer_attach_remove"]'],
    "send_button": ['[data-testid="vkme_composer_send"]', '[aria-label="Отправить сообщение"]',
                    '[class*="ConvoComposer__sendButton"]'],
    "history_photos": ['.AttachPhotos__link img.PhotoItem__img'],   # фото в ленте теперь с vkuserphoto, не userapi
}

DEFAULTS = {
    "profile_dir": "browser_profile", "user_agent": "", "chat_list_timeout_sec": 20,
    "home_url": "https://vk.com/", "im_url": "https://vk.com/im", "chat_url": "https://vk.com/im/convo/{peer_id}",
    "pause_min_sec": 0.8, "pause_max_sec": 2.2, "page_timeout_sec": 30, "upload_timeout_sec": 90,
    "verify_timeout_sec": 20, "upload_fallback_wait_sec": 8, "attach_check_sec": 8, "send_timeout_sec": 90,
    "save_memory": True,
    "delivery_check": True, "delivery_wait_sec": 30,
    "upload_poll_sec": 1.0, "warm_max_age_sec": 60,
    "keep_error_shots": 20,
    "login_cookies": ["remixsid", "remixnsid"],
    "url_blocked": ["/blocked", "/checkpoint", "act=blocked", "/restore"],
    "url_login": ["/login", "id.vk.com/auth", "act=login", "/join"],
    "url_captcha": ["captcha", "/challenge"],
}

LOGIN_HINT = ("Нужно войти во ВКонтакте: откройте раздел «ВКонтакте» в окне программы и войдите "
              "(или «Настроить заново» → «Вход ВК»).")


# ---------------------------------------------------------------- ошибки
class BrowserError(Exception):
    """Ошибка отправки через браузер. retry=False — повторять бессмысленно/опасно (нужен человек)."""
    kind = "error"
    retry = True
    needs_user = False

    def __init__(self, text, shot=None):
        super().__init__(text)
        self.text = text
        self.shot = shot


class NotLoggedIn(BrowserError):
    kind, retry, needs_user = "not_logged_in", False, True

    def __init__(self, text=LOGIN_HINT, shot=None, confirmed=False):
        super().__init__(text, shot)
        # confirmed — ВК открыл страницу входа или показал форму входа без cookie сессии:
        # только тогда программа забывает «вход выполнен».
        self.confirmed = bool(confirmed)


class AccountBlocked(BrowserError):
    kind, retry, needs_user = "blocked", False, True

    def __init__(self, text=None, shot=None):
        super().__init__(text or ("ВКонтакте заблокировал или проверяет вашу страницу. Откройте vk.com в обычном "
                                  "браузере и восстановите доступ, затем снова войдите: «Настроить заново» → "
                                  "«Вход ВК». До этого программа ничего отправлять не будет."), shot)


class CaptchaShown(BrowserError):
    kind, retry, needs_user = "captcha", False, True

    def __init__(self, text=None, shot=None):
        super().__init__(text or ("ВКонтакте попросил капчу («Я не робот»). Откройте раздел «ВКонтакте» в окне "
                                  "программы, пройдите проверку, затем нажмите «Отправить сейчас». До этого "
                                  "программа ничего отправлять не будет."), shot)


class ChatNotFound(BrowserError):
    kind, retry, needs_user = "chat_not_found", False, True

    def __init__(self, text=None, shot=None):
        super().__init__(text or ("Беседа не открылась — проверьте, что ваш профиль состоит в беседе, и выберите "
                                  "её заново: «Настроить заново» → «Выбор беседы»."), shot)


class SendFailed(BrowserError):
    kind = "send_failed"


class SendTimeout(SendFailed):
    kind = "timeout"

    def __init__(self, seconds=90, text=None, shot=None):
        super().__init__(text or (f"ВКонтакте не ответил за {int(seconds)} секунд — отправка прервана. Снимок "
                                  "страницы и сведения для разбора сохранены в папке logs (файлы vk_…). "
                                  "Программа попробует ещё раз через 3 минуты."), shot)


class StillInComposer(SendFailed):
    """2.2.1: после нажатия картинки так и остались в поле ввода — сообщение точно НЕ ушло,
    поэтому повтор (с перезагрузкой беседы) безопасен."""
    kind = "still_in_composer"


class DeliveryUnconfirmed(SendFailed):
    """2.2.0: после «Отправить» новое сообщение с картинками так и не появилось в беседе (и после одной
    повторной отправки). Повторять больше нельзя — можно задвоить; нужен взгляд человека."""
    kind, retry = "unconfirmed", False

    def __init__(self, text=None, shot=None):
        super().__init__(text or ("Не удалось убедиться, что сообщение с картинками дошло до беседы. Откройте "
                                  "раздел «ВКонтакте» и проверьте беседу. Чтобы не отправить картинки дважды, "
                                  "больше в этот час программа ничего не отправляет."), shot)


class BrowserUnavailable(BrowserError):
    kind, retry = "no_browser", False


class ChatListTimeout(BrowserError):
    kind, retry = "chat_list_timeout", False

    def __init__(self, text=None, shot=None):
        super().__init__(text or ("Список бесед не загрузился за 20 секунд. Ничего страшного: откройте нужную "
                                  "беседу во ВКонтакте, скопируйте ссылку из адресной строки, вставьте её в поле "
                                  "ниже и нажмите «Далее»."), shot)


# ---------------------------------------------------------------- разбор ссылок
def parse_chat_link(text):
    """Ссылка на беседу/диалог → peer_id. Понимает vk.com/im/convo/2000000001, vk.com/im?sel=c1,
    vk.ru/im/convo/…, vk.com/im?sel=123 и просто число. Иначе None."""
    t = (text or "").strip()
    if not t:
        return None
    m = re.search(r"/im/convo/(-?\d+)", t)
    if m:
        return int(m.group(1))
    m = re.search(r"[?&]sel=c(\d+)", t)
    if m:
        return CHAT_BASE + int(m.group(1))
    m = re.search(r"[?&]sel=(-?\d+)", t)
    if m:
        return int(m.group(1))
    if re.fullmatch(r"-?\d+", t):
        return int(t)
    return None


def peer_type(peer_id):
    peer_id = int(peer_id)
    return "chat" if peer_id > CHAT_BASE else ("group" if peer_id < 0 else "user")


def parse_chat_items(items):
    """[{href, text}] со страницы vk.com/im → [{peer_id, title, type}] без повторов."""
    out, seen = [], set()
    for it in items or []:
        peer = parse_chat_link(it.get("href") or "")
        if peer is None or peer in seen:
            continue
        lines = [ln.strip() for ln in (it.get("text") or "").splitlines() if ln.strip()]
        title = (it.get("title") or (lines[0] if lines else "")).strip()
        if not title:
            continue
        seen.add(peer)
        out.append({"peer_id": peer, "title": title, "type": peer_type(peer)})
    return out


def _short_url(url):
    """Адрес без параметров и якоря — для журнала."""
    return (url or "").split("#")[0].split("?")[0][:120]


def merged_settings(cfg):
    vb = dict(DEFAULTS)
    vb.update({k: v for k, v in (cfg.get("vk_browser") or {}).items() if k != "selectors"})
    if vb.get("upload_timeout_sec") == 45:     # 2.2.1: старое значение по умолчанию — теперь ждём до 90 с
        vb["upload_timeout_sec"] = 90
    sel = {k: list(v) for k, v in DEFAULT_SELECTORS.items()}
    for k, v in ((cfg.get("vk_browser") or {}).get("selectors") or {}).items():
        if v:
            sel[k] = [v] if isinstance(v, str) else list(v)
    # 2.2.3: точные селекторы текущего ВК (data-testid и т.п.) — всегда первыми, даже если в config.yaml
    # остался старый список (в 2.2.2 кнопка «Отправить сообщение» по старому списку не находилась).
    for k, pri in PRIORITY_SELECTORS.items():
        sel[k] = pri + [x for x in sel.get(k, []) if x not in pri]
    vb["selectors"] = sel
    return vb


# ---------------------------------------------------------------- JS на странице
# Понимает те же записи селекторов, что и раньше: CSS, text=/рег.выр/i, text="Точно", text=часть,
# role=button[name="Имя"], css:has-text("часть").
JS_LIB = r"""
var L = {};
L.norm = function (s) { return (s || '').replace(/\s+/g, ' ').trim(); };
L.vis = function (e) {
  if (!e || !e.isConnected) return false;
  var r = e.getBoundingClientRect();
  if (r.width < 1 || r.height < 1) return false;
  var cs = getComputedStyle(e);
  return cs.visibility !== 'hidden' && cs.display !== 'none' && parseFloat(cs.opacity || '1') > 0.01;
};
L.all = function () { return document.body ? Array.prototype.slice.call(document.body.querySelectorAll('*')) : []; };
L.ownText = function (el) {
  var t = '';
  for (var i = 0; i < el.childNodes.length; i++) if (el.childNodes[i].nodeType === 3) t += el.childNodes[i].textContent;
  return L.norm(t);
};
L.byText = function (pred) {
  var skip = {SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1};
  var els = L.all().filter(function (e) { return !skip[e.tagName]; });
  var own = els.filter(function (e) { var t = L.ownText(e); return t && pred(t); });
  if (own.length) return own;
  var full = els.filter(function (e) { return pred(L.norm(e.innerText)); });
  return full.filter(function (e) { return !full.some(function (o) { return o !== e && e.contains(o); }); });
};
L.q = function (sel) {
  sel = (sel || '').trim();
  var m;
  try {
    if ((m = sel.match(/^text=\/([\s\S]*)\/([a-z]*)$/))) {
      var re = new RegExp(m[1], m[2]);
      return L.byText(function (t) { return re.test(t); });
    }
    if ((m = sel.match(/^text="([\s\S]*)"$/))) {
      var want = L.norm(m[1]).toLowerCase();
      return L.byText(function (t) { return t.toLowerCase() === want; });
    }
    if ((m = sel.match(/^text=([\s\S]*)$/))) {
      var part = L.norm(m[1]).toLowerCase();
      return L.byText(function (t) { return t.toLowerCase().indexOf(part) >= 0; });
    }
    if ((m = sel.match(/^role=([\w-]+)\[name="([\s\S]*)"\]$/))) {
      var role = m[1], name = L.norm(m[2]).toLowerCase();
      var css = '[role="' + role + '"]' + (role === 'button' ? ',button,input[type=button],input[type=submit]' : '')
        + (role === 'link' ? ',a[href]' : '') + (role === 'textbox' ? ',input:not([type]),input[type=text],textarea' : '');
      return Array.prototype.slice.call(document.querySelectorAll(css)).filter(function (e) {
        var n = L.norm(e.getAttribute('aria-label') || e.getAttribute('title') || e.innerText || e.value);
        return n.toLowerCase() === name;
      });
    }
    if ((m = sel.match(/^([\s\S]*):has-text\("([\s\S]*)"\)$/))) {
      var sub = m[2].toLowerCase();
      return Array.prototype.slice.call(document.querySelectorAll(m[1] || '*')).filter(function (e) {
        return L.norm(e.innerText).toLowerCase().indexOf(sub) >= 0;
      });
    }
    return Array.prototype.slice.call(document.querySelectorAll(sel));
  } catch (e) { return []; }
};
L.mine = function (e) { return !(e.closest && e.closest('[data-cs-hl]')); };
L.find = function (key, anyVis, root) {
  var sels = S[key] || [];
  for (var i = 0; i < sels.length; i++) {
    var els = L.q(sels[i]);
    for (var j = 0; j < els.length; j++)
      if ((anyVis || L.vis(els[j])) && (!root || root.contains(els[j])) && L.mine(els[j])) return els[j];
  }
  return null;
};
// root задан — считаем только внутри него (область ввода сообщения)
L.count = function (key, onlyVis, root) {
  var best = 0, sels = S[key] || [];
  for (var i = 0; i < sels.length; i++) {
    var els = L.q(sels[i]).filter(function (e) { return (!root || root.contains(e)) && L.mine(e); });
    var n = onlyVis ? els.filter(L.vis).length : els.length;
    if (n > best) best = n;
  }
  return best;
};
// Поле ввода сообщения: из всех подходящих видимых — самое нижнее на странице
L.composer = function () {
  var best = null, bb = -1e9, sels = S.composer || [];
  for (var i = 0; i < sels.length; i++) {
    L.q(sels[i]).forEach(function (e) {
      if (!L.vis(e) || !L.mine(e)) return;
      var b = e.getBoundingClientRect().bottom;
      if (b > bb + 1) { bb = b; best = e; }
    });
    if (best) break;
  }
  return best;
};
// Область ввода: поднимаемся от поля, пока предок не выше max(260 px, 45% окна) — история и
// закреплённые сообщения в неё не попадают
L.box = function () {
  var c = L.composer();
  if (!c) return null;
  var lim = Math.max(260, innerHeight * 0.45), b = c;
  for (var p = c.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
    if (p.getBoundingClientRect().height > lim) break;
    b = p;
  }
  // 2.2.3: кнопка «Отправить» рядом с полем, но вне найденной области — расширяем область до общего
  // корня поля ввода и кнопки (если он не выше 60% окна: история беседы в область не попадает)
  var sb = L.sendNear(c);
  if (sb && !b.contains(sb)) {
    for (var q = b.parentElement; q && q !== document.body; q = q.parentElement) {
      if (q.getBoundingClientRect().height > Math.max(lim, innerHeight * 0.6)) break;
      if (q.contains(sb)) { b = q; break; }
    }
  }
  return b;
};
// 2.2.3: кнопка «Отправить» ищется по всей странице (data-testid → aria-label → класс → прочее);
// из найденных — в состоянии «отправить» (не микрофон), ближайшая к полю ввода
L.sendCands = function () {
  var out = [], sels = S.send_button || [];
  sels.forEach(function (sel, i) {
    L.q(sel).forEach(function (e) {
      if (e.tagName !== 'BUTTON' && e.getAttribute('role') !== 'button') {
        var up = e.closest && e.closest('button,[role="button"]');
        if (up) e = up;
      }
      if (!L.vis(e) || !L.mine(e) || out.some(function (o) { return o.el === e; })) return;
      out.push({el: e, rank: i});
    });
  });
  return out;
};
L.isMic = function (e) {
  var cls = typeof e.className === 'string' ? e.className : '';
  return /sendButton--(?!submit)/.test(cls) && cls.indexOf('--submit') < 0;
};
L.sendNear = function (c) {
  var cands = L.sendCands().filter(function (o) { return !L.isMic(o.el); });
  if (!cands.length) return null;
  if (!c) return cands.sort(function (a, b) { return a.rank - b.rank; })[0].el;
  var cr = c.getBoundingClientRect(), cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
  var dist = function (e) { var r = e.getBoundingClientRect(); return Math.hypot(r.left + r.width / 2 - cx, r.top + r.height / 2 - cy); };
  cands.sort(function (a, b) { return (a.rank - b.rank) || (dist(a.el) - dist(b.el)); });
  // самый точный селектор, но не дальше 600 px от поля; иначе — просто ближайшая
  var near = cands.filter(function (o) { return dist(o.el) < 600; });
  return (near.length ? near : cands.sort(function (a, b) { return dist(a.el) - dist(b.el); }))[0].el;
};
L.sendButton = function () { return L.sendNear(L.composer()); };
// полная последовательность событий указателя/мыши + .click()
L.press = function (el) {
  var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  var o = {bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0,
           pointerId: 1, pointerType: 'mouse', isPrimary: true};
  var pe = function (t, b) { try { el.dispatchEvent(new PointerEvent(t, Object.assign({}, o, {buttons: b}))); } catch (e) {} };
  var me = function (t, b) { el.dispatchEvent(new MouseEvent(t, Object.assign({}, o, {buttons: b}))); };
  pe('pointerover', 0); pe('pointerenter', 0); me('mouseover', 0); me('mouseenter', 0);
  pe('pointermove', 0); me('mousemove', 0);
  pe('pointerdown', 1); me('mousedown', 1);
  try { el.focus({preventScroll: true}); } catch (e) {}
  pe('pointerup', 0); me('mouseup', 0);
  el.click();
};
L.desc = function (e) {
  if (!e) return '';
  var cls = (typeof e.className === 'string' ? e.className : '').trim().split(/\s+/).slice(0, 3).join('.');
  return e.tagName.toLowerCase() + (e.id ? '#' + e.id : '') + (cls ? '.' + cls : '');
};
L.inZone = function (e, zone) {
  var r = e.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  return x >= zone.l && x <= zone.r && y >= zone.t && y <= zone.b;
};
// Поле выбора файла: в области ввода с картинками → любое с картинками → в области → любое
L.fileInput = function () {
  var box = L.box(), all = Array.prototype.slice.call(document.querySelectorAll('input[type="file"]'));
  var sels = S.file_input || [], cands = [];
  sels.forEach(function (s) { L.q(s).forEach(function (e) { if (cands.indexOf(e) < 0 && e.tagName === 'INPUT') cands.push(e); }); });
  all.forEach(function (e) { if (cands.indexOf(e) < 0) cands.push(e); });
  var img = function (e) { var a = (e.getAttribute('accept') || '').toLowerCase(); return !a || a.indexOf('image') >= 0 || a.indexOf('*') >= 0 || /\.(png|jpe?g)/.test(a); };
  var strict = function (e) { return (e.getAttribute('accept') || '').toLowerCase().indexOf('image') >= 0; };
  var inBox = function (e) { return box && box.contains(e); };
  var order = [function (e) { return inBox(e) && strict(e); }, strict, function (e) { return inBox(e) && img(e); }, img];
  for (var i = 0; i < order.length; i++) for (var j = 0; j < cands.length; j++) if (!cands[j].disabled && order[i](cands[j])) return cands[j];
  return null;
};
L.files = function (files) {
  var dt = new DataTransfer();
  files.forEach(function (f) {
    var bin = atob(f.data), buf = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    dt.items.add(new File([buf], f.name, {type: f.type}));
  });
  return dt;
};
L.mouse = function (el) {
  var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  var o = {bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0};
  try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (e) {}
  el.dispatchEvent(new MouseEvent('mousedown', o));
  try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (e) {}
  el.dispatchEvent(new MouseEvent('mouseup', o));
  el.click();
};
L.caretEnd = function (el) {
  el.focus();
  try {
    var r = document.createRange(); r.selectNodeContents(el); r.collapse(false);
    var s = getSelection(); s.removeAllRanges(); s.addRange(r);
  } catch (e) {}
};
L.key = function (el, name, code) {
  ['keydown', 'keypress', 'keyup'].forEach(function (t) {
    el.dispatchEvent(new KeyboardEvent(t, {key: name, code: name, keyCode: code, which: code, bubbles: true, cancelable: true}));
  });
};
L.scroller = function (el) {
  for (var p = el; p && p !== document.body; p = p.parentElement) {
    var cs = getComputedStyle(p);
    if (/(auto|scroll)/.test(cs.overflowY) && p.scrollHeight > p.clientHeight + 10) return p;
  }
  return document.scrollingElement;
};
var F = {};
// какой селектор сработал (для журнала разбора: только сами селекторы, без содержимого страницы)
L.which = function (key, onlyVis) {
  var sels = S[key] || [];
  for (var i = 0; i < sels.length; i++) {
    var els = L.q(sels[i]).filter(function (e) { return L.mine(e) && (!onlyVis || L.vis(e)); });
    if (els.length) return sels[i];
  }
  return '';
};
F.probe = function (a) {
  var c = {}, m = {}, g = {}, boxed = a.box || [], box = null;
  if (boxed.length) box = L.box();
  (a.keys || []).forEach(function (k) {
    var vis = (a.all || []).indexOf(k) < 0;
    if (k === 'composer') c[k] = L.composer() ? 1 : 0;
    else if (k === 'send_button') { c[k] = L.sendButton() ? 1 : 0; g[k] = L.count(k, vis); }
    else if (boxed.indexOf(k) >= 0) { c[k] = box ? L.count(k, vis, box) : 0; g[k] = L.count(k, vis); }
    else c[k] = L.count(k, vis);
    if (a.why && c[k] && k !== 'composer' && boxed.indexOf(k) < 0) m[k] = L.which(k, vis);
  });
  return {url: location.href, title: document.title, ready: document.readyState, c: c, m: m, all: g, box: !!box};
};
// scope: 'box' — только в области ввода; 'prefer' — сначала в ней, потом везде
F.click = function (a) {
  var box = a.scope ? L.box() : null;
  if (a.scope === 'box' && !box) return false;
  var el = box ? L.find(a.key, false, box) : null;
  if (!el && a.scope !== 'box') el = L.find(a.key);
  if (!el) return false;
  try { el.scrollIntoView({block: 'center'}); } catch (e) {}
  L.mouse(el);
  return true;
};
F.center = function (a) {
  var el = L.find(a.key);
  if (!el) return null;
  try { el.scrollIntoView({block: 'center'}); } catch (e) {}
  var r = el.getBoundingClientRect();
  return {x: r.left + r.width / 2, y: r.top + r.height / 2, w: innerWidth, h: innerHeight};
};
F.name = function (a) {
  var sels = S[a.key] || [];
  for (var i = 0; i < sels.length; i++) {
    var els = L.q(sels[i]);
    for (var j = 0; j < els.length; j++) {
      var e = els[j], vals = [e.getAttribute('alt'), e.getAttribute('aria-label'), e.innerText];
      for (var k = 0; k < vals.length; k++) {
        var v = L.norm(vals[k]);
        if (v && v.length < 80 && !/^(http|меню|menu)/i.test(v)) return v;
      }
    }
  }
  return '';
};
// Беседы: все ссылки вида /im/convo/<id> или ?sel=<id> с их текстом (+ свои селекторы), с прокруткой
L.CHAT_RE = /\/im\/convo\/-?\d+|[?&]sel=c?-?\d+/;
L.rowText = function (e) {
  var t = L.norm(e.innerText), p = e;
  for (var i = 0; i < 4 && !t && p.parentElement; i++) { p = p.parentElement; t = L.norm(p.innerText); }
  return e.innerText && L.norm(e.innerText) ? e.innerText : (t || '');
};
F.chats = function (a) {
  var seen = [], out = [];
  var push = function (e) {
    if (seen.indexOf(e) >= 0 || !L.mine(e)) return;
    var link = e.tagName === 'A' ? e : (e.closest('a[href]') || e.querySelector('a[href]'));
    var href = (link && link.getAttribute('href')) || e.getAttribute('data-href') || '';
    if (!L.CHAT_RE.test(href)) return;
    seen.push(e);
    out.push({href: href, text: L.rowText(e), title: e.getAttribute('aria-label') || e.getAttribute('title') || ''});
  };
  Array.prototype.slice.call(document.querySelectorAll('a[href]')).forEach(push);
  (S[a.key] || []).forEach(function (sel) { L.q(sel).forEach(push); });
  var moved = false;
  if (a.scroll) {
    var boxes = [];
    if (seen.length) boxes.push(L.scroller(seen[seen.length - 1]));
    // запасной вариант: самый большой прокручиваемый блок в левой половине окна
    var big = null, bh = 0;
    Array.prototype.slice.call(document.querySelectorAll('div,ul,section,nav')).forEach(function (e) {
      if (e.scrollHeight <= e.clientHeight + 10 || !/(auto|scroll)/.test(getComputedStyle(e).overflowY)) return;
      var r = e.getBoundingClientRect();
      if (r.left < innerWidth / 2 && r.height > bh) { bh = r.height; big = e; }
    });
    if (big) boxes.push(big);
    boxes.forEach(function (box) {
      if (!box || moved) return;
      var before = box.scrollTop;
      box.scrollTop = before + Math.max(200, box.clientHeight * 0.8);
      moved = box.scrollTop > before;
    });
    if (!moved && seen.length) { try { seen[seen.length - 1].scrollIntoView({block: 'end'}); } catch (e) {} }
  }
  return {items: out, moved: moved, anchors: document.querySelectorAll('a[href]').length};
};
F.input_info = function (a) {
  var el = L.fileInput();
  return el ? {found: true, multiple: !!el.multiple, in_box: !!(L.box() && L.box().contains(el))} : {found: false, multiple: false};
};
F.set_files = function (a) {
  var el = L.fileInput();
  if (!el) return {ok: false, reason: 'noinput'};
  el.files = L.files(a.files).files;
  window.__csInput = el;
  el.dispatchEvent(new Event('input', {bubbles: true}));
  el.dispatchEvent(new Event('change', {bubbles: true}));
  return {ok: true, n: el.files.length};
};
// Перетаскивание файлов на область ввода: 1) dragenter/dragover, 2) (через полсекунды) drop
F.drag = function (a) {
  var t = L.box() || L.composer();
  if (!t) return false;
  window.__csDT = L.files(a.files);
  var r = t.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
  ['dragenter', 'dragover'].forEach(function (n) {
    t.dispatchEvent(new DragEvent(n, {bubbles: true, cancelable: true, dataTransfer: window.__csDT, clientX: x, clientY: y}));
  });
  window.__csDrag = {x: x, y: y, t: t};
  return true;
};
F.drop = function (a) {
  var d = window.__csDrag;
  if (!d || !window.__csDT) return false;
  var t = document.elementFromPoint(d.x, d.y) || d.t;  // ВК мог показать слой «Перетащите сюда»
  var o = {bubbles: true, cancelable: true, dataTransfer: window.__csDT, clientX: d.x, clientY: d.y};
  t.dispatchEvent(new DragEvent('dragover', o));
  t.dispatchEvent(new DragEvent('drop', o));
  window.__csDrag = null;
  return true;
};
F.paste = function (a) {
  var el = L.composer();
  if (!el) return false;
  L.caretEnd(el);
  var dt = L.files(a.files);
  el.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true}));
  return true;
};
// «Подпись» области ввода: по её изменению понимаем, что ВК принял картинки (без повторного прикрепления)
L.MEDIA = 'img,canvas,video,[style*="background-image"],[role="progressbar"]';
F.sig = function (a) {
  var c = L.composer();
  if (!c) return {ok: false};
  var b = L.box(), r = c.getBoundingClientRect();
  var zone = {t: r.top - 280, b: r.bottom + 20, l: r.left - 80, r: r.right + 80};
  var zm = 0;
  Array.prototype.slice.call(document.querySelectorAll(L.MEDIA)).forEach(function (e) { if (L.mine(e) && L.vis(e) && L.inZone(e, zone)) zm++; });
  var inp = window.__csInput;
  return {ok: true, n: b ? b.getElementsByTagName('*').length : 0,
          media: b ? b.querySelectorAll(L.MEDIA).length : 0, zone: zm,
          h: b ? Math.round(b.getBoundingClientRect().height) : 0,
          prev: b ? L.count('attachment_preview', true, b) : 0, prog: b ? L.count('upload_progress', true, b) : 0,
          blob: document.querySelectorAll('img[src^="blob:"],[style*="blob:"]').length,
          consumed: !!(inp && (!inp.isConnected || !inp.files || inp.files.length === 0))};
};
F.type = function (a) {
  var el = L.composer();
  if (!el) return false;
  L.caretEnd(el);
  if (el.tagName === 'TEXTAREA') {
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(el, (el.value || '') + a.text);
    el.dispatchEvent(new Event('input', {bubbles: true}));
    return true;
  }
  if (!document.execCommand('insertText', false, a.text)) {
    el.textContent = (el.textContent || '') + a.text;
    el.dispatchEvent(new InputEvent('input', {bubbles: true, data: a.text, inputType: 'insertText'}));
  }
  return true;
};
F.enter = function (a) {
  var el = L.composer();
  if (!el) return false;
  L.caretEnd(el);
  L.key(el, 'Enter', 13);
  return true;
};
F.click_send = function (a) {
  var el = L.sendButton();
  if (!el) return 'none';
  if (el.disabled || el.getAttribute('aria-disabled') === 'true') return 'disabled';
  L.press(el);
  return 'clicked';
};
// 2.2.3: после нажатия — очистилось ли поле ввода (нет превью и текста)
F.composer_state = function (a) {
  var c = L.composer(), b = L.box();
  return {prev: b ? L.count('attachment_preview', true, b) : 0, text: c ? L.norm(c.innerText || c.value || '').length : 0,
          composer: !!c};
};
F.search = function (a) {
  var el = L.find(a.key);
  if (!el) return false;
  el.focus();
  var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, a.text);
  el.dispatchEvent(new Event('input', {bubbles: true}));
  return true;
};
// 2.2.4: сообщения с фото за этот час (для защиты от двойной отправки). Тексты сообщений не читаются —
// только автор (ссылка), время (ЧЧ:ММ), адреса и размеры картинок.
L.path = function (h) {
  if (!h) return '';
  try { var u = new URL(h, location.href); } catch (e) { return ''; }
  if (u.hostname && u.hostname.indexOf('vk.') < 0 && u.hostname.indexOf('vk.com') < 0) return '';
  var m = (u.search || '').match(/[?&](?:id|sel|uid)=(\d+)/);
  if (m) return 'id' + m[1];
  var p = (u.pathname || '').replace(/^\/+|\/+$/g, '');
  if (!p || p.indexOf('/') >= 0 || p === 'im') return '';
  return p.toLowerCase();
};
L.ownId = function () {
  try { if (window.vk && vk.id) return 'id' + vk.id; } catch (e) {}
  var sels = ['[data-testid="leftmenuitem_profile"] a[href]', 'a[data-testid="leftmenuitem_profile"]', '#l_pr a[href]',
              'a.TopNavBtn__profileLink[href]', '[data-testid="topnav_profile"] a[href]', 'a[data-testid="topnav_profile"]'];
  for (var i = 0; i < sels.length; i++) {
    var e = document.querySelector(sels[i]);
    if (e) { var r = L.path(e.getAttribute('href')); if (r) return r; }
  }
  return '';
};
F.hour_photos = function (a) {
  var own = L.ownId();
  var roots = Array.prototype.slice.call(document.querySelectorAll('.ConvoHistory__messageWrapper'));
  if (!roots.length) roots = Array.prototype.slice.call(document.querySelectorAll(
      '[class*="ConvoMessage--out"], [class*="ConvoMessage--in"], .im-mess'));
  var seps = Array.prototype.slice.call(document.querySelectorAll(
      '[class*="DateSeparator"], [class*="ConvoHistory__date"]:not(.ConvoHistory__dateStack), [class*="ServiceMessage"]'))
      .filter(function (e) { return /\d/.test(e.textContent || '') && !/сегодня|today/i.test(e.textContent || ''); });
  var out = [], author = null, time = null;
  roots.forEach(function (r) {
    var link = r.querySelector('a[class*="authorLink"][href], [class*="ConvoMessageHeader"] a[href], a[class*="PeerTitle"][href]');
    var hasHead = !!r.querySelector('[class*="ConvoMessageHeader"], [class*="authorLink"]');
    if (link) author = L.path(link.getAttribute('href'));
    else if (hasHead) author = '';
    var cls = String(r.className || '') + ' ' + String((r.firstElementChild || {}).className || '');
    var isOut = /--out\b|Message--out|im-mess--out/.test(cls) ? true : (/--in\b|im-mess--in/.test(cls) ? false : null);
    var d = r.querySelector('[class*="__date"], [class*="MessageInfo"] time, time');
    var m = d ? (d.textContent || d.getAttribute('datetime') || '').match(/(\d{1,2}):(\d{2})/) : null;
    if (m) time = (+m[1]) * 60 + (+m[2]);
    var imgs = Array.prototype.slice.call(r.querySelectorAll(
        '.AttachPhotos__link img, [class*="mediaAttachments"] img, [class*="AttachPhoto"] img, [class*="PhotoItem"] img'))
        .filter(function (i, k, all) { return all.indexOf(i) === k && !i.closest('[class*="vatar"]'); });
    if (!imgs.length) return;
    var after = seps.some(function (sp) { return r.compareDocumentPosition(sp) & Node.DOCUMENT_POSITION_FOLLOWING; });
    out.push({own: isOut !== null ? isOut : (own && author ? author === own : null), author_known: !!author,
              own_known: !!own, t: time, old_day: after,
              imgs: imgs.map(function (i) {
                var rc = i.getBoundingClientRect();
                return {src: i.currentSrc || i.src || '', w: i.naturalWidth || Math.round(rc.width),
                        h: i.naturalHeight || Math.round(rc.height)};
              })});
  });
  return {own: !!own, msgs: out.slice(-int0(a.max || 6))};
  function int0(x) { return Math.max(1, parseInt(x, 10) || 6); }
};
// ---- сведения для разбора ошибок: без текстов сообщений, без cookie, без адресов картинок
F.diag = function (a) {
  var c = L.composer(), b = L.box();
  var fi = Array.prototype.slice.call(document.querySelectorAll('input[type="file"]'));
  var m = {};
  ['composer', 'file_input', 'attach_button', 'attach_photo_item', 'attachment_preview', 'upload_progress',
   'attachment_remove', 'send_button', 'captcha', 'login_form', 'logged_in', 'chat_list_item'].forEach(function (k) {
    m[k] = L.count(k, true) + (b ? '/' + L.count(k, true, b) : '');
    if (k === 'send_button') { var sb = L.sendButton(); m[k] += ' (нажимается: ' + (sb ? L.desc(sb) + (b && b.contains(sb) ? ', в области' : ', вне области') : 'нет') + ')'; }
  });
  return {visibility: document.visibilityState, hidden: document.hidden, focus: document.hasFocus(),
          url: location.href.split('#')[0], title: document.title.slice(0, 80), size: innerWidth + 'x' + innerHeight,
          ready: document.readyState, composer: c ? L.desc(c) : null,
          box: b ? L.desc(b) + ' ' + Math.round(b.getBoundingClientRect().height) + 'px' : null,
          file_inputs: fi.length, file_inputs_in_box: b ? fi.filter(function (e) { return b.contains(e); }).length : 0,
          file_input_chosen: L.fileInput() ? L.desc(L.fileInput()) + '[' + (L.fileInput().getAttribute('accept') || '') + ']' : null,
          anchors_chat: Array.prototype.slice.call(document.querySelectorAll('a[href]')).filter(function (e) { return L.CHAT_RE.test(e.getAttribute('href')); }).length,
          matched: m};
};
L.esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); };
L.KEEP = ['id', 'class', 'role', 'type', 'accept', 'multiple', 'contenteditable', 'data-testid', 'disabled',
          'aria-disabled', 'aria-label', 'tabindex', 'draggable'];
L.attrs = function (e) {
  var out = '';
  L.KEEP.forEach(function (k) {
    if (!e.hasAttribute(k)) return;
    var v = e.getAttribute(k) || '';
    if (k === 'aria-label') {
      var btn = /^(BUTTON|INPUT|A)$/.test(e.tagName) || e.getAttribute('role') === 'button';
      v = btn ? v.slice(0, 40) : '[' + v.length + ' симв.]';
    }
    if (k === 'class') v = v.slice(0, 160);
    out += ' ' + k + '="' + L.esc(v) + '"';
  });
  var src = e.getAttribute('src');
  if (src) { var mm = src.match(/^[a-z]+:(\/\/[^\/?#]*)?/i); out += ' src="' + L.esc(mm ? mm[0] : '?') + '"'; }
  if ((e.getAttribute('style') || '').indexOf('background-image') >= 0) out += ' data-bg="1"';
  var r = e.getBoundingClientRect();
  out += ' data-rect="' + Math.round(r.left) + ',' + Math.round(r.top) + ' ' + Math.round(r.width) + 'x' + Math.round(r.height) + (L.vis(e) ? '' : ' скрыт') + '"';
  return out;
};
L.walk = function (e, d, st) {
  if (st.n++ > st.max) return st.n === st.max + 2 ? '\n<!-- обрезано -->' : '';
  var tag = e.tagName.toLowerCase();
  if (/^(script|style|noscript|template|link|meta)$/.test(tag) || !L.mine(e)) return '';
  var pad = new Array(d + 1).join('  '), s = '\n' + pad + '<' + tag + L.attrs(e) + '>';
  if (tag === 'svg') return s + '…</svg>';
  if (d > st.depth) return s + '…</' + tag + '>';
  for (var ch = e.firstChild; ch; ch = ch.nextSibling) {
    if (ch.nodeType === 3) { var t = ch.textContent.trim(); if (t) s += '[текст ' + t.length + ' симв.]'; }
    else if (ch.nodeType === 1) s += L.walk(ch, d + 1, st);
  }
  return s + '</' + tag + '>';
};
F.dump = function (a) {
  var c = L.composer(), b = L.box(), parts = [];
  var chain = [];
  for (var p = c || null; p && p !== document.documentElement; p = p.parentElement)
    chain.push(L.desc(p) + ' ' + Math.round(p.getBoundingClientRect().height) + 'px');
  parts.push('<!-- цепочка предков поля ввода (снизу вверх):\n' + L.esc(chain.join('\n')) + '\n-->');
  var fi = Array.prototype.slice.call(document.querySelectorAll('input[type="file"]')).map(function (e) {
    var anc = [], q = e.parentElement;
    for (var i = 0; i < 4 && q; i++, q = q.parentElement) anc.push(L.desc(q));
    return '<input' + L.attrs(e) + '> в области ввода: ' + (b && b.contains(e) ? 'да' : 'нет') + '; родители: ' + anc.join(' < ');
  });
  parts.push('<!-- поля выбора файла (' + fi.length + '):\n' + L.esc(fi.join('\n')) + '\n-->');
  var root = b ? (b.parentElement && b.parentElement.parentElement) || b : null;
  if (root) parts.push('<!-- область ввода и два уровня вокруг: -->' + L.walk(root, 0, {n: 0, max: a.max || 2500, depth: a.depth || 40}));
  else {
    var stats = {};
    Array.prototype.slice.call(document.querySelectorAll('a[href]')).forEach(function (e) {
      var h = (e.getAttribute('href') || '').replace(/^https?:\/\/[^\/]+/, '').replace(/\d+/g, 'N').replace(/\?.*$/, function (q) { return q.replace(/=[^&]*/g, '='); });
      stats[h] = (stats[h] || 0) + 1;
    });
    var top = Object.keys(stats).sort(function (x, y) { return stats[y] - stats[x]; }).slice(0, 40);
    parts.push('<!-- поле ввода не найдено. Ссылки на странице (цифры заменены на N):\n' + L.esc(top.map(function (k) { return stats[k] + ' × ' + k; }).join('\n')) + '\n-->');
    parts.push('<!-- начало страницы: -->' + L.walk(document.body, 0, {n: 0, max: a.max || 2500, depth: 14}));
  }
  return parts.join('\n');
};
// Отладка: подсветить найденные элементы рамками (на видимой странице)
F.highlight = function (a) {
  Array.prototype.slice.call(document.querySelectorAll('[data-cs-hl]')).forEach(function (e) { e.remove(); });
  if (a.off) return [];
  var marks = [];
  var mark = function (el, color, label) {
    if (!el) return;
    var r = el.getBoundingClientRect(), d = document.createElement('div'), t = document.createElement('span');
    d.setAttribute('data-cs-hl', '1');
    d.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;box-sizing:border-box;border:3px solid ' + color
      + ';left:' + (r.left - 3) + 'px;top:' + (r.top - 3) + 'px;width:' + (r.width + 6) + 'px;height:' + (r.height + 6) + 'px;';
    t.textContent = label;
    t.style.cssText = 'position:absolute;left:0;top:-20px;background:' + color + ';color:#fff;font:12px sans-serif;padding:1px 5px;white-space:nowrap';
    d.appendChild(t);
    document.body.appendChild(d);
    marks.push(label);
  };
  var b = L.box();
  mark(b, '#1e88e5', 'область ввода');
  mark(L.composer(), '#43a047', 'поле ввода');
  mark((b && L.find('attach_button', false, b)) || L.find('attach_button'), '#fb8c00', 'скрепка');
  mark(L.sendButton(), '#8e24aa', 'кнопка «Отправить»');
  var fi = L.fileInput();
  if (fi) { var p = fi; while (p && !L.vis(p)) p = p.parentElement; mark(p, '#e53935', 'поле выбора файла (внутри)'); }
  if (b) L.q((S.attachment_preview || []).join(',')).forEach(function (e) { if (b.contains(e) && L.vis(e)) mark(e, '#00897b', 'превью'); });
  return marks;
};
F.click_chat = function (a) {
  var want = (a.title || '').toLowerCase();
  var sels = S[a.key] || [];
  for (var i = 0; i < sels.length; i++) {
    var els = L.q(sels[i]);
    for (var j = 0; j < els.length && j < 30; j++)
      if (L.norm(els[j].innerText).toLowerCase().indexOf(want) >= 0) { L.mouse(els[j]); return true; }
  }
  return false;
};
"""


def build_js(fn, selectors, args):
    """JS-код одного вызова. Результат всегда — строка JSON (массивы из runJavaScript иначе теряются)."""
    return ("(function(){var S=" + json.dumps(selectors, ensure_ascii=False) + ";" + JS_LIB
            + "try{return JSON.stringify({v:F." + fn + "(" + json.dumps(args, ensure_ascii=False) + ")});}"
            + "catch(e){return JSON.stringify({error:String(e&&e.message||e)});}})()")


def decode_js_result(raw):
    """Строка JSON из build_js → значение. Ошибка JS → None (и запись в журнал)."""
    if raw is None or raw == "":
        return None
    try:
        data = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError:
        return None
    if isinstance(data, dict) and "error" in data and "v" not in data:
        log.debug("JS: %s", data["error"])
        return None
    return data.get("v") if isinstance(data, dict) else data


def file_payload(paths):
    out = []
    for p in paths:
        with open(p, "rb") as f:
            out.append({"name": os.path.basename(p), "type": mimetypes.guess_type(p)[0] or "image/png",
                        "data": base64.b64encode(f.read()).decode()})
    return out


def rotate_shots(log_dir, keep, pattern="vk_*.png"):
    shots = sorted(glob.glob(os.path.join(log_dir, pattern)), key=os.path.getmtime)
    for old in shots[:-max(1, int(keep))]:
        try:
            os.remove(old)
        except OSError:
            pass


# ---------------------------------------------------------------- сценарии
class Flows:
    """Сценарии работы со страницей ВК. Каждый метод — генератор, который выдаёт операции:

      ("load", url, timeout)    → True/False  открыть адрес и дождаться загрузки
      ("js", code, fn, args)    → значение    выполнить функцию F.<fn> на странице
      ("sleep", seconds)        → None
      ("clock",)                → секунды (монотонные часы)
      ("cookies",)              → {имя: значение} cookie сайта ВК или None, если неизвестно
      ("visible",)              → True, если окно браузера сейчас видно на экране
      ("arm_files", paths|None) → None        что ответить на окно «Открыть файл»
      ("files_taken",)          → True, если окно «Открыть файл» было и файлы отданы
      ("click_real", x, y)      → True/False  щелчок событием Qt внутри страницы (не настоящая мышь)
      ("shot", kind)            → путь к снимку страницы или None
      ("save_text", kind, text) → путь к файлу logs\vk_<kind>_<время>.html или None
      ("log", text)             → None        строка в журнал
    """

    def __init__(self, settings, rand=random.uniform):
        self.s = settings
        self.sel = settings["selectors"]
        self.rand = rand

    # ----- операции
    def js(self, fn, **args):
        return (yield ("js", build_js(fn, self.sel, args), fn, args))

    def pause(self, k=1.0):
        lo, hi = float(self.s["pause_min_sec"]), float(self.s["pause_max_sec"])
        yield ("sleep", max(0.0, self.rand(lo, max(lo, hi)) * k))

    def _url_has(self, url, key):
        url = (url or "").lower()
        return any(p.lower() in url for p in self.s.get(key) or [])

    def has_login_cookie(self):
        """True / False — есть ли cookie сессии (vk.com / vk.ru); None — cookie не проверяем."""
        names = set(self.s.get("login_cookies") or [])
        if not names:
            return None
        cookies = yield ("cookies",)
        if cookies is None:
            return None
        return any(cookies.get(n) for n in names)

    def state(self, deep=True):
        """ok | logged_out | blocked | captcha. deep — проверять ещё и текст страницы и форму входа.
        Вошли = (cookie сессии ИЛИ признаки входа на странице) и не видна форма входа.
        Подробности последней проверки — в self.last_login (для журнала и решения «сбросить вход»)."""
        keys = ["captcha", "logged_in"] + (["blocked_text", "login_form"] if deep else [])
        p = yield from self.probe(keys, why=True)
        c, url = p["c"], p["url"]
        cookie = yield from self.has_login_cookie()
        info = {"url": _short_url(url), "cookie": cookie, "logged_in": int(c.get("logged_in") or 0),
                "login_form": int(c.get("login_form") or 0), "matched": dict(p.get("m") or {}),
                "login_url": self._url_has(url, "url_login")}
        st = self._decide_state(url, c, cookie, deep)
        info["state"] = st
        self.last_login = info
        log.debug("Проверка входа: %s — адрес %s, cookie сессии: %s, признаки входа: %d (%s), форма входа: %d (%s)",
                  st, info["url"], {True: "есть", False: "нет", None: "не проверялись"}[cookie],
                  info["logged_in"], info["matched"].get("logged_in", "—"),
                  info["login_form"], info["matched"].get("login_form", "—"))
        return st

    def _decide_state(self, url, c, cookie, deep):
        if self._url_has(url, "url_blocked"):
            return "blocked"
        if self._url_has(url, "url_captcha") or c.get("captcha"):
            return "captcha"
        if self._url_has(url, "url_login"):
            return "logged_out"
        if deep and c.get("blocked_text"):
            return "blocked"
        return "ok" if decide(cookie, c.get("logged_in"), deep and c.get("login_form")) else "logged_out"

    def confirmed_logout(self):
        """Вход точно пропал: открыта страница входа, или видна форма входа без cookie сессии и без
        признаков входа. Только тогда программа забывает сохранённый «вход выполнен»."""
        i = getattr(self, "last_login", None) or {}
        return i.get("state") == "logged_out" and bool(
            i.get("login_url") or (i.get("login_form") and not i.get("cookie") and not i.get("logged_in")))

    def raise_for_state(self, st):
        if st == "blocked":
            raise AccountBlocked()
        if st == "captcha":
            raise CaptchaShown()
        if st == "logged_out":
            raise NotLoggedIn(confirmed=self.confirmed_logout())

    # ----- вход
    def login_status(self, navigate=False, settle=6.0):
        """{state, name, url}. navigate — сначала открыть главную ВК."""
        if navigate:
            yield ("load", self.s["home_url"], float(self.s["page_timeout_sec"]))
        start = yield ("clock",)
        while True:
            st = yield from self.state(deep=True)
            now = yield ("clock",)
            if st != "logged_out" or now - start >= settle:
                break
            p = yield from self.probe(["login_form"])
            if p["c"].get("login_form"):
                break  # явно видна форма входа
            yield ("sleep", 0.7)
        name = ""
        if st == "ok":
            name = (yield from self.js("name", key="profile_name")) or ""
        url = (yield from self.probe([]))["url"]
        info = getattr(self, "last_login", None) or {}
        return {"state": st, "name": name, "url": url, "cookie": info.get("cookie"),
                "form": bool(info.get("login_form")), "markers": info.get("logged_in", 0),
                "confirmed_logout": self.confirmed_logout()}

    # ----- список бесед
    def list_chats(self, timeout=None):
        """Беседы со страницы vk.com/im: [{peer_id, title, type}]. Сначала страница грузится (до
        page_timeout_sec), потом список ищется не дольше timeout секунд (chat_list_timeout_sec = 20),
        иначе ChatListTimeout с подсказкой вставить ссылку."""
        timeout = float(timeout if timeout is not None else self.s.get("chat_list_timeout_sec", 20))
        yield ("load", self.s["im_url"], float(self.s["page_timeout_sec"]))
        start = yield ("clock",)
        items, chats, stable = [], [], 0
        try:
            while True:
                p = yield from self.probe(["captcha", "logged_in"])
                if self._url_has(p["url"], "url_blocked"):
                    raise AccountBlocked()
                if self._url_has(p["url"], "url_captcha") or p["c"].get("captcha"):
                    raise CaptchaShown()
                if self._url_has(p["url"], "url_login"):
                    raise NotLoggedIn(confirmed=True)
                r = yield from self.js("chats", key="chat_list_item", scroll=True)
                r = r if isinstance(r, dict) else {}
                items += r.get("items") or []
                new = parse_chat_items(items)
                stable = stable + 1 if (len(new) == len(chats) and new and not r.get("moved")) else 0
                chats = new
                now = yield ("clock",)
                if chats and (stable >= 2 or len(chats) >= 300):
                    break
                if now - start >= timeout:
                    break
                yield ("sleep", 0.8)
            if not chats:
                st = yield from self.state(deep=True)
                if st != "ok":
                    self.raise_for_state(st)
                raise ChatListTimeout()
        except BrowserError as e:
            if isinstance(e, ChatListTimeout):
                yield from self.diagnose("chats")
            raise
        log.info("Найдено бесед: %d", len(chats))
        return chats

    # ----- отправка
    def chat_ready(self, peer_id=None):
        """Заранее открытая беседа ещё годится? Только смотрит на уже загруженную страницу — без загрузок."""
        p = yield from self.probe(["composer", "chat_not_found"])
        url = (p.get("url") or "").lower()
        if not p["c"].get("composer") or p["c"].get("chat_not_found"):
            return False
        if peer_id and f"/im/convo/{int(peer_id)}" not in url and f"sel=c{int(peer_id) - 2000000000}" not in url:
            return False
        st = yield from self.state(deep=False)
        self.raise_for_state(st)
        return True

    def open_chat(self, peer_id=None, title="", reuse=False):
        """Открыть беседу. reuse=True — если она уже открыта заранее и поле ввода на месте, не загружать снова."""
        timeout = float(self.s["page_timeout_sec"])
        if reuse:
            if (yield from self.chat_ready(peer_id)):
                log.info("Беседа уже открыта заранее — отправляю без повторной загрузки")
                return "reused"
            log.info("Заранее открытая беседа не готова (нет поля ввода) — загружаю заново")
        if peer_id:
            yield ("load", self.s["chat_url"].format(peer_id=int(peer_id)), timeout)
        elif title:
            yield from self._open_by_title(title, timeout)
        else:
            raise ChatNotFound("Беседа не выбрана — «Настроить заново» → «Выбор беседы».")
        start = yield ("clock",)
        while True:
            st = yield from self.state(deep=False)
            if st != "ok":
                self.raise_for_state(st)
            p = yield from self.probe(["composer", "chat_not_found"])
            if p["c"].get("composer"):
                return True
            if p["c"].get("chat_not_found"):
                raise ChatNotFound()
            now = yield ("clock",)
            if now - start >= timeout:
                break
            yield ("sleep", 0.5)
        st = yield from self.state(deep=True)
        self.raise_for_state(st)
        raise ChatNotFound("Беседа открылась, но поле для сообщения не появилось. Если ВК сменил дизайн — "
                           "обновите vk_browser.selectors в config.yaml.")

    def _open_by_title(self, title, timeout):
        yield ("load", self.s["im_url"], timeout)
        start = yield ("clock",)
        while not (yield from self.js("search", key="chat_search", text=title)):
            if (yield ("clock",)) - start >= timeout:
                self.raise_for_state((yield from self.state()))
                raise ChatNotFound("Не нашлось поле поиска бесед.")
            yield ("sleep", 0.5)
        yield from self.pause()
        start = yield ("clock",)
        while (yield ("clock",)) - start < 15:
            if (yield from self.js("click_chat", key="chat_list_item", title=title)):
                return
            yield ("sleep", 0.5)
        raise ChatNotFound(f"Беседа «{title}» не найдена поиском. Выберите её заново: «Настроить заново».")

    BOXED = ["attachment_preview", "upload_progress", "attachment_remove"]

    def previews(self):
        """(превью, загрузка) — только внутри области ввода сообщения."""
        p = yield from self.probe(["attachment_preview", "upload_progress"], box=self.BOXED)
        return p["c"].get("attachment_preview", 0), p["c"].get("upload_progress", 0)

    def probe(self, keys, all_=(), box=(), why=False):
        r = yield from self.js("probe", keys=list(keys), all=list(all_), box=list(box), why=bool(why))
        r = r if isinstance(r, dict) else {}
        r.setdefault("url", "")
        r.setdefault("c", {})
        r.setdefault("m", {})
        return r

    def clear_old_attachments(self):
        """ВК хранит черновики: если В ОБЛАСТИ ВВОДА остались старые картинки — убрать их.
        Не получилось — не мешаем отправке: пишем предупреждение и считаем их «базой».
        Возвращает, сколько превью осталось."""
        for _ in range(12):
            n, _ = yield from self.previews()
            if not n:
                return 0
            if not (yield from self.js("click", key="attachment_remove", scope="box")):
                break
            yield from self.pause(0.4)
        n, _ = yield from self.previews()
        if n:
            log.warning("В поле ввода, похоже, есть старые вложения (%d) — убрать не удалось, отправляю как есть. "
                        "Если в беседу ушло лишнее — удалите черновик в разделе «ВКонтакте».", n)
        return n

    def sig(self):
        r = yield from self.js("sig")
        return r if isinstance(r, dict) else {"ok": False}

    @staticmethod
    def sig_changed(a, b):
        if not b.get("ok"):
            return False
        if not a.get("ok"):
            return bool(b.get("prev") or b.get("prog"))
        return (b.get("prev", 0) > a.get("prev", 0) or b.get("prog", 0) > a.get("prog", 0)
                or b.get("media", 0) > a.get("media", 0) or b.get("zone", 0) > a.get("zone", 0)
                or b.get("blob", 0) > a.get("blob", 0) or b.get("n", 0) >= a.get("n", 0) + 3
                or abs(b.get("h", 0) - a.get("h", 0)) >= 16 or (b.get("consumed") and not a.get("consumed")))

    def wait_change(self, before, seconds=None):
        """Ждёт, пока область ввода изменится (ВК принял картинки). True/False."""
        seconds = float(seconds if seconds is not None else self.s.get("attach_check_sec", 8))
        start = yield ("clock",)
        while True:
            now_sig = yield from self.sig()
            if self.sig_changed(before, now_sig):
                return True
            p = yield from self.probe(["captcha", "upload_error"])
            if p["c"].get("captcha"):
                raise CaptchaShown()
            if p["c"].get("upload_error"):
                raise SendFailed("ВКонтакте не принял картинку (ошибка загрузки). Программа попробует позже.")
            if (yield ("clock",)) - start >= seconds:
                return False
            yield ("sleep", 0.5)

    def attach(self, paths, base=0):
        """Прикрепить картинки полностью в фоне — без мыши, клавиатуры и показа окна.
        Способы по очереди, каждый проверяется по изменению области ввода (чтобы не прикрепить дважды):
        1) поле выбора файла страницы (файлы кладутся в него напрямую, событие change);
        2) «перетаскивание» файлов на поле ввода; 3) «вставка из буфера» в поле ввода;
        4) окно «Открыть файл» по щелчку внутри фоновой страницы (событие Qt, не настоящая мышь)."""
        files = file_payload(paths)
        tried = []
        info = yield from self.js("input_info", key="file_input")
        if not (info or {}).get("found"):
            # Новый ВК создаёт поле выбора файла только после нажатия «скрепки» — нажимаем программно
            if (yield from self.js("click", key="attach_button", scope="prefer")):
                yield from self.pause(0.6)
                info = yield from self.js("input_info", key="file_input")
        if (info or {}).get("found"):
            tried.append("input")
            before = yield from self.sig()
            if info.get("multiple") or len(paths) == 1:
                r = yield from self.js("set_files", key="file_input", files=files)
                if (r or {}).get("ok") and (yield from self.wait_change(before)):
                    return "input"
            else:
                r = yield from self.js("set_files", key="file_input", files=[files[0]])
                if (r or {}).get("ok") and (yield from self.wait_change(before)):
                    yield from self.wait_uploaded(1, base)
                    for i, f in enumerate(files[1:], 2):
                        r = yield from self.js("set_files", key="file_input", files=[f])
                        if not (r or {}).get("ok"):
                            raise SendFailed("Не удалось прикрепить картинку. Программа попробует позже.")
                        yield from self.wait_uploaded(i, base)
                    return "input-single"
            log.info("Поле выбора файла не сработало — пробую перетаскивание")
        before = yield from self.sig()
        if (yield from self.js("drag", files=files)):
            tried.append("drop")
            yield ("sleep", 0.5)
            yield from self.js("drop")
            if (yield from self.wait_change(before)):
                return "drop"
            log.info("Перетаскивание не сработало — пробую вставку")
        before = yield from self.sig()
        if (yield from self.js("paste", key="composer", files=files)):
            tried.append("paste")
            if (yield from self.wait_change(before)):
                return "paste"
        if (yield ("visible",)):
            c = yield from self.js("center", key="attach_photo_item")
            if not c and (yield from self.js("click", key="attach_button", scope="prefer")):
                yield from self.pause(0.6)
                c = yield from self.js("center", key="attach_photo_item")
            if c:
                tried.append("chooser")
                before = yield from self.sig()
                yield ("arm_files", list(paths))
                yield ("click_real", c["x"], c["y"])
                yield ("sleep", 1.5)
                taken = yield ("files_taken",)
                yield ("arm_files", None)
                if taken and (yield from self.wait_change(before)):
                    return "chooser"
        if "paste" in tried:
            # Вставка «ушла» в поле, но изменений не видно (возможно, превью не распознаются) — ждём загрузку
            log.warning("Не видно, что ВК принял картинки (способы: %s) — проверю по превью", ", ".join(tried))
            return "paste?"
        raise SendFailed("Не нашлось, куда прикрепить картинки. Если ВК сменил дизайн — обновите "
                         "vk_browser.selectors в config.yaml.")

    def wait_uploaded(self, n, base=0, fallback=True):
        """Ждёт, пока в области ввода появятся n новых картинок (сверх base) и закончится загрузка.
        2.2.1: загрузка считается законченной, только когда нет индикаторов загрузки (ни в области ввода,
        ни на странице) и появилась кнопка «Отправить» — пока ВК грузит картинки, кнопки нет. Ждём до
        upload_timeout_sec (90 с), опрос раз в upload_poll_sec (1 с).
        fallback=False — если превью так и не появились, это ошибка (а не «подождать и отправить»)."""
        start = yield ("clock",)
        seen = 0
        poll = max(0.3, float(self.s.get("upload_poll_sec", 1.0)))
        logged = False
        while True:
            p = yield from self.probe(["captcha", "upload_error", "attachment_preview", "upload_progress",
                                       "send_button"], box=self.BOXED)
            c = p["c"]
            if c.get("captcha"):
                raise CaptchaShown()
            if c.get("upload_error"):
                raise SendFailed("ВКонтакте не принял картинку (ошибка загрузки). Программа попробует позже.")
            cnt = c.get("attachment_preview", 0) - base
            seen = max(seen, cnt)
            prog_box = c.get("upload_progress", 0)
            prog_all = (p.get("all") or {}).get("upload_progress", prog_box)
            btn = c.get("send_button", 0)
            if cnt >= n and not prog_box and (btn or not prog_all):
                if (yield ("clock",)) - start > 2 or logged:
                    log.info("Картинки загружены (превью %d, кнопка «Отправить»: %s)", cnt, "есть" if btn else "нет")
                return True
            if cnt >= n and not logged:
                log.info("ВК ещё загружает картинки (индикаторов: %s, кнопки «Отправить» нет) — жду до %s с",
                         prog_all or prog_box, self.s["upload_timeout_sec"])
                logged = True
            if (yield ("clock",)) - start >= float(self.s["upload_timeout_sec"]):
                break
            yield ("sleep", poll)
        if not seen and not fallback:
            raise SendFailed("ВКонтакте не принял картинки: они так и не появились в поле ввода. "
                             "Программа попробует позже; сведения для разбора — в папке logs.")
        if not seen:
            wait = float(self.s["upload_fallback_wait_sec"])
            log.warning("Не удалось распознать превью картинок (возможно, ВК сменил дизайн) — жду %s с", wait)
            yield ("sleep", wait)
            return False
        raise SendFailed(f"Картинки не загрузились за {int(float(self.s['upload_timeout_sec']))} с "
                         f"({max(0, seen)} из {n}, загрузка зависла). Программа перезагрузит беседу и попробует ещё раз.")

    def click_send(self, base=0):
        """2.2.3: кнопка «Отправить» ищется по всей странице (ближайшая к полю ввода), нажимается полной
        последовательностью событий; затем ждём, что поле ввода очистилось. Не очистилось за
        send_clear_sec — фокус в поле и Enter (один раз)."""
        start = yield ("clock",)
        r = None
        while True:
            r = yield from self.js("click_send", key="send_button")
            if r == "clicked":
                break
            if (yield ("clock",)) - start >= 5:
                break
            yield ("sleep", 0.5)
        if r == "clicked":
            t0 = yield ("clock",)
            while True:
                st = yield from self.js("composer_state")
                if not isinstance(st, dict) or (st.get("prev", 0) <= base and not st.get("text")):
                    return "button"
                if (yield ("clock",)) - t0 >= float(self.s.get("send_clear_sec", 3)):
                    break
                yield ("sleep", 0.5)
            log.warning("После нажатия «Отправить» поле ввода не очистилось — нажимаю Enter в поле ввода")
        else:
            log.warning("Кнопка «Отправить» не найдена (%s) — нажимаю Enter в поле ввода", r)
        yield from self.js("enter", key="composer")
        return "enter"

    def verify(self, before, n, base=0):
        start = yield ("clock",)
        previews = 0
        while True:
            p = yield from self.probe(["captcha", "history_photos", "outgoing_message", "attachment_preview"],
                                      all_=["history_photos", "outgoing_message"], box=self.BOXED)
            c = p["c"]
            if c.get("captcha"):
                raise CaptchaShown()
            previews = max(0, c.get("attachment_preview", 0) - base)
            if c.get("history_photos", 0) >= before.get("history_photos", 0) + n:
                return "verified"
            if not previews and c.get("outgoing_message", 0) > before.get("outgoing_message", 0):
                return "verified"
            if (yield ("clock",)) - start >= float(self.s["verify_timeout_sec"]):
                break
            yield ("sleep", 0.7)
        if not previews:
            log.warning("Сообщение ушло (поле ввода очистилось), но проверить его в истории не удалось")
            return "unverified"
        raise StillInComposer("Сообщение не отправилось: картинки остались в поле ввода. Программа попробует позже.")

    # ----- 2.2.0: проверка доставки (только по уже открытой странице беседы, без лишних запросов)
    def delivered(self, before, n):
        """Новое сообщение с картинками уже видно в истории? None — проверить нельзя (селекторы истории на
        этой странице ничего не находят: ВК сменил дизайн) — тогда повторная отправка запрещена."""
        p = yield from self.probe(["history_photos", "outgoing_message"], all_=["history_photos", "outgoing_message"])
        c = p["c"]
        if c.get("history_photos", 0) >= before.get("history_photos", 0) + n:
            return True
        if c.get("outgoing_message", 0) > before.get("outgoing_message", 0):
            return True
        if not before.get("history_photos") and not before.get("outgoing_message"):
            return None
        return False

    def wait_delivered(self, before, n, seconds):
        start = yield ("clock",)
        while True:
            d = yield from self.delivered(before, n)
            if d:
                return True
            if d is None or (yield ("clock",)) - start >= seconds:
                return d
            yield ("sleep", 1.0)

    def confirm_delivery(self, before, paths, caption=""):
        """Поле ввода очистилось, но сообщения в истории пока нет. Ждём ещё (всего ~delivery_wait_sec с
        момента нажатия), затем — ОДНА повторная отправка на той же странице, если и тогда не видно.
        Повтор только когда история на странице точно распознаётся (иначе можно задвоить)."""
        wait = max(0.0, float(self.s.get("delivery_wait_sec", 30)) - float(self.s["verify_timeout_sec"]))
        d = yield from self.wait_delivered(before, len(paths), wait)
        if d:
            log.info("Доставка подтверждена: сообщение появилось в беседе")
            return "verified"
        if d is None:
            log.warning("Проверить доставку нельзя: на странице не распознаётся история сообщений — повтора нет")
            return "unverified"
        log.warning("Сообщение не появилось в беседе за %s с — одна повторная отправка",
                    self.s.get("delivery_wait_sec", 30))
        base = yield from self.clear_old_attachments()
        before2 = (yield from self.probe(["history_photos", "outgoing_message"],
                                        all_=["history_photos", "outgoing_message"]))["c"]
        if (yield from self.delivered(before, len(paths))):     # дошло в последний момент — не повторяем
            return "verified"
        how = yield from self.attach(paths, base)
        if how != "input-single":
            yield from self.wait_uploaded(len(paths), base, fallback=(how != "paste?"))
        if caption:
            yield from self.js("type", key="composer", text=caption)
        yield from self.click_send(base)
        r = yield from self.verify(before2, len(paths), base)
        if r == "verified" or (yield from self.wait_delivered(before2, len(paths), wait)):
            log.info("Доставка подтверждена после повторной отправки")
            return "verified_retry"
        raise DeliveryUnconfirmed()

    # ----- разбор ошибок
    def diagnose(self, kind):
        """В журнал — состояние страницы; в logs\\vk_dom_<что>_<время>.html — обезличенная разметка
        области ввода (без текстов сообщений и cookie). Никогда не бросает исключений."""
        try:
            d = yield from self.js("diag")
            d = d if isinstance(d, dict) else {}
            log.warning("Страница ВК при ошибке: видимость=%s, адрес=%s, заголовок=%s, размер=%s, поле ввода=%s, "
                        "область ввода=%s, полей файла=%s (в области %s), выбрано=%s, найдено (всего/в области): %s",
                        d.get("visibility"), d.get("url"), d.get("title"), d.get("size"), d.get("composer"),
                        d.get("box"), d.get("file_inputs"), d.get("file_inputs_in_box"),
                        d.get("file_input_chosen"), d.get("matched"))
            html = yield from self.js("dump", max=2500, depth=40)
            head = ("<!-- Скриншоты клуба: обезличенная разметка страницы ВК для разбора ошибки «%s».\n"
                    "Тексты сообщений заменены на [текст N симв.], адреса картинок обрезаны до сайта, cookie нет.\n"
                    "%s\n-->\n" % (kind, json.dumps(d, ensure_ascii=False, indent=1).replace("--", "- -")))
            yield ("save_text", "dom_" + kind, head + str(html or "(страница не ответила)"))
        except Exception:  # noqa: BLE001
            log.debug("diagnose", exc_info=True)

    def hour_photos(self, peer_id, title="", reuse=False):
        """2.2.4: сообщения с картинками внизу беседы (автор, ЧЧ:ММ, адреса картинок). Только чтение."""
        yield from self.open_chat(peer_id, title, reuse=reuse)
        yield ("sleep", 0.5)
        r = yield from self.js("hour_photos", max=6)
        return r if isinstance(r, dict) else {"own": False, "msgs": []}

    def prewarm(self, peer_id, title=""):
        """Заранее (за несколько минут до отправки) открыть беседу: одна загрузка страницы, та же, что нужна
        для отправки. Вход проверяется по уже загруженной странице, без лишних запросов. Возвращает 'ready'."""
        try:
            yield from self.open_chat(peer_id, title)
            return "ready"
        except BrowserError as e:
            if not e.shot:
                e.shot = yield ("shot", "prewarm_" + e.kind)
            raise

    def send(self, peer_id, paths, caption="", title="", reuse=False):
        """Одно сообщение со всеми картинками по порядку. Возвращает 'verified' или 'unverified'.
        reuse=True — беседа открыта заранее (см. prewarm): если поле ввода на месте, страница не загружается."""
        if not paths:
            raise SendFailed("Нет картинок для отправки.")
        paths = list(paths)
        clicked = False
        try:
            yield from self.open_chat(peer_id, title, reuse=reuse)
            yield from self.pause()
            base = yield from self.clear_old_attachments()
            before = (yield from self.probe(["history_photos", "outgoing_message"],
                                           all_=["history_photos", "outgoing_message"]))["c"]
            how = yield from self.attach(paths, base)
            log.info("Картинки прикреплены (%s): %s", how, ", ".join(os.path.basename(p) for p in paths))
            if how != "input-single":
                yield from self.wait_uploaded(len(paths), base, fallback=(how != "paste?"))
            yield from self.pause()
            if caption:
                yield from self.js("type", key="composer", text=caption)
                yield from self.pause(0.6)
            clicked = True  # дальше повтор опасен: сообщение могло уже уйти
            via = yield from self.click_send(base)
            result = yield from self.verify(before, len(paths), base)
            if result == "unverified":
                # 2.2.4: поле ввода очистилось — сообщение ушло. По истории беседы НЕ повторяем: сообщение могли
                # удалить вручную, и повтор дал бы дубль.
                result = "sent"
            log.info("Сообщение отправлено через браузер (%s, %s)", via, result)
            return result
        except BrowserError as e:
            if not e.shot:
                e.shot = yield ("shot", e.kind)
            if not e.needs_user or e.kind == "chat_not_found":
                yield from self.diagnose(e.kind)
            if clicked and not isinstance(e, StillInComposer):
                e.retry = False
                if isinstance(e, SendTimeout):
                    e.text = ("ВКонтакте долго не отвечал после нажатия «Отправить» — проверьте беседу. Чтобы не "
                              "отправить картинки дважды, в этот час повтора не будет.")
                    e.args = (e.text,)
            raise
        except Exception as e:  # noqa: BLE001
            shot = yield ("shot", "error")
            yield from self.diagnose("error")
            if clicked:
                err = SendFailed("После нажатия «Отправить» что-то пошло не так — проверьте беседу. Чтобы не "
                                 "отправить картинки дважды, в этот час повтора не будет.", shot)
                err.retry = False
                raise err from e
            if "timeout" in str(e).lower() or "Timeout" in type(e).__name__:
                raise SendFailed("ВКонтакте долго не отвечает (страница не загрузилась). Программа попробует "
                                 "позже.", shot) from e
            raise SendFailed(f"Не получилось отправить через браузер: {str(e).splitlines()[0][:200]}",
                             shot) from e

    def send_text(self, peer_id, text, title="", reuse=False):
        """2.2.0: одно короткое текстовое сообщение (утренняя сводка). Повтора после нажатия нет."""
        clicked = False
        try:
            yield from self.open_chat(peer_id, title, reuse=reuse)
            yield from self.pause()
            before = (yield from self.probe(["outgoing_message"], all_=["outgoing_message"]))["c"]
            yield from self.js("type", key="composer", text=text)
            yield from self.pause(0.6)
            clicked = True
            yield from self.click_send()
            start = yield ("clock",)
            while (yield ("clock",)) - start < float(self.s["verify_timeout_sec"]):
                c = (yield from self.probe(["outgoing_message"], all_=["outgoing_message"]))["c"]
                if c.get("outgoing_message", 0) > before.get("outgoing_message", 0):
                    return "verified"
                yield ("sleep", 0.7)
            return "unverified"
        except BrowserError as e:
            if clicked:
                e.retry = False
            raise

    # ----- отладка (Настройки → «Проверить отправку по шагам»): «Отправить» не нажимается НИКОГДА
    def debug_send(self, peer_id, paths=None, title="", step_pause=1.5):
        """Пошагово: открыть беседу, подсветить найденные элементы, сохранить сведения; если даны
        картинки — прикрепить их и снова убрать. Возвращает список строк отчёта."""
        rep = []

        def say(text):
            rep.append(text)
            return ("log", "Проверка отправки: " + text)

        yield say("открываю беседу…")
        try:
            yield from self.open_chat(peer_id, title)
        except BrowserError as e:
            yield say("✖ беседа не открылась: " + e.text)
            yield from self.diagnose("debug")
            return rep
        yield say("✔ беседа открыта, поле ввода найдено")
        d = yield from self.js("diag")
        d = d if isinstance(d, dict) else {}
        m = d.get("matched") or {}
        yield say(f"видимость страницы: {d.get('visibility')}; область ввода: {d.get('box') or 'не найдена'}")
        yield say(f"полей выбора файла: {d.get('file_inputs')} (в области ввода {d.get('file_inputs_in_box')}); "
                  f"будет использовано: {d.get('file_input_chosen') or 'нет'}")
        yield say(f"скрепка: {m.get('attach_button')}, кнопка «Отправить»: {m.get('send_button')}, "
                  f"превью в области ввода: {m.get('attachment_preview')} (всего/в области)")
        marks = yield from self.js("highlight")
        yield say("подсвечено на странице: " + (", ".join(marks or []) or "ничего"))
        yield ("sleep", step_pause)
        yield ("shot", "debug")
        if paths:
            base = yield from self.clear_old_attachments()
            yield say("прикрепляю пробные картинки (отправлять НЕ буду)…")
            try:
                how = yield from self.attach(list(paths), base)
                ok = yield from self.wait_uploaded(len(paths), base)
                yield say(f"✔ картинки прикреплены способом «{how}»" + ("" if ok else " (превью не распознаны)"))
                yield from self.js("highlight")
                yield ("sleep", step_pause)
                yield ("shot", "debug_attached")
            except BrowserError as e:
                yield say("✖ прикрепить не удалось: " + e.text)
            left = yield from self.clear_old_attachments()
            yield say("пробные картинки убраны из поля ввода" if not left else
                      "⚠ уберите пробные картинки из поля ввода вручную (крестик на превью)")
        yield from self.diagnose("debug")
        yield say("готово. Подробности — в журнале и в файлах logs\\vk_dom_debug_*.html")
        return rep


def warm_fresh(browser, s, now=None):
    """2.2.1: заранее открытую беседу можно использовать, только если она открыта не дольше warm_max_age_sec
    (60 с) назад; иначе (вкладка могла «уснуть» или устареть) беседа перезагружается перед отправкой."""
    if not getattr(browser, "warm", False):
        return False
    at = getattr(browser, "warm_at", None)
    if at is None:
        return True
    age = (time.monotonic() if now is None else now) - at
    if age > float(s.get("warm_max_age_sec", 60)):
        log.info("Беседа открыта заранее %d с назад — перед отправкой открываю её заново", int(age))
        return False
    return True


class BrowserVKSender:
    """Отправитель для JobRunner: передаёт сценарий send встроенному браузеру (app/ui/browser.py).
    browser — объект с методом run_blocking(flow_factory, timeout) (выполняет сценарий в потоке окна)."""

    def __init__(self, browser, cfg):
        self.browser = browser
        self.cfg = cfg

    def send_photos(self, peer_id, paths, message=""):
        s = merged_settings(self.cfg)
        title = (self.cfg.get("vk") or {}).get("chat_search_title", "")
        limit = float(s.get("send_timeout_sec") or 90)
        flows = Flows(s)
        if s.get("delivery_check", True):           # 2.2.0: ожидание доставки и один повтор на той же странице
            limit += 2 * float(s.get("delivery_wait_sec") or 30) + 30
        limit += max(0.0, float(s.get("upload_timeout_sec") or 90) - 45)   # 2.2.1: ожидание загрузки до 90 с
        reuse = warm_fresh(self.browser, s)  # беседа уже открыта заранее и недавно
        return self.browser.run_blocking(lambda: flows.send(peer_id, paths, message or "", title, reuse), limit + 30,
                                         deadline=limit, on_deadline=lambda: SendTimeout(limit))

    def already_sent(self, peer_id, paths, since, now=None):
        """2.2.4: есть ли в беседе за этот час своё сообщение с этими же двумя скринами (см. app/dupcheck.py).
        → (True/False, причина). Ошибки — (False, причина): тогда считаем, что не отправлено."""
        from . import dupcheck
        s = merged_settings(self.cfg)
        title = (self.cfg.get("vk") or {}).get("chat_search_title", "")
        flows = Flows(s)
        reuse = warm_fresh(self.browser, s)
        try:
            page = self.browser.run_blocking(lambda: flows.hour_photos(peer_id, title, reuse), 60, deadline=40,
                                             on_deadline=lambda: SendTimeout(40))
        except Exception as e:  # noqa: BLE001
            return False, f"беседу проверить не удалось ({e})"
        return dupcheck.find(page, paths, since, now=now)

    def presence(self, peer_id, paths, since, now=None):
        """3.0.2: проверка «скрины за этот час на месте» → (found/missing/failed, причина). Только чтение,
        на фоновой странице; после проверки она закрывается (если не ждёт ближайшую отправку)."""
        from . import dupcheck
        s = merged_settings(self.cfg)
        title = (self.cfg.get("vk") or {}).get("chat_search_title", "")
        flows = Flows(s)
        reuse = warm_fresh(self.browser, s)
        try:
            page = self.browser.run_blocking(lambda: flows.hour_photos(peer_id, title, reuse), 60, deadline=40,
                                             on_deadline=lambda: SendTimeout(40), drop_after=True)
        except Exception as e:  # noqa: BLE001
            return dupcheck.FAILED, f"беседу прочитать не удалось ({e})"
        return dupcheck.find_status(page, paths, since, now=now)

    def send_text(self, peer_id, message):
        s = merged_settings(self.cfg)
        title = (self.cfg.get("vk") or {}).get("chat_search_title", "")
        limit = float(s.get("send_timeout_sec") or 90)
        flows = Flows(s)
        reuse = warm_fresh(self.browser, s)
        return self.browser.run_blocking(lambda: flows.send_text(peer_id, message, title, reuse), limit + 30,
                                         deadline=limit, on_deadline=lambda: SendTimeout(limit))
