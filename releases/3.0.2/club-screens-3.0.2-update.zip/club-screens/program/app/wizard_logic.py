# Original-Author: Владислав С.
# Created: 2026-10-28
"""Логика мастера настройки без интерфейса (удобно тестировать)."""
import re

from .config import wizard_templates

DEFAULT_KEYWORD = "камеры"


def pick_default_conversation(convs, peer_id=None, keyword=DEFAULT_KEYWORD):
    """Индекс беседы, которую выбрать заранее: тот же peer_id → название с «Камеры» → первая беседа."""
    try:
        peer_id = int(peer_id) if peer_id else None
    except (TypeError, ValueError):
        peer_id = None
    if peer_id:
        for i, c in enumerate(convs):
            if c.get("peer_id") == peer_id:
                return i
    kw = (keyword or "").casefold()
    if kw:
        for i, c in enumerate(convs):
            if c.get("type") == "chat" and kw in (c.get("title") or "").casefold():
                return i
    for i, c in enumerate(convs):
        if c.get("type") == "chat":
            return i
    return 0 if convs else None


def filter_conversations(convs, query):
    q = (query or "").strip().casefold()
    return [c for c in convs if not q or q in (c.get("title") or "").casefold() or q in str(c.get("peer_id"))]


def button_label(hint, default="кнопку"):
    """«Кнопка «Карта клуба» на левой панели…» → «Карта клуба»."""
    m = re.search(r"«([^»]+)»", hint or "")
    return m.group(1) if m else default


def wizard_pages(cfg):
    """Список страниц мастера: [(ключ, заголовок_в_списке, источник|None)]."""
    pages = [("welcome", "Приветствие", None), ("vk", "Вход ВК", None), ("chat", "Выбор беседы", None),
             ("programs", "Программы", None)]
    for src in cfg.get("sources") or []:
        if src.get("enabled", True):
            pages.append(("source", src.get("name", "Программа"), src))
    # 3.0.0: сценарий съёмки камер — записать свой или пропустить (останется встроенный способ)
    for src in cfg.get("sources") or []:
        if src.get("enabled", True) and src.get("kind") != "oasys":
            pages.append(("scenario", f"Сценарий: {src.get('name', 'камеры')}", src))
    pages += [("test", "Проверка", None), ("done", "Готово", None)]
    return pages


def source_templates(src, root=None):
    return wizard_templates(src, root)


def step_done(cfg, key, src=None, root=None):
    """Шаг мастера уже выполнен по СОХРАНЁННЫМ настройкам (не по тому, что сейчас видно в браузере).
    Нужен, чтобы при переходах по шагам уже сделанное не показывалось «не настроено»."""
    vk = cfg.get("vk") or {}
    if key == "welcome":
        return bool((cfg.get("app") or {}).get("setup_done"))
    if key == "vk":
        if vk.get("sender") == "group_api":
            return bool(vk.get("group_token"))
        return bool(vk.get("login_ok"))
    if key == "chat":
        return bool(vk.get("peer_id") or vk.get("chat_search_title"))
    if key == "programs":
        return bool((cfg.get("app") or {}).get("setup_done"))
    if key == "scenario":
        return True                       # необязательный шаг: без записи работает встроенный способ
    if key == "source" and src is not None:
        req = [ex for _, _, required, ex in source_templates(src, root) if required]
        if not req:                       # 2.2.0: своя программа без кнопок — достаточно выбранного окна
            return bool((src.get("window") or {}).get("process_regex") or (src.get("window") or {}).get("title_regex"))
        return all(req)
    return False
