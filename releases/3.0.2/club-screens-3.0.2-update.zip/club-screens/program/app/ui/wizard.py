# Original-Author: Владислав С.
# Created: 2026-10-28
"""Мастер первой настройки — внутри главного окна. Шаги: приветствие, вход ВК (прямо в окне), беседа,
Oasys, iVMS-4200, проверка, готово. Содержимое прокручивается, кнопки «Назад»/«Далее» всегда видны внизу."""
import logging
import os
import sys
import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QKeySequence
from PySide6.QtWidgets import (QCheckBox, QComboBox, QFrame, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton, QScrollArea, QSizePolicy, QVBoxLayout,
                               QWidget)

from .. import APP_NAME, startup
from ..config import resolve_path
from ..friendly import humanize
from ..job import make_group_client
from ..pictures import picture
from ..vk_browser import AccountBlocked, ChatListTimeout, parse_chat_link
from ..wizard_logic import (button_label, step_done, filter_conversations, pick_default_conversation, source_templates,
                            wizard_pages)
from . import theme
from .common import BLUE, GREEN, VK_BLUE, Task, big_button, label, link_button, set_image, set_status, set_tone

log = logging.getLogger("club")
KINDS = {"chat": "беседа", "user": "человек", "group": "сообщество"}
TEST_SEND_GAP_SEC = 180  # пробная отправка — не чаще раза в 3 минуты
LOGIN_POLL_MS = 2000      # шаг «Вход ВК»: проверять вход каждые 2 секунды


def chat_url(peer_id):
    return f"https://vk.com/im/convo/{int(peer_id)}"


def source_picture(src):
    name = (src.get("name") or "").lower()
    for key in ("oasys", "ivms"):
        if key in name:
            return key
    return "welcome"


class LinkEdit(QLineEdit):
    """Поле ссылки: Ctrl+V работает и в русской раскладке (Ctrl+М), Shift+Insert — тоже."""

    def keyPressEvent(self, e):  # noqa: N802
        ctrl = e.modifiers() & Qt.KeyboardModifier.ControlModifier
        if ctrl and not e.matches(QKeySequence.StandardKey.Paste) and (
                e.nativeVirtualKey() == 0x56 or e.key() == 0x6cc):  # VK_V / «М»
            self.paste()
            return
        super().keyPressEvent(e)


class WizardWidget(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.cfg = main.cfg
        self.pages = wizard_pages(self.cfg)
        self.index = 0
        self.convs = []
        self.shown = []
        self.preview = None
        self.test_paths = []
        self.last_test_send = 0.0
        self.checking = False
        self.loading_chats = False
        self.autostart_on = True
        self.view_here = False
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._on_timer)
        self.timer_fn = None
        self.chat_guard = QTimer(self)
        self.chat_guard.setSingleShot(True)
        self.chat_guard.timeout.connect(self._chat_list_slow)

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        side = QFrame()
        side.setObjectName("side")
        side.setFixedWidth(208)          # как в главном окне
        sl = QVBoxLayout(side)
        sl.setContentsMargins(10, 18, 10, 12)
        t = QLabel("Настройка")
        t.setObjectName("sideTitle")
        sl.addWidget(t)
        sl.addSpacing(10)
        self.side_labels = []
        self.side_layout = sl
        self._build_side()
        sl.addStretch(1)
        lay.addWidget(side)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(0)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        right.addWidget(self.scroll, 1)
        foot = QFrame()
        foot.setObjectName("footer")
        fl = QHBoxLayout(foot)
        fl.setContentsMargins(20, 10, 20, 10)
        self.back_btn = QPushButton("← Назад")
        self.back_btn.clicked.connect(self.back)
        fl.addWidget(self.back_btn)
        fl.addSpacing(12)
        fl.addWidget(link_button("Закрыть мастер", self.cancel))
        fl.addStretch(1)
        self.next_btn = big_button("Далее →", BLUE, self.next)
        fl.addWidget(self.next_btn)
        right.addWidget(foot)
        lay.addLayout(right, 1)
        self.show_page(0)

    def _build_side(self):
        """Список шагов слева; 2.2.0: пересобирается, когда на шаге «Программы» меняется набор программ."""
        for lbl in self.side_labels:
            self.side_layout.removeWidget(lbl)
            lbl.deleteLater()
        self.side_labels = []
        for i, (_, title, _) in enumerate(self.pages):
            lbl = QLabel(f"{i + 1}. {title}")
            lbl.setObjectName("sideStep")
            self.side_layout.insertWidget(2 + i, lbl)
            self.side_labels.append(lbl)

    def refresh_pages(self):
        self.pages = wizard_pages(self.cfg)
        self._build_side()

    # ---------- общее ----------
    @property
    def key(self):
        return self.pages[self.index][0]

    def stop(self):
        self.timer.stop()
        self.chat_guard.stop()
        if self.view_here:
            self.view_here = False
            self.main.restore_view()   # страница ВК вернётся в раздел и выгрузится (экономия памяти)

    def is_done(self, j):
        key, _, src = self.pages[j]
        try:
            return step_done(self.cfg, key, src)
        except Exception:  # noqa: BLE001
            return False

    def every(self, ms, fn):
        self.timer_fn = fn
        self.timer.start(ms)

    def _on_timer(self):
        if self.timer_fn:
            self.timer_fn()

    def set_next(self, enabled=True, text="Далее →", color=BLUE):
        self.next_btn.setText(text)
        self.next_btn.setEnabled(enabled)
        set_tone(self.next_btn, color)

    def cancel(self):
        if self.cfg["app"].get("setup_done") or QMessageBox.question(
                self, "Настройка", "Настройка ещё не закончена. Закрыть мастер?\n"
                                   "Открыть его снова можно кнопкой «Настроить заново» на главной."
        ) == QMessageBox.StandardButton.Yes:
            self.main.close_wizard()

    def back(self):
        if self.index > 0:
            self.show_page(self.index - 1)

    def next(self):
        key, _, src = self.pages[self.index]
        if key == "welcome":
            self.cfg["app"]["club_name"] = self.club.text().strip()
        if key == "chat" and not self._apply_link(quiet=True):
            return
        if key == "source" and not self._source_ready(src):
            return
        if key == "programs" and not self._programs_ready():
            return
        if key == "done":
            self.finish()
            return
        if self.index < len(self.pages) - 1:
            self.show_page(self.index + 1)

    def show_page(self, i):
        self.stop()
        self.index = i
        for j, lbl in enumerate(self.side_labels):
            # ✔ — пройденные шаги и шаги, уже выполненные по сохранённым настройкам (вход, беседа…):
            # переход по шагам их не «сбрасывает»
            done = j < i or (j != i and self.is_done(j))
            state = "cur" if j == i else ("done" if done else "")
            lbl.setText(("✔ " if done else f"{j + 1}. ") + self.pages[j][1])
            lbl.setProperty("state", state)
            lbl.style().unpolish(lbl)
            lbl.style().polish(lbl)
        key, _, src = self.pages[i]
        content = QWidget()
        content.setObjectName("page")
        cl = QVBoxLayout(content)
        cl.setContentsMargins(26, 20, 26, 16)
        head = QHBoxLayout()
        texts = QVBoxLayout()
        self.step_lbl = label(f"Шаг {i + 1} из {len(self.pages)}", "muted")
        self.title_lbl = label("", "title")
        self.text_lbl = label("", "big")
        for w in (self.step_lbl, self.title_lbl, self.text_lbl):
            texts.addWidget(w)
        texts.addStretch(1)
        head.addLayout(texts, 1)
        self.pic = QLabel()
        self.pic.setFixedSize(220, 150)
        set_image(self.pic, picture(source_picture(src) if src else {"programs": "oasys"}.get(key, key)), (220, 150))
        head.addWidget(self.pic, 0, Qt.AlignmentFlag.AlignTop)
        # 2.1.7: на шаге входа ВК картинка не нужна — всё место отдаём странице ВК (QR-код целиком)
        self.pic.setVisible(key != "vk" or self._group_mode())
        cl.addLayout(head)
        self.body = QVBoxLayout()
        self.body.setSpacing(8)
        login_step = key == "vk" and not self._group_mode()
        if login_step:              # шаг входа: поля поменьше — больше места странице ВК
            cl.setContentsMargins(20, 12, 20, 8)
            texts.setSpacing(2)
        cl.addSpacing(4 if login_step else 10)
        cl.addLayout(self.body, 1)
        self.back_btn.setEnabled(i > 0)
        self.set_next(True)
        getattr(self, "page_" + key)(src) if src else getattr(self, "page_" + key)()
        if key != "vk":
            cl.addStretch(1)
        old = self.scroll.takeWidget()
        self.scroll.setWidget(content)
        if old:
            old.deleteLater()

    def _group_mode(self):
        return self.cfg["vk"].get("sender") == "group_api"

    # ---------- 1. приветствие ----------
    def page_welcome(self):
        self.title_lbl.setText("Здравствуйте!")
        self.text_lbl.setText("Эта программа каждый час, ровно в 00 минут, делает снимки экрана Oasys и камер "
                              "iVMS-4200 и отправляет их одним сообщением в беседу ВКонтакте.\n\n"
                              "Настройка займёт около 5 минут. Просто следуйте подсказкам.")
        self.body.addWidget(label("Название клуба (для себя, можно не заполнять):", "big"))
        self.club = QLineEdit(self.cfg["app"].get("club_name", ""))
        self.club.setMaximumWidth(520)
        self.body.addWidget(self.club)
        self.body.addWidget(label("Например: Клуб на Центральной", "muted"))
        # 2.1.8: тема оформления — сразу видно, как будет выглядеть программа (потом — «Настройки» → «Внешний вид»)
        self.body.addSpacing(12)
        row = QHBoxLayout()
        row.addWidget(label("Оформление:", "big", wrap=False))
        self.theme_combo = QComboBox()
        for key, text in theme.THEMES:
            self.theme_combo.addItem(text, key)
        self.theme_combo.setCurrentIndex(max(0, self.theme_combo.findData(self.cfg["app"].get("theme") or "system")))
        self.theme_combo.currentIndexChanged.connect(self._on_theme)
        row.addWidget(self.theme_combo)
        row.addStretch(1)
        self.body.addLayout(row)
        self.set_next(True, "Начать →")

    def _on_theme(self, _i=None):
        mode = self.theme_combo.currentData() or "system"
        self.cfg["app"]["theme"] = mode
        theme.apply(None, mode, self.cfg["app"].get("accent") or "blue")
        if hasattr(self.main, "page_settings"):
            self.main.page_settings.load_look()

    # ---------- 2. вход ВК прямо в окне ----------
    def page_vk(self):
        self.title_lbl.setText("Вход во ВКонтакте")
        if self._group_mode():
            self.text_lbl.setText("В «Настройках» включена отправка через сообщество (ключ сообщества). "
                                  "Этот шаг можно пропустить.")
            return
        self.text_lbl.setText("Войдите как обычно — по QR-коду с телефона или логином и паролем. "
                              "Когда войдёте, появится зелёная галочка.")
        self.main.ensure_big()     # маленькое окно — увеличить, чтобы страница входа поместилась
        row = QHBoxLayout()
        self.vk_status = label("", "muted")
        # короткое «Жду входа» — в одну строку; длинные ошибки переносятся
        self.vk_status.setMinimumWidth(self.vk_status.fontMetrics().horizontalAdvance("⏳ Жду входа в ВК…") * 9 // 8 + 8)
        row.addWidget(self.vk_status, 1)
        # запасной путь, если вход не распознался (ВК сменил дизайн): видно сразу, без прокрутки
        self.vk_already_btn = QPushButton("Я уже вошёл — продолжить")
        self.vk_already_btn.setToolTip("Если вы видите свою страницу ВК, а зелёная галочка не появляется "
                                       "(например, ВК сменил дизайн) — подтвердите вход сами")
        self.vk_already_btn.clicked.connect(lambda: self.confirm_logged_in())
        row.addWidget(self.vk_already_btn)
        for text, tip, fn in (("⟳", "Обновить страницу", self.main.browser.reload),
                              ("Главная ВК", "Открыть главную страницу ВК",
                               lambda: self.main.browser.go(self.main.browser.settings()["home_url"], load=True))):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            row.addWidget(b)
        self.body.addLayout(row)
        holder = self.main.browser.holder
        holder.setMinimumHeight(360)
        holder.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        url = self.main.browser.current_url()
        if not url or url == "about:blank" or "/im/convo/" in url:
            self.main.browser.go(self.main.browser.settings()["home_url"])  # адрес на потом
        self.main.place_view(self.body)   # здесь страница и создаётся
        self.view_here = True
        self.main.browser.refit()
        note = label("Программа не видит и не хранит ваш пароль. Не передавайте никому папку browser_profile "
                     "и файл config.yaml.", "muted")
        note.setToolTip("Сообщения будут уходить от вашего имени — так же, как если бы вы отправили их сами. "
                        "Профиль браузера хранится только на этом компьютере.")
        self.body.addWidget(note)
        if self.cfg["vk"].get("login_ok"):
            self._vk_ok(self.cfg["vk"].get("account_name"))
        else:
            set_status(self.vk_status, "Вы ещё не вошли.", "muted")
            self.set_next(False)
        self.main.check_login()
        self.every(LOGIN_POLL_MS, self.main.check_login)  # пока виден шаг входа — каждые 2 с

    def confirm_logged_in(self, ask=True):
        """«Я уже вошёл — продолжить»: человек видит свою страницу ВК, а программа вход не распознала."""
        if ask and QMessageBox.question(
                self, "Вход ВК",
                "Вы видите на странице ниже свою страницу ВКонтакте (ленту, сообщения, свою фотографию)?\n\n"
                "Если да — нажмите «Да», и можно идти дальше. Если вход на самом деле не выполнен, "
                "программа скажет об этом при первой отправке.") != QMessageBox.StandardButton.Yes:
            return False
        vk = self.cfg["vk"]
        log.info("Вход ВК подтверждён вручную («Я уже вошёл — продолжить»)")
        vk["login_ok"] = True
        self.main.save_config(quiet=True)
        self._vk_ok(vk.get("account_name"))
        return True

    def on_login(self, st):
        """Результат проверки входа (из главного окна)."""
        if self.key != "vk" or self._group_mode():
            return
        state = (st or {}).get("state")
        if state == "ok":
            self._vk_ok(st.get("name") or self.cfg["vk"].get("account_name"))
        elif state == "blocked":
            self._vk_bad(AccountBlocked().text)
        elif state == "captcha":
            self._vk_bad("ВК просит пройти проверку («Я не робот») — пройдите её на странице ниже.")
        elif self.cfg["vk"].get("login_ok"):
            # вход уже сохранён и настоящая проверка его не сбросила — шаг остаётся выполненным
            self._vk_ok(self.cfg["vk"].get("account_name"))
        elif st is None or state == "logged_out":
            set_status(self.vk_status, "⏳ Жду входа в ВК…", "wait")
            self.set_next(False)

    def _vk_bad(self, text):
        set_status(self.vk_status, "✖ " + text, "bad")
        self.set_next(False)

    def _vk_ok(self, name):
        set_status(self.vk_status, f"✔ Вы вошли как {name}" if name else "✔ Вы вошли", "ok")
        self.set_next(True)

    # ---------- 3. беседа ----------
    def page_chat(self):
        self.title_lbl.setText("Выбор беседы")
        self.text_lbl.setText("Куда отправлять скриншоты? Вставьте ссылку на беседу ВКонтакте "
                              "(или выберите её из списка ниже). Если беседа уже выбрана — просто нажмите «Далее».")
        lrow = QHBoxLayout()
        lrow.addWidget(label("Ссылка на беседу:", "big", wrap=False))
        self.link = LinkEdit()
        self.link.setPlaceholderText("https://vk.com/im/convo/2000000001")
        self.link.setClearButtonEnabled(True)
        lrow.addWidget(self.link, 1)
        paste = QPushButton("Вставить")
        paste.setToolTip("Вставить ссылку из буфера обмена")
        paste.clicked.connect(self._paste)
        lrow.addWidget(paste)
        self.body.addLayout(lrow)
        self.body.addWidget(label("Например: vk.com/im/convo/2000000001 — откройте беседу во ВКонтакте и скопируйте "
                                  "адрес из адресной строки (Ctrl+C), затем сюда — Ctrl+V или «Вставить».", "muted"))
        self.chat_status = label("", "muted")
        self.body.addWidget(self.chat_status)
        self.list_toggle = QPushButton("▸ или выбрать из списка бесед")
        self.list_toggle.setFlat(True)
        self.list_toggle.setObjectName("linkish")
        self.list_toggle.clicked.connect(self._toggle_list)
        self.body.addWidget(self.list_toggle, 0, Qt.AlignmentFlag.AlignLeft)
        box = QGroupBox("Ваши беседы")
        self.list_box = box
        bl = QVBoxLayout(box)
        srow = QHBoxLayout()
        srow.addWidget(QLabel("Поиск:"))
        self.query = QLineEdit()
        self.query.textChanged.connect(lambda _: self._fill())
        srow.addWidget(self.query, 1)
        srow.addWidget(link_button("Обновить список", self._load_chats))
        bl.addLayout(srow)
        self.chat_list = QListWidget()
        self.chat_list.setMinimumHeight(150)
        self.chat_list.itemClicked.connect(self._on_pick)
        bl.addWidget(self.chat_list)
        self.list_status = label("", "muted")
        bl.addWidget(self.list_status)
        self.body.addWidget(box)
        box.setVisible(False)            # список — только по запросу: ссылка проще и надёжнее
        self.body.addStretch(1)
        vk = self.cfg["vk"]
        self.link.textChanged.connect(lambda _: self._apply_link(quiet=True))
        self.link.returnPressed.connect(lambda: self._apply_link())
        if vk.get("peer_id"):
            self.link.setText(chat_url(vk["peer_id"]))
        else:
            self._apply_link(quiet=True)

    def _toggle_list(self):
        show = self.list_box.isHidden()
        self.list_box.setVisible(show)
        self.list_toggle.setText(("▾ " if show else "▸ ") + "или выбрать из списка бесед")
        if show:
            if self.convs:
                self._fill()
            else:
                self._load_chats()

    def _paste(self):
        from PySide6.QtWidgets import QApplication
        text = (QApplication.clipboard().text() or "").strip()
        if text:
            self.link.setText(text)
        else:
            set_status(self.chat_status, "Буфер обмена пуст — сначала скопируйте ссылку на беседу.", "bad")

    def _apply_link(self, quiet=False):
        """Ссылка из поля → беседа. True, если ссылка правильная."""
        peer = parse_chat_link(self.link.text())
        if not peer and quiet and not self.link.text().strip():
            set_status(self.chat_status, "Вставьте ссылку на беседу, куда отправлять скриншоты.", "muted")
            self.set_next(False)
            return False
        if not peer:
            set_status(self.chat_status, "✖ Не похоже на ссылку на беседу. Откройте беседу в ВК и скопируйте адрес, "
                                         "например vk.com/im/convo/2000000001", "bad")
            self.set_next(False)
            return False
        vk = self.cfg["vk"]
        known = next((c for c in self.convs if c["peer_id"] == peer), None)
        if known:
            title = known["title"]
        elif peer == vk.get("peer_id") and vk.get("peer_title"):
            title = vk["peer_title"]
        else:
            title = f"беседа {peer}"
        vk["peer_id"], vk["peer_title"] = peer, title
        set_status(self.chat_status, f"✔ Выбрано: {title} (vk.com/im/convo/{peer})", "ok")
        self.set_next(True)
        self._select_current()
        return True

    def _select_current(self):
        cur = self.cfg["vk"].get("peer_id")
        for i, c in enumerate(self.shown):
            if c["peer_id"] == cur:
                self.chat_list.blockSignals(True)
                self.chat_list.setCurrentRow(i)
                self.chat_list.blockSignals(False)
                return

    def _fill(self):
        if self.key != "chat":
            return
        self.chat_list.clear()
        self.shown = filter_conversations(self.convs, self.query.text())
        for c in self.shown:
            it = QListWidgetItem(f"{c['title']}   ·   {KINDS.get(c['type'], c['type'])}")
            self.chat_list.addItem(it)
        self._select_current()
        if self.convs and not self.shown:
            set_status(self.list_status, "Ничего не найдено.", "muted")

    def _on_pick(self, item):
        c = self.shown[self.chat_list.row(item)]
        self.link.setText(chat_url(c["peer_id"]))

    def _load_chats(self):
        if self.loading_chats:
            return
        self.loading_chats = True
        set_status(self.list_status, "⏳ Загружаю список бесед (не дольше 20 секунд)… Ссылку выше можно "
                                     "не ждать — нажмите «Далее».", "wait")

        def done(convs, err=None):
            self.loading_chats = False
            self.chat_guard.stop()
            if self.key != "chat":
                return
            if err is not None:
                set_status(self.list_status, "✖ " + humanize(err) + "\nСсылка выше всё равно работает.", "bad")
                return
            self.convs = [c for c in convs or [] if c.get("title")]
            self._fill()
            n = len(self.convs)
            set_status(self.list_status, f"Найдено бесед: {n}." if n else "Беседы не найдены.", "muted")
            cur = self.cfg["vk"].get("peer_id")
            if self.convs and not any(c["peer_id"] == cur for c in self.convs):
                i = pick_default_conversation(self.convs, cur)
                if i is not None and not cur:
                    self.link.setText(chat_url(self.convs[i]["peer_id"]))
            self._apply_link(quiet=True)
        if self._group_mode():
            Task(lambda: make_group_client(self.cfg).get_conversations(), done, lambda e: done(None, e))
        else:
            self.chat_guard.start(25000)
            self.main.browser.run_flow(self.main.browser.flows().list_chats(timeout=20), lambda r, e: done(r, e))

    def _chat_list_slow(self):
        if self.key == "chat" and self.loading_chats:
            set_status(self.list_status, "✖ " + ChatListTimeout().text, "bad")

    # ---------- 4–5. программы ----------
    # ---------- 4. программы (2.2.0) ----------
    def page_programs(self):
        self.title_lbl.setText("Какие программы снимать")
        self.text_lbl.setText("Программа сама ищет среди запущенных Oasys и iVMS-4200. Отметьте, что снимать. "
                              "Вместо них или вместе с ними можно выбрать любую другую открытую программу.")
        self.prog_box = QVBoxLayout()
        self.body.addLayout(self.prog_box)
        self.prog_status = label("⏳ Ищу запущенные программы…", "wait")
        self.body.addWidget(self.prog_status)
        row = QHBoxLayout()
        row.addWidget(link_button("Искать снова", self._detect_programs))
        row.addSpacing(16)
        add = QPushButton("Добавить другую программу…")
        add.setToolTip("Выбрать любое открытое окно — его будут снимать каждый час")
        add.clicked.connect(self._add_custom)
        row.addWidget(add)
        row.addStretch(1)
        self.body.addLayout(row)
        self.prog_preview = QLabel()
        self.prog_preview.setFixedSize(420, 236)
        self.prog_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.prog_preview.setObjectName("previewEmpty")
        self.prog_preview.hide()
        self.body.addWidget(self.prog_preview)
        self._detect_programs()

    def _detect_programs(self):
        from ..sources import detect_known

        def done(wins):
            if self.key != "programs":
                return
            self._fill_programs(detect_known(wins or [], os.getpid()))

        def fail(err):
            if self.key == "programs":
                self._fill_programs([])
                set_status(self.prog_status, "✖ " + humanize(err), "bad")
        self.main.run_bg(lambda: self.main.backend_factory().all_windows(), done, fail)

    def _fill_programs(self, found):
        from ..sources import guess_kind
        while self.prog_box.count():
            w = self.prog_box.takeAt(0).widget()
            if w:
                w.deleteLater()
        self.prog_checks = []
        by_kind = {f["kind"]: f for f in found}
        for src in self.cfg.get("sources") or []:
            kind = src.get("kind") or guess_kind(src)
            f = by_kind.get(kind)
            win = f["window"] if f else None
            box = QGroupBox(src.get("name", "Программа"))
            bl = QHBoxLayout(box)
            cb = QCheckBox("Снимать")
            cb.setChecked(bool(src.get("enabled", True)))
            cb.toggled.connect(lambda on, s=src: self._set_src_enabled(s, on))
            bl.addWidget(cb)
            if kind == "custom":
                state = "своя программа"
            elif win:
                state = "✔ запущена"
            else:
                state = "не найдена среди запущенных"
            bl.addWidget(label(state, "ok" if win or kind == "custom" else "muted"), 1)
            b = QPushButton("Пробный снимок")
            b.clicked.connect(lambda _=False, s=src: self._test_shot(s))
            bl.addWidget(b)
            self.prog_box.addWidget(box)
            self.prog_checks.append(cb)
        n = sum(1 for f in found if f["window"])
        set_status(self.prog_status, f"Найдено программ: {n} из {len(found)}." if found else
                   "Запущенных Oasys и iVMS-4200 не видно — откройте их или добавьте другую программу.",
                   "muted" if n else "wait")

    def _set_src_enabled(self, src, on):
        src["enabled"] = bool(on)
        self.main.save_config(quiet=True)
        self.refresh_pages()
        self.show_page_labels()

    def show_page_labels(self):
        for j, lbl in enumerate(self.side_labels):
            done = j < self.index
            lbl.setText(("✔ " if done else f"{j + 1}. ") + self.pages[j][1])
            lbl.setProperty("state", "cur" if j == self.index else ("done" if done else ""))
            lbl.style().unpolish(lbl)
            lbl.style().polish(lbl)

    def _programs_ready(self):
        if any(s.get("enabled", True) for s in self.cfg.get("sources") or []):
            return True
        QMessageBox.warning(self, "Нечего снимать", "Отметьте хотя бы одну программу.")
        return False

    def _add_custom(self):
        from ..sources import MAX_SOURCES, add_source, custom_source

        def done(wins):
            from .winpicker import pick_window
            w = pick_window(self, wins, "")
            if not w:
                return
            src = custom_source(w, taken=[s.get("name", "") for s in self.cfg.get("sources") or []])
            if not add_source(self.cfg, src):
                QMessageBox.warning(self, "Слишком много программ",
                                    f"Можно снимать не больше {MAX_SOURCES} программ — снимите отметку с ненужной.")
                return
            log.info("Добавлена программа для съёмки: %s", src["name"])
            self.main.save_config(quiet=True)
            self.refresh_pages()
            self.show_page_labels()
            self._detect_programs()
        self.main.run_bg(lambda: self.main.backend_factory().all_windows(), done)

    def _test_shot(self, src):
        """Пробный снимок окна программы (без нажатий кнопок): вывести окно, снять его область, показать."""
        def run():
            b = self.main.backend_factory()
            w = src.get("window") or {}
            hwnd = b.find_window(w.get("title_regex", ""), w.get("process_regex", ""),
                                 w.get("exclude_title_regex", ""), w.get("match", "any"), src.get("name", ""))
            if not hwnd:
                raise RuntimeError(f"Окно {src.get('name')} не найдено — откройте программу")
            self.main.gui(self.main.hide_for_capture, wait=5)
            try:
                b.activate(hwnd)
                time.sleep(1.0)
                return b.grab(b.window_rect(hwnd))
            finally:
                self.main.gui(self.main.show_after_capture, wait=5)

        def done(img):
            if self.key != "programs" or img is None:
                return
            set_image(self.prog_preview, img, (416, 232))
            self.prog_preview.show()
            set_status(self.prog_status, f"✔ Снимок {src.get('name')} получен.", "ok")
        self.main.run_bg(run, done, source=src.get("name"))

    def page_source(self, src):
        name = src.get("name", "программа")
        self.title_lbl.setText(f"Программа {name}")
        self.text_lbl.setText(f"Откройте программу {name} (если она ещё не открыта). Программа сама найдёт её "
                              "окно — ниже загорится зелёная галочка.\nЗатем покажите, какую кнопку нажимать: "
                              "нажмите «Обвести…» и выделите кнопку мышкой.")
        self.win_status = label("⏳ Ищу окно…", "wait")
        self.body.addWidget(self.win_status)
        row = QHBoxLayout()
        row.addWidget(link_button("Проверить снова", lambda: self._check_window(src)))
        row.addSpacing(16)
        manual = QPushButton("Выбрать окно вручную…")
        manual.setToolTip("Если программа не находит окно сама — выберите его из списка открытых окон")
        manual.clicked.connect(lambda: self._pick_window(src))
        row.addWidget(manual)
        row.addStretch(1)
        self.body.addLayout(row)
        self.tpl_rows = {}
        for tpl, hint, required, _ in source_templates(src):
            box = QGroupBox(f"Кнопка «{button_label(hint)}»" + ("" if required else " (необязательно)"))
            bl = QHBoxLayout(box)
            left = QVBoxLayout()
            left.addWidget(label(hint))
            st = label("", "muted")
            left.addWidget(st)
            b = QPushButton(f"Обвести кнопку «{button_label(hint)}»")
            b.clicked.connect(lambda _=False, t=tpl, s=src: self._capture(s, t))
            left.addWidget(b, 0, Qt.AlignmentFlag.AlignLeft)
            bl.addLayout(left, 1)
            prev = QLabel()
            prev.setFixedSize(190, 90)
            prev.setAlignment(Qt.AlignmentFlag.AlignCenter)
            prev.setObjectName("previewEmpty")
            bl.addWidget(prev)
            self.body.addWidget(box)
            self.tpl_rows[tpl] = (prev, st)
            self._show_template(tpl)
        self._check_window(src)
        self.every(2500, lambda: self._check_window(src, quiet=True))

    # ---------- 3.0.0: сценарий съёмки ----------
    def page_scenario(self, src):
        from .. import recorder
        name = src.get("name", "камеры")
        self.title_lbl.setText(f"Сценарий съёмки: {name}")
        self.text_lbl.setText("Если в программе камер окно часто остаётся «не в том виде» (например развёрнута одна "
                              "камера) — запишите, как привести его в порядок. Если нет — пропустите: "
                              "будет работать встроенный способ.")
        self.body.addWidget(label(recorder.HOWTO, "hint"))
        self.scn_lbl = label("Сейчас: " + recorder.state_text(src), "muted")
        self.body.addWidget(self.scn_lbl)
        row = QHBoxLayout()
        row.addWidget(big_button("Записать сценарий для съёмки", BLUE, lambda: self._record_scenario(src)))
        row.addSpacing(10)
        row.addWidget(big_button("Пропустить", GREEN, self.next))
        row.addStretch(1)
        self.body.addLayout(row)

    def _record_scenario(self, src):
        from .. import recorder
        from .recorder_ui import RecorderDialog
        d = RecorderDialog(self, self.main, src, fresh=True)
        d.exec()
        if d.saved:
            if hasattr(self.main, "save_config"):
                self.main.save_config(quiet=True)
        self.scn_lbl.setText("Сейчас: " + recorder.state_text(src))

    def _show_template(self, tpl):
        prev, st = self.tpl_rows[tpl]
        path = resolve_path(tpl)
        if os.path.exists(path):
            set_image(prev, path, (186, 86))
            set_status(st, "✔ Кнопка выделена. Если промахнулись — обведите заново.", "ok")
        else:
            set_image(prev, None, (186, 86), "ещё не\nвыделено")
            set_status(st, "Кнопка ещё не выделена.", "muted")

    def _check_window(self, src, quiet=False):
        if self.checking:
            return
        self.checking = True
        name = src.get("name")
        page = self.index
        from .capture import find_source_window

        def done(hwnd):
            self.checking = False
            if self.index != page:
                return
            if hwnd:
                set_status(self.win_status, f"✔ Окно {name} найдено", "ok")
            else:
                set_status(self.win_status, f"✖ {name} не найден — откройте программу {name}. Если она открыта, "
                                            "нажмите «Выбрать окно вручную…».", "bad")

        def fail(err):
            self.checking = False
            if self.index == page:
                set_status(self.win_status, "✖ " + humanize(err, name), "bad")
        Task(lambda: find_source_window(self.main.backend_factory(), src), done, fail)

    def _pick_window(self, src):
        def done(wins):
            from .winpicker import pick_window_rule
            rule = pick_window_rule(self, wins, src.get("name", ""))
            if rule:
                src.setdefault("window", {}).update(rule)
                log.info("%s: окно выбрано вручную (%s)", src.get("name"),
                         rule.get("process_regex") or rule.get("title_regex"))
                self.main.save_config(quiet=True)
                self._check_window(src)
        self.main.run_bg(lambda: self.main.backend_factory().all_windows(), done)

    def _capture(self, src, tpl):
        def done(img, err):
            if err:
                QMessageBox.warning(self, "Обвести кнопку", humanize(err, src.get("name")))
            elif img is not None:
                path = resolve_path(tpl)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                img.save(path)
                log.info("Шаблон сохранён: %s (%dx%d)", tpl, img.width, img.height)
            if tpl in getattr(self, "tpl_rows", {}) and self.key == "source":
                self._show_template(tpl)
        from .main_window import capture_button
        capture_button(self.main, src, done)

    def _source_ready(self, src):
        missing = [button_label(h) for t, h, req, _ in source_templates(src)
                   if req and not os.path.exists(resolve_path(t))]
        if not missing:
            return True
        return QMessageBox.question(
            self, "Кнопка не выделена",
            f"Не выделена кнопка «{', '.join(missing)}».\nБез неё программа будет нажимать в примерное место "
            "экрана и может промахнуться.\n\nВсё равно продолжить?") == QMessageBox.StandardButton.Yes

    # ---------- 6. проверка ----------
    def page_test(self):
        self.title_lbl.setText("Проверка")
        self.text_lbl.setText("Сделайте пробные скриншоты и посмотрите, всё ли попало в кадр. "
                              "Если всё хорошо — отправьте их пробно в беседу.")
        row = QHBoxLayout()
        self.cap_btn = big_button("Сделать пробные скриншоты", BLUE, self.test_capture)
        self.send_test_btn = big_button("Отправить пробно в беседу", GREEN, self.test_send)
        self.send_test_btn.setEnabled(False)
        row.addWidget(self.cap_btn)
        row.addSpacing(10)
        row.addWidget(self.send_test_btn)
        row.addStretch(1)
        self.body.addLayout(row)
        self.test_status = label("", "muted")
        self.body.addWidget(self.test_status)
        self.prev_row = QHBoxLayout()
        self.body.addLayout(self.prev_row)
        if self.preview:
            self._show_preview(*self.preview)

    def test_capture(self):
        set_status(self.test_status, "⏳ Снимаю… не трогайте мышь несколько секунд.", "wait")
        self.cap_btn.setEnabled(False)
        page = self.index

        def done(res):
            self.preview = res
            if self.index == page:
                self.cap_btn.setEnabled(True)
                self._show_preview(*res)

        def fail(err):
            if self.index == page:
                self.cap_btn.setEnabled(True)
                set_status(self.test_status, "✖ " + humanize(err), "bad")
        Task(self.main.job.capture_preview, done, fail, "preview")

    def _show_preview(self, done, errors):
        while self.prev_row.count():
            it = self.prev_row.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        names = [s.get("name") for s in self.cfg["sources"] if s.get("enabled", True)]
        for col, name in enumerate(names):
            cell = QVBoxLayout()
            w = QWidget()
            w.setLayout(cell)
            cell.addWidget(label(f"{col + 1}. {name}", "big"))
            paths = done.get(name) or []
            if paths:
                img = QLabel()
                set_image(img, paths[0], (300, 190))
                cell.addWidget(img)
            else:
                cell.addWidget(label("✖ " + errors.get(name, "не снято"), "bad"))
            cell.addStretch(1)
            self.prev_row.addWidget(w)
        self.prev_row.addStretch(1)
        ok = [n for n in names if done.get(n)]
        if len(ok) == len(names):
            set_status(self.test_status, "✔ Снимки готовы. Проверьте, что всё видно.", "ok")
        else:
            set_status(self.test_status, "Не всё получилось — исправьте и попробуйте снова.", "bad")
        self.test_paths = [p for n in names for p in done.get(n, [])]
        self.send_test_btn.setEnabled(bool(self.test_paths))

    def test_send(self):
        wait = TEST_SEND_GAP_SEC - (time.monotonic() - self.last_test_send)
        if self.last_test_send and wait > 0:
            set_status(self.test_status, f"Пробную отправку можно повторить через {int(wait // 60) + 1} мин — "
                                         "чтобы не засорять беседу.", "wait")
            return
        self.last_test_send = time.monotonic()
        title = self.cfg["vk"].get("peer_title") or self.cfg["vk"].get("peer_id")
        self.send_test_btn.setEnabled(False)
        set_status(self.test_status, "⏳ Отправляю через ВКонтакте в программе (до минуты)…", "wait")
        page = self.index

        def done(res):
            if self.index != page:
                return
            if res == "unverified":
                set_status(self.test_status, f"✔ Похоже, отправлено в беседу «{title}» — проверьте ВКонтакте.", "ok")
            else:
                set_status(self.test_status, f"✔ Отправлено в беседу «{title}». Проверьте ВКонтакте.", "ok")

        def fail(err):
            if self.index == page:
                set_status(self.test_status, "✖ " + humanize(err), "bad")
                self.send_test_btn.setEnabled(True)
        paths = list(self.test_paths)
        Task(lambda: self.main.job.send_paths(paths, "Пробная отправка"), done, fail, "test-send")

    # ---------- 7. готово ----------
    def page_done(self):
        self.title_lbl.setText("Всё готово!")
        self.text_lbl.setText("Программа будет отправлять скриншоты каждый час. Компьютер не должен быть "
                              "заблокирован или в спящем режиме.")
        vk = self.cfg["vk"]
        if self._group_mode():
            lines = [(bool(vk.get("group_token")), "Отправка через сообщество (ключ сообщества)")]
        else:
            lines = [(bool(vk.get("login_ok")), "Вход ВК: " + ((vk.get("account_name") or "выполнен")
                                                             if vk.get("login_ok") else "не выполнен"))]
        lines.append((bool(vk.get("peer_id")), f"Беседа: {vk.get('peer_title') or vk.get('peer_id')}"))
        for _, _, src in self.pages:
            if src:
                tpls = [t for t, _, req, _ in source_templates(src) if req]
                ok = all(os.path.exists(resolve_path(t)) for t in tpls)
                lines.append((ok, f"{src.get('name')}: " + ("кнопка выделена" if ok else
                                                           "кнопка не выделена (будет клик по координатам)")))
        lines.append((self.main.admin, "Запуск от имени администратора" if self.main.admin else
                      "Программа запущена без прав администратора — нажатия в iVMS-4200 могут не работать"))
        for ok, text in lines:
            self.body.addWidget(label(("✔  " if ok else "⚠  ") + text, "ok" if ok else "wait"))
        self.autostart = QCheckBox("Запускать вместе с Windows (сразу с правами администратора)")
        self.autostart.setChecked(self.autostart_on)
        self.autostart.toggled.connect(lambda v: setattr(self, "autostart_on", v))
        self.body.addSpacing(10)
        self.body.addWidget(self.autostart)
        self.set_next(True, "Начать работу ✔", GREEN)

    def finish(self):
        cfg = self.cfg
        cfg["app"]["setup_done"] = True
        cfg["schedule"]["enabled"] = True
        if sys.platform == "win32":
            try:
                startup.set_enabled(self.autostart_on)
            except Exception as e:  # noqa: BLE001
                log.error("Автозапуск: %s", e)
                QMessageBox.warning(self, "Автозапуск", f"{e}\nЭто можно сделать позже в «Настройках».")
        self.main.save_config(quiet=True)
        log.info("Настройка завершена")
        self.main.close_wizard(finished=True)


_ = (APP_NAME, VK_BLUE)
