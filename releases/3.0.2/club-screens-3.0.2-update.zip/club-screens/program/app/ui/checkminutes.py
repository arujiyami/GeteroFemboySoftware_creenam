# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.2: список минут проверки «скрины на месте» — как панель точек маршрута в Яндекс Картах.
Тёмная скруглённая панель; строка: круглый значок слева, «:05» (щелчок — правка числом 1–59, Enter или щелчок мимо — сохранить, повтор отклоняется с подсказкой),
справа серый «×» (удалить). Тонкие линии между строками. Без перетаскивания:
строки всегда стоят по порядку минут — после правки или добавления список сортируется, повторы убираются.
Последняя строка — «+ Добавить проверку» (следующая свободная минута), не больше 15."""
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QSpinBox, QStackedWidget, QVBoxLayout,
                               QWidget)

from ..sentcheck import CHECK_OFFSETS, MAX_CHECKS, normalize_minutes

ROW_H = 44
STYLE = """
#checkPanel { background: #26272b; border-radius: 14px; }
#checkPanel QLabel { color: #f2f2f2; font-size: 11pt; background: transparent; }
#checkPanel QLabel#marker { color: #9e9e9e; font-size: 13pt; }
#checkPanel QLabel#marker[first="true"] { color: #ff5a4a; }
#checkPanel QPushButton#minuteText { color: #f2f2f2; font-size: 11pt; background: transparent; border: none;
    border-bottom: 1px dashed #6a6b70; text-align: left; padding: 0 2px; }
#checkPanel QPushButton#minuteText:hover { background: #313237; border-radius: 4px; }
#checkPanel QPushButton#removeCheck { color: #8a8a8e; font-size: 15pt; background: transparent; border: none; }
#checkPanel QPushButton#removeCheck:disabled { color: #4a4a4e; }
#checkPanel QPushButton#addCheck { color: #c8c8cc; font-size: 11pt; background: transparent; border: none;
    text-align: left; padding: 0 0 0 2px; }
#checkPanel QPushButton#addCheck:disabled { color: #5a5a5e; }
#checkPanel QFrame#sep { background: #3a3b40; }
#checkPanel QPushButton#stepBtn { background: #3a3b40; color: #e8e8e8; border: none; border-radius: 6px;
    font-size: 9pt; }
#checkPanel QPushButton#stepBtn:hover { background: #4a4b52; }
#checkPanel QSpinBox::up-button, """


class _MinuteSpin(QSpinBox):
    """Минута в виде «:05»."""

    def textFromValue(self, v):  # noqa: N802
        return f"{v:02d}"

    def resizeEvent(self, e):  # noqa: N802
        super().resizeEvent(e)
        # Qt со стилями и без кнопок сжимает поле ввода до 1 px — растягиваем на всю ширину
        self.lineEdit().setGeometry(self.rect())

    def showEvent(self, e):  # noqa: N802
        super().showEvent(e)
        self.lineEdit().setGeometry(self.rect())


class _Row(QWidget):
    def __init__(self, owner, minute):
        super().__init__()
        self.owner = owner
        self.setFixedHeight(ROW_H)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 0, 8, 0)
        lay.setSpacing(10)
        self.marker = QLabel("●")
        self.marker.setObjectName("marker")
        self.marker.setFixedWidth(18)
        self.spin = _MinuteSpin()
        self.spin.setRange(1, 59)
        self.spin.setPrefix(":")
        self.spin.setButtonSymbols(QSpinBox.ButtonSymbols.NoButtons)
        self.spin.setToolTip("Минута часа, 1–59. Enter или щелчок мимо — сохранить")
        self.committed = int(minute)
        self.spin.setValue(int(minute))
        self.spin.setFixedSize(64, 28)
        self.spin.lineEdit().setObjectName("minuteEdit")
        self.spin.lineEdit().setStyleSheet("background: #34353a; color: white; border: 1px solid #4a8cff; "
                                           "border-radius: 6px; padding: 0 6px; font-size: 11pt;")
        self.spin.setFrame(False)
        self.text = QPushButton()
        self.text.setObjectName("minuteText")
        self.text.setCursor(Qt.CursorShape.IBeamCursor)
        self.text.setToolTip("Щёлкните, чтобы изменить минуту")
        self.text.setFlat(True)
        self.text.clicked.connect(self.edit)
        self.stack = QStackedWidget()
        self.stack.addWidget(self.text)
        ed = QWidget()
        el = QHBoxLayout(ed)
        el.setContentsMargins(0, 0, 0, 0)
        el.setSpacing(4)
        el.addWidget(self.spin)
        for sym, step, tip in (("▲", 1, "Позже на минуту"), ("▼", -1, "Раньше на минуту")):
            b = QPushButton(sym)
            b.setObjectName("stepBtn")
            b.setToolTip(tip)
            b.setFixedSize(26, 26)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setAutoRepeat(True)
            b.clicked.connect(lambda _=False, d=step: (self.spin.stepBy(d), self.spin.setFocus()))
            el.addWidget(b)
        el.addStretch(1)
        self.edit_w = ed
        self.stack.addWidget(ed)
        self.stack.setFixedHeight(30)
        self.spin.valueChanged.connect(self._value)
        self.spin.editingFinished.connect(self.done_edit)
        self.remove = QPushButton("×")
        self.remove.setObjectName("removeCheck")
        self.remove.setToolTip("Удалить проверку")
        self.remove.setFixedWidth(30)
        self.remove.setCursor(Qt.CursorShape.PointingHandCursor)
        self.remove.clicked.connect(lambda: owner.remove_row(self))
        lay.addWidget(self.marker)
        lay.addWidget(self.stack, 1)
        lay.addWidget(self.remove)
        self._value()

    def _value(self, *_):
        self.text.setText(f":{self.spin.value():02d}  ✎")
        self.owner.changed.emit()

    def edit(self):
        self.stack.setCurrentWidget(self.edit_w)
        self.spin.setFocus()
        self.spin.selectAll()

    def done_edit(self):
        if self.stack.currentWidget() is not self.edit_w:
            return
        v = self.spin.value()
        if v != self.committed and v in [r.spin.value() for r in self.owner._rows if r is not self]:
            self.owner.hint(f"Проверка в :{v:02d} уже есть")
            self.spin.blockSignals(True)
            self.spin.setValue(self.committed)
            self.spin.blockSignals(False)
            self._value()
        elif v != self.committed:
            self.committed = v
            self.owner.hint("")
        self.stack.setCurrentWidget(self.text)
        self.owner.resort()


class MinuteList(QWidget):
    changed = Signal()

    def __init__(self, minutes=CHECK_OFFSETS):
        super().__init__()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.panel = QFrame()
        self.panel.setObjectName("checkPanel")
        self.panel.setStyleSheet(STYLE)
        self.panel.setMinimumWidth(300)
        outer.addWidget(self.panel)
        self.lay = QVBoxLayout(self.panel)
        self.lay.setContentsMargins(0, 4, 0, 4)
        self.lay.setSpacing(0)
        self._rows = []
        add = QWidget()
        add.setFixedHeight(ROW_H)
        al = QHBoxLayout(add)
        al.setContentsMargins(14, 0, 8, 0)
        self.add_btn = QPushButton("+   Добавить проверку")
        self.add_btn.setObjectName("addCheck")
        self.add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.add_btn.clicked.connect(self.add_new)
        al.addWidget(self.add_btn, 1)
        self.add_row_w = add
        self.hint_lbl = QLabel("")
        self.hint_lbl.setObjectName("checkHint")
        self.hint_lbl.setStyleSheet("color: #e0a030; font-size: 9pt;")
        self.hint_lbl.hide()
        outer.addWidget(self.hint_lbl)
        self.set_minutes(minutes)

    # ----- данные
    def rows(self):
        return list(self._rows)

    def raw(self):
        """Минуты в порядке списка (как видит пользователь)."""
        return [r.spin.value() for r in self._rows]

    def minutes(self):
        """Для сохранения: по времени, без повторов."""
        return normalize_minutes(self.raw())

    def set_minutes(self, minutes):
        self.blockSignals(True)
        for r in self._rows:
            r.setParent(None)
            r.deleteLater()
        self._rows = [_Row(self, m) for m in normalize_minutes(minutes)]
        self.blockSignals(False)
        self._relayout()

    def _relayout(self):
        while self.lay.count():
            it = self.lay.takeAt(0)
            w = it.widget()
            if w is not None and w.objectName() == "sep":
                w.deleteLater()
        for i, w in enumerate(self._rows + [self.add_row_w]):
            if i:
                sep = QFrame()
                sep.setObjectName("sep")
                sep.setFixedHeight(1)
                self.lay.addWidget(sep)
            self.lay.addWidget(w)
            w.show()
        n = len(self._rows)
        for i, r in enumerate(self._rows):
            r.marker.setProperty("first", i == 0)
            r.marker.style().unpolish(r.marker)
            r.marker.style().polish(r.marker)
            r.remove.setEnabled(n > 1)
        self.add_btn.setEnabled(n < MAX_CHECKS)
        self.add_btn.setToolTip("" if n < MAX_CHECKS else f"Не больше {MAX_CHECKS} проверок")

    def add_new(self):
        if len(self._rows) >= MAX_CHECKS:
            return
        cur = self.raw()
        free = [m for m in range((max(cur) if cur else 4) + 1, 60) if m not in cur] or \
               [m for m in range(1, 60) if m not in cur]
        self._rows.append(_Row(self, free[0] if free else 59))
        self._relayout()
        self.resort()
        self.changed.emit()

    def remove_row(self, row):
        if len(self._rows) <= 1 or row not in self._rows:
            return
        self._rows.remove(row)
        row.setParent(None)
        row.deleteLater()
        self._relayout()
        self.changed.emit()

    def hint(self, text):
        self.hint_lbl.setText(text)
        self.hint_lbl.setVisible(bool(text))

    def resort(self):
        """Строки по порядку минут, без повторов (после правки или добавления)."""
        keep, seen = [], set()
        for r in sorted(self._rows, key=lambda r: r.spin.value()):
            if r.spin.value() in seen:
                r.setParent(None)
                r.deleteLater()
            else:
                seen.add(r.spin.value())
                keep.append(r)
        if keep != self._rows:
            self._rows = keep
            self._relayout()
            self.changed.emit()
