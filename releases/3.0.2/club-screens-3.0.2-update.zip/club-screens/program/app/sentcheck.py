# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.2: «Проверять в :05, что скрины ушли» (sent_check.enabled, по умолчанию выключено).
3.0.2: проверки в :05, :07 и :10 смотрят саму беседу ВК (см. due_check / presence_verdict внизу).
Через check_after_min минут после планового съёма (обычно в ЧЧ:05) смотрим журнал съёмов
(logs/cycles.jsonl): снялось ли и ушло ли сообщение за этот час. Если нет — своё заметное окно поверх
всех окон (не уведомление Windows). Чистая логика — без Qt, проверяется тестами."""
from datetime import timedelta

CHECK_AFTER_MIN = 5
PENDING_LIMIT_MIN = 20      # идёт повтор (вторая попытка через ~3 мин) — ждём его итога, но не дольше

NOT_CAPTURED = "not_captured"
NOT_SENT = "not_sent"


def settings(cfg):
    s = (cfg or {}).get("sent_check") or {}
    return {"enabled": bool(s.get("enabled", False)), "sound": bool(s.get("sound", True)),
            "minutes": normalize_minutes(s.get("minutes"))}


def target_for(now, minute):
    """Время планового съёма, который проверяется сейчас: последний ЧЧ:minute не позже now."""
    t = now.replace(minute=int(minute or 0) % 60, second=0, microsecond=0)
    if t > now:
        t -= timedelta(hours=1)
    return t


def decide(now, minute, rows, running=True, started_at=None, skipped=(), busy=False, checked=None, done=None):
    """→ (target, verdict). verdict: None — проверять ещё рано / уже проверено / не нужно;
    'ok'; 'skip' (пропуск по просьбе, расписание остановлено, программа запущена позже);
    'pending' (цикл ещё идёт — например, ждёт вторую попытку); или словарь тревоги
    {'reason': NOT_CAPTURED|NOT_SENT, 'text': ..., 'detail': ...}."""
    target = target_for(now, minute)
    if checked == target:
        return target, None
    age = (now - target).total_seconds() / 60
    if age < CHECK_AFTER_MIN:
        return target, None
    if not running or target in set(skipped or ()):
        return target, "skip"
    if started_at is not None and started_at > target - timedelta(minutes=1):
        return target, "skip"
    if done:                     # 2.2.4: час уже закрыт (программа увидела отправку / ручная / найдено в беседе)
        return target, "ok"
    hour = [r for r in rows if target <= r["dt"] < target + timedelta(hours=1)]
    if any(r.get("sent") for r in hour):
        return target, "ok"
    if busy and age < PENDING_LIMIT_MIN:
        return target, "pending"
    planned = [r for r in hour if r.get("planned", True)] or hour
    when = target.strftime("%H:%M")
    if not planned:
        return target, {"reason": NOT_CAPTURED, "text": f"Скрины за {when} не снялись",
                        "detail": "Плановый съём не состоялся (программа зависла, компьютер спал или съём не начался)."}
    r = planned[-1]
    if r.get("shots", 1) == 0:
        return target, {"reason": NOT_CAPTURED, "text": f"Скрины за {when} не снялись",
                        "detail": r.get("err") or "Не удалось снять Oasys и iVMS-4200."}
    if r.get("queued"):
        return target, {"reason": NOT_SENT, "text": f"Скрины за {when} не отправились",
                        "detail": "Нет интернета — снимки ждут в очереди и уйдут, когда связь вернётся."}
    return target, {"reason": NOT_SENT, "text": f"Скрины за {when} не отправились",
                    "detail": r.get("err") or "Отправка в ВК не удалась."}


# ----- 3.0.2: проверка «скрины на месте» в :05, :07 и :10 — по самой беседе ВК, а не по отметке часа
CHECK_OFFSETS = (5, 7, 10)   # минуты часа по умолчанию (sent_check.minutes)
MAX_CHECKS = 15
CHECK_WINDOW_MIN = 60


def normalize_minutes(v, default=CHECK_OFFSETS):
    """Список минут часа (1–59): отсортирован, без повторов, не больше MAX_CHECKS. Мусор отбрасывается;
    пустой/негодный список → по умолчанию (5, 7, 10)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        v = [v]
    out = set()
    for x in v if isinstance(v, (list, tuple)) else []:
        try:
            if isinstance(x, bool):
                continue
            m = int(x)
        except (TypeError, ValueError):
            continue
        if 1 <= m <= 59:
            out.add(m)
    out = sorted(out)[:MAX_CHECKS]
    return out or list(default)


def check_minutes(cfg):
    return normalize_minutes(((cfg or {}).get("sent_check") or {}).get("minutes"))


def offsets_for(minutes, sched_minute):
    """Минуты часа → смещения от планового съёма (по времени, по порядку). Минута самого съёма не считается."""
    m0 = int(sched_minute or 0) % 60
    return sorted({(int(m) - m0) % 60 for m in minutes} - {0})
FOUND, MISSING, FAILED = "found", "missing", "failed"
CHECK_FAILED = "check_failed"
MISSING_IN_CHAT = "missing_in_chat"


def due_check(now, minute, done_offsets=(), offsets=CHECK_OFFSETS):
    """→ (target, offset) — какую проверку пора сделать сейчас, или (target, None).
    Берётся самая поздняя из уже наступивших отметок (:05/:07/:10 от планового съёма), ещё не сделанная;
    пропущенные более ранние не догоняются (одна проверка за раз). done_offsets — сделанные для этого target."""
    target = target_for(now, minute)
    age = (now - target).total_seconds() / 60
    if age >= CHECK_WINDOW_MIN:
        return target, None
    passed = [o for o in sorted(offsets) if age >= o]
    if not passed or passed[-1] in set(done_offsets or ()):
        return target, None
    return target, passed[-1]


def skip_reason(target, running=True, started_at=None, skipped=()):
    """Проверка не нужна: расписание остановлено, съём пропущен по просьбе, программа запущена позже."""
    if not running:
        return "расписание остановлено"
    if target in set(skipped or ()):
        return "съём пропущен по просьбе"
    if started_at is not None and started_at > target - timedelta(minutes=1):
        return "программа запущена позже планового съёма"
    return ""


def presence_verdict(target, status, reason="", log_verdict=None, sent_by=None):
    """Итог проверки беседы → 'ok' или словарь тревоги (как у decide).
    status: FOUND / MISSING / FAILED. log_verdict — вердикт decide() по журналу (если скринов не было вовсе,
    причина «не снялись/не отправились» точнее). sent_by — отметка часа (program/manual/chat) или None."""
    when = target.strftime("%H:%M")
    if status == FOUND:
        return "ok"
    if status == FAILED:
        return {"reason": CHECK_FAILED, "text": f"Не удалось проверить скрины за {when}",
                "detail": "Беседу ВК прочитать не получилось (нет связи или ВК не ответил) — неизвестно, на месте ли "
                          f"скрины. Посмотрите беседу сами. {('Причина: ' + reason) if reason else ''}".strip()}
    if isinstance(log_verdict, dict) and not sent_by:
        d = dict(log_verdict)
        d["detail"] = d.get("detail", "") + " В беседе сообщения со скринами за этот час нет."
        return d
    why = {"program": "Программа отправила их (поле ввода очистилось), но",
           "manual": "Их отправляли вручную кнопкой программы, но",
           "chat": "Раньше они были в беседе, но"}.get(sent_by, "")
    return {"reason": MISSING_IN_CHAT, "text": f"Скринов за {when} нет в беседе",
            "detail": (why + " сейчас " if why else "") +
                      "в беседе нет своего сообщения с двумя скринами за этот час — возможно, его удалили или ВК его "
                      "не принял. Повторно сама программа не отправляет."}


def banner_action(shown_for, target, verdict):
    """Что сделать с окном-тревогой: 'show' (новое), 'update' (уже висит за этот час — обновить текст),
    'close' (висит за этот час, а скрины нашлись), None — ничего."""
    if verdict == "ok":
        return "close" if shown_for == target else None
    if isinstance(verdict, dict):
        return "update" if shown_for == target else "show"
    return None
