# Original-Author: Владислав С.
# Created: 2026-10-30
"""2.2.5: пресет вида iVMS (select_view) и запись сценария съёмки."""
import copy
import os
import tempfile
import unittest

from PIL import Image

from app import recorder
from app.config import DEFAULTS, migrate, validate
from app.steps import Context, StepRunner

PROGRAM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(PROGRAM)


class FakeBE:
    def __init__(self, ui=None, found=None):
        self.ui, self.found = ui, found
        self.clicks, self.ui_calls = [], []

    def find_ui_item(self, hwnd, name, tab=None, group=None):
        self.ui_calls.append(name)
        return self.ui

    def click(self, x, y, double=False):
        self.clicks.append((x, y, double))

    def window_rect(self, hwnd):
        return (100, 50, 1920, 1040)

    def grab(self, rect):
        return Image.new("RGB", (int(rect[2]), int(rect[3])), "gray")

    def locate(self, path, rect, conf):
        return self.found


def ivms():
    return copy.deepcopy([s for s in DEFAULTS["sources"] if s["kind"] == "ivms"][0])


def step_of(src):
    return [s for s in src["steps"] if isinstance(s, dict) and s.get("type") == "select_view"][0]


class SelectView(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.sleeps = []

    def runner(self, be):
        return StepRunner(be, lambda p: os.path.join(self.root, p), sleep=self.sleeps.append)

    def ctx(self, src):
        c = Context(src)
        c.hwnd = 1
        return c

    def test_default_has_step_after_main_view(self):
        src = ivms()
        types = [s["type"] for s in src["steps"]]
        self.assertEqual(src["view_preset"], "cam")
        i = types.index("select_view")
        self.assertIn("main_view", src["steps"][i - 2]["template"])
        self.assertIn("fullscreen", src["steps"][i + 1]["template"])
        self.assertFalse([e for e in validate(copy.deepcopy(DEFAULTS)) if "шаг" in e.lower()])

    def test_uia_double_click_and_learn(self):
        be = FakeBE(ui=(160, 250))
        src = ivms()
        self.runner(be).run_step(step_of(src), self.ctx(src))
        self.assertEqual(be.clicks, [(160, 250, True)])
        self.assertEqual(be.ui_calls, ["cam"])
        self.assertIn(3.0, self.sleeps)
        self.assertTrue(os.path.exists(os.path.join(self.root, "state", "view_cam.png")))

    def test_learned_image_then_fallback(self):
        src = ivms()
        os.makedirs(os.path.join(self.root, "state"))
        Image.new("RGB", (10, 10)).save(os.path.join(self.root, "state", "view_cam.png"))
        be = FakeBE(ui=None, found=(300, 400))
        self.runner(be).run_step(step_of(src), self.ctx(src))
        self.assertEqual(be.clicks, [(300, 400, True)])
        be = FakeBE(ui=None, found=None)
        self.runner(be).run_step(step_of(src), self.ctx(src))
        self.assertEqual(be.clicks, [(184, 138, False), (203, 250, True)])   # Resource, затем cam (от угла окна)

    def test_empty_preset_skips(self):
        be = FakeBE(ui=(1, 1))
        src = ivms()
        src["view_preset"] = ""
        self.runner(be).run_step(step_of(src), self.ctx(src))
        self.assertEqual(be.clicks, [])
        self.assertEqual(be.ui_calls, [])

    def test_migration_inserts_once(self):
        cfg = copy.deepcopy(DEFAULTS)
        for s in cfg["sources"]:
            if s["kind"] == "ivms":
                s["steps"] = [x for x in s["steps"] if x.get("type") != "select_view"]
                s.pop("view_preset")
        cfg["app"]["config_version"] = "2.2.0"
        notes = migrate(cfg)
        src = [s for s in cfg["sources"] if s["kind"] == "ivms"][0]
        self.assertEqual([x["type"] for x in src["steps"]], [x["type"] for x in ivms()["steps"]])
        self.assertEqual(src["view_preset"], "cam")
        self.assertTrue(any("2.2.5" in n for n in notes))
        migrate(cfg)
        self.assertEqual([x["type"] for x in src["steps"]].count("select_view"), 1)

    def test_migration_skips_recorded(self):
        cfg = copy.deepcopy(DEFAULTS)
        src = [s for s in cfg["sources"] if s["kind"] == "ivms"][0]
        src["steps"] = [{"type": "activate_window"}, {"type": "screenshot"}]
        src["recorded"] = True
        cfg["app"]["config_version"] = "2.2.0"
        migrate(cfg)
        self.assertEqual(len(src["steps"]), 2)


class Rec(unittest.TestCase):
    def test_events_to_steps(self):
        ev = [{"kind": "click", "t": 0.0, "x": 50, "y": 100}, {"kind": "click", "t": 0.2, "x": 52, "y": 101},
              {"kind": "click", "t": 2.0, "x": 300, "y": 20}, {"kind": "key", "t": 2.1, "keys": ["esc"]},
              {"kind": "key", "t": 9.0, "keys": ["ctrl", "f"]}]
        st = recorder.events_to_steps(ev, {2: "recordings/x/step03.png"})
        self.assertEqual(st[0], {"type": "click_xy", "x": 50, "y": 100, "units": "pixels", "double": True})
        self.assertEqual(st[1], {"type": "wait", "seconds": 1.8})
        self.assertEqual(st[2]["type"], "click_image")
        self.assertEqual(st[2]["fallback"]["x"], 300)
        self.assertFalse(st[2].get("double"))
        self.assertEqual(st[3], {"type": "press", "key": "esc"})
        self.assertEqual(st[4], {"type": "wait", "seconds": 5.0})
        self.assertEqual(st[5], {"type": "hotkey", "keys": ["ctrl", "f"]})
        full = recorder.scenario(st, ivms()["steps"])
        self.assertEqual(full[0]["type"], "activate_window")
        self.assertEqual(full[-1]["mode"], "monitor")
        for s in full:
            recorder.describe(s)
        cfg = copy.deepcopy(DEFAULTS)
        cfg["sources"][1]["steps"] = full
        self.assertFalse([e for e in validate(cfg) if "iVMS" in e])

    def test_recorder_hooks(self):
        class BE(FakeBE):
            def record_hook_factory(self, m, k):
                class H:
                    def start(self):
                        return True

                    def stop(self):
                        pass
                return H()
        folder = tempfile.mkdtemp()
        stopped = []
        t = [0.0]
        r = recorder.Recorder(BE(), 1, folder, on_stop=lambda: stopped.append(1), clock=lambda: t[0])
        self.assertTrue(r.start())
        r.on_mouse(0x0201, 0, 150, 200)
        r.on_mouse(0x0201, 0, 10, 10)              # вне окна
        r.on_mouse(0x0200, 0, 150, 200)            # движение
        t[0] = 1.0
        r.on_key(0x0100, 0x1B, 0)
        r.on_key(0x0100, 0xA2, 0)
        r.on_key(0x0100, 0xA4, 0)
        self.assertTrue(r.on_key(0x0100, ord("S"), 0))
        r.on_mouse(0x0201, 0, 160, 200)            # после остановки — не пишется
        import time
        time.sleep(0.3)
        self.assertEqual(stopped, [1])
        self.assertEqual(r.ignored, 1)
        st = r.steps(rel=lambda p: "recordings/x/" + os.path.basename(p))
        self.assertEqual([s["type"] for s in st], ["click_image", "wait", "press"])
        self.assertEqual(st[0]["fallback"]["x"], 50)
        self.assertEqual(st[0]["fallback"]["y"], 150)


class Shipping(unittest.TestCase):
    def test_no_recordings_and_names(self):
        bad = [bytes.fromhex(h).decode() for h in ("d0a0d183d181d0bbd0b0d0bd",
                                                    "d0a1d0bfd0b8d180d0b8d0b4d0b5d0bdd0bad0be", "6d61676e6b6172")]
        for d in (os.path.join(PROGRAM, "app"), os.path.join(PROGRAM, "templates")):
            for dp, _, fs in os.walk(d):
                for f in fs:
                    if f.endswith(".pyc"):
                        continue
                    with open(os.path.join(dp, f), "rb") as fh:
                        t = fh.read().decode("utf-8", "ignore")
                    for b in bad:
                        self.assertNotIn(b, t, f)


class DialogSmoke(unittest.TestCase):
    def test_dialog(self):
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication([])
        from app.ui.recorder_ui import RecorderDialog
        src = ivms()
        src["steps"] = [{"type": "wait", "seconds": 1}, {"type": "press", "key": "esc"}]
        src["recorded"] = True
        src["default_steps"] = ivms()["steps"]
        d = RecorderDialog(None, None, src)
        self.assertEqual(d.list.count(), 2)
        d.list.setCurrentRow(0)
        d.move(1)
        self.assertEqual(d.steps[1]["type"], "wait")
        d.add_wait()
        d.delete()
        d.save()
        self.assertTrue(src["recorded"])
        d = RecorderDialog(None, None, src)
        d.restore_default()
        self.assertNotIn("recorded", src)
        self.assertEqual(src["steps"], ivms()["steps"])
        app.processEvents()


class V300(unittest.TestCase):
    def test_update_major(self):
        from app.updater import is_newer
        self.assertTrue(is_newer("3.0.0", "2.2.5"))
        self.assertTrue(is_newer("v3.0.0", "2.2.10"))
        self.assertFalse(is_newer("2.2.9", "3.0.0"))

    def test_default_is_builtin(self):
        src = ivms()
        self.assertFalse(src.get("recorded"))
        self.assertEqual(recorder.state_text(src), "Стандартный")
        self.assertIn("select_view", [s["type"] for s in src["steps"]])

    def test_save_rerecord_reset(self):
        root = tempfile.mkdtemp()
        res = lambda p: os.path.join(root, p)  # noqa: E731
        src = ivms()
        old = os.path.join(root, recorder.new_session_folder(src["name"], 1000))
        new = os.path.join(root, recorder.new_session_folder(src["name"], 2000))
        for d in (old, new):
            os.makedirs(d)
        recorder.mark_saved(src, [{"type": "press", "key": "esc"}])
        self.assertTrue(recorder.state_text(src).startswith("Записанный, 1 шагов"))
        recorder.keep_only(res(recorder.recordings_root(src["name"])), new)
        self.assertFalse(os.path.exists(old))
        self.assertTrue(os.path.exists(new))
        recorder.mark_saved(src, [{"type": "wait", "seconds": 1}])
        recorder.reset(src, res)
        self.assertEqual(src["steps"], ivms()["steps"])
        self.assertNotIn("recorded", src)
        self.assertNotIn("recorded_at", src)
        self.assertFalse(os.path.exists(res(recorder.recordings_root(src["name"]))))

    def test_dialog_fresh_cancel_keeps_old(self):
        from PySide6.QtWidgets import QApplication
        QApplication.instance() or QApplication([])
        from app.ui.recorder_ui import RecorderDialog
        src = ivms()
        recorder.mark_saved(src, [{"type": "press", "key": "esc"}])
        d = RecorderDialog(None, None, src, fresh=True)
        self.assertEqual(d.list.count(), 0)
        d.session = tempfile.mkdtemp()
        d.reject()
        self.assertFalse(os.path.exists(d.session or "x"))
        self.assertEqual(src["steps"], [{"type": "press", "key": "esc"}])

    def test_wizard_page(self):
        from app.wizard_logic import step_done, wizard_pages
        pages = wizard_pages(copy.deepcopy(DEFAULTS))
        sc = [p for p in pages if p[0] == "scenario"]
        self.assertEqual(len(sc), 1)
        self.assertEqual(sc[0][2]["kind"], "ivms")
        self.assertTrue(step_done(DEFAULTS, "scenario", sc[0][2]))
        for w in ("Ctrl+Alt+S", "Начать запись", "Сохранить", "полного экрана"):
            self.assertIn(w, recorder.HOWTO)
