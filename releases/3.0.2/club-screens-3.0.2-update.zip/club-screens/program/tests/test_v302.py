# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.2: проверка «скрины на месте» в :05, :07 и :10 по самой беседе ВК; одно окно-тревога на час."""
import os
import tempfile
import threading
import unittest
from datetime import datetime
from unittest import mock

from app import dupcheck, hourdone, sentcheck

T = datetime(2026, 10, 30, 23, 0)
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def at(m, h=23):
    return datetime(2026, 10, 30, h, m)


class Schedule(unittest.TestCase):
    def test_offsets(self):
        self.assertEqual(sentcheck.CHECK_OFFSETS, (5, 7, 10))

    def test_due_times(self):
        self.assertEqual(sentcheck.due_check(at(4), 0), (T, None))
        self.assertEqual(sentcheck.due_check(at(5), 0), (T, 5))
        self.assertEqual(sentcheck.due_check(at(6), 0, {5}), (T, None))
        self.assertEqual(sentcheck.due_check(at(7), 0, {5}), (T, 7))
        self.assertEqual(sentcheck.due_check(at(9), 0, {5, 7}), (T, None))
        self.assertEqual(sentcheck.due_check(at(10), 0, {5, 7}), (T, 10))
        self.assertEqual(sentcheck.due_check(at(15), 0, {5, 7, 10}), (T, None))

    def test_late_takes_latest_only(self):
        # компьютер «проснулся» в :08 — сразу проверка :07, а не догонять :05
        self.assertEqual(sentcheck.due_check(at(8), 0, set()), (T, 7))
        self.assertEqual(sentcheck.due_check(at(8), 0, {7}), (T, None))

    def test_window_closes(self):
        self.assertEqual(sentcheck.due_check(at(20), 0, {10}), (T, None))   # пропущенные не догоняются
        self.assertEqual(sentcheck.due_check(at(20), 0), (T, 10))           # проснулся — одна последняя

    def test_other_minute(self):
        self.assertEqual(sentcheck.due_check(at(37), 30), (at(30), 7))

    def test_skip_reason(self):
        self.assertTrue(sentcheck.skip_reason(T, running=False))
        self.assertTrue(sentcheck.skip_reason(T, skipped=[T]))
        self.assertTrue(sentcheck.skip_reason(T, started_at=at(3)))
        self.assertEqual(sentcheck.skip_reason(T, started_at=at(0, 22)), "")


class Verdicts(unittest.TestCase):
    def test_found(self):
        self.assertEqual(sentcheck.presence_verdict(T, sentcheck.FOUND), "ok")

    def test_missing_despite_sent(self):
        v = sentcheck.presence_verdict(T, sentcheck.MISSING, "нет", sent_by=hourdone.PROGRAM)
        self.assertEqual(v["reason"], sentcheck.MISSING_IN_CHAT)
        self.assertIn("23:00", v["text"])
        self.assertIn("удалили", v["detail"])

    def test_failed_not_claimed_missing(self):
        v = sentcheck.presence_verdict(T, sentcheck.FAILED, "нет связи")
        self.assertEqual(v["reason"], sentcheck.CHECK_FAILED)
        self.assertIn("Не удалось проверить", v["text"])
        self.assertNotIn("нет в беседе", v["text"])

    def test_log_reason_kept(self):
        lv = {"reason": sentcheck.NOT_CAPTURED, "text": "Скрины за 23:00 не снялись", "detail": "x."}
        v = sentcheck.presence_verdict(T, sentcheck.MISSING, "", log_verdict=lv)
        self.assertEqual(v["reason"], sentcheck.NOT_CAPTURED)

    def test_banner_actions(self):
        miss = {"reason": "x", "text": "t", "detail": "d"}
        self.assertEqual(sentcheck.banner_action(None, T, miss), "show")
        self.assertEqual(sentcheck.banner_action(T, T, miss), "update")
        self.assertEqual(sentcheck.banner_action(T, T, "ok"), "close")
        self.assertIsNone(sentcheck.banner_action(None, T, "ok"))
        self.assertEqual(sentcheck.banner_action(at(0, 22), T, miss), "show")

    def test_dupcheck_status(self):
        p = [os.path.join(tempfile.mkdtemp(), "a.png")] * 2
        self.assertEqual(dupcheck.find_status(None, p, T)[0], dupcheck.FAILED)
        self.assertEqual(dupcheck.find_status({"msgs": []}, p, T)[0], dupcheck.MISSING)
        self.assertEqual(dupcheck.find_status({"msgs": []}, [], T)[0], dupcheck.FAILED)
        self.assertEqual(dupcheck.FOUND, sentcheck.FOUND)


class FakeAlert:
    def __init__(self):
        self.visible, self.shows = False, 0

    def isVisible(self):
        return self.visible

    def dismiss(self, by_user=True):
        self.visible = False


class FakeLock:
    def __init__(self):
        self.l = threading.Lock()

    def locked(self):
        return self.l.locked()


class Sched:
    running, started_at, skipped = True, None, []


class Job:
    def __init__(self, root, results):
        self.lock = FakeLock()
        self.root, self.results, self.calls, self.resends = root, results, [], 0

    def _root(self):
        return self.root

    def chat_presence(self, cfg, when):
        self.calls.append(when)
        return self.results.pop(0)

    def resend_latest(self):
        self.resends += 1


def make_win(results):
    try:
        from app.ui.services import ServicesMixin
    except Exception:  # noqa: BLE001
        raise unittest.SkipTest("нет Qt")

    class W(ServicesMixin):
        quitting = False
        tray = None

        def __init__(self):
            self.cfg = {"sent_check": {"enabled": True}, "schedule": {"minute": 0}}
            self.scheduler = Sched()
            self.job = Job(tempfile.mkdtemp(), results)
            self.sent_alert = FakeAlert()
            self.alerts = []

        def show_sent_alert(self, v, update=False):
            self.alerts.append((v["reason"], update))
            self.sent_alert.visible = True
    return W()


class Sync:
    def __init__(self, fn, ok, fail, name=""):
        try:
            r = fn()
        except Exception as e:  # noqa: BLE001
            return fail(e)
        ok(r)


class Tick(unittest.TestCase):
    def run_minutes(self, w, minutes):
        out = []
        with mock.patch("app.ui.services.Task", Sync):
            for m in minutes:
                out.append(w.sent_check_tick(at(m)))
        return out

    def test_three_checks_one_banner(self):
        M = (sentcheck.MISSING, "нет")
        w = make_win([M, M, M])
        hourdone.mark(w.job.root, T, hourdone.PROGRAM)       # «verified», но в беседе нет — тревога всё равно
        out = self.run_minutes(w, range(0, 16))
        self.assertEqual(len(w.job.calls), 3)
        self.assertEqual(out.count("checking"), 3)
        self.assertEqual(w.alerts, [(sentcheck.MISSING_IN_CHAT, False), (sentcheck.MISSING_IN_CHAT, True),
                                    (sentcheck.MISSING_IN_CHAT, True)])
        self.assertEqual(w.job.resends, 0)                    # повтор сам не отправляется

    def test_found_later_closes(self):
        w = make_win([(sentcheck.MISSING, ""), (sentcheck.FOUND, "ok"), (sentcheck.FOUND, "ok")])
        self.run_minutes(w, [5, 7])
        self.assertFalse(w.sent_alert.isVisible())
        self.assertEqual(len(w.alerts), 1)

    def test_failed_says_failed(self):
        w = make_win([(sentcheck.FAILED, "сеть"), (sentcheck.FOUND, ""), (sentcheck.FOUND, "")])
        self.run_minutes(w, [5])
        self.assertEqual(w.alerts, [(sentcheck.CHECK_FAILED, False)])

    def test_closed_by_user_not_reshown(self):
        M = (sentcheck.MISSING, "")
        w = make_win([M, M, M])
        self.run_minutes(w, [5])
        w._sent_alert_closed(True)
        w.sent_alert.visible = False
        self.run_minutes(w, [7, 10])
        self.assertEqual(len(w.alerts), 1)

    def test_busy_waits(self):
        w = make_win([(sentcheck.FOUND, "")] * 3)
        w.job.lock.l.acquire()
        self.assertEqual(self.run_minutes(w, [5, 6]), ["pending", "pending"])
        w.job.lock.l.release()
        self.assertEqual(self.run_minutes(w, [6]), ["checking"])
        self.assertEqual(len(w.job.calls), 1)

    def test_disabled_and_skip(self):
        w = make_win([])
        w.cfg["sent_check"]["enabled"] = False
        self.assertEqual(self.run_minutes(w, [5]), [None])
        w.cfg["sent_check"]["enabled"] = True
        w.scheduler.running = False
        self.assertEqual(self.run_minutes(w, [5]), ["skip"])
        self.assertEqual(w.job.calls, [])


class Minutes(unittest.TestCase):
    def test_normalize(self):
        n = sentcheck.normalize_minutes
        self.assertEqual(n([10, 5, 7, 5]), [5, 7, 10])
        self.assertEqual(n([0, 60, "x", None, True, 30]), [30])
        self.assertEqual(n([]), [5, 7, 10])
        self.assertEqual(n(None), [5, 7, 10])
        self.assertEqual(n(12), [12])
        self.assertEqual(len(n(list(range(1, 40)))), sentcheck.MAX_CHECKS)

    def test_offsets_chronological(self):
        self.assertEqual(sentcheck.offsets_for([10, 5, 7], 0), [5, 7, 10])
        self.assertEqual(sentcheck.offsets_for([35, 5, 30], 30), [5, 35])      # минута съёма не считается
        offs = sentcheck.offsets_for([20, 3], 0)
        self.assertEqual(sentcheck.due_check(at(3), 0, (), offs), (T, 3))
        self.assertEqual(sentcheck.due_check(at(19), 0, {3}, offs), (T, None))
        self.assertEqual(sentcheck.due_check(at(25), 0, {3}, offs), (T, 20))
        self.assertEqual(sentcheck.due_check(at(59), 0, {3, 20}, offs), (T, None))

    def test_custom_minutes_in_tick(self):
        w = make_win([(sentcheck.FOUND, "")] * 5)
        w.cfg["sent_check"]["minutes"] = [30, 3]
        with mock.patch("app.ui.services.Task", Sync):
            out = [w.sent_check_tick(at(m)) for m in range(0, 40)]
        self.assertEqual(out.count("checking"), 2)

    def test_defaults_and_validate(self):
        from app.config import DEFAULTS, validate
        self.assertEqual(DEFAULTS["sent_check"]["minutes"], [5, 7, 10])
        cfg = {"vk": {"sender": "browser"}, "sent_check": {"minutes": [5, 7, 10]}}
        bad = [e for e in validate(cfg) if "sent_check" in e]
        self.assertEqual(bad, [])
        for v in ([], [0], [60], list(range(1, 17)), "5", [True]):
            cfg["sent_check"]["minutes"] = v
            self.assertTrue([e for e in validate(cfg) if "sent_check" in e], v)

    def test_migrate(self):
        from app.config import _migrate_sent_check_302
        sc = {"sent_check": {"enabled": True}}
        self.assertTrue(_migrate_sent_check_302(sc))
        self.assertEqual(sc["sent_check"]["minutes"], [5, 7, 10])
        sc = {"sent_check": {"enabled": True, "check_after_min": 12}}
        _migrate_sent_check_302(sc)
        self.assertEqual(sc["sent_check"]["minutes"], [5, 7, 10, 12])
        self.assertNotIn("check_after_min", sc["sent_check"])
        sc = {"sent_check": {"minutes": [10, 5, 5, 99]}}
        _migrate_sent_check_302(sc)
        self.assertEqual(sc["sent_check"]["minutes"], [5, 10])
        sc = {"sent_check": {"minutes": [5, 20]}}
        self.assertEqual(_migrate_sent_check_302(sc), [])

    def test_widget(self):
        try:
            from PySide6.QtWidgets import QApplication
        except Exception:  # noqa: BLE001
            self.skipTest("нет Qt")
        QApplication.instance() or QApplication([])
        from app.ui.checkminutes import MinuteList
        w = MinuteList([10, 5, 7])
        self.assertEqual(w.raw(), [5, 7, 10])
        w.rows()[0].spin.setValue(30)           # порядок в списке — как ввели, при сохранении — по времени
        self.assertEqual(w.raw(), [30, 7, 10])
        self.assertEqual(w.minutes(), [7, 10, 30])
        while w.add_btn.isEnabled():
            w.add_new()
        self.assertEqual(len(w.raw()), sentcheck.MAX_CHECKS)
        w.add_new()
        self.assertEqual(len(w.raw()), sentcheck.MAX_CHECKS)
        while len(w.raw()) > 1:
            w.remove_row(w.rows()[0])
        self.assertFalse(w.rows()[0].remove.isEnabled())
        w.remove_row(w.rows()[0])
        self.assertEqual(len(w.raw()), 1)
        w.set_minutes([5, 7, 10])
        w.rows()[2].text.click()
        w.rows()[2].spin.setValue(3)             # правка «:10» → «:03»
        w.rows()[2].done_edit()
        self.assertEqual(w.raw(), [3, 5, 7])     # пересортировано сразу
        w.rows()[0].text.click()
        w.rows()[0].spin.setValue(7)             # повтор отклоняется с подсказкой
        w.rows()[0].done_edit()
        self.assertEqual(w.raw(), [3, 5, 7])
        self.assertIn(":07 уже есть", w.hint_lbl.text())
        self.assertTrue(w.rows()[0].text.text().startswith(":03"))
        w.rows()[0].text.click()                 # щелчок по тексту — правка числом
        self.assertIs(w.rows()[0].stack.currentWidget(), w.rows()[0].edit_w)
        self.assertFalse(hasattr(w.rows()[0], "handle"))  # без перетаскивания

class Texts(unittest.TestCase):
    def test_checkbox_renamed(self):
        src = open(os.path.join(HERE, "app", "ui", "settings.py"), encoding="utf-8").read()
        self.assertIn("Проверять, что скрины на месте", src)
        self.assertNotIn("Проверять в :05, что скрины ушли", src)

    def test_no_windows_notification(self):
        src = open(os.path.join(HERE, "app", "ui", "services.py"), encoding="utf-8").read()
        body = src[src.index("def sent_check_tick"):src.index("def show_sent_alert")]
        self.assertNotIn("showMessage", body)
        self.assertNotIn("resend_latest(", body)


if __name__ == "__main__":
    unittest.main()
