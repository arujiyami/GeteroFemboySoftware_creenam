# Original-Author: Владислав С.
# Created: 2026-10-28
import copy
import unittest

from app.config import DEFAULTS
from app.wizard_logic import button_label, filter_conversations, pick_default_conversation, wizard_pages

CONVS = [
    {"peer_id": 123, "title": "Иван", "type": "user"},
    {"peer_id": 2000000003, "title": "Админы", "type": "chat"},
    {"peer_id": 2000000001, "title": "Камеры | Мой клуб", "type": "chat"},
    {"peer_id": 2000000030, "title": "Камеры — другой клуб", "type": "chat"},
]


class WizardLogicTest(unittest.TestCase):
    def test_default_by_peer(self):
        self.assertEqual(pick_default_conversation(CONVS, 2000000030), 3)

    def test_default_by_keyword(self):
        self.assertEqual(pick_default_conversation(CONVS, None), 2)
        self.assertEqual(pick_default_conversation(CONVS, "мусор"), 2)

    def test_default_first_chat_or_none(self):
        convs = [CONVS[0], CONVS[1]]
        self.assertEqual(pick_default_conversation(convs, None), 1)
        self.assertEqual(pick_default_conversation([CONVS[0]], None), 0)
        self.assertIsNone(pick_default_conversation([], None))

    def test_filter(self):
        self.assertEqual(len(filter_conversations(CONVS, "камеры")), 2)
        self.assertEqual(len(filter_conversations(CONVS, "")), 4)
        self.assertEqual(filter_conversations(CONVS, "2000000003")[0]["title"], "Админы")

    def test_button_label(self):
        self.assertEqual(button_label("Кнопка «Карта клуба» на левой панели"), "Карта клуба")
        self.assertEqual(button_label("что-то"), "кнопку")

    def test_pages(self):
        cfg = copy.deepcopy(DEFAULTS)
        keys = [p[0] for p in wizard_pages(cfg)]
        self.assertEqual(keys, ["welcome", "vk", "chat", "programs", "source", "source", "scenario", "test", "done"])
        cfg["sources"][1]["enabled"] = False
        self.assertEqual(len(wizard_pages(cfg)), 7)


if __name__ == "__main__":
    unittest.main()
