# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.4: «этот час уже отправлен» — logs/hours_done.json. Пишется, когда программа сама увидела, что
сообщение ушло (поле ввода очистилось), и при ручной отправке кнопками программы. Отметка постоянная:
повтор и тревога в :05 за этот час больше не нужны, даже если сообщение потом удалили из беседы."""
import json
import logging
import os
import threading
from datetime import datetime

log = logging.getLogger("club")
KEEP = 72
PROGRAM, MANUAL, CHAT = "program", "manual", "chat"
_lock = threading.Lock()


def path(root):
    return os.path.join(root, "logs", "hours_done.json")


def key(dt):
    return dt.strftime("%Y-%m-%d %H")


def settings(cfg):
    s = (cfg or {}).get("dup_guard") or {}
    return {"skip_if_manual": bool(s.get("skip_if_manual", True)), "chat_check": bool(s.get("chat_check", True))}


def _read(p):
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _write(p, d):
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, p)
        return True
    except OSError:
        log.debug("hours_done", exc_info=True)
        return False


def sent_paths(root, dt):
    """3.0.6: снимки, которые ушли за этот час (если записаны и файлы на месте), иначе []."""
    e = _read(path(root)).get(key(dt)) or {}
    ps = [p for p in (e.get("paths") or []) if os.path.exists(p)]
    return ps if len(ps) == 2 else []


def mark(root, dt, by, note="", paths=None):
    """3.0.6: paths — снимки, которые РЕАЛЬНО ушли за этот час («эталон» для проверок беседы). Отметку,
    подтверждённую программой или беседой, позднейшая ручная отправка/пробный съём не перезаписывают."""
    p = path(root)
    with _lock:
        d = _read(p)
        k = key(dt)
        if k in d and d[k].get("by") in (PROGRAM, CHAT):
            if paths and not d[k].get("paths"):
                d[k]["paths"] = [str(x) for x in paths]
                _write(p, d)
            return
        d[k] = {"by": by, "at": datetime.now().isoformat(timespec="seconds"), "note": note[:200]}
        if paths:
            d[k]["paths"] = [str(x) for x in paths]
        for old in sorted(d)[:-KEEP]:
            d.pop(old, None)
        if not _write(p, d):
            return
    log.info("Час %s отмечен как отправленный (%s)", k + ":00", {PROGRAM: "программой", MANUAL: "вручную",
                                                                 CHAT: "найдено в беседе"}.get(by, by))


def done(root, dt, cfg=None):
    """→ кем отмечен час (program/manual/chat) или None. Ручная отметка учитывается, только если включена
    галочка «Не повторять, если в этот час уже отправлял вручную»."""
    e = _read(path(root)).get(key(dt))
    if not e:
        return None
    by = e.get("by")
    if by == MANUAL and not settings(cfg)["skip_if_manual"]:
        return None
    return by
