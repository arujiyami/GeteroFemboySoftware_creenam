# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.3: кнопка «Отправить» на НАСТОЯЩЕМ Qt WebEngine по обезличенной разметке ВК
(tests/fixtures/vk_convo_composer_2026.html, без сети). Последняя строка вывода — JSON.
Вызывается из tests/test_v223.py."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
FIX = os.path.join(HERE, "fixtures", "vk_convo_composer_2026.html")


def main():
    from PySide6.QtCore import QEventLoop, QTimer, QUrl
    from PySide6.QtWebEngineCore import QWebEnginePage
    from PySide6.QtWidgets import QApplication

    from app.config import DEFAULTS
    from app.vk_browser import build_js, decode_js_result, merged_settings

    app = QApplication(sys.argv[:1])
    page = QWebEnginePage()
    page.setViewportSize if hasattr(page, "setViewportSize") else None
    from PySide6.QtWebEngineWidgets import QWebEngineView
    view = QWebEngineView()
    view.setPage(page)
    view.resize(1280, 900)
    view.show()

    def wait(ms):
        lp = QEventLoop()
        QTimer.singleShot(ms, lp.quit)
        lp.exec()

    def load(mode, tag=""):
        lp = QEventLoop()
        page.loadFinished.connect(lp.quit)
        page.load(QUrl.fromLocalFile(FIX).toString() + "?" + tag + "#" + mode)
        QTimer.singleShot(15000, lp.quit)
        lp.exec()
        page.loadFinished.disconnect(lp.quit)
        wait(300)

    def run(code):
        box = {}
        lp = QEventLoop()
        page.runJavaScript(code, 0, lambda r: (box.setdefault("r", r), lp.quit()))
        QTimer.singleShot(10000, lp.quit)
        lp.exec()
        return box.get("r")

    def call(sel, fn, **a):
        return decode_js_result(run(build_js(fn, sel, a)))

    new = merged_settings({"vk_browser": DEFAULTS["vk_browser"]})["selectors"]
    old_cfg = {"vk_browser": {"selectors": {"send_button": ['role=button[name="Отправить"]', '[aria-label="Отправить"]',
                                                            '[aria-label="Send"]', 'role=button[name="Send"]']}}}
    old = merged_settings(old_cfg)["selectors"]
    raw_old = dict(new, send_button=old_cfg["vk_browser"]["selectors"]["send_button"])
    out = {}
    for name, sel, mode in (("new", new, "ok"), ("old_config", old, "ok"), ("dead", new, "deadbutton"),
                            ("v222_selectors", raw_old, "ok"), ("outside", new, "outside")):
        load(mode, name)
        r = {"diag": call(sel, "diag"), "probe": call(sel, "probe", keys=["send_button", "attachment_preview",
                                                                          "attachment_remove"],
                                                      box=["attachment_preview", "attachment_remove"])}
        r["click"] = call(sel, "click_send", key="send_button")
        wait(200)
        r["state"] = call(sel, "composer_state")
        if mode == "deadbutton":
            r["enter"] = call(sel, "enter", key="composer")
            wait(200)
            r["state_after_enter"] = call(sel, "composer_state")
        r["sent"] = run("window.__sent")
        r["decoy"] = run("window.__decoy")
        out[name] = r
    for mode in ("itemloading", "itemretry", "busy"):     # 3.0.6: разметка ВК 01.11 00:00
        load(mode, mode)
        out[mode] = {"att": call(new, "att_state"), "send": call(new, "send_state"),
                     "diag": call(new, "diag")}
    load("ok", "ready")
    out["ready"] = {"att": call(new, "att_state"), "send": call(new, "send_state")}
    view.close()
    print(json.dumps(out, ensure_ascii=False, default=str), flush=True)
    app.quit()


if __name__ == "__main__":
    main()
