# Original-Author: Владислав С.
# Created: 2026-10-28
"""Блокировка ввода на время съёмки — логика без Windows (обратный отсчёт — test_countdown.py)."""
import threading
import unittest
from datetime import datetime, timedelta

from app import inputlock as il
from app.inputlock import (Hotkey, HotkeyTracker, InputBlocker, format_hotkey, hotkey_text, key_should_block,
                           mouse_should_block, parse_hotkey)
from app.scheduler import minutes_text, plural_ru


class HotkeyParse(unittest.TestCase):
    def test_default(self):
        hk = parse_hotkey("Ctrl+Alt+Q")
        self.assertEqual(hk, Hotkey({"ctrl", "alt"}, 0x51))
        self.assertEqual(format_hotkey(hk), "Ctrl+Alt+Q")

    def test_qt_forms_and_aliases(self):
        self.assertEqual(parse_hotkey("alt+ctrl+q"), parse_hotkey("Ctrl+Alt+Q"))
        self.assertEqual(parse_hotkey("Meta+Shift+F9"), Hotkey({"win", "shift"}, 0x78))
        self.assertEqual(format_hotkey(parse_hotkey("shift+control+5")), "Ctrl+Shift+5")
        self.assertEqual(parse_hotkey("Ctrl+Alt+Del").vk, 0x2E)
        self.assertEqual(format_hotkey("ctrl + alt + pgdown"), "Ctrl+Alt+PgDown")

    def test_bad(self):
        for bad in ("", "Q", "Shift+Q", "Ctrl+Alt", "Ctrl+Q+W", "Ctrl+Q, Ctrl+W", "Ctrl+Ё", "Ctrl++"):
            with self.assertRaises(ValueError, msg=bad):
                parse_hotkey(bad)
        self.assertEqual(hotkey_text("ерунда"), "Ctrl+Alt+Q")
        self.assertEqual(hotkey_text("ctrl+shift+u"), "Ctrl+Shift+U")


class Filtering(unittest.TestCase):
    def test_mouse(self):
        self.assertTrue(mouse_should_block(il.WM_MOUSEMOVE, 0))
        self.assertTrue(mouse_should_block(0x0201, 0))             # левая кнопка нажата
        self.assertFalse(mouse_should_block(0x0201, il.LLMHF_INJECTED))  # наш SendInput
        self.assertFalse(mouse_should_block(0x0201, il.LLMHF_INJECTED | 0x02))
        self.assertFalse(mouse_should_block(il.WM_LBUTTONUP, 0))   # отпускание — не глотаем
        self.assertTrue(mouse_should_block(0x020A, 0))             # колесо

    def test_keys(self):
        self.assertTrue(key_should_block(il.WM_KEYDOWN, 0))
        self.assertTrue(key_should_block(il.WM_SYSKEYDOWN, 0x20))
        self.assertFalse(key_should_block(il.WM_KEYDOWN, il.LLKHF_INJECTED))
        self.assertFalse(key_should_block(il.WM_KEYUP, 0))
        self.assertFalse(key_should_block(il.WM_SYSKEYUP, il.LLKHF_UP))

    def test_tracker(self):
        t = HotkeyTracker(parse_hotkey("Ctrl+Alt+Q"))
        self.assertFalse(t.feed(il.WM_KEYDOWN, 0x51))              # просто Q
        self.assertFalse(t.feed(il.WM_KEYUP, 0x51))
        self.assertFalse(t.feed(il.WM_KEYDOWN, 0xA2))              # левый Ctrl
        self.assertFalse(t.feed(il.WM_SYSKEYDOWN, 0xA5))           # правый Alt
        self.assertTrue(t.feed(il.WM_SYSKEYDOWN, 0x51))
        t.feed(il.WM_KEYUP, 0xA2)
        self.assertFalse(t.feed(il.WM_SYSKEYDOWN, 0x51))           # Ctrl уже отпущен


class FakeHook:
    def __init__(self, on_mouse, on_key, ok=True):
        self.on_mouse, self.on_key, self.ok = on_mouse, on_key, ok
        self.started = self.stopped = 0

    def start(self):
        self.started += 1
        return self.ok

    def stop(self):
        self.stopped += 1


class FakeTimer:
    made = []

    def __init__(self, sec, fn):
        self.sec, self.fn, self.cancelled, self.started = sec, fn, False, False
        FakeTimer.made.append(self)

    def start(self):
        self.started = True

    def cancel(self):
        self.cancelled = True

    def fire(self):
        if not self.cancelled:
            self.fn()


class Blocker(unittest.TestCase):
    def make(self, ok=True, **kw):
        hooks = []

        def factory(m, k):
            hooks.append(FakeHook(m, k, ok))
            return hooks[-1]
        released = []
        b = InputBlocker(factory, kw.pop("hotkey", "Ctrl+Alt+Q"), kw.pop("watchdog_sec", 30),
                         on_release=released.append, timer_factory=FakeTimer, **kw)
        return b, hooks, released

    def test_swallow_user_pass_injected(self):
        b, hooks, released = self.make()
        self.assertTrue(b.start())
        self.assertTrue(b.on_mouse(il.WM_MOUSEMOVE, 0))
        self.assertFalse(b.on_mouse(il.WM_MOUSEMOVE, il.LLMHF_INJECTED))
        self.assertTrue(b.on_key(il.WM_KEYDOWN, 0x41, 0))
        self.assertFalse(b.on_key(il.WM_KEYDOWN, 0x41, il.LLKHF_INJECTED))
        b.release()
        self.assertFalse(b.on_mouse(il.WM_MOUSEMOVE, 0))
        self.assertEqual(hooks[0].stopped, 1)
        self.assertEqual(released, ["done"])

    def test_hotkey_releases_immediately(self):
        b, hooks, released = self.make()
        b.start()
        self.assertTrue(b.on_key(il.WM_KEYDOWN, 0xA2, 0))
        self.assertTrue(b.on_key(il.WM_SYSKEYDOWN, 0xA4, 0))
        self.assertTrue(b.on_key(il.WM_SYSKEYDOWN, 0x51, 0))    # само сочетание тоже не уходит в окна
        self.assertFalse(b.active)
        self.assertEqual(b.reason, "hotkey")
        self.assertEqual(released, ["hotkey"])
        self.assertTrue(FakeTimer.made[-1].cancelled)
        self.assertFalse(b.on_mouse(0x0201, 0))
        b.release()                                              # повторно — ничего
        self.assertEqual(released, ["hotkey"])
        self.assertEqual(hooks[0].stopped, 1)

    def test_injected_hotkey_ignored(self):
        b, _, released = self.make()
        b.start()
        for vk in (0x11, 0x12, 0x51):
            b.on_key(il.WM_KEYDOWN, vk, il.LLKHF_INJECTED)
        self.assertTrue(b.active)

    def test_watchdog(self):
        b, hooks, released = self.make(watchdog_sec=7)
        b.start()
        t = FakeTimer.made[-1]
        self.assertEqual(t.sec, 7)
        self.assertTrue(t.started)
        t.fire()
        self.assertFalse(b.active)
        self.assertEqual(released, ["watchdog"])
        self.assertEqual(hooks[0].stopped, 1)

    def test_watchdog_clamped(self):
        self.assertEqual(self.make(watchdog_sec=1)[0].watchdog_sec, 5)
        self.assertEqual(self.make(watchdog_sec=999)[0].watchdog_sec, 30)       # 2.1.5: не больше 30 с
        self.assertEqual(self.make(watchdog_sec="x")[0].watchdog_sec, 30)

    def test_real_timer_watchdog(self):
        hooks = []
        done = threading.Event()
        b = InputBlocker(lambda m, k: hooks.append(FakeHook(m, k)) or hooks[-1], "Ctrl+Alt+Q", 5,
                         on_release=lambda r: done.set(), timer_factory=lambda s, fn: threading.Timer(0.05, fn))
        b.start()
        self.assertTrue(done.wait(2))
        self.assertEqual(b.reason, "watchdog")

    def test_context_manager_releases_on_error(self):
        b, hooks, released = self.make()
        with self.assertRaises(RuntimeError):
            with b:
                self.assertTrue(b.active)
                raise RuntimeError("съёмка упала")
        self.assertFalse(b.active)
        self.assertEqual(released, ["error"])

    def test_hook_fail_means_no_block(self):
        b, hooks, released = self.make(ok=False)
        self.assertFalse(b.start())
        self.assertFalse(b.active)
        self.assertEqual(hooks[0].stopped, 1)
        self.assertFalse(b.on_mouse(il.WM_MOUSEMOVE, 0))

    def test_release_all(self):
        b1, _, r1 = self.make()
        b2, _, r2 = self.make()
        b1.start()
        b2.start()
        il.release_all("exit")
        self.assertEqual((r1, r2), (["exit"], ["exit"]))
        self.assertFalse(il._ACTIVE)


class Plural(unittest.TestCase):
    def test_plural(self):
        got = {n: minutes_text(n) for n in (1, 2, 4, 5, 11, 12, 14, 15, 21, 22, 25, 101, 111)}
        self.assertEqual(got, {1: "1 минуту", 2: "2 минуты", 4: "4 минуты", 5: "5 минут", 11: "11 минут",
                               12: "12 минут", 14: "14 минут", 15: "15 минут", 21: "21 минуту", 22: "22 минуты",
                               25: "25 минут", 101: "101 минуту", 111: "111 минут"})
        self.assertEqual(plural_ru(3, "a", "b", "c"), "b")


class ConfigChecks(unittest.TestCase):
    def test_defaults_and_validation(self):
        import copy
        from app.config import DEFAULTS, validate
        self.assertEqual(DEFAULTS["countdown"], {"seconds": 60, "opacity": 75, "buttons": True})
        self.assertNotIn("notifications", DEFAULTS)
        self.assertEqual(DEFAULTS["input_lock"], {"enabled": True, "hotkey": "Ctrl+Alt+Q", "early_sec": 5,
                                                  "watchdog_sec": 30})
        self.assertEqual(DEFAULTS["oasys_check"], {"enabled": True, "timeout_sec": 10})
        self.assertEqual(validate(DEFAULTS), [])
        for sec, key, bad in (("input_lock", "hotkey", "Q"), ("input_lock", "watchdog_sec", 4),
                              ("input_lock", "watchdog_sec", 31), ("countdown", "seconds", -1),
                              ("countdown", "seconds", 61), ("countdown", "seconds", "60"),
                              ("countdown", "opacity", 29), ("countdown", "opacity", 101),
                              ("input_lock", "early_sec", 16), ("input_lock", "early_sec", -1),
                              ("oasys_check", "timeout_sec", 2), ("oasys_check", "timeout_sec", 31)):
            cfg = copy.deepcopy(DEFAULTS)
            cfg[sec][key] = bad
            self.assertTrue([e for e in validate(cfg) if e.startswith(sec)], (sec, key, bad))


class WatchdogCap(unittest.TestCase):
    """2.1.5: одна блокировка — никогда не дольше 30 секунд, и всегда снимается."""

    def test_effective_watchdog(self):
        from app.inputlock import HARD_CAP_SEC, effective_watchdog
        self.assertEqual(HARD_CAP_SEC, 30)
        self.assertEqual(effective_watchdog(30, 5, 10), 30)
        self.assertEqual(effective_watchdog(120, 15, 30, 12), 30)
        self.assertEqual(effective_watchdog(5, 5, 0, 12), 17)          # хватает на ранний старт и съёмку
        self.assertEqual(effective_watchdog(5, 0, 0, 0), 5)
        self.assertEqual(effective_watchdog("x", "y"), 30)
        self.assertLessEqual(max(effective_watchdog(w, e, r, m) for w in (5, 30, 999) for e in (0, 15, 99)
                                 for r in (3, 30, 99) for m in (0, 12, 99)), 30)

    def test_job_lock_watchdog_from_config(self):
        import copy
        from app.config import DEFAULTS
        from app.job import lock_watchdog_sec
        cfg = copy.deepcopy(DEFAULTS)
        self.assertEqual(lock_watchdog_sec(cfg), 30)
        cfg["input_lock"]["watchdog_sec"] = 120          # руками в config.yaml
        self.assertEqual(lock_watchdog_sec(cfg), 30)

    def test_watchdog_releases_with_fake_timer(self):
        released = []
        timers = []

        class FakeTimer:
            def __init__(self, sec, fn):
                self.sec, self.fn = sec, fn
                timers.append(self)
                self.daemon = True

            def start(self):
                pass

            def cancel(self):
                pass
        b = InputBlocker(lambda m, k: FakeHook(m, k), "Ctrl+Alt+Q", 999,
                         on_release=released.append, timer_factory=FakeTimer)
        self.assertTrue(b.start())
        self.assertEqual(timers[0].sec, 30)
        timers[0].fn()                                   # прошло 30 с — сторож срабатывает
        self.assertEqual(released, ["watchdog"])
        self.assertFalse(b.active)


if __name__ == "__main__":
    unittest.main()
