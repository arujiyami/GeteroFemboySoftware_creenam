# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.14: в сообщения ВК не добавляются «(повторная отправка вручную)» и «⚠ …» предупреждений."""
import os
import unittest

from app import __version__

SRC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app", "job.py")


class NoCaptionNotes(unittest.TestCase):
    def test_version(self):
        self.assertEqual(__version__, "3.0.14")

    def test_no_resend_note_and_no_warning_notes_in_caption(self):
        src = open(SRC, encoding="utf-8").read()
        self.assertNotIn('"(повторная отправка вручную)"', src)
        self.assertNotIn("caption = caption_with_notes(", src)



class AlertButtons(unittest.TestCase):
    """3.0.14: кнопки красного окна «Скрины не ушли»."""

    @classmethod
    def setUpClass(cls):
        try:
            from PySide6.QtWidgets import QApplication
        except Exception:  # noqa: BLE001
            raise unittest.SkipTest("нет Qt")
        cls.app = QApplication.instance() or QApplication([])

    def make(self, resend, now):
        from app.ui.sentalert import SentAlert
        a = SentAlert(on_resend=resend, on_send_now=now, on_close=lambda u: None)
        a.show_alert("Скрины за 17:00 не на месте", "Проверить не удалось", "failed", can_resend=True)
        return a

    def click(self, b):
        from PySide6.QtCore import Qt
        from PySide6.QtTest import QTest
        QTest.mouseClick(b, Qt.MouseButton.LeftButton)
        self.app.processEvents()

    def test_click_starts_and_shows_progress(self):
        calls = []
        a = self.make(lambda: calls.append("r") or True, lambda: calls.append("n") or True)
        self.click(a.b_resend)
        self.assertEqual(calls, ["r"])
        self.assertEqual(a.b_resend.text(), "Отправляю…")
        self.assertFalse(a.b_now.isEnabled())
        a.dismiss(by_user=False)

    def test_not_started_reenables_buttons(self):
        calls = []
        a = self.make(lambda: calls.append("r") or False, lambda: calls.append("n") or False)
        self.click(a.b_now)
        self.assertEqual(calls, ["n"])
        self.assertTrue(a.b_now.isEnabled() and a.b_resend.isEnabled())
        self.assertIn("другая съёмка или отправка", a.detail.text())
        self.click(a.b_resend)
        self.assertEqual(calls, ["n", "r"])
        a.dismiss(by_user=False)

    def test_reshow_after_success_buttons_enabled(self):
        a = self.make(lambda: True, lambda: True)
        self.click(a.b_now)
        self.assertFalse(a.b_now.isEnabled())
        a.dismiss(by_user=False)            # отправка прошла — окно закрыла программа
        a.show_alert("Скрины за 18:00 не на месте", "x", "failed", can_resend=True)
        self.assertTrue(a.b_now.isEnabled() and a.b_resend.isEnabled())
        self.assertEqual(a.b_now.text(), "Снять и отправить сейчас")
        a.dismiss(by_user=False)

    def test_exception_in_handler_reenables(self):
        def boom():
            raise RuntimeError("x")
        a = self.make(boom, boom)
        with self.assertLogs("club", "ERROR"):
            self.click(a.b_resend)
        self.assertTrue(a.b_resend.isEnabled())
        a.dismiss(by_user=False)

    def test_verified_send_marks_hour_found(self):
        from datetime import datetime
        from app.ui.services import ServicesMixin

        class W(ServicesMixin):
            cfg = {"schedule": {"minute": 0}}
        w = W()
        w._mark_presence_sent({"time": datetime(2026, 11, 2, 17, 10, 18), "sent": True})
        self.assertEqual(w._presence_found, datetime(2026, 11, 2, 17, 0))

    def test_handlers_return_started(self):
        src = open(os.path.join(os.path.dirname(SRC), "ui", "main_window.py"), encoding="utf-8").read()
        self.assertIn("self._mark_presence_sent(r)", src)
        body = src.split("def resend_latest(self):")[1].split("def _resend_feedback")[0]
        self.assertIn("return True", body)
        self.assertIn("return False", body)


if __name__ == "__main__":
    unittest.main()
