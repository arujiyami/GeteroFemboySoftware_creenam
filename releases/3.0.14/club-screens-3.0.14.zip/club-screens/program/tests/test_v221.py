# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.1: ожидание загрузки картинок (до 90 с), настоящая вторая попытка после «картинки остались в поле ввода»,
обновление заранее открытой беседы, «Отправить последние скрины»."""
import copy
import os
import shutil
import tempfile
import unittest
from datetime import datetime

from app.config import DEFAULTS
from app.vk_browser import SendFailed, StillInComposer, merged_settings, warm_fresh
from tests.test_vk_browser import FakeDriver, FakeVK, flows, settings, two_pngs


class SlowUploadVK(FakeVK):
    """Как в журнале 2.1.7: превью уже есть, а индикаторы загрузки — вне области ввода (4/0),
    кнопки «Отправить» нет, Enter ничего не отправляет, пока ВК грузит картинки."""

    def __init__(self, upload_probes=25, **kw):
        super().__init__(**kw)
        self.left = None
        self.upload_probes = upload_probes
        self.clicked_while_uploading = False

    def uploading(self):
        return self.left is not None and self.left > 0

    def call(self, fn, a):
        if fn == "set_files":
            r = super().call(fn, a)
            self.left = self.upload_probes
            return r
        if fn == "probe":
            c = self.counts(a["keys"], a.get("box") or ())
            up = self.uploading()
            if "upload_progress" in a["keys"]:
                c["upload_progress"] = 0                    # в области ввода индикаторов не видно
            if "send_button" in a["keys"]:
                c["send_button"] = 0 if up else 1
            res = {"url": self.url, "c": c, "all": {"upload_progress": 4 if up else 0}}
            if up and "send_button" in a["keys"]:
                self.left -= 1
            return res
        if fn in ("click_send", "enter"):
            if self.uploading():
                self.clicked_while_uploading = True
                return "none" if fn == "click_send" else True
        return super().call(fn, a)


class UploadWaitTest(unittest.TestCase):
    def run_send(self, page, s=None):
        self.driver = FakeDriver(page)
        return self.driver.run(flows(s).send(2000000001, two_pngs(), "", ""))

    def test_waits_for_upload_then_sends(self):
        page = SlowUploadVK(upload_probes=25)          # ~25 с загрузки — ждём (3.0.5: после 30 с — прикрепить заново)
        self.assertEqual(self.run_send(page), "verified")
        self.assertFalse(page.clicked_while_uploading)
        self.assertEqual(page.outgoing, 1)
        self.assertEqual(page.history, 2)

    def test_stalled_upload_fails_before_click_and_can_retry(self):
        page = SlowUploadVK(upload_probes=10 ** 6)
        with self.assertRaises(SendFailed) as cm:
            self.run_send(page)
        self.assertTrue(cm.exception.retry)
        self.assertNotIn("click_send", page.calls)
        self.assertIn("повторных прикреплений", str(cm.exception))   # 3.0.5: 30 с + 3 раза заново
        self.assertLess(self.driver.t, 170)

    def test_still_in_composer_is_retryable(self):
        page = FakeVK(send_button=False)
        page.call_orig = page.call

        def call(fn, a):
            if fn == "enter":
                return True                                 # Enter ничего не отправил
            return page.call_orig(fn, a)
        page.call = call
        with self.assertRaises(StillInComposer) as cm:
            self.run_send(page)
        self.assertTrue(cm.exception.retry)                 # точно не ушло → второй попытке можно быть

    def test_legacy_upload_timeout_raised_to_90(self):
        self.assertEqual(merged_settings({"vk_browser": {"upload_timeout_sec": 45}})["upload_timeout_sec"], 90)
        self.assertEqual(settings()["upload_timeout_sec"], 90)
        self.assertEqual(settings({"upload_timeout_sec": 3})["upload_timeout_sec"], 3)


class WarmTest(unittest.TestCase):
    def test_fresh_and_stale(self):
        class B:
            warm, warm_at = True, 1000.0
        s = settings()
        self.assertTrue(warm_fresh(B, s, now=1030.0))
        self.assertFalse(warm_fresh(B, s, now=1000.0 + 5 * 60))    # открыта за 5 минут — перезагрузить
        B.warm = False
        self.assertFalse(warm_fresh(B, s, now=1001.0))


class JobTest(unittest.TestCase):
    def make(self, vk):
        from app.job import JobRunner
        from tests.test_steps_job import FakeBackend
        root = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, root, True)
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["caption"] = "{time}"
        cfg["vk"]["peer_id"] = 2000000001
        cfg["schedule"]["attempts"] = 2
        job = JobRunner(lambda: cfg, lambda: FakeBackend(), vk_factory=lambda c: vk, root=root,
                        now=lambda: datetime(2026, 10, 29, 14, 0), sleep=lambda s: None)
        job.online = lambda: True
        return job, root, cfg

    def test_second_attempt_really_happens(self):
        class VK:
            def __init__(self):
                self.calls = 0

            def send_photos(self, peer, paths, msg):
                self.calls += 1
                if self.calls == 1:
                    raise StillInComposer("Сообщение не отправилось: картинки остались в поле ввода.")
                return "verified"
        vk = VK()
        job, _, _ = self.make(vk)
        with self.assertLogs("club", "INFO") as lg:
            self.assertTrue(job.run_cycle())
        self.assertEqual(vk.calls, 2)
        self.assertTrue(any("Попытка 2 из 2" in m for m in lg.output))
        self.assertTrue(any("Цикл завершён: успешно" in m for m in lg.output))

    def test_resend_latest_without_capture(self):
        from tests.test_steps_job import FakeVK as JVK
        vk = JVK()
        job, root, cfg = self.make(vk)
        shots = os.path.join(root, "screenshots")
        cfg["storage"]["screenshots_dir"] = shots
        self.assertFalse(job.resend_latest())               # снимков нет — ничего не отправляется
        self.assertEqual(vk.sent, [])
        os.makedirs(shots)
        for st in ("2026-10-29_13-00", "2026-10-29_14-00"):
            for n in ("01_Oasys.png", "02_iVMS-4200.png"):
                open(os.path.join(shots, f"{st}_{n}"), "wb").close()
                os.utime(os.path.join(shots, f"{st}_{n}"), (1 if st.endswith("13-00") else 2,) * 2)
        self.assertEqual(len(job.latest_paths()), 2)
        with self.assertLogs("club", "INFO") as lg:
            self.assertTrue(job.resend_latest())
        peer, files, msg = vk.sent[0]
        self.assertEqual(files, ["2026-10-29_14-00_01_Oasys.png", "2026-10-29_14-00_02_iVMS-4200.png"])
        self.assertIn("14:00", msg)
        self.assertNotIn("повторная отправка", msg)   # 3.0.14: без приписки
        self.assertTrue(any("Ручная отправка последних скринов" in m for m in lg.output))
        self.assertTrue(job.last_result["sent"] and job.last_result["resend"])
        self.assertFalse(job.lock.locked())

    def test_resend_failure_reported(self):
        from tests.test_steps_job import FakeVK as JVK
        vk = JVK(fail=1)
        job, root, cfg = self.make(vk)
        shots = os.path.join(root, "s")
        cfg["storage"]["screenshots_dir"] = shots
        os.makedirs(shots)
        open(os.path.join(shots, "2026-10-29_14-00_01_Oasys.png"), "wb").close()
        self.assertFalse(job.resend_latest())
        self.assertTrue(job.last_result["send_error"])
        self.assertFalse(job.lock.locked())


class UiSourceTest(unittest.TestCase):
    def test_button_and_tray(self):
        with open(os.path.join(os.path.dirname(__file__), "..", "app", "ui", "main_window.py"),
                  encoding="utf-8") as f:
            src = f.read()
        self.assertEqual(src.count('"Отправить последние скрины"'), 2)
        self.assertIn("self.resend_btn.setEnabled(can_resend)", src)
        self.assertIn("self.tray_resend.setEnabled(can_resend)", src)


if __name__ == "__main__":
    unittest.main()
