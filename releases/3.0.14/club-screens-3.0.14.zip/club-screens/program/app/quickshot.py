# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.13: съём раньше времени — кнопки «Снять сейчас» / «Снять позже» в окошке предупреждения и
сочетание клавиш для ручного съёма (по умолчанию Shift+Alt+2).

Окно ручного съёма — с ЧЧ:50:00 до ЧЧ:10:00 вокруг минуты съёма (при минуте 0 — вокруг начала часа):
  * с :50:00 до :59:59 снимок идёт за СЛЕДУЮЩИЙ час (11:55 — это съём за 12:00);
  * с :00:00 до :10:00 — за текущий час, но только если он ещё не отправлен;
  * вне окна сочетание ничего не делает (в окне программы — короткая подсказка).

Надёжность: час НЕ отмечается отправленным в начале съёма. На время съёма он «занят» (замок в памяти
программы): плановый запуск в :00 ждёт окончания ручного и не дублирует его. Отправленным час становится
только после подтверждения доставки ВКонтакте и сохранённого номера (id) сообщения. Ручная отправка не
удалась или программу закрыли посреди неё — час остаётся неотправленным, и плановый запуск в :00 делает
свою обычную попытку (не больше 2 попыток в час, удалённое сообщение повторно не отправляется)."""
from datetime import timedelta

from .inputlock import format_hotkey, parse_hotkey

WINDOW_SEC = 10 * 60          # ±10 минут вокруг минуты съёма
POSTPONE_SEC = 60             # «Снять позже» — на 1 минуту
DEFAULT_HOTKEY = "Shift+Alt+2"   # 2 — цифра в верхнем ряду (VK 0x32), не на цифровом блоке
RUN, OUTSIDE, DONE, BUSY = "run", "outside", "done", "busy"


def slot_for(when, minute=0):
    """Плановый съём (ЧЧ:minute), к которому относится ручной съём в момент when, или None — вне окна.
    Границы включительно: :50:00 и :10:00 — ещё в окне, :49:59 и :10:01 — уже нет."""
    m = int(minute or 0) % 60
    probe = when + timedelta(seconds=WINDOW_SEC)
    slot = probe.replace(minute=m, second=0, microsecond=0)
    if slot > probe:
        slot -= timedelta(hours=1)
    delta = (when - slot).total_seconds()
    if -WINDOW_SEC <= delta <= WINDOW_SEC:
        return slot
    return None


def in_window(when, minute=0):
    return slot_for(when, minute) is not None


def decide(when, minute=0, done_by=None, busy=False):
    """Что сделать по нажатию сочетания: (RUN | OUTSIDE | DONE | BUSY, слот).
    done_by — кем уже закрыт час слота (hourdone.done), busy — идёт другой съём."""
    slot = slot_for(when, minute)
    if slot is None:
        return OUTSIDE, None
    if done_by:
        return DONE, slot
    if busy:
        return BUSY, slot
    return RUN, slot


# С зажатым Shift поле ввода сочетания может прислать не «2», а символ над ней («@» в английской раскладке,
# «"» в русской). Клавиша та же — цифра верхнего ряда.
SHIFTED_DIGITS = {c: d for chars, d in (("!", "1"), ("@\"", "2"), ("#№", "3"), ("$;", "4"), ("%", "5"),
                                        ("^:", "6"), ("&?", "7"), ("*", "8"), ("(", "9"), (")", "0"))
                  for c in chars}
MOD_ORDER = ("shift", "ctrl", "alt", "win")
MOD_TITLES = {"shift": "Shift", "ctrl": "Ctrl", "alt": "Alt", "win": "Win"}


def parse(text):
    """«Shift+Alt+2» / «Alt+Shift+@» → Hotkey (цифра верхнего ряда). ValueError — понятный текст."""
    text = str(text or "").strip()
    if text and "+" in text.rstrip("+"):
        head, _, key = text.rpartition("+")
        if key in SHIFTED_DIGITS:
            text = head + "+" + SHIFTED_DIGITS[key]
    return parse_hotkey(text)


def fmt(hk):
    """Hotkey → «Shift+Alt+2» (Shift первым — как пишут это сочетание)."""
    key = format_hotkey(hk).rsplit("+", 1)[-1]
    return "+".join([MOD_TITLES[m] for m in MOD_ORDER if m in hk.mods] + [key])


def settings(cfg):
    """(включено, сочетание «Shift+Alt+2»). Ошибка в сочетании — по умолчанию."""
    ms = (cfg or {}).get("manual_shot") or {}
    try:
        hk = fmt(parse(ms.get("hotkey") or DEFAULT_HOTKEY))
    except ValueError:
        hk = DEFAULT_HOTKEY
    return bool(ms.get("enabled", True)), hk


def buttons_enabled(cfg):
    """Кнопки «Снять сейчас» / «Снять позже» в окошке предупреждения (по умолчанию включены)."""
    return bool(((cfg or {}).get("countdown") or {}).get("buttons", True))


def outside_text(minute=0):
    m = int(minute or 0) % 60
    a, b = (m - 10) % 60, (m + 10) % 60
    return (f"Ручной съём работает только с ЧЧ:{a:02d} до ЧЧ:{b:02d} — рядом с плановым съёмом. "
            "Сейчас сочетание ничего не делает")


class PostponeGuard:
    """«Снять позже» — не чаще раза в час: одна отсрочка на плановый съём и не раньше чем через час
    после прошлой."""

    def __init__(self):
        self.last = None        # когда откладывали
        self.slots = set()

    def allowed(self, now, slot):
        if slot in self.slots:
            return False
        return self.last is None or (now - self.last).total_seconds() >= 3600 - WINDOW_SEC * 2

    def use(self, now, slot):
        if not self.allowed(now, slot):
            return False
        self.last = now
        self.slots = {s for s in self.slots if (now - s).total_seconds() < 6 * 3600} | {slot}
        return True
