# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.13: системное сочетание клавиш (работает, даже когда окно программы свёрнуто) — для ручного съёма.
Windows: RegisterHotKey в своём потоке с очередью сообщений. Вне Windows — ничего не делает.
Если сочетание уже занято другой программой — в журнал понятная запись, программа работает как обычно."""
import logging
import sys
import threading

from .inputlock import parse_hotkey

log = logging.getLogger("club")
MOD_ALT, MOD_CONTROL, MOD_SHIFT, MOD_WIN, MOD_NOREPEAT = 0x1, 0x2, 0x4, 0x8, 0x4000
MOD_BITS = {"alt": MOD_ALT, "ctrl": MOD_CONTROL, "shift": MOD_SHIFT, "win": MOD_WIN}
WM_HOTKEY, WM_QUIT = 0x0312, 0x0012
HOTKEY_ID = 0x3013


def win_mods(hk):
    """Hotkey → флаги RegisterHotKey (с MOD_NOREPEAT: зажатая клавиша не повторяет нажатие)."""
    bits = MOD_NOREPEAT
    for m in hk.mods:
        bits |= MOD_BITS[m]
    return bits


class GlobalHotkey:
    def __init__(self, text, callback):
        self.hotkey = parse_hotkey(text)
        self.text = text
        self.callback = callback
        self._thread = None
        self._tid = None
        self.registered = False
        self._ready = threading.Event()

    def start(self):
        if sys.platform != "win32" or self._thread is not None:
            return False
        self._thread = threading.Thread(target=self._loop, name="hotkey", daemon=True)
        self._thread.start()
        self._ready.wait(2)
        return self.registered

    def _loop(self):
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL("user32")
        kernel32 = ctypes.WinDLL("kernel32")
        self._tid = kernel32.GetCurrentThreadId()
        try:
            self.registered = bool(user32.RegisterHotKey(None, HOTKEY_ID, win_mods(self.hotkey), self.hotkey.vk))
        except Exception:  # noqa: BLE001
            self.registered = False
        if self.registered:
            log.info("Ручной съём: сочетание %s включено", self.text)
        else:
            log.warning("Сочетание %s для ручного съёма занято другой программой — выберите другое в настройках",
                        self.text)
        self._ready.set()
        if not self.registered:
            return
        msg = wintypes.MSG()
        try:
            while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_HOTKEY and msg.wParam == HOTKEY_ID:
                    try:
                        self.callback()
                    except Exception:  # noqa: BLE001
                        log.exception("Ручной съём по сочетанию клавиш")
        finally:
            user32.UnregisterHotKey(None, HOTKEY_ID)

    def stop(self):
        if self._thread is None:
            return
        if self._tid and sys.platform == "win32":
            try:
                import ctypes
                ctypes.WinDLL("user32").PostThreadMessageW(self._tid, WM_QUIT, 0, 0)
            except Exception:  # noqa: BLE001
                pass
        self._thread.join(timeout=2)
        self._thread = None
        self.registered = False
