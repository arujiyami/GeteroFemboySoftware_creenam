# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.2: собственное заметное окно-тревога «Скрины не ушли» (НЕ уведомление Windows).
Большая ярко-красная плашка сверху по центру экрана, поверх всех окон, крупный жирный текст с причиной,
мягко пульсирующая рамка. Висит, пока админ не закроет её или пока отправка не пройдёт успешно.
Фокус не отбирает (показ без активации), на снимки экрана не попадает (WDA_EXCLUDEFROMCAPTURE;
на старой Windows — прячется на время съёма)."""
import logging
import sys

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import QApplication, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from .common import exclude_from_capture

log = logging.getLogger("club")

RED = "#d50000"
PULSE_MS = 600


def beep():
    """Короткий негромкий звук (по желанию). Любая ошибка — молча."""
    try:
        if sys.platform == "win32":
            import winsound
            winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        else:
            QApplication.beep()
    except Exception:  # noqa: BLE001
        pass


class SentAlert(QWidget):
    def __init__(self, on_resend=None, on_send_now=None, on_close=None):
        super().__init__(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint |
                         Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setObjectName("sentAlert")
        self.setWindowTitle("Скрины не ушли")
        self.on_resend, self.on_send_now, self.on_close = on_resend, on_send_now, on_close
        self.reason = None
        self._phase = False
        self.setStyleSheet(
            f"#sentAlert {{ background: {RED}; }}"
            "QLabel { color: white; background: transparent; }"
            "QLabel#title { font-size: 26pt; font-weight: 800; }"
            "QLabel#detail { font-size: 13pt; font-weight: 600; }"
            "QPushButton { font-size: 13pt; font-weight: 700; padding: 10px 18px; border-radius: 8px;"
            " background: white; color: #b00000; border: none; }"
            "QPushButton#close { background: #7f0000; color: white; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 22)
        lay.setSpacing(10)
        self.title = QLabel("⚠  Скрины не ушли")
        self.title.setObjectName("title")
        self.title.setWordWrap(True)
        self.detail = QLabel("")
        self.detail.setObjectName("detail")
        self.detail.setWordWrap(True)
        lay.addWidget(self.title)
        lay.addWidget(self.detail)
        row = QHBoxLayout()
        row.setSpacing(12)
        self.b_resend = QPushButton("Отправить последние скрины")
        self.b_now = QPushButton("Снять и отправить сейчас")
        self.b_close = QPushButton("Закрыть")
        self.b_close.setObjectName("close")
        for b in (self.b_resend, self.b_now, self.b_close):
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            f = QFont(b.font())
            f.setPointSize(13)
            f.setBold(True)
            b.setFont(f)
            b.setMinimumWidth(QFontMetrics(f).horizontalAdvance(b.text()) + 48)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self.b_resend.clicked.connect(lambda: self._act(self.on_resend, self.b_resend))
        self.b_now.clicked.connect(lambda: self._act(self.on_send_now, self.b_now))
        self.b_close.clicked.connect(self.dismiss)
        self.pulse = QTimer(self)
        self.pulse.timeout.connect(self._tick)

    # ----- показ
    def show_alert(self, text, detail, reason=None, can_resend=True, sound=False):
        self.reason = reason
        self.title.setText("⚠  " + text)
        self.detail.setText(detail + "\nОкно закроется само, когда отправка пройдёт успешно или скрины найдутся в беседе.")
        self.can_resend = bool(can_resend)
        self.set_busy(False)        # 3.0.14: после прошлой отправки кнопки не остаются серыми
        self._place()
        self.show()
        self.raise_()
        if not exclude_from_capture(self, True):
            log.debug("тревога: исключение из снимков недоступно — прячется на время съёма")
        self.pulse.start(PULSE_MS)
        log.warning("Тревога на экране: %s — %s", text, detail)
        if sound:
            beep()

    def _place(self):
        scr = QApplication.primaryScreen()
        g = scr.availableGeometry() if scr else None
        w = min(980, int(g.width() * 0.9)) if g else 900
        w = max(w, self.layout().minimumSize().width())    # кнопки целиком
        self.setFixedWidth(w)
        self.adjustSize()
        if g:
            self.move(g.x() + (g.width() - w) // 2, g.y() + 24)

    def set_busy(self, busy):
        self.b_resend.setEnabled(not busy and getattr(self, "can_resend", True))
        self.b_now.setEnabled(not busy)
        if not busy:
            self.b_resend.setText("Отправить последние скрины")
            self.b_now.setText("Снять и отправить сейчас")

    def _act(self, fn, btn=None):
        """3.0.14: видно, что нажатие сработало («Отправляю…»); не запустилось (идёт другая отправка) —
        кнопки сразу снова доступны, а причина — в строке окна."""
        if not fn:
            return
        self.set_busy(True)
        if btn is not None:
            btn.setText("Отправляю…")
        try:
            started = fn()
        except Exception:  # noqa: BLE001
            log.exception("Тревога: кнопка «%s» — ошибка", btn.text() if btn else "?")
            started = False
        if started is False:
            self.set_busy(False)
            self.note("Сейчас идёт другая съёмка или отправка — нажмите через минуту.")

    def note(self, text):
        base = self.detail.text().split("\n⏳ ")[0]
        self.detail.setText(base + "\n⏳ " + text)
        self.adjustSize()

    def dismiss(self, by_user=True):
        if not self.isVisible():
            return
        self.pulse.stop()
        self.hide()
        if by_user:
            log.info("Тревога «скрины не ушли» закрыта администратором")
        if self.on_close:
            self.on_close(by_user)

    # ----- пульсирующая рамка
    def _tick(self):
        self._phase = not self._phase
        self.update()

    def paintEvent(self, e):  # noqa: N802
        super().paintEvent(e)
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(RED))
        pen = QPen(QColor("#ffeb3b" if self._phase else "#ffffff"))
        pen.setWidth(8)
        p.setPen(pen)
        p.drawRect(self.rect().adjusted(4, 4, -4, -4))
        p.end()
