# Original-Author: Владислав С.
# Created: 2026-10-28
"""Раздел «Настройки».

2.1.6: всё действует и сохраняется само (через полсекунды после последней правки) — кнопки «Сохранить» нет.
2.1.7: новый вид в духе «Параметров» Windows 11: каждая настройка — строка в белой карточке: слева название
и одна короткая строка пояснения, справа — переключатель, ползунок или поле. Подробности — в значке «?».
Содержимое по центру (не шире 760 точек), тонкая полоса прокрутки, на узком окне элемент уходит под название."""
import copy
import logging
import os
import sys
import time

import yaml
from PySide6.QtCore import QEvent, QObject, QRegularExpression, QSize, Qt, QTime, QTimer
from PySide6.QtGui import QFont, QFontMetrics, QKeySequence, QRegularExpressionValidator
from PySide6.QtWidgets import (QBoxLayout, QButtonGroup, QComboBox, QDialog, QFileDialog, QFormLayout, QGridLayout,
                               QFrame, QHBoxLayout, QInputDialog, QKeySequenceEdit, QLabel, QLineEdit,
                               QListWidget, QMessageBox, QPlainTextEdit, QPushButton, QRadioButton, QScrollArea,
                               QSizePolicy, QSlider, QSpinBox, QTabWidget, QTimeEdit, QToolButton,
                               QVBoxLayout, QWidget)

from .. import startup
from ..cleanup import DEFAULT_KEEP_HOURS, DEFAULT_TIME as CLEANUP_TIME, parse_time as parse_cleanup_time
from ..config import DEFAULTS, resolve_path, validate
from ..friendly import humanize
from .. import quickshot
from ..inputlock import (DEFAULT_HOTKEY, WATCHDOG_MAX_SEC, WATCHDOG_MIN_SEC, clamp_watchdog, format_hotkey,
                         parse_hotkey)
from ..mediapause import media_settings
from ..readiness import READY_MAX_SEC, READY_MIN_SEC, ready_settings
from ..scheduler import (COUNTDOWN_MAX_OPACITY, COUNTDOWN_MAX_SEC, COUNTDOWN_MIN_OPACITY, COUNTDOWN_MIN_SEC,
                         EARLY_MAX_SEC, EARLY_MIN_SEC, countdown_settings, early_settings, plural_ru)
from ..job import make_group_client
from ..steps import StepRunner
from . import theme
from .common import ToggleSwitch, help_icon, label, set_image

log = logging.getLogger("club")
LIVE_SAVE_MS = 400      # записать config.yaml через столько мс после последней правки
CONTENT_MAX_W = 760     # ширина колонки настроек (по центру окна)
STACK_TITLE_W = 230     # уже этого названию не сжиматься — тогда элемент уходит под название

# 2.1.8: стиль настроек — в theme.py (SETTINGS_QSS), общий для всего приложения и всех тем.


def secs(n):
    return f"{n} {plural_ru(n, 'секунду', 'секунды', 'секунд')}"


def secs_nom(n):
    return f"{n} {plural_ru(n, 'секунда', 'секунды', 'секунд')}"


def mins(n):
    return f"{n} {plural_ru(n, 'минуту', 'минуты', 'минут')}"


def hours_nom(n):
    return f"{n} {plural_ru(n, 'час', 'часа', 'часов')}"


def shots_nom(n):
    return f"{n} {plural_ru(n, 'снимок', 'снимка', 'снимков')}"


def show_images(parent, title, images):
    d = QDialog(parent)
    d.setWindowTitle(f"Результат: {title}")
    lay = QVBoxLayout(d)
    for img in images:
        lbl = QLabel()
        set_image(lbl, img, (900, 520))
        lay.addWidget(lbl)
        lay.addWidget(label(f"Размер: {img.width}×{img.height}", "muted"))
    d.exec()


def _scroll(widget):
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QScrollArea.Shape.NoFrame)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    sa.setWidget(widget)
    return sa


def _hint(text):
    h = label(text, "hint")
    h.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
    h.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
    return h


def _centered(widget, max_w=CONTENT_MAX_W, margins=(24, 0, 24, 0)):
    """Колонка по центру: не шире max_w, по бокам — поля."""
    wrap = QWidget()
    wrap.setObjectName("settingsBody")
    lay = QHBoxLayout(wrap)
    lay.setContentsMargins(*margins)
    lay.setSpacing(0)
    widget.setMaximumWidth(max_w)
    lay.addStretch(1)
    lay.addWidget(widget, 100)
    lay.addStretch(1)
    return wrap


class Row(QFrame):
    """Одна настройка: слева название (+ «?») и короткое пояснение, справа — элемент управления.
    На узком окне элемент переносится под название (а не сжимает его в столбик)."""

    def __init__(self, title, hint=None, help_text=None, indent=0):
        super().__init__()
        self.setObjectName("row")
        self.indent = indent
        self.box = QBoxLayout(QBoxLayout.Direction.LeftToRight, self)
        self.box.setContentsMargins(16 + indent, 12, 16, 12)
        self.box.setSpacing(16)
        left = QVBoxLayout()
        left.setSpacing(2)
        top = QHBoxLayout()
        top.setSpacing(8)
        self.title = QLabel(title)
        self.title.setObjectName("rowTitle")
        self.title.setWordWrap(True)
        top.addWidget(self.title, 1 if not help_text else 0)
        self.help = None
        if help_text:
            self.help = help_icon(help_text)
            top.addWidget(self.help, 0, Qt.AlignmentFlag.AlignVCenter)
            top.addStretch(1)
        left.addLayout(top)
        self.hint = _hint(hint) if hint else None
        if self.hint:
            left.addWidget(self.hint)
        self.left = left
        self.box.addLayout(left, 1)
        self.ctl = QHBoxLayout()
        self.ctl.setSpacing(8)
        self.box.addLayout(self.ctl, 0)
        self.toggle = None
        self.stacked = False

    def add_control(self, w):
        if isinstance(w, QWidget):
            self.ctl.addWidget(w, 0, Qt.AlignmentFlag.AlignVCenter)
        else:
            self.ctl.addLayout(w)

    def set_toggle(self, box):
        """Щелчок по названию строки тоже переключает (как в Windows 11)."""
        self.toggle = box
        self.title.setCursor(Qt.CursorShape.PointingHandCursor)

    def mouseReleaseEvent(self, e):  # noqa: N802 (Qt)
        if self.toggle is not None and self.toggle.isEnabled() and e.button() == Qt.MouseButton.LeftButton:
            self.toggle.toggle()
        super().mouseReleaseEvent(e)

    def _title_w(self):
        return self.title.fontMetrics().horizontalAdvance(self.title.text()) + 4

    def _extra(self):
        m = self.box.contentsMargins()
        return m.left() + m.right() + (26 if self.help else 0)

    def _needed(self):
        title_w = min(self._title_w(), STACK_TITLE_W)
        return title_w + self.ctl.sizeHint().width() + self.box.spacing() + self._extra()

    def minimumSizeHint(self):  # noqa: N802 (Qt)
        """Узкое окно: строка может стать столбиком (элемент под названием), поэтому минимум — столбик."""
        h = super().minimumSizeHint()
        m = self.box.contentsMargins()
        narrow = max(min(self._title_w(), STACK_TITLE_W) + (26 if self.help else 0),
                     self.ctl.minimumSize().width()) + m.left() + m.right()
        return QSize(min(h.width(), narrow), h.height())

    def resizeEvent(self, e):  # noqa: N802 (Qt)
        super().resizeEvent(e)
        stacked = self.width() < self._needed()
        if stacked != self.stacked:
            self.stacked = stacked
            self.box.setDirection(QBoxLayout.Direction.TopToBottom if stacked
                                  else QBoxLayout.Direction.LeftToRight)
            self.box.setSpacing(8 if stacked else 16)
            self.box.setAlignment(self.ctl, Qt.AlignmentFlag.AlignLeft if stacked else Qt.AlignmentFlag(0))
        # название — в одну строку, если места хватает (иначе QLabel с переносом сжимается в столбик)
        room = self.width() - self._extra() - (0 if self.stacked else self.ctl.sizeHint().width() + self.box.spacing())
        # не больше STACK_TITLE_W: иначе минимум, выставленный в широком окне, не даёт окну сузиться
        want = max(0, min(self._title_w(), room, STACK_TITLE_W))
        if self.title.minimumWidth() != want:
            self.title.setMinimumWidth(want)


class Section(QWidget):
    """Раздел: заголовок над белой карточкой, внутри — строки, разделённые тонкой линией."""

    def __init__(self, title, intro=None):
        super().__init__()
        self.outer = QVBoxLayout(self)
        self.outer.setContentsMargins(0, 0, 0, 0)
        self.outer.setSpacing(8)
        t = QLabel(title)
        t.setObjectName("sectionTitle")
        self.title = t
        self.outer.addWidget(t)
        self.group = QFrame()
        self.group.setObjectName("group")
        self.rows = QVBoxLayout(self.group)
        self.rows.setContentsMargins(0, 4, 0, 4)
        self.rows.setSpacing(0)
        self.outer.addWidget(self.group)
        self.count = 0
        if intro:
            r = Row(intro)
            r.title.setObjectName("hint")
            self._append(r)

    def _append(self, row):
        if self.count:
            line = QFrame()
            line.setObjectName("divider")
            line.setFixedHeight(1)
            holder = QHBoxLayout()
            holder.setContentsMargins(16, 0, 16, 0)
            holder.addWidget(line)
            self.rows.addLayout(holder)
        self.rows.addWidget(row)
        self.count += 1
        return row

    def add(self, text, widget, hint=None, tail=None, help=None, indent=0):  # noqa: A002
        row = Row(text, hint, help, indent)
        row.add_control(widget)
        for t in (tail if isinstance(tail, (list, tuple)) else [tail] if tail is not None else []):
            row.add_control(t)
        row.title.setBuddy(widget if isinstance(widget, QWidget) else None)
        return self._append(row)

    def add_slider(self, text, slider, hint=None, help=None):  # noqa: A002
        """Ползунок справа, значение словами — слева от него (как в Windows 11)."""
        row = Row(text, hint, help)
        slider.value_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        row.add_control(slider.value_label)
        row.add_control(slider)
        return self._append(row)

    def add_check(self, box, hint=None, indent=False, help=None):  # noqa: A002
        """Переключатель справа, его текст — название строки. indent — подпункт предыдущей строки."""
        row = Row(box.text(), hint, help, 28 if indent else 0)
        row.add_control(box)
        row.set_toggle(box)
        row.title.setEnabled(box.isEnabled())
        # подпункт гаснет вместе с переключателем (например «включать обратно» без паузы)
        box.installEventFilter(_EnableMirror(row.title, row.hint, parent=row))
        return self._append(row)

    def add_wide(self, widget_or_layout, title=None, hint=None):
        row = Row(title or "", hint)
        if not title:
            row.title.hide()
        row.box.setDirection(QBoxLayout.Direction.TopToBottom)
        row.box.setSpacing(8)
        row.resizeEvent = lambda e, r=row: QFrame.resizeEvent(r, e)
        row.add_control(widget_or_layout)
        return self._append(row)


class _EnableMirror(QObject):
    """Название и пояснение строки серые, когда переключатель недоступен."""

    def __init__(self, *labels, parent=None):
        super().__init__(parent)
        self.labels = [lb for lb in labels if lb is not None]

    def eventFilter(self, obj, ev):  # noqa: N802 (Qt)
        if ev.type() == QEvent.Type.EnabledChange:
            for lb in self.labels:
                lb.setEnabled(obj.isEnabled())
        return False


class SettingsPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.cfg = main.cfg
        self._loading = False
        self._general_dirty = False      # менялось что-то кроме ползунков съёма — перезапустить расписание
        self._src_dirty = False
        self.current_src = None
        self.last_error = None
        self.setObjectName("settingsPage")
        em = self.fontMetrics().horizontalAdvance("М")
        self._em = max(8, em)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self._build_header())
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        self.tabs.tabBar().hide()              # вкладки — переключателем в шапке
        self.tabs.addTab(self._build_main(), "Основные")
        self.tabs.addTab(self._build_sources(), "Окна программ (для опытных)")
        self.tabs.addTab(self._build_tagged(), "Аккаунт программы")
        self.tabs.currentChanged.connect(self._on_tab)
        lay.addWidget(self.tabs, 1)
        from PySide6.QtWidgets import QAbstractSpinBox
        for sp in self.findChildren(QAbstractSpinBox):   # отступ текста от рамки (padding стиля сюда не доходит)
            sp.lineEdit().setTextMargins(4, 0, 0, 0)
        self._live_timer = QTimer(self)
        self._live_timer.setSingleShot(True)
        self._live_timer.setInterval(LIVE_SAVE_MS)
        self._live_timer.timeout.connect(self._save_live)
        self._connect_live()
        self.load()

    def _build_header(self):
        head = QWidget()
        hl = QVBoxLayout(head)
        hl.setContentsMargins(0, 20, 0, 8)
        hl.setSpacing(8)
        top = QHBoxLayout()
        top.setSpacing(16)
        t = QLabel("Настройки")
        t.setObjectName("pageTitle")
        top.addWidget(t)
        top.addStretch(1)
        self.page_desc = _hint("Как выглядит программа, когда снимать экран и куда отправлять снимки.")
        self.page_desc.setObjectName("pageDesc")
        note = _hint("Изменения действуют сразу и сохраняются сами.")
        note.setWordWrap(False)
        top.addWidget(note, 0, Qt.AlignmentFlag.AlignVCenter)
        self.header_note = note
        self.saved_label = QLabel("")
        self.saved_label.setObjectName("savedOk")
        top.addWidget(self.saved_label, 0, Qt.AlignmentFlag.AlignVCenter)
        hl.addLayout(top)
        hl.addWidget(self.page_desc)
        bar = QHBoxLayout()
        bar.setSpacing(16)
        seg = QFrame()
        seg.setObjectName("segBar")
        sl = QHBoxLayout(seg)
        sl.setContentsMargins(3, 3, 3, 3)
        sl.setSpacing(2)
        self.seg_group = QButtonGroup(self)
        self.seg_buttons = []
        for i, text in enumerate(("Основные", "Окна программ (для опытных)", "Аккаунт программы")):
            b = QPushButton(text)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, i=i: self.tabs.setCurrentIndex(i))
            self.seg_group.addButton(b, i)
            self.seg_buttons.append(b)
            bf = QFont(self.font())
            bf.setWeight(QFont.Weight.DemiBold)
            b.setMinimumWidth(QFontMetrics(bf).horizontalAdvance(text) + 2 * 16 + 8)   # жирный текст не обрежется
            sl.addWidget(b)
        self.seg_buttons[0].setChecked(True)
        bar.addWidget(seg)
        bar.addStretch(1)
        hl.addLayout(bar)
        return _centered(head)

    def _on_tab(self, i):
        if 0 <= i < len(self.seg_buttons):
            self.seg_buttons[i].setChecked(True)

    # ---------- общие элементы ----------
    def _w(self, widget, ems):
        widget.setFixedWidth(int(self._em * ems))
        return widget

    def _spin(self, lo, hi, unit_fn, ems=9, step=1):
        sp = QSpinBox()
        sp.setRange(lo, hi)
        sp.setSingleStep(step)
        sp.unit_fn = unit_fn
        sp.valueChanged.connect(lambda v: sp.setSuffix(" " + unit_fn(v).split(" ", 1)[1]))
        sp.setSuffix(" " + unit_fn(lo).split(" ", 1)[1])
        # ширина — по самой длинной подписи («300 снимков», «1800 секунд»), плюс место под стрелки
        samples = {lo, hi} | set(range(lo, min(hi, lo + 30) + 1, step)) | {hi - hi % 10 + 5 if hi >= 10 else hi}
        text_w = max(sp.fontMetrics().horizontalAdvance(unit_fn(v)) for v in samples if lo <= v <= hi)
        sp.setFixedWidth(max(int(self._em * ems), text_w + 52, 148))
        return sp

    def _slider(self, lo, hi, fmt, step=1):
        """Ползунок; рядом — значение словами (меняется сразу при перетаскивании)."""
        sl = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(lo, hi)
        sl.setSingleStep(step)
        sl.setPageStep(max(step, 5))
        sl.setTickPosition(QSlider.TickPosition.NoTicks)
        sl.setCursor(Qt.CursorShape.PointingHandCursor)
        sl.setFixedWidth(184)
        lbl = QLabel(fmt(lo))
        lbl.setObjectName("value")
        widest = max((fmt(v) for v in range(lo, hi + 1, step)), key=lambda t: self.fontMetrics().horizontalAdvance(t))
        lbl.setMinimumWidth(self.fontMetrics().horizontalAdvance(widest) + 8)
        sl.valueChanged.connect(lambda v: lbl.setText(fmt(v)))
        sl.value_label = lbl
        sl.fmt = fmt
        return sl, None

    def _toggle(self, text):
        t = ToggleSwitch(text)
        t.setFocusPolicy(Qt.FocusPolicy.TabFocus)
        return t

    # ---------- «Основные» ----------
    def _build_main(self):
        col_w = QWidget()
        col = QVBoxLayout(col_w)
        col.setContentsMargins(0, 8, 0, 32)
        col.setSpacing(24)
        for build in (self._sec_look, self._sec_schedule, self._sec_before, self._sec_during, self._sec_oasys, self._sec_cameras, self._sec_vk,
                      self._sec_cleanup, self._sec_app, self._sec_reliable):
            col.addWidget(build())
        col.addWidget(self._build_advanced())
        col.addStretch(1)
        body = _centered(col_w)
        self.main_scroll = _scroll(body)
        return self.main_scroll

    def _sec_look(self):
        """2.1.8: «Внешний вид» — тема оформления (применяется сразу, во всех окнах) и цвет акцента."""
        s = Section("Внешний вид")
        bar = QFrame()
        bar.setObjectName("segBar")
        bl = QGridLayout(bar)          # 2×2: влезает и при 150 % в узком окне
        bl.setContentsMargins(3, 3, 3, 3)
        bl.setSpacing(2)
        self.theme_group = QButtonGroup(self)
        self.theme_buttons = {}
        bf = QFont(self.font())
        bf.setWeight(QFont.Weight.Bold)
        for i, (key, text) in enumerate(theme.THEMES):
            b = QPushButton(text)
            b.setObjectName("seg")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setMinimumWidth(QFontMetrics(bf).horizontalAdvance(text) + 2 * 16 + 8)
            self.theme_group.addButton(b, i)
            self.theme_buttons[key] = b
            bl.addWidget(b, i // 2, i % 2)
        self.theme_group.idClicked.connect(lambda i: self._on_theme())
        s.add("Тема оформления", bar, "«Как в Windows» — светлая или тёмная, как настроено в Windows",
              help="Тема меняется сразу, во всех окнах программы. «Высокий контраст» — белый текст на чёрном, "
                   "для яркого зала или плохо видимого монитора.")
        self.accent = QComboBox()
        for key, text in theme.ACCENTS:
            self.accent.addItem(text, key)
        self.accent.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        self.accent.currentIndexChanged.connect(lambda _i: self._on_theme())
        s.add("Цвет акцента", self.accent, "Кнопки, выделение и переключатели")
        return s

    def _load_look(self, app):
        mode = str(app.get("theme") or "system")
        self.theme_buttons.get(mode, self.theme_buttons["system"]).setChecked(True)
        i = self.accent.findData(str(app.get("accent") or "blue"))
        self.accent.setCurrentIndex(max(0, i))
        self.accent.setEnabled(mode != "contrast")

    def load_look(self):
        """Тему поменяли в мастере — показать выбор и здесь."""
        was, self._loading = self._loading, True
        try:
            self._load_look(self.cfg.get("app") or {})
        finally:
            self._loading = was

    def theme_choice(self):
        for key, b in self.theme_buttons.items():
            if b.isChecked():
                return key
        return "system"

    def _on_theme(self):
        if self._loading:
            return
        app = self.cfg.setdefault("app", {})
        app["theme"] = self.theme_choice()
        app["accent"] = self.accent.currentData() or "blue"
        self.accent.setEnabled(app["theme"] != "contrast")
        theme.apply(None, app["theme"], app["accent"])
        log.info("Тема оформления: %s", dict(theme.THEMES).get(app["theme"], app["theme"]))
        self._live_timer.start()

    def _sec_schedule(self):
        s = Section("Расписание")
        self.club_name = self._w(QLineEdit(), 18)
        self.club_name.setPlaceholderText("Мой клуб")
        s.add("Название клуба", self.club_name, "В окне программы и в подписи к снимкам",
              help="В подпись к снимкам название попадает, если в ней есть {club}.")
        self.sched_minute = self._spin(0, 59, lambda v: f"{v} {plural_ru(v, 'минута', 'минуты', 'минут')}", 10)
        s.add("Минута съёма в каждом часе", self.sched_minute, "0 — ровно в 10:00, 11:00…; 15 — в 10:15, 11:15…",
              help="Снимки Oasys и камер делаются каждый час в эту минуту и отправляются в беседу ВКонтакте.")
        self.prewarm, _ = self._slider(0, 15, lambda v: "не открывать" if v == 0 else f"за {mins(v)}")
        s.add_slider("Заранее открывать беседу ВК", self.prewarm, "Слетевший вход видно до отправки",
                     help="Если вход в ВК слетел, вы узнаете об этом заранее, а не в момент отправки.")
        return s

    def _sec_before(self):
        s = Section("Перед съёмом")
        self.countdown_seconds, _ = self._slider(
            COUNTDOWN_MIN_SEC, COUNTDOWN_MAX_SEC, lambda v: "не показывать" if v == 0 else f"за {secs(v)}")
        s.add_slider("Предупреждение на экране", self.countdown_seconds, "Окошко с отсчётом в углу экрана",
                     help="Небольшое окошко «Съём скриншотов через 0:59» в правом нижнем углу. На снимки оно "
                          "не попадает. Без кнопок щелчки проходят сквозь него.")
        self.countdown_buttons = self._toggle("Кнопки «Снять сейчас» и «Снять позже» в предупреждении")
        s.add_check(self.countdown_buttons, "«Позже» — на 1 минуту, не чаще раза в час",
                    help="«Снять сейчас» — снять и отправить сразу, не дожидаясь конца отсчёта. «Снять позже» — "
                         "отложить съём на 1 минуту, например чтобы закрыть лишнее окно; можно один раз в час. "
                         "Если выключить — окошко такое же, как раньше, и щелчки проходят сквозь него.")
        self.manual_hotkey = QKeySequenceEdit()
        if hasattr(self.manual_hotkey, "setMaximumSequenceLength"):
            self.manual_hotkey.setMaximumSequenceLength(1)
        self._w(self.manual_hotkey, 10)
        self.manual_default = QPushButton("По умолчанию")
        self.manual_default.clicked.connect(
            lambda: self.manual_hotkey.setKeySequence(QKeySequence(quickshot.DEFAULT_HOTKEY)))
        s.add("Ручной съём клавишами", self.manual_hotkey, "Работает с :50 до :10 вокруг минуты съёма",
              tail=self.manual_default,
              help="Нажмите сочетание (по умолчанию Shift+Alt+2, цифра 2 в верхнем ряду) — программа сразу снимет экран и отправит в "
                   "беседу. С :50 до :59 снимок идёт за следующий час, с :00 до :10 — за текущий, если он ещё "
                   "не отправлен. В другое время сочетание ничего не делает. Чтобы выключить — очистите поле.")
        self.countdown_opacity, _ = self._slider(COUNTDOWN_MIN_OPACITY, COUNTDOWN_MAX_OPACITY, lambda v: f"{v} %", 5)
        s.add_slider("Заметность окошка", self.countdown_opacity, "100 % — совсем непрозрачное")
        self.lock_early, _ = self._slider(EARLY_MIN_SEC, EARLY_MAX_SEC,
                                          lambda v: "в момент съёма" if v == 0 else f"за {secs(v)}")
        s.add_slider("Заранее блокировать ввод", self.lock_early, "Мышь и клавиатуру — чтобы Oasys успел выйти вперёд",
                     help="Заранее — чтобы Oasys успел выйти вперёд и открыть «Карту клуба», пока никто не щёлкает.")
        self.media_pause = self._toggle("Ставить видео на паузу на время съёма")
        s.add_check(self.media_pause, "Музыка продолжит играть",
                    help="Только видео, которое играет сейчас (браузер, кино-плеер). Музыка (Spotify, AIMP, "
                         "Яндекс Музыка…) не трогается. Музыка во вкладке браузера может встать на паузу, "
                         "если браузер сообщает о ней как о видео. Если Windows не умеет ставить паузу — съёмка "
                         "идёт как обычно.")
        self.media_resume = self._toggle("После снимков включать обратно")
        s.add_check(self.media_resume, "Только то, что поставила на паузу программа", indent=True)
        self.media_pause.toggled.connect(self.media_resume.setEnabled)
        return s

    def _sec_during(self):
        s = Section("Во время съёма")
        self.lock_enabled = self._toggle("Блокировать мышь и клавиатуру")
        s.add_check(self.lock_enabled, "Пока делаются снимки — обычно несколько секунд",
                    help="Отправка в ВК идёт в фоне и ничего не блокирует. Ctrl+Alt+Del работает всегда.")
        self.lock_hotkey = QKeySequenceEdit()
        if hasattr(self.lock_hotkey, "setMaximumSequenceLength"):
            self.lock_hotkey.setMaximumSequenceLength(1)
        self._w(self.lock_hotkey, 10)
        self.hotkey_default = QPushButton("По умолчанию")
        self.hotkey_default.clicked.connect(lambda: self.lock_hotkey.setKeySequence(QKeySequence(DEFAULT_HOTKEY)))
        s.add("Снять блокировку клавишами", self.lock_hotkey, "Щёлкните в поле и нажмите, например, Ctrl+Alt+Q",
              tail=self.hotkey_default)
        self.lock_watchdog = self._spin(WATCHDOG_MIN_SEC, WATCHDOG_MAX_SEC, secs_nom, 10)
        s.add("Страховка от зависания", self.lock_watchdog, "Блокировка снимется сама не позже этого",
              help="Что бы ни случилось, мышь и клавиатура вернутся не позже этого времени.")
        self.restore_foreground = self._toggle("Возвращать окно, в котором вы работали")
        s.add_check(self.restore_foreground, "Сразу после снимков")
        return s

    def _sec_oasys(self):
        s = Section("Проверка Oasys")
        self.oasys_check = self._toggle("Проверять, что Oasys загрузился")
        s.add_check(self.oasys_check, "Видна «Карта клуба»; если нет — переснять",
                    help="Окно отвечает и на нём видна «Карта клуба». Если нет — Oasys переснимается ещё раз.")
        self.oasys_wait, _ = self._slider(READY_MIN_SEC, READY_MAX_SEC, lambda v: f"до {secs(v)}")
        s.add_slider("Ждать загрузку Oasys", self.oasys_wait, "Потом снимок уйдёт с пометкой",
                     help="Не загрузился — мышь и клавиатура сразу освобождаются, в ВК уходит снимок с пометкой "
                          "«Oasys не загрузился — снимок может быть неактуален», а программа предупредит.")
        return s

    def _sec_cameras(self):
        """3.0.9: сценарий камер (iVMS) — запись, второй вид, кнопка Cancel — в ОСНОВНЫХ настройках."""
        s = Section("Сценарий камер (iVMS)",
                    "Как программа снимает камеры. Обычно хватает записанного сценария. Если iVMS "
                    "спрашивает, сохранить ли изменения, один раз запишите щелчок по Cancel. Второй вид "
                    "нужен, только если камеры часто переставляют.")
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        self.cam_state = label("", "hint")
        v.addWidget(self.cam_state)
        row = QHBoxLayout()
        row.setSpacing(8)
        for text, fn, tip in (
                ("Записать сценарий…", lambda: self._cam_do(self.rerecord_scenario), "Записать щелчки по iVMS заново"),
                ("Cancel и второй вид…", lambda: self._cam_do(self.alt_scenario),
                 "Записать щелчок по Cancel в вопросе iVMS и, если нужно, вид камер с приписью Editing"),
                ("Проверить", lambda: self._cam_do(self.test_source), "Пробный съём камер"),
                ("Сбросить", lambda: self._cam_do(self.reset_scenario), "Удалить запись и снимать стандартным способом")):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        s.add_wide(box)
        return s

    def _cam_index(self):
        for i, src in enumerate(self.cfg.get("sources") or []):
            if src.get("kind") == "ivms":
                return i
        return None

    def _cam_do(self, fn):
        i = self._cam_index()
        if i is None:
            QMessageBox.information(self, "Камеры", "Программа камер (iVMS) не настроена — запустите мастер настройки")
            return
        if self.src_list.currentRow() != i:
            self.src_list.setCurrentRow(i)
        fn()
        self._cam_refresh()

    def _cam_refresh(self):
        if not hasattr(self, "cam_state"):
            return
        i = self._cam_index()
        if i is None:
            self.cam_state.setText("Программа камер не настроена")
            return
        from .. import recorder
        src = self.cfg["sources"][i]
        alt = any(isinstance(st, dict) and st.get("alt_templates") for st in src.get("steps") or [])
        self.cam_state.setText(f"{src.get('name', '')}: {recorder.state_text(src)} · "
                               f"{recorder.cancel_state_text(src, resolve_path)} · "
                               f"второй вид: {'записан' if alt else 'нет'}")

    def _sec_vk(self):
        s = Section("Отправка в ВК")
        self.r_browser = QRadioButton("От моего профиля (рекомендуется)")
        self.r_group = QRadioButton("От сообщества")
        self.sender_group = QButtonGroup(self)
        box = QVBoxLayout()
        box.setSpacing(6)
        for r in (self.r_browser, self.r_group):
            self.sender_group.addButton(r)
            box.addWidget(r)
        s.add("От чьего имени отправлять", box, "Профиль — через ВКонтакте внутри программы",
              help="От сообщества — по ключу доступа; ключ вводится в «Дополнительно» → «Отправка от сообщества».")
        self.peer_title = self._w(QLineEdit(), 18)
        self.peer_title.setPlaceholderText("Отчёты клуба")
        s.add("Беседа", self.peer_title, "Название — только для вас",
              help="Выбрать беседу проще в мастере: «Главная» → «Настроить заново».")
        self.peer = self._w(QLineEdit(), 10)
        self.peer.setValidator(QRegularExpressionValidator(QRegularExpression(r"\d{0,12}"), self.peer))
        self.peer.setPlaceholderText("2000000001")
        s.add("Номер беседы (peer_id)", self.peer, "Из адреса vk.com/im/convo/2000000001")
        self.caption = self._w(QLineEdit(), 18)
        self.caption.setPlaceholderText("необязательно")
        s.add("Подпись к снимкам", self.caption, "Можно вставить {club}, {date}, {time}")
        self.send_partial = self._toggle("Отправлять, даже если одна программа не снялась")
        s.add_check(self.send_partial, "Уйдёт то, что получилось")
        self.save_memory = self._toggle("Экономить память")
        s.add_check(self.save_memory, "Страница ВК открыта только когда нужна",
                    help="Страница ВК открыта только во время отправки и пока открыт раздел «ВКонтакте». "
                         "Вход не теряется.")
        row = QHBoxLayout()
        row.setSpacing(8)
        for text, fn in (("Проверить вход", lambda: self.main.check_login(show=True)),
                         ("Проверить отправку…", self.debug_send)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        s.add("Проверка", row, "Вход в ВК и отправка — по шагам",
              help="«Проверить отправку…» проходит отправку по шагам и показывает, что видит программа.")
        return s

    def _sec_cleanup(self):
        s = Section("Очистка снимков")
        self.cleanup_enabled = self._toggle("Удалять старые снимки")
        s.add_check(self.cleanup_enabled, "Раз в день; последние снимки не трогаются",
                    help="Снимки текущей и последней отправки не удаляются никогда.")
        self.cleanup_hours = self._spin(1, 720, hours_nom, 10)
        s.add("Хранить снимки", self.cleanup_hours, "Более старые удаляются")
        self.cleanup_time = self._w(QTimeEdit(), 11)
        self.cleanup_time.setDisplayFormat("HH:mm")
        s.add("Время уборки", self.cleanup_time, "Совпала с отправкой — сдвинется на полчаса")
        self.keep_last = self._spin(0, 100000, shots_nom, 10, 10)
        s.add("Не больше снимков", self.keep_last, "0 — без ограничения по числу",
              help="Снимки неудачных отправок и файлы для разбора ошибок хранятся 3 дня, папка logs — "
                   "не больше 50 МБ.")
        return s

    def _sec_app(self):
        s = Section("Запуск и окно")
        self.autostart = self._toggle("Запускать вместе с Windows")
        self.autostart.clicked.connect(self.toggle_autostart)
        s.add_check(self.autostart, "От имени администратора, без лишних вопросов")
        self.start_minimized = self._toggle("Запускать свёрнутой")
        s.add_check(self.start_minimized, "Сразу в область уведомлений, к часам")
        self.use_tray = self._toggle("Прятать к часам при закрытии окна")
        s.add_check(self.use_tray, "Вместо выхода; действует после перезапуска")
        return s

    def _sec_reliable(self):
        """2.2.0: утренняя сводка, лёгкий режим, сторож, обновления, резервная копия."""
        s = Section("Надёжность и обновления")
        self.summary_enabled = self._toggle("Утренняя сводка в беседу")
        s.add_check(self.summary_enabled, "«За ночь отправлено 23 из 24…» — с ближайшей отправкой после времени",
                    help="Если обычной отправки так и не было — отдельным коротким сообщением через час.")
        self.sent_check = self._toggle("Проверять, что скрины на месте")
        s.add_check(self.sent_check, "В выбранные минуты часа смотрит беседу ВК — если скринов нет, большое красное окно поверх всех",
                    help="В минуты из списка ниже (по умолчанию :05, :07 и :10) программа ищет в беседе своё сообщение с двумя последними "
                         "скринами (даже если считала, что отправила: сообщение могли удалить). Своё окно (не "
                         "уведомление Windows) с причиной и кнопками «Отправить последние скрины» / «Снять и "
                         "отправить сейчас». Сама повторно не отправляет. Если беседу прочитать не удалось — окно так "
                         "и скажет. На скрины не попадает.")
        from .checkminutes import MinuteList
        self.sent_minutes = MinuteList()
        s.add("Минуты проверок", self.sent_minutes,
              "Каждая строка — минута часа (щёлкните, чтобы изменить), список сам встаёт по порядку; «×» — удалить, до 15 проверок",
              help="Проверки идут по времени, порядок в списке не важен. Пока идёт съём и отправка, проверка ждёт.",
              indent=28)
        self.sent_check.toggled.connect(self.sent_minutes.setEnabled)
        self.sent_check_sound = self._toggle("Звук при тревоге")
        s.add_check(self.sent_check_sound, "Короткий звуковой сигнал вместе с окном")
        self.skip_if_manual = self._toggle("Не повторять, если в этот час уже отправлял вручную")
        s.add_check(self.skip_if_manual, "Ручная отправка кнопками программы закрывает час: без повтора и тревоги в :05",
                    help="Перед повтором и тревогой программа ещё смотрит беседу: своё сообщение за этот час "
                         "с теми же двумя скринами считается отправкой. Удалённое сообщение повтора не вызывает.")
        self.summary_time = self._w(QTimeEdit(), 11)
        self.summary_time.setDisplayFormat("HH:mm")
        s.add("Время сводки", self.summary_time, "Сводка за сутки до этого времени")
        self.light_mode = self._toggle("Лёгкий режим (меньше памяти)")
        s.add("Лёгкий режим", self.light_mode, "По умолчанию выключен; действует после перезапуска",
              help="Включайте, только если компьютеру не хватает памяти: меньше кэш страницы ВК, снимки — JPEG "
                   "не шире 1920 точек. Сам по себе не включается.")
        self.watchdog_enabled = self._toggle("Сторож: перезапуск при сбое")
        s.add_check(self.watchdog_enabled, "Программа упала или зависла — откроется снова; после перезапуска")
        self.updates_auto = self._toggle("Проверять обновления раз в день")
        s.add_check(self.updates_auto, "Только проверка; ставится по вашей кнопке, не во время съёма")
        row = QHBoxLayout()
        b_upd = QPushButton("Проверить обновления")
        b_upd.clicked.connect(lambda: self.main.check_updates(manual=True))
        self.update_note = QLabel("")
        row.addWidget(b_upd)
        row.addWidget(self.update_note, 1)
        s.add_wide(row)
        row2 = QHBoxLayout()
        b_exp = QPushButton("Сохранить резервную копию…")
        b_imp = QPushButton("Восстановить из копии…")
        from .backup_ui import export_dialog, import_dialog
        b_exp.clicked.connect(lambda: export_dialog(self, self.main))
        b_imp.clicked.connect(lambda: import_dialog(self, self.main))
        row2.addWidget(b_exp)
        row2.addWidget(b_imp)
        row2.addStretch(1)
        s.add_wide(row2, hint="Настройки и вход в ВК в одном файле, зашифрованном паролем. Файл даёт доступ к "
                              "аккаунту ВК — не пересылайте его.")
        return s

    def show_update(self, info):
        self.update_note.setText(f"Есть версия {info['version']}" if info else "У вас последняя версия")

    def _build_advanced(self):
        wrap = QWidget()
        lay = QVBoxLayout(wrap)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(24)
        self.adv_toggle = QToolButton()
        self.adv_toggle.setObjectName("advToggle")
        self.adv_toggle.setText("Дополнительно")
        self.adv_toggle.setToolTip("Повторы, папка снимков, ключ сообщества, селекторы ВК, файл настроек")
        self.adv_toggle.setCheckable(True)
        self.adv_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.adv_toggle.setArrowType(Qt.ArrowType.RightArrow)
        self.adv_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.adv_toggle.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        lay.addWidget(self.adv_toggle)
        self.adv_body = QWidget()
        bl = QVBoxLayout(self.adv_body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(24)

        s = Section("Повторы при ошибке")
        self.attempts = self._spin(1, 2, lambda v: f"{v} {plural_ru(v, 'попытка', 'попытки', 'попыток')}", 10)
        s.add("Попыток в час", self.attempts, "Не больше двух, чтобы не беспокоить ВК")
        self.retry_interval = self._spin(60, 3600, secs_nom, 10, 30)
        s.add("Пауза между попытками", self.retry_interval, "Не меньше 1 минуты")
        self.max_delay = self._spin(60, 3600, secs_nom, 10, 60)
        s.add("Пропустить, если опоздали на", self.max_delay, "Компьютер спал и проснулся позже",
              help="Компьютер спал и проснулся позже — такой запуск пропускается.")
        bl.addWidget(s)

        s = Section("Где хранить снимки")
        self.shots_dir = self._w(QLineEdit(), 15)
        b = QPushButton("Выбрать…")
        b.clicked.connect(self._pick_dir)
        s.add("Папка", self.shots_dir, "По умолчанию — screenshots рядом с программой", tail=b)
        self.image_format = QComboBox()
        self.image_format.addItem("PNG — без потерь", "png")
        self.image_format.addItem("JPG — файлы меньше", "jpg")
        self.image_format.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        s.add("Формат", self.image_format, "PNG чётче, JPG занимает меньше места")
        bl.addWidget(s)

        s = Section("Отправка от сообщества")
        self.token = self._w(QLineEdit(), 18)
        self.token.setEchoMode(QLineEdit.EchoMode.Password)
        s.add("Ключ доступа сообщества", self.token, "Нужен, только если отправка — от сообщества",
              help="«Управление» → «Работа с API» → «Ключи доступа», право «сообщения». Сообщество должно быть "
                   "в беседе. Никому не передавайте ключ и config.yaml.")
        self.api_version = self._w(QLineEdit(), 6)
        s.add("Версия API", self.api_version, "Обычно менять не нужно")
        b = QPushButton("Проверить ключ")
        b.clicked.connect(self.check_token)
        s.add("Проверка ключа", b, "Ключ работает и сообщество видит беседу")
        bl.addWidget(s)

        s = Section("Страница ВК: селекторы и паузы")
        self.vb_text = QPlainTextEdit()
        self.vb_text.setObjectName("mono")
        self.vb_text.setMinimumHeight(int(self._em * 8))
        s.add_wide(self.vb_text, "Раздел vk_browser (YAML)", "Пусто — по умолчанию. Менять, только если ВК "
                   "поменял страницу")
        bl.addWidget(s)

        s = Section("Файл настроек")
        self.cfg_path_label = label(str(getattr(self.main, "cfg_path", "") or ""), "hint")
        s.add_wide(self.cfg_path_label, "Где лежит config.yaml")
        self.reset_btn = QPushButton("Сбросить по умолчанию…")
        self.reset_btn.clicked.connect(self.reset_defaults)
        s.add("Сбросить настройки", self.reset_btn, "Беседа ВК, вход, ключ и окна программ останутся",
              help="Возвращает расписание, предупреждение, блокировку, проверку Oasys, паузу музыки, очистку и "
                   "хранение к исходным значениям. Беседа ВК, вход, ключ и окна программ остаются.")
        bl.addWidget(s)

        lay.addWidget(self.adv_body)
        self.adv_body.setVisible(False)
        self.adv_toggle.toggled.connect(self.set_advanced_open)
        return wrap

    def set_advanced_open(self, on):
        self.adv_toggle.blockSignals(True)
        self.adv_toggle.setChecked(on)
        self.adv_toggle.blockSignals(False)
        self.adv_toggle.setArrowType(Qt.ArrowType.DownArrow if on else Qt.ArrowType.RightArrow)
        self.adv_body.setVisible(on)

    def _pick_dir(self):
        start = resolve_path(self.shots_dir.text().strip() or "screenshots")
        d = QFileDialog.getExistingDirectory(self, "Папка для снимков", start)
        if d:
            self.shots_dir.setText(d)
            self._changed()

    # ---------- программы ----------
    def _build_tagged(self):
        """3.0.3: режим «отдельный аккаунт ВК для программы + подпись-тег часа»."""
        col_w = QWidget()
        col = QVBoxLayout(col_w)
        col.setContentsMargins(0, 8, 0, 32)
        s = Section("Аккаунт программы и тег часа",
                    "Программа входит в ВК под своим отдельным аккаунтом и подписывает каждое сообщение со "
                    "скринами тегом часа, например «Камеры за 7:00». Проверки ищут сообщение часа по тегу и "
                    "сравнивают картинки. Войти в аккаунт программы — в разделе «ВКонтакте».")
        self.tg_enabled = self._toggle("Включить режим «аккаунт программы»")
        s.add_check(self.tg_enabled, "Выключено — работает как раньше")
        self.tg_caption = self._w(QLineEdit(), 18)
        self.tg_caption.setPlaceholderText("Камеры за {hour}")
        s.add("Тег часа", self.tg_caption, "{hour} — 7:00, {time} — 07:00, {date} — дата")
        self.tg_account = self._w(QLineEdit(), 18)
        self.tg_account.setPlaceholderText("необязательно: id123 или vk.com/имя")
        s.add("Адрес профиля программы", self.tg_account, "Проверка, что вошли именно в него")
        self.tg_preview = QLabel("")
        s.add("Пример подписи", self.tg_preview, "Если снято позже 5 минут — дописывается «(снято в …)»")
        col.addWidget(s)
        col.addStretch(1)
        for w in (self.tg_caption, self.tg_account):
            w.textEdited.connect(self._tg_preview)
        self.tg_enabled.toggled.connect(self._tg_preview)
        return _scroll(_centered(col_w))

    def _tg_preview(self, *_):
        from datetime import datetime
        from app import tagged
        cfg = {"tagged": {"caption": self.tg_caption.text().strip() or tagged.DEFAULTS["caption"]}}
        slot = datetime.now().replace(minute=0, second=0, microsecond=0)
        self.tg_preview.setText(tagged.caption_for(cfg, slot, slot) + "   ·   с опозданием: "
                                + tagged.caption_for(cfg, slot, slot.replace(minute=23)))

    def _build_sources(self):
        inner = QFrame()
        inner.setObjectName("group")
        lay = QHBoxLayout(inner)
        lay.setContentsMargins(16, 16, 16, 16)
        lay.setSpacing(16)
        left = QVBoxLayout()
        left.setSpacing(8)
        self.src_list = QListWidget()
        self.src_list.setObjectName("srcList")
        self.src_list.setMaximumWidth(int(self._em * 13))
        self.src_list.currentRowChanged.connect(self._on_src_select)
        left.addWidget(self.src_list, 1)
        for text, fn in (("Добавить", self.src_add), ("Удалить", self.src_delete),
                         ("Выше", lambda: self.src_move(-1)), ("Ниже", lambda: self.src_move(1))):
            b = QPushButton(text)
            b.clicked.connect(fn)
            left.addWidget(b)
        lay.addLayout(left)
        right = QVBoxLayout()
        right.setSpacing(8)
        right.addWidget(_hint("Обычно здесь ничего менять не нужно: мастер настройки всё делает сам. "
                              "Правки сохраняются сами; шаги с ошибкой не сохраняются, пока их не исправить."))
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(8)
        self.src_fields = {k: QLineEdit() for k in ("name", "title_regex", "process_regex", "exclude_title_regex",
                                                    "view_preset")}
        for k, text in (("name", "Название"), ("title_regex", "Заголовок окна"),
                        ("process_regex", "Процесс"), ("exclude_title_regex", "Кроме окон"),
                        ("view_preset", "Пресет вида iVMS")):
            lbl = QLabel(text)
            lbl.setObjectName("rowTitle")
            form.addRow(lbl, self.src_fields[k])
        self.src_fields["title_regex"].setToolTip("Регулярное выражение для заголовка окна")
        self.src_fields["process_regex"].setToolTip("Регулярное выражение для имени процесса")
        self.src_fields["exclude_title_regex"].setToolTip("Не брать окна с таким заголовком (рег. выражение)")
        self.src_fields["process_regex"].setPlaceholderText(r"например (?i)^OASys\.Admin\.exe$")
        self.src_fields["title_regex"].setPlaceholderText("например (?i)oasys")
        self.src_fields["view_preset"].setPlaceholderText("например cam; пусто — не выбирать")
        self.src_fields["view_preset"].setToolTip("iVMS-4200: перед снимком двойной щелчок по этому виду в "
                                                  "Resource → Custom View (вернёт раскладку камер)")
        self.src_enabled = ToggleSwitch("Снимать эту программу")
        en_row = QHBoxLayout()
        en_row.setSpacing(10)
        en_row.addWidget(self.src_enabled)
        en_lbl = QLabel(self.src_enabled.text())
        en_lbl.setObjectName("rowTitle")
        en_lbl.mousePressEvent = lambda e: self.src_enabled.toggle()
        en_row.addWidget(en_lbl)
        en_row.addStretch(1)
        form.addRow("", en_row)
        right.addLayout(form)
        pick = QHBoxLayout()
        pick.setSpacing(8)
        for text, fn in (("Выбрать окно из списка…", self.pick_window), ("Проверить, что окно находится",
                                                                         self.check_window)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            pick.addWidget(b)
        pick.addStretch(1)
        right.addLayout(pick)
        self.win_status = label("", "hint")
        right.addWidget(self.win_status)
        right.addWidget(label("Шаги (YAML, типы шагов описаны в README):", "rowTitle"))
        self.steps_text = QPlainTextEdit()
        self.steps_text.setObjectName("mono")
        right.addWidget(self.steps_text, 1)
        row = QHBoxLayout()
        row.setSpacing(8)
        for text, fn in (("Проверить источник", self.test_source),
                         ("Обвести кнопку (шаблон)…", self.capture_template)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        right.addLayout(row)
        # 3.0.0: сценарий съёмки — перезаписать / сбросить к стандартному
        row = QHBoxLayout()
        row.setSpacing(8)
        self.scn_state = label("", "hint")
        row.addWidget(label("Сценарий для съёмки:", "rowTitle"))
        row.addWidget(self.scn_state)
        row.addStretch(1)
        for text, fn, tip in (("Перезаписать сценарий для съёмки", self.rerecord_scenario, ""),
                              ("Сброс сценария для съёмки", self.reset_scenario, "")):
            b = QPushButton(text)
            b.clicked.connect(fn)
            if tip:
                b.setToolTip(tip)
            row.addWidget(b)
        right.addLayout(row)
        lay.addLayout(right, 1)
        col = QWidget()
        cl = QVBoxLayout(col)
        cl.setContentsMargins(0, 8, 0, 24)
        cl.addWidget(inner, 1)
        return _centered(col)


    # ---------- применение сразу и автосохранение ----------
    CAPTURE_WIDGETS = ("countdown_seconds", "countdown_opacity", "lock_early", "oasys_wait", "lock_watchdog",
                       "lock_enabled", "oasys_check", "lock_hotkey", "media_pause", "media_resume",
                       "countdown_buttons", "manual_hotkey")

    def _connect_live(self):
        for name in ("countdown_seconds", "countdown_opacity", "lock_early", "oasys_wait", "lock_watchdog"):
            getattr(self, name).valueChanged.connect(self._apply_live)
        for name in ("lock_enabled", "oasys_check", "media_pause", "media_resume", "countdown_buttons"):
            getattr(self, name).toggled.connect(self._apply_live)
        self.lock_hotkey.keySequenceChanged.connect(self._apply_live)
        self.manual_hotkey.keySequenceChanged.connect(self._apply_live)
        for w in (self.sched_minute, self.prewarm, self.cleanup_hours, self.keep_last, self.attempts,
                  self.retry_interval, self.max_delay):
            w.valueChanged.connect(self._changed)
        for w in (self.restore_foreground, self.send_partial, self.save_memory, self.start_minimized, self.use_tray,
                  self.cleanup_enabled, self.r_browser, self.r_group):
            w.toggled.connect(self._changed)
        for w in (self.club_name, self.peer, self.peer_title, self.caption, self.token, self.api_version,
                  self.shots_dir):
            w.textEdited.connect(self._changed)
        self.cleanup_time.timeChanged.connect(self._changed)
        self.sent_minutes.changed.connect(self._changed)
        self.summary_time.timeChanged.connect(self._changed)
        self.light_mode.toggled.connect(self._changed)
        self.tg_enabled.toggled.connect(self._changed)
        for w in (self.tg_caption, self.tg_account):
            w.textEdited.connect(self._changed)
        for w in (self.summary_enabled, self.watchdog_enabled, self.updates_auto, self.sent_check,
                  self.sent_check_sound, self.skip_if_manual):
            w.toggled.connect(self._changed)
        self.image_format.currentIndexChanged.connect(self._changed)
        self.vb_text.textChanged.connect(self._changed)
        for f in self.src_fields.values():
            f.textEdited.connect(self._src_changed)
        self.src_enabled.toggled.connect(self._src_changed)
        self.steps_text.textChanged.connect(self._src_changed)

    def _apply_live(self, *_):
        """Отсчёт, блокировка, проверка Oasys, пауза музыки — в памяти мгновенно (планировщик перечитывает их
        каждые полсекунды), в config.yaml — через полсекунды покоя. Регрессия 2.1.5: «поставил 15 вместо 60»."""
        if self._loading:
            return
        cd = self.cfg.setdefault("countdown", {})
        cd.pop("enabled", None)
        cd["seconds"] = int(self.countdown_seconds.value())
        cd["opacity"] = int(self.countdown_opacity.value())
        self.cfg.pop("notifications", None)      # старые уведомления Windows (до 2.1.4)
        lk = self.cfg.setdefault("input_lock", {})
        lk["enabled"] = self.lock_enabled.isChecked()
        lk["early_sec"] = int(self.lock_early.value())
        lk["watchdog_sec"] = int(self.lock_watchdog.value())
        seq = self.lock_hotkey.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        try:
            lk["hotkey"] = format_hotkey(parse_hotkey(seq))
            self._hotkey_error = None
        except ValueError as e:
            self._hotkey_error = f"Сочетание для разблокировки: {e}"   # прежнее сочетание остаётся
        cd["buttons"] = self.countdown_buttons.isChecked()
        ms = self.cfg.setdefault("manual_shot", {})
        try:
            text = self._manual_hotkey_text()
            ms["enabled"] = bool(text)
            if text:
                ms["hotkey"] = text
        except ValueError as e:
            self._hotkey_error = str(e)
        oc = self.cfg.setdefault("oasys_check", {})
        oc["enabled"] = self.oasys_check.isChecked()
        oc["timeout_sec"] = int(self.oasys_wait.value())
        mp = self.cfg.setdefault("media_pause", {})
        mp["enabled"] = self.media_pause.isChecked()
        mp["resume"] = self.media_resume.isChecked()
        self.media_resume.setEnabled(mp["enabled"])
        self._live_timer.start()

    def _changed(self, *_):
        if self._loading:
            return
        self._general_dirty = True
        self._apply_general()
        self._live_timer.start()

    def _src_changed(self, *_):
        if self._loading:
            return
        self._src_dirty = True
        self._live_timer.start()

    def _apply_general(self):
        """Поля → cfg. Неверное поле не применяется; ошибки — список строк."""
        errors = []
        cfg = self.cfg
        app = cfg.setdefault("app", {})
        app["club_name"] = self.club_name.text().strip()
        app["start_minimized"] = self.start_minimized.isChecked()
        app["use_tray"] = self.use_tray.isChecked()
        sc = cfg.setdefault("schedule", {})
        sc["minute"] = int(self.sched_minute.value())
        sc["prewarm_minutes"] = int(self.prewarm.value())
        sc["attempts"] = int(self.attempts.value())
        sc["retry_interval_sec"] = int(self.retry_interval.value())
        sc["max_delay_sec"] = int(self.max_delay.value())
        sc["restore_foreground"] = self.restore_foreground.isChecked()
        sc["send_partial"] = self.send_partial.isChecked()
        st = cfg.setdefault("storage", {})
        st["screenshots_dir"] = self.shots_dir.text().strip() or "screenshots"
        st["keep_last"] = int(self.keep_last.value())
        st["image_format"] = self.image_format.currentData() or "png"
        cl = cfg.setdefault("cleanup", {})
        cl["enabled"] = self.cleanup_enabled.isChecked()
        cl["keep_hours"] = int(self.cleanup_hours.value())
        cl["time"] = self.cleanup_time.time().toString("HH:mm")
        cfg.setdefault("summary", {}).update(enabled=self.summary_enabled.isChecked(),
                                             time=self.summary_time.time().toString("HH:mm"))
        cfg.setdefault("sent_check", {}).update(enabled=self.sent_check.isChecked(),
                                                sound=self.sent_check_sound.isChecked(),
                                                minutes=self.sent_minutes.minutes())
        cfg.setdefault("dup_guard", {})["skip_if_manual"] = self.skip_if_manual.isChecked()
        cfg.setdefault("light_mode", {})["mode"] = "on" if self.light_mode.isChecked() else "off"
        tg = cfg.setdefault("tagged", {})
        tg["enabled"] = self.tg_enabled.isChecked()
        tg["caption"] = self.tg_caption.text().strip() or "Камеры за {hour}"
        tg["account_id"] = self.tg_account.text().strip()
        cfg.setdefault("watchdog", {})["enabled"] = self.watchdog_enabled.isChecked()
        cfg.setdefault("updates", {})["auto_check"] = self.updates_auto.isChecked()
        vk = cfg.setdefault("vk", {})
        vk["sender"] = "group_api" if self.r_group.isChecked() else "browser"
        peer = self.peer.text().strip()
        if peer:
            try:
                vk["peer_id"] = int(peer)
            except ValueError:
                errors.append("Номер беседы — это число, например 2000000001")
        vk["peer_title"] = self.peer_title.text().strip()
        vk["caption"] = self.caption.text()
        vk["group_token"] = self.token.text().strip()
        vk["api_version"] = self.api_version.text().strip() or "5.199"
        text = self.vb_text.toPlainText().strip()
        try:
            vb = yaml.safe_load(text) if text else {}
            if not isinstance(vb, dict):
                raise ValueError("нужен словарь «ключ: значение»")
            vb["save_memory"] = self.save_memory.isChecked()
            cfg["vk_browser"] = vb
        except (yaml.YAMLError, ValueError) as e:
            first = str(e).splitlines()[0] if str(e) else ""
            errors.append(f"Страница ВК (YAML): {first}")
            vbc = cfg.setdefault("vk_browser", {})
            if isinstance(vbc, dict):
                vbc["save_memory"] = self.save_memory.isChecked()
        self._general_errors = errors
        return errors

    def _show_saved(self, ok, text=None):
        self.saved_label.setObjectName("savedOk" if ok else "savedBad")
        self.saved_label.setText(text or ("✓ Сохранено " + time.strftime("%H:%M:%S")))
        self.header_note.hide()          # вместо «сохраняются сами» — когда сохранено
        self.saved_label.style().unpolish(self.saved_label)
        self.saved_label.style().polish(self.saved_label)

    def _save_live(self):
        problems = []
        if self._src_dirty and self.current_src is not None:
            ok, err = self._src_apply_silent()
            if not ok:
                problems.append(err)
        self._src_dirty = False
        problems += list(getattr(self, "_general_errors", None) or [])
        if getattr(self, "_hotkey_error", None):
            problems.append(self._hotkey_error)
        errors = validate(self.cfg)
        if errors:
            self.last_error = "; ".join(problems + errors)
            self._show_saved(False, "Не сохранено: " + (problems + errors)[0])
            log.warning("Настройки не сохранены: %s", self.last_error)
            return False
        general = self._general_dirty
        self._general_dirty = False
        try:
            self.main.save_config(quiet=not general)
        except Exception as e:  # noqa: BLE001
            self._show_saved(False, f"Не сохранено: {e}")
            log.warning("Не удалось сохранить настройки: %s", e)
            return False
        if general:
            pass                          # save_config уже перезапустил расписание и обновил окно
        else:
            log.info("Настройки съёмки применены: отсчёт %s, заранее %d с, ждать Oasys до %d с, пауза музыки %s",
                     f"{self.cfg['countdown']['seconds']} с" if self.cfg["countdown"]["seconds"] else "выключен",
                     self.cfg["input_lock"]["early_sec"], self.cfg["oasys_check"]["timeout_sec"],
                     "вкл." if media_settings(self.cfg)[0] else "выкл.")
        self.last_error = "; ".join(problems) or None
        if problems:
            self._show_saved(False, "Сохранено, кроме: " + problems[0])
        else:
            self._show_saved(True)
        return True

    def flush_live(self):
        """Записать отложенные изменения сейчас (закрытие программы, переход в другой раздел)."""
        if self._live_timer.isActive():
            self._live_timer.stop()
            self._save_live()

    def refresh_autostart(self):
        was, self._loading = self._loading, True
        try:
            self.autostart.setChecked(sys.platform == "win32" and startup.is_enabled())
        except Exception:  # noqa: BLE001
            log.debug("autostart", exc_info=True)
        finally:
            self._loading = was

    def reset_defaults(self, confirm=True):
        if confirm and QMessageBox.question(
                self, "Сбросить по умолчанию",
                "Вернуть исходные значения расписания, предупреждения, блокировки, проверки Oasys, паузы музыки, "
                "очистки и хранения снимков?\n\nБеседа ВК, вход, ключ сообщества и окна программ не меняются.") \
                != QMessageBox.StandardButton.Yes:
            return False
        keep_app = {k: self.cfg.get("app", {}).get(k) for k in ("club_name", "setup_done", "config_version")}
        for sec in ("countdown", "input_lock", "oasys_check", "media_pause", "cleanup", "manual_shot"):
            self.cfg[sec] = copy.deepcopy(DEFAULTS[sec])
        sc = self.cfg.setdefault("schedule", {})
        for k, v in DEFAULTS["schedule"].items():
            if k != "enabled":
                sc[k] = copy.deepcopy(v)
        self.cfg["storage"] = copy.deepcopy(DEFAULTS["storage"])
        app = self.cfg.setdefault("app", {})
        for k in ("start_minimized", "use_tray"):
            app[k] = DEFAULTS["app"][k]
        app.update({k: v for k, v in keep_app.items() if v is not None})
        self.load()
        self._general_dirty = True
        self._live_timer.stop()
        self._save_live()
        log.info("Настройки сброшены по умолчанию")
        return True

    # ---------- загрузка / сохранение ----------
    def load(self):
        """cfg → поля. Ничего не сохраняет. Вызывается при запуске, после мастера и после правки config.yaml."""
        self._live_timer.stop()
        self._loading = True
        try:
            self._load_all(self.cfg)
        finally:
            self._loading = False
        self._general_errors = []
        self._hotkey_error = None
        self._general_dirty = self._src_dirty = False
        self.cfg_path_label.setText(f"{getattr(self.main, 'cfg_path', '')}")
        self.current_src = None
        self._refresh_src_list(0)
        self._cam_refresh()

    def _load_all(self, cfg):
        vk = cfg.get("vk") or {}
        (self.r_group if vk.get("sender") == "group_api" else self.r_browser).setChecked(True)
        self.peer.setText(str(vk.get("peer_id") or ""))
        self.peer_title.setText(vk.get("peer_title") or "")
        self.caption.setText(vk.get("caption") or "")
        self.token.setText(vk.get("group_token") or "")
        self.api_version.setText(str(vk.get("api_version") or "5.199"))
        vb = dict(cfg.get("vk_browser") or {})
        self.save_memory.setChecked(bool(vb.get("save_memory", True)))
        vb_show = {k: v for k, v in vb.items() if k != "save_memory"}
        self.vb_text.setPlainText(yaml.safe_dump(vb_show, allow_unicode=True, sort_keys=False) if vb_show else "")
        app = cfg.get("app") or {}
        self._load_look(app)
        self.club_name.setText(app.get("club_name") or "")
        self.start_minimized.setChecked(bool(app.get("start_minimized", False)))
        self.use_tray.setChecked(bool(app.get("use_tray", True)))
        sc = cfg.get("schedule") or {}

        def num(v, d):
            try:
                return int(v)
            except (TypeError, ValueError):
                return d
        self.sched_minute.setValue(num(sc.get("minute"), 0))
        self.prewarm.setValue(num(sc.get("prewarm_minutes"), 5))
        self.attempts.setValue(num(sc.get("attempts"), 2))
        self.retry_interval.setValue(num(sc.get("retry_interval_sec"), 60))
        self.max_delay.setValue(num(sc.get("max_delay_sec"), 600))
        self.restore_foreground.setChecked(bool(sc.get("restore_foreground", True)))
        self.send_partial.setChecked(bool(sc.get("send_partial", True)))
        st = cfg.get("storage") or {}
        self.shots_dir.setText(str(st.get("screenshots_dir") or "screenshots"))
        self.keep_last.setValue(num(st.get("keep_last"), 300))
        fmt = str(st.get("image_format") or "png").lower()
        self.image_format.setCurrentIndex(1 if fmt in ("jpg", "jpeg") else 0)
        self.autostart.setChecked(sys.platform == "win32" and startup.is_enabled())
        self._load_capture(cfg)
        cl = cfg.get("cleanup") or {}
        self.cleanup_enabled.setChecked(bool(cl.get("enabled", True)))
        self.cleanup_hours.setValue(num(cl.get("keep_hours", DEFAULT_KEEP_HOURS), DEFAULT_KEEP_HOURS)
                                    or DEFAULT_KEEP_HOURS)
        try:
            h, m = parse_cleanup_time(str(cl.get("time") or CLEANUP_TIME))
        except ValueError:
            h, m = parse_cleanup_time(CLEANUP_TIME)
        self.cleanup_time.setTime(QTime(h, m))
        sm = cfg.get("summary") or {}
        self.summary_enabled.setChecked(bool(sm.get("enabled", False)))
        sc = cfg.get("sent_check") or {}
        self.sent_check.setChecked(bool(sc.get("enabled", False)))
        self.sent_check_sound.setChecked(bool(sc.get("sound", True)))
        self.sent_minutes.set_minutes(sc.get("minutes"))
        self.sent_minutes.setEnabled(self.sent_check.isChecked())
        self.skip_if_manual.setChecked(bool((cfg.get("dup_guard") or {}).get("skip_if_manual", True)))
        try:
            h, m = parse_cleanup_time(str(sm.get("time") or "09:00"))
        except ValueError:
            h, m = 9, 0
        self.summary_time.setTime(QTime(h, m))
        self.light_mode.setChecked(str((cfg.get("light_mode") or {}).get("mode", "off")).lower() == "on")
        tg = cfg.get("tagged") or {}
        self.tg_enabled.setChecked(bool(tg.get("enabled")))
        self.tg_caption.setText(str(tg.get("caption") or "Камеры за {hour}"))
        self.tg_account.setText(str(tg.get("account_id") or ""))
        self._tg_preview()
        self.watchdog_enabled.setChecked(bool((cfg.get("watchdog") or {}).get("enabled", True)))
        self.updates_auto.setChecked(bool((cfg.get("updates") or {}).get("auto_check", True)))
        # подписи единиц у полей с числами (сигнал valueChanged не приходит, если значение то же)
        for sp in (self.sched_minute, self.cleanup_hours, self.keep_last, self.attempts, self.retry_interval,
                   self.max_delay, self.lock_watchdog):
            sp.setSuffix(" " + sp.unit_fn(sp.value()).split(" ", 1)[1])

    def _load_capture(self, cfg):
        cd_sec, cd_op = countdown_settings(cfg)
        self.countdown_seconds.setValue(cd_sec)
        self.countdown_opacity.setValue(cd_op)
        lk = cfg.get("input_lock") or {}
        self.lock_enabled.setChecked(bool(lk.get("enabled", True)))
        self.lock_early.setValue(early_settings(cfg))
        try:
            hotkey = format_hotkey(parse_hotkey(lk.get("hotkey") or DEFAULT_HOTKEY))
        except ValueError:
            hotkey = DEFAULT_HOTKEY
        self.lock_hotkey.setKeySequence(QKeySequence(hotkey))
        self.countdown_buttons.setChecked(quickshot.buttons_enabled(cfg))
        ms_on, ms_text = quickshot.settings(cfg)
        self.manual_hotkey.setKeySequence(QKeySequence(ms_text if ms_on and ms_text else ""))
        self.lock_watchdog.setValue(clamp_watchdog(lk.get("watchdog_sec", WATCHDOG_MAX_SEC)))
        on, timeout = ready_settings(cfg)
        self.oasys_check.setChecked(on)
        self.oasys_wait.setValue(int(timeout))
        mp_on, mp_resume = media_settings(cfg)
        self.media_pause.setChecked(mp_on)
        self.media_resume.setChecked(mp_resume)
        self.media_resume.setEnabled(mp_on)

    def collect(self):
        """Все поля → cfg. Ошибка ValueError с понятным текстом (для «Проверить ключ» и т. п.)."""
        errors = self._apply_general()
        if errors:
            raise ValueError(errors[0])
        self._collect_capture()
        if self.current_src is not None:
            ok, err = self._src_apply_silent()
            if not ok:
                raise ValueError(err)

    def _manual_hotkey_text(self):
        """Поле ручного съёма → «Shift+Alt+2» или "" (поле пустое — выключено). ValueError — понятный текст."""
        seq = self.manual_hotkey.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        if not seq.strip():
            return ""
        try:
            hk = quickshot.parse(seq)
            text = quickshot.fmt(hk)
        except ValueError as e:
            raise ValueError(f"Сочетание для ручного съёма: {e}") from None
        lock = self.lock_hotkey.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        try:
            same = bool(lock) and parse_hotkey(lock) == hk
        except ValueError:
            same = False
        if same:
            raise ValueError("Сочетание для ручного съёма совпадает с сочетанием разблокировки — выберите другое")
        return text

    def _collect_capture(self):
        self._manual_hotkey_text()
        seq = self.lock_hotkey.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        try:
            format_hotkey(parse_hotkey(seq))
        except ValueError as e:
            raise ValueError(f"Сочетание для разблокировки: {e}") from None
        was, self._loading = self._loading, False
        try:
            self._apply_live()
        finally:
            self._loading = was

    def save(self):
        """Сохранить сейчас (с проверкой). Обычно не нужно — всё сохраняется само."""
        try:
            self.collect()
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Ошибка", str(e))
            return False
        errors = validate(self.cfg)
        if errors:
            QMessageBox.critical(self, "Ошибки в настройках", "\n".join(errors))
            return False
        self._live_timer.stop()
        self._general_dirty = self._src_dirty = False
        self.main.save_config()
        self._show_saved(True)
        return True

    # ---------- кнопки ----------
    def debug_send(self):
        """Пошаговая проверка на видимой странице: подсветка элементов, снимки, сведения в logs.
        «Отправить» не нажимается никогда."""
        ans = QMessageBox.question(
            self, "Проверить отправку по шагам",
            "Программа откроет беседу в разделе «ВКонтакте», подсветит поле ввода, скрепку и кнопку "
            "«Отправить» и сохранит сведения для разбора в папку logs. Ничего не отправляется.\n\n"
            "Попробовать ещё и прикрепить последние скриншоты (а потом убрать их, не отправляя)?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel)
        if ans == QMessageBox.StandardButton.Cancel:
            return
        self.main.debug_send(ans == QMessageBox.StandardButton.Yes)

    def toggle_autostart(self):
        on = self.autostart.isChecked()
        try:
            startup.set_enabled(on)
            log.info("Автозапуск %s", "включён" if on else "выключен")
        except Exception as e:  # noqa: BLE001
            self.autostart.setChecked(not on)
            QMessageBox.critical(self, "Автозапуск", str(e))

    def check_token(self):
        try:
            self.collect()
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Ошибка", str(e))
            return
        if not self.cfg["vk"].get("group_token"):
            QMessageBox.information(self, "Ключ сообщества", "Ключ сообщества не указан.")
            return
        self.main.run_bg(lambda: make_group_client(self.cfg).whoami(),
                         lambda who: QMessageBox.information(self, "Ключ работает", str(who)))

    # ---------- источники ----------
    def _refresh_src_list(self, select=None):
        self.src_list.blockSignals(True)
        self.src_list.clear()
        for s in self.cfg["sources"]:
            self.src_list.addItem(("" if s.get("enabled", True) else "[выкл] ") + s.get("name", "?"))
        self.src_list.blockSignals(False)
        if select is not None and self.cfg["sources"]:
            select = max(0, min(select, len(self.cfg["sources"]) - 1))
            self.src_list.blockSignals(True)
            self.src_list.setCurrentRow(select)
            self.src_list.blockSignals(False)
            self._load_src(select)

    def _load_src(self, i):
        was, self._loading = self._loading, True
        try:
            self._load_src_fields(i)
        finally:
            self._loading = was

    def _load_src_fields(self, i):
        self.current_src = i
        s = self.cfg["sources"][i]
        w = s.get("window") or {}
        self.src_fields["name"].setText(s.get("name", ""))
        for k in ("title_regex", "process_regex", "exclude_title_regex"):
            self.src_fields[k].setText(w.get(k, "") or "")
        self.src_fields["view_preset"].setText(str(s.get("view_preset", "") or ""))
        self.src_fields["view_preset"].setEnabled(s.get("kind") == "ivms")
        self.src_enabled.setChecked(s.get("enabled", True))
        if hasattr(self, "scn_state"):
            from .. import recorder
            self.scn_state.setText(recorder.state_text(s))
        self.steps_text.setPlainText(yaml.safe_dump({"steps": s.get("steps", []), "exit_steps": s.get("exit_steps", [])},
                                                    allow_unicode=True, sort_keys=False))
        self.win_status.setText("")

    def _on_src_select(self, row):
        if row < 0 or row == self.current_src:
            return
        if self.current_src is not None and not self.src_apply(quiet=True):
            self.src_list.blockSignals(True)
            self.src_list.setCurrentRow(self.current_src)
            self.src_list.blockSignals(False)
            return
        self._load_src(row)

    def _src_apply_silent(self):
        """Поля текущей программы → cfg. (True, None) или (False, «что не так») — без окон."""
        if self.current_src is None or self.current_src >= len(self.cfg.get("sources") or []):
            return True, None
        try:
            data = yaml.safe_load(self.steps_text.toPlainText()) or {}
            if not isinstance(data, dict):
                raise ValueError("нужны разделы steps и exit_steps")
        except (yaml.YAMLError, ValueError) as e:
            first = str(e).splitlines()[0] if str(e) else ""
            return False, f"шаги программы (YAML): {first}"
        s = self.cfg["sources"][self.current_src]
        s["name"] = self.src_fields["name"].text().strip() or "Источник"
        s["enabled"] = self.src_enabled.isChecked()
        win = dict(s.get("window") or {})
        win.update({k: self.src_fields[k].text() for k in ("title_regex", "process_regex", "exclude_title_regex")})
        s["window"] = win
        if s.get("kind") == "ivms" or "view_preset" in s:
            s["view_preset"] = self.src_fields["view_preset"].text().strip()
        s["steps"] = data.get("steps") or []
        s["exit_steps"] = data.get("exit_steps") or []
        it = self.src_list.item(self.current_src)
        if it:
            it.setText(("" if s["enabled"] else "[выкл] ") + s["name"])
        return True, None

    def src_apply(self, quiet=False):
        ok, err = self._src_apply_silent()
        if not ok:
            QMessageBox.critical(self, "Ошибка в шагах", "Исправьте " + err)
            return False
        if not quiet and self.current_src is not None:
            s = self.cfg["sources"][self.current_src]
            errs = [e for e in validate(self.cfg) if e.startswith(s["name"])]
            if errs:
                QMessageBox.warning(self, "Проверьте источник", "\n".join(errs))
        return True

    def _sources_changed(self):
        self._general_dirty = True
        self._live_timer.start()

    def src_add(self):
        self.src_apply(quiet=True)
        self.cfg["sources"].append({
            "name": f"Источник {len(self.cfg['sources']) + 1}", "enabled": True,
            "window": {"title_regex": "", "process_regex": "", "exclude_title_regex": "", "match": "any"},
            "steps": [{"type": "activate_window"}, {"type": "maximize"}, {"type": "wait", "seconds": 1},
                      {"type": "screenshot", "mode": "window"}], "exit_steps": []})
        self.current_src = None
        self._refresh_src_list(len(self.cfg["sources"]) - 1)
        self._sources_changed()

    def src_delete(self):
        if self.current_src is None:
            return
        name = self.cfg["sources"][self.current_src].get("name")
        if QMessageBox.question(self, "Удалить", f"Удалить источник «{name}»?") == QMessageBox.StandardButton.Yes:
            del self.cfg["sources"][self.current_src]
            self.current_src = None
            self._refresh_src_list(0)
            self._sources_changed()

    def src_move(self, delta):
        i = self.current_src
        if i is None or not self.src_apply(quiet=True):
            return
        j = i + delta
        if 0 <= j < len(self.cfg["sources"]):
            src = self.cfg["sources"]
            src[i], src[j] = src[j], src[i]
            self.current_src = None
            self._refresh_src_list(j)
            self._sources_changed()

    def _current(self):
        if self.current_src is None or not self.src_apply(quiet=True):
            return None
        return self.cfg["sources"][self.current_src]

    def pick_window(self):
        src = self._current()
        if not src:
            return

        def done(wins):
            from .winpicker import pick_window_rule
            rule = pick_window_rule(self, wins, src.get("name", ""))
            if rule:
                for k in ("title_regex", "process_regex"):
                    self.src_fields[k].setText(rule.get(k, ""))
                self.src_apply(quiet=True)
                src["window"]["match"] = rule.get("match", "any")
                self._sources_changed()
                log.info("%s: окно выбрано вручную (%s)", src.get("name"),
                         rule.get("process_regex") or rule.get("title_regex"))
                self.check_window()
        self.main.run_bg(lambda: self.main.backend_factory().all_windows(), done)

    def check_window(self):
        src = self._current()
        if not src:
            return
        from .capture import find_source_window
        name = src.get("name")
        self.win_status.setText("⏳ Ищу окно…")

        def done(hwnd):
            self.win_status.setText(f"✔ Окно {name} найдено" if hwnd else
                                    f"✖ {name} не найден — откройте программу или нажмите «Выбрать окно из списка…» "
                                    "(список окон записан в журнал)")
        self.main.run_bg(lambda: find_source_window(self.main.backend_factory(), src), done,
                         lambda e: self.win_status.setText("✖ " + humanize(e, name)))

    def test_source(self):
        src = self._current()
        if not src:
            return

        def run():
            backend = self.main.backend_factory()
            prev = backend.foreground()
            self.main._capture_hook(True)
            try:
                return StepRunner(backend, resolve_path).run_source(src)
            finally:
                backend.set_foreground(prev)
                self.main._capture_hook(False)
        log.info("Проверка источника «%s»…", src.get("name"))
        self.main.run_bg(run, lambda imgs: show_images(self, src.get("name"), imgs), source=src.get("name"))

    def _scn_refresh(self):
        self._cam_refresh()
        if self.current_src is not None and hasattr(self, "scn_state"):
            from .. import recorder
            self.scn_state.setText(recorder.state_text(self.cfg["sources"][self.current_src]))

    def rerecord_scenario(self):
        """3.0.0: записать новый сценарий; прошлый удаляется только после «Сохранить»."""
        src = self._current()
        if not src:
            return
        if QMessageBox.question(self, "Перезаписать сценарий",
                                f"Записать новый сценарий съёмки для «{src.get('name', '')}»?\n"
                                "Прошлая запись удалится после сохранения новой. Если отменить — "
                                "останется прежний сценарий.") != QMessageBox.StandardButton.Yes:
            return
        from .recorder_ui import RecorderDialog
        d = RecorderDialog(self, self.main, src, fresh=True)
        d.exec()
        if d.saved:
            self._load_src(self.current_src)
            self._sources_changed()
        self._scn_refresh()

    def alt_scenario(self):
        """3.0.8: второй вид кнопки (строка вида «Editing») для записанного сценария."""
        src = self._current()
        if not src:
            return
        from .recorder_ui import RecorderDialog
        d = RecorderDialog(self, self.main, src, fresh=False, auto_test=False, alt_hint=bool(src.get("recorded")))
        d.exec()
        if d.saved:
            self._load_src(self.current_src)
            self._sources_changed()
        self._scn_refresh()

    def reset_scenario(self):
        """3.0.0: удалить запись и вернуть встроенный способ съёмки."""
        src = self._current()
        if not src:
            return
        if QMessageBox.question(self, "Сброс сценария",
                                f"Удалить записанный сценарий «{src.get('name', '')}» и вернуть стандартный?"
                                ) != QMessageBox.StandardButton.Yes:
            return
        from .. import recorder
        recorder.reset(src, resolve_path)
        log.info("Сценарий «%s»: сброшен к стандартному", src.get("name"))
        self._load_src(self.current_src)
        self._sources_changed()
        self._scn_refresh()

    def capture_template(self):
        target, ok = QInputDialog.getText(self, "Шаблон кнопки", "Имя файла шаблона:", text="templates/button.png")
        if not ok or not target.strip():
            return
        target = target.strip()
        if not target.lower().endswith(".png"):
            target += ".png"
        src = self._current()

        def done(img, err):
            if err:
                QMessageBox.warning(self, "Шаблон кнопки", humanize(err, src and src.get("name")))
            elif img is not None:
                path = resolve_path(target)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                img.save(path)
                log.info("Шаблон сохранён: %s (%dx%d)", target, img.width, img.height)
                show_images(self, f"шаблон {target}", [img])
        from .main_window import capture_button
        capture_button(self.main, src, done)

