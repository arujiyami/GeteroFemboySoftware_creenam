# Original-Author: Владислав С.
# Created: 2026-10-28
"""Обратный отсчёт перед съёмкой (2.1.4): своё полупрозрачное окошко в правом нижнем углу экрана —
над часами панели задач. Не уведомление Windows: «Не беспокоить» его не прячет, в центре уведомлений
ничего не копится.

Окошко не забирает фокус и пропускает щелчки мыши насквозь (можно спокойно работать), не появляется
на панели задач и не попадает на скриншоты: Windows исключает его из снимков экрана
(WDA_EXCLUDEFROMCAPTURE), а перед самой съёмкой программа ещё и прячет его."""
import logging
import sys
from datetime import datetime

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QFontMetrics, QGuiApplication, QPainter, QPainterPath
from PySide6.QtWidgets import QHBoxLayout, QPushButton, QWidget

from ..scheduler import (DEFAULT_COUNTDOWN_OPACITY, countdown_hint, countdown_left, countdown_opacity,
                         countdown_text, countdown_visible)

log = logging.getLogger("club")

# Windows: расширенные стили окна
GWL_EXSTYLE = -20
WS_EX_TOPMOST = 0x00000008
WS_EX_TRANSPARENT = 0x00000020
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_LAYERED = 0x00080000
WS_EX_NOACTIVATE = 0x08000000
LWA_ALPHA = 0x2
WDA_EXCLUDEFROMCAPTURE = 0x11
SWP_NOSIZE, SWP_NOMOVE, SWP_NOZORDER, SWP_NOACTIVATE, SWP_FRAMECHANGED = 0x1, 0x2, 0x4, 0x10, 0x20
CLICK_THROUGH_EX = WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW

MARGIN = 12          # отступ от края рабочей области, логические пиксели (Qt сам учитывает масштаб экрана)
PAD_X, PAD_Y = 16, 10
RADIUS = 10
TICK_MS = 200


BTN_H = 28
NOW_TEXT, LATER_TEXT = "Снять сейчас", "Снять позже"
NOW_TIP = "Сделать снимки и отправить их в беседу прямо сейчас — за этот же час"
LATER_TIP = "Отложить съём и отправку на 1 минуту. Можно один раз в час"
LATER_USED_TIP = "Откладывать можно один раз в час — в этот раз уже откладывали"


def win_click_through(hwnd, interactive=False):
    """Windows: окно пропускает мышь насквозь, не активируется, не на панели задач, не на снимках экрана.
    Возвращает (стили_применены, исключено_из_снимков). Вне Windows — (False, False)."""
    if sys.platform != "win32" or not hwnd:
        return False, False
    styled = excluded = False
    try:
        import ctypes
        user32 = ctypes.WinDLL("user32")   # свой экземпляр: argtypes не влияют на остальной код
        get = getattr(user32, "GetWindowLongPtrW", None) or user32.GetWindowLongW
        put = getattr(user32, "SetWindowLongPtrW", None) or user32.SetWindowLongW
        get.restype = ctypes.c_ssize_t
        get.argtypes = [ctypes.c_void_p, ctypes.c_int]
        put.restype = ctypes.c_ssize_t
        put.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
        h = ctypes.c_void_p(int(hwnd))
        ex = int(get(h, GWL_EXSTYLE))
        was_layered = bool(ex & WS_EX_LAYERED)
        # 3.0.13: с кнопками окошко принимает щелчки (но по-прежнему не забирает фокус и не на панели задач)
        put(h, GWL_EXSTYLE, (ex | CLICK_THROUGH_EX) & ~WS_EX_TRANSPARENT if interactive else ex | CLICK_THROUGH_EX)
        if not was_layered:
            # Qt не сделал окно «слоистым» сам — без этого вызова оно стало бы невидимым
            user32.SetLayeredWindowAttributes(h, 0, 255, LWA_ALPHA)
        user32.SetWindowPos(h, None, 0, 0, 0, 0,
                            SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED)
        styled = True
        # Windows 10 2004+; на старых — ошибка, тогда окошко просто прячется перед съёмкой
        excluded = bool(user32.SetWindowDisplayAffinity(h, WDA_EXCLUDEFROMCAPTURE))
    except Exception:  # noqa: BLE001
        log.debug("countdown: стили окна", exc_info=True)
    return styled, excluded


class CountdownOverlay(QWidget):
    """Окошко «Съём скриншотов через 0:59». start(target) — показать и считать до target; само исчезает
    за долю секунды до target. stop() — убрать сразу (перед съёмкой, при «Стоп», «Отправить сейчас»…)."""

    FLAGS = (Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool
             | Qt.WindowType.WindowDoesNotAcceptFocus | Qt.WindowType.WindowTransparentForInput
             | Qt.WindowType.NoDropShadowWindowHint)

    def __init__(self, now=datetime.now, opacity=DEFAULT_COUNTDOWN_OPACITY, interactive=False):
        # 3.0.13: interactive — с кнопками «Снять сейчас» / «Снять позже» (окошко принимает щелчки)
        self.interactive = bool(interactive)
        flags = self.FLAGS
        if self.interactive:
            flags &= ~Qt.WindowType.WindowTransparentForInput
        super().__init__(None, flags)
        self.now = now
        self.target = None
        self.lock_at = None      # 2.1.5: момент блокировки ввода (target − early); окошко исчезает к нему
        self.hotkey = None
        self.hint = ""
        self.text = ""
        self.opacity = countdown_opacity(opacity)
        self.excluded = False
        self._styled = False
        for attr in (Qt.WidgetAttribute.WA_TranslucentBackground, Qt.WidgetAttribute.WA_ShowWithoutActivating,
                     Qt.WidgetAttribute.WA_TransparentForMouseEvents, Qt.WidgetAttribute.WA_NoSystemBackground):
            self.setAttribute(attr, True)
        if self.interactive:
            self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        self.on_now = self.on_later = None
        self.btn_now = self.btn_later = None
        if self.interactive:
            self.btn_row = QWidget(self)
            row = QHBoxLayout(self.btn_row)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(8)
            self.btn_now = QPushButton(NOW_TEXT, self.btn_row)
            self.btn_later = QPushButton(LATER_TEXT, self.btn_row)
            for b, tip, fn in ((self.btn_now, NOW_TIP, self._click_now), (self.btn_later, LATER_TIP, self._click_later)):
                b.setToolTip(tip)
                b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
                b.setCursor(Qt.CursorShape.PointingHandCursor)
                b.setFixedHeight(BTN_H)
                b.setStyleSheet("QPushButton{background:rgba(255,255,255,40);color:white;border:1px solid "
                                "rgba(255,255,255,90);border-radius:6px;padding:2px 10px;}"
                                "QPushButton:hover{background:rgba(255,255,255,70);}"
                                "QPushButton:disabled{color:rgba(255,255,255,110);border-color:rgba(255,255,255,40);}")
                b.clicked.connect(fn)
                row.addWidget(b)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setWindowTitle("Обратный отсчёт")
        f = QFont("Segoe UI" if sys.platform == "win32" else "DejaVu Sans")
        f.setPointSizeF(13)
        f.setBold(True)
        self.big_font = f
        s = QFont(f)
        s.setPointSizeF(8.5)
        s.setBold(False)
        self.small_font = s
        self.timer = QTimer(self)
        self.timer.setInterval(TICK_MS)
        self.timer.timeout.connect(self._tick)

    # ---------- управление ----------
    @property
    def active(self):
        return self.target is not None

    @property
    def end(self):
        """Когда окошко исчезает: в момент блокировки ввода (начала подготовки), иначе — в момент съёмки."""
        return self.lock_at or self.target

    def set_buttons(self, on_now=None, on_later=None, later_allowed=True):
        """3.0.13: что делают кнопки. on_later=None или later_allowed=False — «Снять позже» недоступна
        (уже откладывали в этот час)."""
        self.on_now, self.on_later = on_now, on_later
        if self.btn_later is not None:
            ok = bool(on_later) and later_allowed
            self.btn_later.setEnabled(ok)
            self.btn_later.setToolTip(LATER_TIP if ok else LATER_USED_TIP)

    def _click_now(self):
        fn = self.on_now
        if fn and self.active:
            self.stop()
            fn()

    def _click_later(self):
        fn = self.on_later
        if fn and self.active and self.btn_later is not None and self.btn_later.isEnabled():
            self.stop()
            fn()

    def start(self, target, hint="", opacity=None, lock_at=None, hotkey=None):
        """Показать отсчёт до съёмки target. lock_at — момент блокировки ввода: окошко исчезает к нему,
        а hotkey задан — вторая строка «Мышь и клавиатура заблокируются через N с. Разблокировать: …»
        пересчитывается каждую секунду. False — уже поздно (меньше доли секунды)."""
        if opacity is not None:
            self.opacity = countdown_opacity(opacity)
        self.target = target
        self.lock_at = lock_at if (lock_at is not None and lock_at < target) else None
        self.hotkey = hotkey
        self.hint = hint or ""
        if not countdown_visible(self.now(), self.end):
            self.stop()
            return False
        self._ensure_native()
        self._update_text(force=True)
        self._place()
        self.show()
        self.timer.start()
        log.info("Обратный отсчёт до съёмки в %s", target.strftime("%H:%M"))
        return True

    def stop(self):
        was = self.target is not None or self.isVisible()
        self.timer.stop()
        self.target = None
        self.lock_at = None
        self.hide()
        return was

    # ---------- внутреннее ----------
    def _ensure_native(self):
        # при каждом показе: Qt может пересоздать окно или сбросить стили; повторный вызов безвреден
        hwnd = int(self.winId())          # создаёт окно Windows до показа
        self._styled, self.excluded = win_click_through(hwnd, self.interactive)

    def _tick(self):
        if self.target is None or not countdown_visible(self.now(), self.end):
            self.stop()
            return
        self._update_text()

    def _update_text(self, force=False):
        now = self.now()
        text = countdown_text(countdown_left(now, self.target))
        hint = self.hint
        if self.hotkey:
            hint = countdown_hint(self.hotkey, countdown_left(now, self.end) if self.lock_at else None)
        if force or text != self.text or hint != self.hint:
            self.text = text
            self.hint = hint
            self._resize()
            self.update()

    def _resize(self):
        big, small = QFontMetrics(self.big_font), QFontMetrics(self.small_font)
        # ширина — по самому длинному тексту «9:59», чтобы окошко не «прыгало» каждую секунду
        w = big.horizontalAdvance(countdown_text(599))
        h = big.height()
        hint = countdown_hint_lines(self.hint)
        for line in hint:
            w = max(w, small.horizontalAdvance(line))
            h += small.height()
        if hint:
            h += 4
        if self.interactive:
            bw = sum(QFontMetrics(b.font()).horizontalAdvance(b.text()) + 34 for b in (self.btn_now, self.btn_later)) + 8
            w = max(w, bw)
            self.btn_row.setGeometry(PAD_X, int(h + PAD_Y + 8), int(w), BTN_H)
            h += 8 + BTN_H
        size = (int(w + 2 * PAD_X), int(h + 2 * PAD_Y))
        if (self.width(), self.height()) != size:
            self.setFixedSize(*size)
            if self.isVisible():
                self._place()

    def _place(self):
        """Правый нижний угол рабочей области основного экрана (над часами панели задач)."""
        self._resize()
        scr = QGuiApplication.primaryScreen()
        if scr is None:
            return
        g = scr.availableGeometry()
        self.move(g.right() - self.width() - MARGIN + 1, g.bottom() - self.height() - MARGIN + 1)

    def paintEvent(self, _):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(r, RADIUS, RADIUS)
        alpha = int(round(255 * self.opacity / 100))
        p.fillPath(path, QColor(18, 22, 30, alpha))
        p.setPen(QColor(255, 255, 255, min(255, alpha + 60)))
        p.drawPath(path)
        p.setPen(QColor(255, 255, 255))
        p.setFont(self.big_font)
        big = QFontMetrics(self.big_font)
        y = PAD_Y + big.ascent()
        p.drawText(PAD_X, y, self.text)
        y += big.descent()
        hint = countdown_hint_lines(self.hint)
        if hint:
            p.setFont(self.small_font)
            small = QFontMetrics(self.small_font)
            p.setPen(QColor(225, 230, 238))
            y += 4
            for line in hint:
                y += small.ascent()
                p.drawText(PAD_X, y, line)
                y += small.descent()
        p.end()


def countdown_hint_lines(hint):
    """Подсказку о блокировке — в две короткие строки, чтобы окошко оставалось небольшим."""
    if not hint:
        return []
    head, sep, tail = hint.partition(". ")
    return [head + "." if sep else head] + ([tail] if tail else [])
