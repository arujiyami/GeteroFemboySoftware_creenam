# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.12: номер (id) своего сообщения ВК за час — logs/sent_msg_ids.json.

Сразу после отправки программа читает со страницы ВК id своего нового сообщения и запоминает его на этот
час. Перед повтором и при проверке беседы своё сообщение ищется сначала по id: есть в беседе — своё,
повторно не отправляется. Формат и размер монитора, подпись, время — не нужны.
Если ВК подтвердил доставку (галочка), а сообщения с этим id в беседе уже нет — его удалили; автоматически
оно повторно НЕ отправляется. Если id прочитать не удалось — проверка по скрытой метке и сходству картинок."""
import json
import logging
import os
import threading

log = logging.getLogger("club")
KEEP = 72
_lock = threading.Lock()


def path(root):
    return os.path.join(root, "logs", "sent_msg_ids.json")


def key(dt):
    return dt.strftime("%Y-%m-%d %H")


def _read(p):
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save(root, when, mid, ok, peer=None):
    """Запомнить id своего сообщения за час when. ok — ВК подтвердил доставку (галочка)."""
    if not mid:
        return
    p = path(root)
    with _lock:
        d = _read(p)
        cur = d.get(key(when)) or {}
        if cur.get("ok") and not ok and cur.get("mid") != mid:
            return          # подтверждённое не затираем неподтверждённым
        d[key(when)] = {"mid": str(mid), "ok": bool(ok)}
        if peer:
            d[key(when)]["peer"] = int(peer)
        for k in sorted(d)[:-KEEP]:
            d.pop(k, None)
        try:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            tmp = p + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=1)
            os.replace(tmp, p)
        except OSError:
            log.debug("msgids", exc_info=True)


def get(root, when, peer=None):
    """→ {'mid': ..., 'ok': bool[, 'peer': ...]} или None. id сообщения ВК — номер внутри беседы, поэтому
    запись другой беседы (сменили peer_id) не подходит."""
    v = _read(path(root)).get(key(when))
    if not (isinstance(v, dict) and v.get("mid")):
        return None
    if peer and v.get("peer") and int(v["peer"]) != int(peer):
        return None
    return v
