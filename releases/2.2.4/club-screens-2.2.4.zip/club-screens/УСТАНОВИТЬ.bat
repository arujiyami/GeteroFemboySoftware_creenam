@echo off
rem Original-Author: Vladislav S.
rem Created: 2026-10-28
chcp 65001 >nul
setlocal EnableExtensions
title Установка: Скриншоты клуба
cd /d "%~dp0program"
echo ==================================================
echo    Установка программы «Скриншоты клуба»
echo ==================================================
echo.
call :findpy
if defined PY goto havepy
echo Python не найден - он нужен для работы программы.
echo.
echo Нажмите Enter, чтобы установить Python автоматически - нужен интернет.
echo Чтобы отменить, просто закройте это окно.
pause >nul
call :installpy
call :findpy
if defined PY goto havepy
echo.
echo Не получилось установить Python автоматически.
echo Сейчас откроется сайт python.org. Скачайте и установите Python 3.12 (64-bit),
echo в первом окне установщика отметьте галочку "Add python.exe to PATH".
echo Потом запустите этот файл УСТАНОВИТЬ.bat ещё раз.
start "" "https://www.python.org/downloads/"
pause
exit /b 1

:havepy
echo [1/4] Python найден.
if exist ".venv\Scripts\pythonw.exe" goto deps
echo [2/4] Готовлю папку программы...
%PY% -m venv .venv
if errorlevel 1 goto venvfail

:deps
echo [3/4] Скачиваю нужные библиотеки.
echo       Встроенный браузер (PySide6 / Qt WebEngine) весит несколько сотен МБ -
echo       при первой установке это может занять 5-15 минут. Не закрывайте окно.
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q --upgrade pip >nul 2>nul
".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto pipfail
rem старые библиотеки прошлой версии больше не нужны
".venv\Scripts\python.exe" -m pip uninstall -y -q playwright pystray pyautogui >nul 2>nul
:shortcut
echo [4/4] Создаю ярлык «Скриншоты клуба» на рабочем столе...
".venv\Scripts\python.exe" main.py --create-shortcut
if errorlevel 1 echo Ярлык создать не удалось - запускайте программу файлом program\run.bat
echo.
echo ==================================================
echo    Готово! Программа установлена.
echo    Дальше запускайте её ярлыком «Скриншоты клуба» на рабочем столе.
echo.
echo    При запуске Windows спросит «Разрешить этому приложению вносить
echo    изменения?» - нажмите «Да». Права администратора нужны, чтобы
echo    программа могла нажимать кнопки в iVMS-4200 и Oasys.
echo ==================================================
echo.
set "ANS="
set /p ANS=Запустить программу сейчас? Enter - да, N и Enter - нет: 
if /i "%ANS%"=="N" exit /b 0
if /i "%ANS%"=="Н" exit /b 0
start "" ".venv\Scripts\pythonw.exe" main.py
exit /b 0

:venvfail
echo.
echo Не удалось подготовить папку программы.
echo Попробуйте переустановить Python с python.org и запустить этот файл снова.
pause
exit /b 1

:pipfail
echo.
echo Не удалось скачать библиотеки. Проверьте интернет и запустите этот файл ещё раз.
pause
exit /b 1

rem ---------- поиск Python 3.9-3.13, 64-бит (для PySide6) ----------
:findpy
set "PY="
set "PYCHK=import sys; sys.exit(0 if (3,9)<=sys.version_info[:2]<=(3,13) and sys.maxsize>2**32 else 1)"
py -3.12 -c "%PYCHK%" >nul 2>nul
if not errorlevel 1 (set "PY=py -3.12"& exit /b 0)
py -3 -c "%PYCHK%" >nul 2>nul
if not errorlevel 1 (set "PY=py -3"& exit /b 0)
python -c "%PYCHK%" >nul 2>nul
if not errorlevel 1 (set "PY=python"& exit /b 0)
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%ProgramFiles%\Python312\python.exe" "%ProgramFiles%\Python313\python.exe") do call :trypy %%P
exit /b 0

:trypy
if defined PY exit /b 0
if not exist "%~1" exit /b 0
"%~1" -c "%PYCHK%" >nul 2>nul
if not errorlevel 1 set PY="%~1"
exit /b 0

rem ---------- установка Python ----------
:installpy
where winget >nul 2>nul
if errorlevel 1 goto pyorg
echo Устанавливаю Python через winget, подождите...
winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" exit /b 0
:pyorg
echo Скачиваю установщик Python с python.org...
set "PYINST=%TEMP%\python-3.12.10-amd64.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe' -OutFile (Join-Path $env:TEMP 'python-3.12.10-amd64.exe')"
if not exist "%PYINST%" exit /b 1
echo Устанавливаю Python, подождите 1-2 минуты...
"%PYINST%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=0 Include_test=0
del "%PYINST%" >nul 2>nul
exit /b 0
