# Original-Author: Владислав С.
# Created: 2026-10-28
"""Служебные данные сборки (вторая копия сведений об исходном авторе — для окна «О программе»)."""
BUILD_DATE = "2026-10-28"
# base64(UTF-8) — сверяется с ORIGINAL_AUTHOR_SHA256 из app/about.py
ORIGIN = "0JLQu9Cw0LTQuNGB0LvQsNCyINChLg=="
