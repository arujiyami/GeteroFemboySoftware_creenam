# Original-Author: Владислав С.
# Created: 2026-10-28
"""Вход в ВК: учёт cookie сессии (без значений) и решение «вошли / не вошли» по cookie и странице.

Cookie запоминаются с самого запуска профиля: cookie, прочитанные с диска, тоже приходят через
QWebEngineCookieStore.cookieAdded. Учитываются по (домен, имя, путь) — удаление cookie на одном
домене (например, при обновлении сессии или на vk.ru) не «стирает» такую же на vk.com."""

SESSION_COOKIES = ("remixsid", "remixnsid")
SESSION_DOMAINS = ("vk.com", "vk.ru")
LOGOUT_DEBOUNCE_SEC = 10


def base_domain(domain):
    """'.m.vk.com' → 'vk.com'; чужие домены → ''."""
    d = (domain or "").lstrip(".").lower()
    for base in SESSION_DOMAINS:
        if d == base or d.endswith("." + base):
            return base
    return ""


class CookieTracker:
    """Какие cookie есть у профиля (только имена, значения не храним и не пишем в журнал)."""

    def __init__(self):
        self._jar = {}            # (домен, имя, путь) → True

    def add(self, domain, name, path="/"):
        self._jar[((domain or "").lower(), name, path or "/")] = True

    def remove(self, domain, name, path="/"):
        self._jar.pop(((domain or "").lower(), name, path or "/"), None)

    def names_by_domain(self):
        out = {}
        for d, n, _ in self._jar:
            out.setdefault(d, set()).add(n)
        return {d: sorted(v) for d, v in sorted(out.items())}

    def names(self, session_only=True):
        """{имя: True} — для проверки входа; session_only — только домены vk.com / vk.ru."""
        return {n: True for d, n, _ in self._jar if not session_only or base_domain(d)}

    def has_session(self, names=SESSION_COOKIES):
        names = set(names or SESSION_COOKIES)
        return any(n in names and base_domain(d) for d, n, _ in self._jar)


def decide(cookie, logged_in, login_form):
    """cookie: True / False / None (не проверяли); logged_in, login_form — сколько видно признаков.

    Вошли, если есть cookie сессии ИЛИ признаки входа на странице, и при этом не видна форма входа.
    Cookie и признаки входа вместе — вошли, даже если на странице есть кнопка «Войти» (например, в
    рекламе или виджете)."""
    if cookie and logged_in:
        return True
    if login_form:
        return False
    return bool(cookie or logged_in)
