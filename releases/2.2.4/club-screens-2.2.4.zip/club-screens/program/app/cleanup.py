# Original-Author: Владислав С.
# Created: 2026-10-28
"""Ежедневная уборка: старые скриншоты и файлы для разбора ошибок.

Удаляет только свои файлы — в своих папках (screenshots и logs) и только по своим шаблонам имён.
Никогда не трогает файлы текущей или последней (ожидающей повтора) отправки. Занятые файлы
пропускает молча. Чистые функции — для тестов; планирование — в scheduler.HourlyScheduler."""
import logging
import math
import os
import re
import time
from datetime import timedelta

log = logging.getLogger("club")

DEFAULT_TIME = "12:30"
DEFAULT_KEEP_HOURS = 24
FAILED_KEEP_HOURS = 72          # скриншоты неудачных отправок — 3 дня
DIAG_KEEP_HOURS = 72            # файлы для разбора (logs/vk_*) — 3 дня
LOGS_CAP_BYTES = 50 * 1024 * 1024
STARTUP_DELAY_SEC = 120
SEND_TIMEOUT_SEC = 90
CAPTURE_SEC = 60
FAILED_SUFFIX = "_failed.marker"

# 2026-10-28_06-00_01_Oasys.png, 2026-10-28_06-00-15_test_11_Камеры.jpg
SHOT_RE = re.compile(r"^(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}(?:-\d{2}_test)?)_\d{2}_[\w\-]+\.(?:png|jpe?g)$",
                     re.IGNORECASE | re.UNICODE)
MARKER_RE = re.compile(r"^(\d{4}-\d{2}-\d{2}_\d{2}-\d{2})" + re.escape(FAILED_SUFFIX) + "$")
# logs/vk_dom_send_20261028_060012.html, logs/vk_send_failed_20261028_060012.png
DIAG_RE = re.compile(r"^vk_[\w\-]+_\d{8}_\d{6}\.(?:html|png)$", re.IGNORECASE | re.UNICODE)


def shot_stamp(name):
    m = SHOT_RE.match(name)
    return m.group(1) if m else None


def parse_time(text, default=DEFAULT_TIME):
    """«12:30» → (12, 30). Ошибка — ValueError с понятным текстом."""
    m = re.fullmatch(r"\s*(\d{1,2})[:.](\d{2})\s*", str(text if text is not None else default))
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
        raise ValueError(f"время уборки «{text}» — нужно ЧЧ:ММ, например {DEFAULT_TIME}")
    return int(m.group(1)), int(m.group(2))


def busy_minutes(sched):
    """Минуты часа, когда идёт цикл: от «заранее открыть беседу» до конца отправки с повтором."""
    minute = int(sched.get("minute", 0) or 0) % 60
    prewarm = max(0, min(15, int(sched.get("prewarm_minutes", 5) or 0)))
    attempts = min(2, max(1, int(sched.get("attempts", 2) or 1)))
    retry = max(180, int(sched.get("retry_interval_sec", 180) or 180))
    tail = retry * (attempts - 1) + (CAPTURE_SEC + SEND_TIMEOUT_SEC) * attempts
    start = minute - max(prewarm, 1)
    end = minute + math.ceil(tail / 60)
    return {m % 60 for m in range(start, end + 1)}


def clamp_time(text, sched):
    """Время уборки вне окна цикла. Если попало в окно — :30 того же часа, а если и оно занято —
    первая свободная минута после окна. Возвращает (часы, минуты, сдвинуто ли)."""
    h, m = parse_time(text)
    busy = busy_minutes(sched)
    if m not in busy:
        return h, m, False
    if 30 not in busy:
        return h, 30, True
    for k in range(1, 60):
        mm = (m + k) % 60
        if mm not in busy:
            return (h + (1 if m + k >= 60 else 0)) % 24, mm, True
    return h, m, False  # не бывает: окно короче часа


def in_busy_window(now, sched):
    return now.minute in busy_minutes(sched)


def next_daily(now, h, m):
    t = now.replace(hour=h, minute=m, second=0, microsecond=0)
    return t if t > now else t + timedelta(days=1)


def _remove(path):
    try:
        size = os.path.getsize(path)
        os.remove(path)
        return size
    except (PermissionError, FileNotFoundError):
        return None   # занят или уже удалён — молча пропускаем
    except OSError:
        return None


def mark_failed(folder, stamp):
    """Отметка «отправка не удалась» — такие скриншоты хранятся 3 дня."""
    try:
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, stamp + FAILED_SUFFIX), "w", encoding="utf-8") as f:
            f.write("")
    except OSError:
        log.debug("mark_failed", exc_info=True)


def clean_screenshots(folder, keep_hours, protect=(), now=None, keep_last=0):
    """Удаляет скриншоты старше keep_hours (неудачные — старше 3 дней). Файлы с отметками времени
    из protect и самый свежий цикл не трогает. keep_last > 0 — ещё и предел по количеству.
    Возвращает (файлов, байт)."""
    if not os.path.isdir(folder):
        return 0, 0
    now = now if now is not None else time.time()
    protect = set(p for p in protect if p)
    names = os.listdir(folder)
    failed = {MARKER_RE.match(n).group(1) for n in names if MARKER_RE.match(n)}
    shots = []
    for n in names:
        stamp = shot_stamp(n)
        if stamp is None:
            continue
        p = os.path.join(folder, n)
        try:
            shots.append((os.path.getmtime(p), p, stamp))
        except OSError:
            continue
    if shots:
        protect.add(max(shots)[2])   # самый свежий цикл — его могут отправлять вручную
    shots.sort(reverse=True)
    count = size = 0
    kept = 0
    for mtime, p, stamp in shots:
        if stamp in protect or any(stamp.startswith(x) for x in protect):
            kept += 1
            continue
        hours = FAILED_KEEP_HOURS if stamp[:16] in failed else keep_hours
        too_old = now - mtime > hours * 3600
        too_many = keep_last and kept >= keep_last and stamp[:16] not in failed
        if too_old or too_many:
            s = _remove(p)
            if s is not None:
                count += 1
                size += s
                continue
        kept += 1
    # отметки неудачи: когда их скриншотов не осталось и прошло 3 дня
    left = {shot_stamp(n)[:16] for n in os.listdir(folder) if shot_stamp(n)}
    for stamp in failed - left - protect:
        p = os.path.join(folder, stamp + FAILED_SUFFIX)
        try:
            if now - os.path.getmtime(p) > FAILED_KEEP_HOURS * 3600:
                _remove(p)
        except OSError:
            pass
    return count, size


def clean_logs(folder, log_file=None, now=None, keep_hours=DIAG_KEEP_HOURS, cap_bytes=LOGS_CAP_BYTES):
    """Файлы для разбора (vk_*.html/png) старше 3 дней; затем, если папка logs больше cap_bytes, —
    самые старые vk_* и старые части журнала (club-screens.log.1 …). Текущий журнал не трогаем."""
    if not os.path.isdir(folder):
        return 0, 0
    now = now if now is not None else time.time()
    base = os.path.basename(log_file) if log_file else None
    count = size = 0
    own = []     # (mtime, path, size)
    total = 0
    for n in os.listdir(folder):
        p = os.path.join(folder, n)
        try:
            st = os.stat(p)
        except OSError:
            continue
        if not os.path.isfile(p):
            continue
        total += st.st_size
        is_diag = bool(DIAG_RE.match(n))
        is_rotated = bool(base and re.fullmatch(re.escape(base) + r"\.\d{1,2}", n))
        if not (is_diag or is_rotated):
            continue
        if is_diag and now - st.st_mtime > keep_hours * 3600:
            s = _remove(p)
            if s is not None:
                count += 1
                size += s
                total -= s
                continue
        own.append((st.st_mtime, p, st.st_size))
    own.sort()
    for _mtime, p, _sz in own:
        if total <= cap_bytes:
            break
        s = _remove(p)
        if s is not None:
            count += 1
            size += s
            total -= s
    return count, size


def run_cleanup(cfg, resolve, protect=()):
    """Одна уборка по настройкам. Возвращает (файлов, байт). Пишет одну строку в журнал."""
    st = cfg.get("storage") or {}
    cl = cfg.get("cleanup") or {}
    shots_dir = resolve(st.get("screenshots_dir") or "screenshots")
    log_file = resolve(st.get("log_file") or "logs/club-screens.log")
    c1, s1 = clean_screenshots(shots_dir, float(cl.get("keep_hours", DEFAULT_KEEP_HOURS) or DEFAULT_KEEP_HOURS),
                               protect, keep_last=int(st.get("keep_last", 0) or 0))
    c2, s2 = clean_logs(os.path.dirname(log_file), log_file)
    log.info("Уборка: удалено скриншотов %d, файлов для разбора %d, освобождено %.1f МБ",
             c1, c2, (s1 + s2) / 1048576)
    return c1 + c2, s1 + s2


def stamp_of(dt):
    return dt.strftime("%Y-%m-%d_%H-%M")

