# Original-Author: Владислав С.
# Created: 2026-10-28
"""Блокировка мыши и клавиатуры на время съёмки Oasys/iVMS — платформенно-независимая часть.

Сами перехватчики (WH_MOUSE_LL / WH_KEYBOARD_LL) живут в app/backend_win.py; здесь — разбор сочетания
клавиш, решение «пропустить или проглотить событие», отслеживание сочетания разблокировки и сторож
(watchdog), который снимает блокировку сам, что бы ни случилось. Всё это проверяется тестами без Windows.

Принцип: глотаем только «настоящие» нажатия пользователя. События с флагом INJECTED (их создаёт
SendInput — так программа сама нажимает кнопки в Oasys/iVMS) пропускаются. Отпускания клавиш и кнопок
мыши тоже всегда пропускаются, чтобы ничего не «залипло». BlockInput не используется.
Ctrl+Alt+Del перехватить нельзя — он всегда работает как аварийный выход."""
import logging
import threading
import time

log = logging.getLogger("club")

DEFAULT_HOTKEY = "Ctrl+Alt+Q"
DEFAULT_WATCHDOG_SEC = 30
# 2.1.5: сторож — жёсткий потолок 30 секунд на всю блокировку (ранний старт + ожидание Oasys + съёмка).
WATCHDOG_MIN_SEC, WATCHDOG_MAX_SEC = 5, 30
HARD_CAP_SEC = 30

# ---- флаги и сообщения хуков Windows (значения из WinUser.h) ----
LLMHF_INJECTED = 0x01
LLKHF_INJECTED = 0x10
LLKHF_UP = 0x80
WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0100, 0x0101, 0x0104, 0x0105
WM_MOUSEMOVE = 0x0200
WM_LBUTTONUP, WM_RBUTTONUP, WM_MBUTTONUP, WM_XBUTTONUP = 0x0202, 0x0205, 0x0208, 0x020C
KEY_DOWN_MSGS = (WM_KEYDOWN, WM_SYSKEYDOWN)
KEY_UP_MSGS = (WM_KEYUP, WM_SYSKEYUP)
MOUSE_UP_MSGS = (WM_LBUTTONUP, WM_RBUTTONUP, WM_MBUTTONUP, WM_XBUTTONUP)

# ---- виртуальные коды клавиш ----
MOD_VKS = {"ctrl": (0x11, 0xA2, 0xA3), "alt": (0x12, 0xA4, 0xA5), "shift": (0x10, 0xA0, 0xA1),
           "win": (0x5B, 0x5C)}
MOD_ALIASES = {"ctrl": "ctrl", "control": "ctrl", "ctl": "ctrl", "alt": "alt", "shift": "shift",
               "win": "win", "meta": "win", "super": "win", "windows": "win"}
MOD_ORDER = ("ctrl", "alt", "shift", "win")
MOD_TITLES = {"ctrl": "Ctrl", "alt": "Alt", "shift": "Shift", "win": "Win"}
KEY_VKS = {"esc": 0x1B, "escape": 0x1B, "enter": 0x0D, "return": 0x0D, "tab": 0x09, "space": 0x20,
           "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "insert": 0x2D, "ins": 0x2D, "home": 0x24,
           "end": 0x23, "pageup": 0x21, "pgup": 0x21, "pagedown": 0x22, "pgdown": 0x22, "left": 0x25,
           "up": 0x26, "right": 0x27, "down": 0x28, "pause": 0x13, "scrolllock": 0x91,
           "printscreen": 0x2C, "print": 0x2C}
KEY_VKS.update({f"f{i}": 0x6F + i for i in range(1, 25)})
KEY_TITLES = {0x1B: "Esc", 0x0D: "Enter", 0x09: "Tab", 0x20: "Space", 0x08: "Backspace", 0x2E: "Del",
              0x2D: "Ins", 0x24: "Home", 0x23: "End", 0x21: "PgUp", 0x22: "PgDown", 0x25: "Left",
              0x26: "Up", 0x27: "Right", 0x28: "Down", 0x13: "Pause", 0x91: "ScrollLock", 0x2C: "Print"}
KEY_TITLES.update({0x6F + i: f"F{i}" for i in range(1, 25)})


class Hotkey:
    """Сочетание: набор модификаторов + одна обычная клавиша (виртуальный код)."""

    def __init__(self, mods, vk):
        self.mods = frozenset(mods)
        self.vk = int(vk)

    def __eq__(self, other):
        return isinstance(other, Hotkey) and (self.mods, self.vk) == (other.mods, other.vk)

    def __hash__(self):
        return hash((self.mods, self.vk))

    def __repr__(self):
        return f"Hotkey({format_hotkey(self)!r})"

    def __str__(self):
        return format_hotkey(self)


def _key_vk(name):
    k = name.strip().lower()
    if k in KEY_VKS:
        return KEY_VKS[k]
    if len(k) == 1 and ("a" <= k <= "z" or k.isdigit()):
        return ord(k.upper())
    raise ValueError(f"Неизвестная клавиша «{name}» в сочетании")


def parse_hotkey(text):
    """«Ctrl+Alt+Q» (так же пишет QKeySequence.toString) → Hotkey. Ошибка — ValueError с понятным текстом.
    Нужен хотя бы Ctrl, Alt или Win и ровно одна обычная клавиша — чтобы случайно не нажать."""
    text = str(text or "").strip()
    if not text:
        raise ValueError("Сочетание клавиш для разблокировки не задано")
    if "," in text:  # QKeySequence может хранить несколько аккордов: «Ctrl+Q, Ctrl+W» — берём только один
        raise ValueError("Нужно одно сочетание клавиш, например Ctrl+Alt+Q")
    parts = [p for p in text.replace(" ", "").split("+")]
    if text.endswith("++"):  # «Ctrl++»
        parts = parts[:-2] + ["+"]
    mods, keys = set(), []
    for p in parts:
        if not p:
            raise ValueError(f"Не понимаю сочетание «{text}»")
        low = p.lower()
        if low in MOD_ALIASES:
            mods.add(MOD_ALIASES[low])
        else:
            keys.append(p)
    if len(keys) != 1:
        raise ValueError(f"В сочетании «{text}» должна быть ровно одна обычная клавиша (например Ctrl+Alt+Q)")
    if not mods & {"ctrl", "alt", "win"}:
        raise ValueError(f"Сочетание «{text}» слишком простое — добавьте Ctrl или Alt (например Ctrl+Alt+Q)")
    return Hotkey(mods, _key_vk(keys[0]))


def format_hotkey(hk):
    if isinstance(hk, str):
        hk = parse_hotkey(hk)
    key = KEY_TITLES.get(hk.vk) or chr(hk.vk)
    return "+".join([MOD_TITLES[m] for m in MOD_ORDER if m in hk.mods] + [key])


def hotkey_text(text, default=DEFAULT_HOTKEY):
    """Красивое название сочетания для подсказок; при ошибке — сочетание по умолчанию."""
    try:
        return format_hotkey(parse_hotkey(text))
    except ValueError:
        return default


def clamp_watchdog(sec):
    try:
        sec = int(sec)
    except (TypeError, ValueError):
        sec = DEFAULT_WATCHDOG_SEC
    return max(WATCHDOG_MIN_SEC, min(WATCHDOG_MAX_SEC, sec))


def effective_watchdog(watchdog_sec, early_sec=0, ready_timeout_sec=0, margin_sec=5):
    """Сколько секунд реально держать блокировку не дольше: хватает на ранний старт + ожидание Oasys + съёмку
    (early + ready_timeout + margin), но никогда не больше HARD_CAP_SEC (30 с) — потом ввод снимается всегда."""
    base = clamp_watchdog(watchdog_sec)
    try:
        need = int(early_sec or 0) + int(ready_timeout_sec or 0) + int(margin_sec or 0)
    except (TypeError, ValueError):
        need = 0
    return max(WATCHDOG_MIN_SEC, min(HARD_CAP_SEC, max(base, need)))


# ---- решения «пропустить / проглотить» (чистые функции) ----
def is_injected_mouse(flags):
    return bool(int(flags) & LLMHF_INJECTED)


def is_injected_key(flags):
    return bool(int(flags) & LLKHF_INJECTED)


def mouse_should_block(msg, flags):
    """Глотать ли событие мыши: да, если это пользователь; отпускание кнопки — всегда пропускаем."""
    if is_injected_mouse(flags):
        return False
    return msg not in MOUSE_UP_MSGS


def key_should_block(msg, flags):
    """Глотать ли событие клавиатуры: да, если это нажатие пользователя; отпускание — пропускаем."""
    if is_injected_key(flags):
        return False
    if msg in KEY_UP_MSGS or int(flags) & LLKHF_UP:
        return False
    return True


class HotkeyTracker:
    """Сам помнит, какие клавиши пользователь держит (система их не видит — мы их глотаем),
    и говорит, когда нажато сочетание разблокировки."""

    def __init__(self, hotkey):
        self.hotkey = hotkey
        self.down = set()

    def _mod_down(self, mod):
        return any(vk in self.down for vk in MOD_VKS[mod])

    def feed(self, msg, vk, flags=0):
        """Событие от пользователя (не injected). True — нажато сочетание разблокировки."""
        up = msg in KEY_UP_MSGS or int(flags) & LLKHF_UP
        if up:
            self.down.discard(vk)
            return False
        self.down.add(vk)
        return vk == self.hotkey.vk and all(self._mod_down(m) for m in self.hotkey.mods)


_ACTIVE = set()
_ACTIVE_LOCK = threading.Lock()


def release_all(reason="exit"):
    """Снять все блокировки (выход из программы, atexit). Безопасно вызывать сколько угодно раз."""
    with _ACTIVE_LOCK:
        items = list(_ACTIVE)
    for b in items:
        b.release(reason)


class InputBlocker:
    """Блокировка на время съёмки.

    hook_factory(on_mouse, on_key) -> объект с start() -> bool и stop(); on_mouse(msg, flags) и
    on_key(msg, vk, flags) возвращают True, если событие надо проглотить.
    Использование:  with InputBlocker(...) as b: ...  — снимается всегда, даже при ошибке."""

    def __init__(self, hook_factory, hotkey=DEFAULT_HOTKEY, watchdog_sec=DEFAULT_WATCHDOG_SEC,
                 on_release=None, timer_factory=threading.Timer, clock=time.monotonic):
        self.hotkey = parse_hotkey(hotkey) if isinstance(hotkey, str) else hotkey
        self.watchdog_sec = clamp_watchdog(watchdog_sec)
        self.hook_factory = hook_factory
        self.on_release = on_release
        self.timer_factory = timer_factory
        self.clock = clock
        self.tracker = HotkeyTracker(self.hotkey)
        self.active = False
        self.reason = None
        self.started_at = None
        self._hook = None
        self._timer = None
        self._lock = threading.Lock()

    # --- колбэки хука (вызываются в потоке хука, должны быть быстрыми) ---
    def on_mouse(self, msg, flags):
        if not self.active:
            return False
        return mouse_should_block(msg, flags)

    def on_key(self, msg, vk, flags):
        if not self.active or is_injected_key(flags):
            return False
        if self.tracker.feed(msg, vk, flags):
            self.release("hotkey")
            return True   # само нажатие сочетания тоже глотаем, чтобы оно не попало в Oasys/iVMS
        return key_should_block(msg, flags)

    # --- управление ---
    def start(self):
        """Включить блокировку. False — не удалось (тогда съёмка просто идёт без блокировки)."""
        with self._lock:
            if self.active:
                return True
            try:
                hook = self.hook_factory(self.on_mouse, self.on_key)
                self.active = True   # до start(): первые же события должны обрабатываться
                ok = hook.start()
            except Exception as e:  # noqa: BLE001
                self.active = False
                log.warning("Не удалось заблокировать мышь и клавиатуру: %s — снимаю без блокировки", e)
                return False
            if not ok:
                self.active = False
                try:
                    hook.stop()
                except Exception:  # noqa: BLE001
                    pass
                log.warning("Не удалось заблокировать мышь и клавиатуру — снимаю без блокировки")
                return False
            self._hook = hook
            self.reason = None
            self.started_at = self.clock()
            self._timer = self.timer_factory(self.watchdog_sec, lambda: self.release("watchdog"))
            try:
                self._timer.daemon = True
            except AttributeError:
                pass
            self._timer.start()
        with _ACTIVE_LOCK:
            _ACTIVE.add(self)
        log.info("Мышь и клавиатура заблокированы на время съёмки (разблокировать: %s, сама снимется "
                 "не позже чем через %d с)", format_hotkey(self.hotkey), self.watchdog_sec)
        return True

    def release(self, reason="done"):
        """Снять блокировку. Повторный вызов ничего не делает. reason: done | hotkey | watchdog | error | exit."""
        with self._lock:
            if not self.active and self._hook is None:
                return False
            self.active = False
            self.reason = reason
            hook, self._hook = self._hook, None
            timer, self._timer = self._timer, None
        if timer is not None:
            try:
                timer.cancel()
            except Exception:  # noqa: BLE001
                pass
        if hook is not None:
            try:
                hook.stop()
            except Exception:  # noqa: BLE001
                log.exception("Снятие блокировки ввода")
        with _ACTIVE_LOCK:
            _ACTIVE.discard(self)
        if reason == "hotkey":
            log.info("Пользователь разблокировал мышь и клавиатуру (%s) — съёмка продолжается",
                     format_hotkey(self.hotkey))
        elif reason == "watchdog":
            log.warning("Блокировка мыши и клавиатуры снята автоматически через %d с (защита)", self.watchdog_sec)
        else:
            log.info("Мышь и клавиатура разблокированы")
        if self.on_release:
            try:
                self.on_release(reason)
            except Exception:  # noqa: BLE001
                log.debug("on_release", exc_info=True)
        return True

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.release("error" if exc_type else "done")
        return False
