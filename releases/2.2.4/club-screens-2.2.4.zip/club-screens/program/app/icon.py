# Original-Author: Владислав С.
# Created: 2026-10-28
"""Значок программы (камера) — картинка PIL, без зависимостей от окна."""
from PIL import Image, ImageDraw

BLUE = "#2f6fd8"


def camera_image(color=BLUE, size=64, badge=None):
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((4, 14, 60, 54), 8, fill=color)
    d.rectangle((22, 8, 42, 16), fill=color)
    d.ellipse((20, 20, 44, 46), fill="white")
    d.ellipse((26, 26, 38, 40), fill=color)
    if badge:
        d.ellipse((40, 38, 63, 61), fill=badge, outline="white", width=3)
    return img if size == 64 else img.resize((size, size), Image.LANCZOS)
