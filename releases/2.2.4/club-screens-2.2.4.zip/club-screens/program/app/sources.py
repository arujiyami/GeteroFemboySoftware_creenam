# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: какие программы снимать. Oasys и iVMS-4200 мастер находит сам среди запущенных окон; вместо них
или в дополнение можно выбрать ЛЮБУЮ другую запущенную программу (окно) — она станет источником kind=custom."""
import copy
import re

from . import winmatch

KNOWN = {
    "oasys": {"label": "Oasys", "process_regex": r"(?i)^oasys\.admin\.exe$", "title_regex": "(?i)oasys"},
    "ivms": {"label": "iVMS-4200", "process_regex": "(?i)^ivms-4200", "title_regex": "(?i)ivms-4200"},
}
EXCLUDE = ("(?i)(chrome|firefox|яндекс|yandex|edge|opera|вконтакте|telegram|клуб-скриншоты|скриншоты клуба)")
# ВК принимает до 10 картинок в одном сообщении; оставляем запас под очередь без интернета
MAX_SOURCES = 4


def guess_kind(src):
    """Тип старого источника (до 2.2.0 поля kind не было) — по имени и правилу окна."""
    text = " ".join([str(src.get("name", ""))] + [str(v) for v in (src.get("window") or {}).values()]).lower()
    if "oasys" in text:
        return "oasys"
    if "ivms" in text:
        return "ivms"
    return "custom"


def detect_known(windows, own_pid=None):
    """[{kind, label, window|None}] — найдены ли Oasys и iVMS-4200 среди запущенных окон."""
    out = []
    for kind, k in KNOWN.items():
        w = winmatch.pick_window(windows, k["title_regex"], k["process_regex"], EXCLUDE, "any", own_pid)
        out.append({"kind": kind, "label": k["label"], "window": w})
    return out


def _unique(name, taken):
    base, n = name, 2
    while name.lower() in taken:
        name = f"{base} ({n})"
        n += 1
    return name


def custom_source(window, name=None, taken=()):
    """Источник для произвольной программы: активировать окно, подождать, снять монитор с окном.
    Без разворачивания и щелчков — чужую программу не трогаем сверх необходимого."""
    exe = (window.get("exe") or "").strip()
    title = (window.get("title") or "").strip()
    label = name or re.sub(r"\.exe$", "", exe, flags=re.I) or title[:40] or "Программа"
    rule = winmatch.window_rule(window, "process" if exe else "title")
    rule["exclude_title_regex"] = "(?i)(клуб-скриншоты|скриншоты клуба)"
    return {"name": _unique(label, {t.lower() for t in taken}), "kind": "custom", "enabled": True,
            "window": rule,
            "steps": [{"type": "activate_window"}, {"type": "wait", "seconds": 1.5},
                      {"type": "screenshot", "mode": "monitor", "monitor": "window"}],
            "exit_steps": []}


def add_source(cfg, src):
    """Добавить источник; → False, если уже MAX_SOURCES включённых."""
    sources = cfg.setdefault("sources", [])
    if sum(1 for s in sources if s.get("enabled", True)) >= MAX_SOURCES:
        return False
    sources.append(copy.deepcopy(src))
    return True


def set_enabled_kinds(cfg, kinds):
    """Мастер: включить ровно найденные/отмеченные известные программы (Oasys, iVMS); свои не трогаем."""
    for s in cfg.get("sources") or []:
        k = s.get("kind") or guess_kind(s)
        if k in KNOWN:
            s["enabled"] = k in kinds
