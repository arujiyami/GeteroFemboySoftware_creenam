# Original-Author: Владислав С.
# Created: 2026-10-28
"""Поиск картинки-шаблона на скриншоте (OpenCV, несколько масштабов)."""
import numpy as np

DEFAULT_SCALES = (1.0, 0.9, 1.1, 0.8, 1.25, 0.75, 1.5)


def load_image(path):
    """Читает картинку как BGR (работает и с русскими буквами в пути)."""
    import cv2
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Не удалось прочитать шаблон: {path}")
    return img


def pil_to_bgr(pil_image):
    arr = np.asarray(pil_image.convert("RGB"))
    return arr[:, :, ::-1].copy()


def find_template(haystack_bgr, template_bgr, confidence=0.8, scales=DEFAULT_SCALES):
    """Возвращает (x, y, score) центра лучшего совпадения в координатах haystack или None."""
    import cv2
    hay = cv2.cvtColor(haystack_bgr, cv2.COLOR_BGR2GRAY)
    tpl0 = cv2.cvtColor(template_bgr, cv2.COLOR_BGR2GRAY)
    best = None
    for scale in scales:
        tpl = tpl0 if scale == 1.0 else cv2.resize(
            tpl0, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC)
        th, tw = tpl.shape[:2]
        if th < 4 or tw < 4 or th > hay.shape[0] or tw > hay.shape[1]:
            continue
        if float(tpl.std()) < 2.0:  # однотонный шаблон: корреляция не работает, сравниваем разность
            res = cv2.matchTemplate(hay, tpl, cv2.TM_SQDIFF_NORMED)
            min_v, _, loc, _ = cv2.minMaxLoc(res)
            score = 1.0 - float(min_v)
        else:
            res = cv2.matchTemplate(hay, tpl, cv2.TM_CCOEFF_NORMED)
            res[~np.isfinite(res)] = 0
            _, score, _, loc = cv2.minMaxLoc(res)
        if best is None or score > best[2]:
            best = (loc[0] + tw // 2, loc[1] + th // 2, float(score))
        if score >= 0.97:
            break
    if best and best[2] >= confidence:
        return best
    return None


def is_blank(img, max_std=4.0):
    """True, если снимок однотонный (чёрный экран блокировки, пустое окно)."""
    import numpy as np
    small = img.convert("L")
    small.thumbnail((320, 320))
    return float(np.asarray(small, dtype="float32").std()) < max_std
