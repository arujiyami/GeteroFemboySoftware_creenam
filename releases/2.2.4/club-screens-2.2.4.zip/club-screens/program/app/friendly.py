# Original-Author: Владислав С.
# Created: 2026-10-28
"""Понятные сообщения об ошибках для администратора (без технических подробностей)."""
import os
import re

from .vk import VKError

SEE_LOG = "Подробности — «Настройки» → «Журнал»."


def _strip_name(msg, name):
    if name and msg.startswith(name + ":"):
        return msg[len(name) + 1:].strip()
    return msg


def humanize(error, source=None):
    """Превращает исключение (или текст ошибки) в одно понятное предложение «что случилось — что сделать»."""
    msg = str(error or "").strip()
    name = source or ""
    low = msg.lower()

    if getattr(error, "kind", None) and hasattr(error, "needs_user"):  # ошибка браузера ВК (vk_browser.py)
        text = getattr(error, "text", msg) or msg
        shot = getattr(error, "shot", None)
        if shot:
            text += f" Снимок страницы: logs\\{os.path.basename(shot)}"
        return text

    if isinstance(error, VKError) or low.startswith("ошибка vk"):
        code = getattr(error, "code", None)
        if code is None:
            m = re.match(r"ошибка vk (\d+)", low)
            code = int(m.group(1)) if m else 0
        # Сюда попадают только ошибки режима «через сообщество» (vk.sender: group_api)
        if code == 5 or "токен" in low and "не указан" in low:
            return ("Ключ доступа сообщества не указан или не подходит — «Настройки» → «ВКонтакте» "
                    "(или переключитесь на отправку через браузер).")
        if code in (7, 15, 917, 925, 945, 983):
            return ("Сообщество не может писать в эту беседу — добавьте сообщество в беседу "
                    "и разрешите ему доступ к сообщениям («Настройки» → «ВКонтакте»).")
        if code == 100 and "peer" in low:
            return "Беседа не найдена — выберите её заново («Настроить заново» → «Выбор беседы»)."
        if code in (6, 9, 10, 29):
            return "ВКонтакте временно не принимает сообщения — программа попробует ещё раз позже."
        if code == 14:
            return "ВКонтакте попросил капчу — повторите позже или переключитесь на отправку через браузер."
        return f"ВКонтакте вернул ошибку ({getattr(error, 'message', msg)}). {SEE_LOG}"

    if any(w in low for w in ("connectionerror", "connection aborted", "max retries", "name resolution",
                              "timed out", "timeout", "getaddrinfo", "failed to establish")):
        return "Нет связи с интернетом или с ВКонтакте — проверьте подключение к интернету."
    if "нет прав нажать" in low or "no error message is available" in low or "access is denied" in low \
            or "отказано в доступе" in low:
        prog = name or "программе"
        return (f"Нет прав нажать кнопку в {prog} — запустите «Скриншоты клуба» от имени администратора "
                "(закройте её и откройте снова, ответив «Да» на вопрос Windows).")
    if "окно не найдено" in low:
        prog = name or "Программа"
        return (f"{prog} не найден — откройте программу {prog} "
                f"(окно должно быть открыто, не только значок в трее). Если программа открыта — "
                f"«Настройки» → «Источники» → «Выбрать окно из списка».")
    if "чёрн" in low or "черн" in low or "пуст" in low and "снимок" in low:
        return (f"Снимок {name} получился чёрным — похоже, компьютер заблокирован или спит. "
                "Не блокируйте компьютер и отключите спящий режим.")
    if "не найден шаблон" in low or "так и не виден" in low:
        return (f"{name}: не удалось найти нужную кнопку на экране — нажмите «Настроить заново» "
                "и обведите кнопку ещё раз.")
    if "ни одного скриншота" in low:
        return f"{name}: снимок не сделан. {SEE_LOG}"
    if "нет включённых источников" in low:
        return "Не выбрано ни одной программы для съёмки — откройте «Настройки» → «Источники»."
    if "уже запущен" in low or "не закончен" in low:
        return "Предыдущая отправка ещё не закончилась — подождите минуту."
    text = _strip_name(msg, name) or "неизвестная ошибка"
    return f"{name + ': ' if name else ''}{text}. {SEE_LOG}"
