# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: сторож. Программа раз в 30 с пишет state/heartbeat.json ({pid, t}); отдельный крошечный процесс
(pythonw -m app.watchdog, ~10 МБ, без Qt) раз в 30 с проверяет: процесс жив и отметка свежая. Если
программа упала (процесса нет, а «Выход» не нажимали) или зависла (отметка старше hang_sec) — завершает
зависший процесс и запускает программу заново. «Выход» из меню пишет stopped=true — сторож уходит."""
import json
import os
import subprocess
import sys
import time

CHECK_SEC = 30
HEARTBEAT_SEC = 30


def hb_path(root):
    return os.path.join(root, "state", "heartbeat.json")


def beat(path, pid=None, stopped=False, now=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"pid": os.getpid() if pid is None else pid, "t": now if now is not None else time.time(),
                   "stopped": bool(stopped)}, f)
    os.replace(tmp, path)


def read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def pid_alive(pid):
    if not pid:
        return False
    if sys.platform == "win32":
        import ctypes
        h = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return False
        code = ctypes.c_ulong()
        ctypes.windll.kernel32.GetExitCodeProcess(h, ctypes.byref(code))
        ctypes.windll.kernel32.CloseHandle(h)
        return code.value == 259  # STILL_ACTIVE
    try:
        os.kill(int(pid), 0)
        return True
    except OSError:
        return False


def decide(hb, now, hang_sec, alive):
    """→ "stop" (программа закрыта штатно) | "ok" | "crashed" | "hung"."""
    if hb is None or hb.get("stopped"):
        return "stop"
    if not hb.get("pid"):     # сторож только что перезапустил программу — даём ей время подняться
        return "ok" if now - float(hb.get("t") or 0) <= max(hang_sec, 180) else "crashed"
    if not alive(hb.get("pid")):
        return "crashed"
    if now - float(hb.get("t") or 0) > hang_sec:
        return "hung"
    return "ok"


def kill(pid):
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(int(pid))], capture_output=True, timeout=30,
                           creationflags=0x08000000)
        else:
            os.kill(int(pid), 9)
    except Exception:  # noqa: BLE001
        pass


def restart(program_dir):
    exe = sys.executable
    if sys.platform == "win32" and exe.lower().endswith("python.exe"):
        exe = exe[:-10] + "pythonw.exe"
    subprocess.Popen([exe, os.path.join(program_dir, "main.py"), "--minimized", "--restarted"], cwd=program_dir,
                     close_fds=True, creationflags=0x00000008 if sys.platform == "win32" else 0)


def watch(program_dir, hang_sec=300, sleep=time.sleep, clock=time.time, alive=pid_alive, max_loops=None):
    path = hb_path(program_dir)
    log = os.path.join(program_dir, "logs", "watchdog.log")
    loops = 0
    while max_loops is None or loops < max_loops:
        loops += 1
        sleep(CHECK_SEC)
        hb = read(path)
        st = decide(hb, clock(), hang_sec, alive)
        if st == "stop":
            return "stop"
        if st == "ok":
            continue
        if st == "hung":
            kill(hb["pid"])
        try:
            os.makedirs(os.path.dirname(log), exist_ok=True)
            with open(log, "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S") + f" программа {'зависла' if st == 'hung' else 'упала'}"
                        " — перезапуск\n")
        except OSError:
            pass
        beat(path, pid=0, now=clock())     # чтобы не перезапускать повторно, пока новая копия стартует
        restart(program_dir)
        sleep(90)
    return "loops"


def spawn(program_dir, hang_sec=300):
    """Запустить сторожа отдельным процессом (из главной программы). Не повторно: см. state/watchdog.pid."""
    pidf = os.path.join(program_dir, "state", "watchdog.pid")
    try:
        with open(pidf) as f:
            if pid_alive(int(f.read().strip() or 0)):
                return None
    except (OSError, ValueError):
        pass
    exe = sys.executable
    if sys.platform == "win32" and exe.lower().endswith("python.exe"):
        exe = exe[:-10] + "pythonw.exe"
    p = subprocess.Popen([exe, "-m", "app.watchdog", program_dir, str(int(hang_sec))], cwd=program_dir,
                         close_fds=True, creationflags=0x00000008 | 0x00000200 if sys.platform == "win32" else 0)
    os.makedirs(os.path.dirname(pidf), exist_ok=True)
    with open(pidf, "w") as f:
        f.write(str(p.pid))
    return p


if __name__ == "__main__":
    watch(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 300)
