# Original-Author: Владислав С.
# Created: 2026-10-28
"""Окно «О программе»: короткое «Как работает» по ТЕКУЩИМ настройкам, версия и авторы."""
import base64
import hashlib
from html import escape

from . import APP_NAME, AUTHOR_LINE, CONTRIBUTOR_LINE, __version__
from .cleanup import DEFAULT_KEEP_HOURS, DEFAULT_TIME, LOGS_CAP_BYTES, clamp_time
from .mediapause import media_settings
from .inputlock import DEFAULT_HOTKEY, clamp_watchdog, hotkey_text
from .readiness import ready_settings
from .scheduler import countdown_settings, early_settings, minutes_text, plural_ru

# Исходный автор программы. Хэш — sha256 точной UTF-8 строки ORIGINAL_AUTHOR (см. NOTICE.txt).
ORIGINAL_AUTHOR = "Владислав С."
ORIGINAL_AUTHOR_SHA256 = "2234eca2d3e3aa6dffc9e49407e61cb8b8b714c1239cd939c39db6855e534249"
CREATED = "2026-10-28"
# Показываемая строка об авторе: «Разработано …» (творительный падеж) — свой хэш
AUTHOR_LINE_SHA256 = "24a2bd1c49df40503ba5824ec036eeb5cb8839d97bc3995dab89c3ee67730ffa"


def _sha(text):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def original_author():
    """Имя исходного автора из копии, совпадающей с хэшем; None, если ни одна не совпала."""
    candidates = [ORIGINAL_AUTHOR]
    try:
        from .buildinfo import ORIGIN
        candidates.append(base64.b64decode(ORIGIN).decode("utf-8"))
    except Exception:
        pass
    for c in candidates:
        if _sha(c) == ORIGINAL_AUTHOR_SHA256:
            return c
    return None


def author_intact(line=None):
    """True, если показываемая строка об авторе и ORIGINAL_AUTHOR не менялись."""
    line = AUTHOR_LINE if line is None else line
    return _sha(line) == AUTHOR_LINE_SHA256 and _sha(ORIGINAL_AUTHOR) == ORIGINAL_AUTHOR_SHA256


def author_lines(line=None):
    """Строки об авторе для «О программе»: строка автора и, если её изменили, «Оригинальный автор: …»."""
    line = AUTHOR_LINE if line is None else line
    out = [line] if line else []
    try:
        if not author_intact(line):
            orig = original_author()
            if orig:
                out.append(f"Оригинальный автор: {orig}")
    except Exception:
        pass
    return out


def how_it_works(cfg):
    """4–5 коротких строк простым языком по настройкам cfg."""
    sch = cfg.get("schedule") or {}
    minute = int(sch.get("minute", 0) or 0) % 60
    prewarm = max(0, min(15, int(sch.get("prewarm_minutes", 5) or 0)))
    line = f"Каждый час в :{minute:02d} снимает Oasys и iVMS-4200 и отправляет одним сообщением в беседу ВК"
    line += (f"; беседа открывается заранее, за {minutes_text(prewarm)}." if prewarm
             else "; беседа открывается в момент отправки.")
    lines = [line]

    cd_sec, _ = countdown_settings(cfg)
    if cd_sec:
        lines.append(f"За {cd_sec} {plural_ru(cd_sec, 'секунду', 'секунды', 'секунд')} до блокировки ввода в правом "
                     f"нижнем углу — полупрозрачный обратный отсчёт (окошко программы, не уведомление Windows; "
                     f"на снимки не попадает).")
    else:
        lines.append("Обратный отсчёт перед съёмкой выключен (0 секунд).")

    lk = cfg.get("input_lock") or {}
    early = early_settings(cfg)
    if lk.get("enabled", True):
        sec = clamp_watchdog(lk.get("watchdog_sec", 30))
        when = (f"за {early} {plural_ru(early, 'секунду', 'секунды', 'секунд')} до съёмки (Oasys успевает открыть "
                f"«Карту клуба»)") if early else "на время съёмки"
        lines.append(f"Мышь и клавиатура блокируются {when} и разблокируются сразу после снимков: досрочно — "
                     f"{hotkey_text(lk.get('hotkey') or DEFAULT_HOTKEY)}, сама снимается не позже чем через "
                     f"{sec} {plural_ru(sec, 'секунду', 'секунды', 'секунд')}. Ctrl+Alt+Del работает всегда.")
    else:
        lines.append("Блокировка мыши и клавиатуры во время съёмки выключена. Ctrl+Alt+Del работает всегда.")
    mp_on, mp_resume = media_settings(cfg)
    if mp_on:
        lines.append("На время съёмки ставит на паузу видео, которое сейчас играет (музыка играет дальше)"
                     + (", и после снимков включает его обратно." if mp_resume else "; обратно не включает."))
    on, wait = ready_settings(cfg)
    if on:
        lines.append(f"Перед отправкой проверяет, что Oasys загрузился (ждёт до {wait} "
                     f"{plural_ru(wait, 'секунды', 'секунд', 'секунд')}); если нет — снимок уходит с пометкой "
                     f"«Oasys не загрузился», а программа предупредит.")

    cl = cfg.get("cleanup") or {}
    if cl.get("enabled", True):
        try:
            h, m, _ = clamp_time(cl.get("time", DEFAULT_TIME), sch)
        except ValueError:
            h, m, _ = clamp_time(DEFAULT_TIME, sch)
        hours = int(cl.get("keep_hours", DEFAULT_KEEP_HOURS) or DEFAULT_KEEP_HOURS)
        lines.append(f"Уборка раз в день в {h:02d}:{m:02d}: скриншоты старше {hours} "
                     f"{plural_ru(hours, 'часа', 'часов', 'часов')}, неудачные отправки и файлы для разбора — "
                     f"старше 3 дней, папка logs — не больше {LOGS_CAP_BYTES // 1048576} МБ.")
        lines.append("Файлы текущей и ожидающей повтора отправки не удаляются никогда.")
    else:
        lines.append("Уборка старых скриншотов выключена.")
    lines.append("Настройки действуют сразу и сохраняются сами.")
    return lines


def about_text(cfg):
    """Простой текст (для тестов и журнала)."""
    return "\n".join([f"{APP_NAME}, версия {__version__}", "", "Как работает:"] + how_it_works(cfg)
                     + [""] + author_lines() + [CONTRIBUTOR_LINE])


def about_html(cfg):
    items = "".join(f"<li>{escape(x)}</li>" for x in how_it_works(cfg))
    return (f"<b>{escape(APP_NAME)}</b><br/>версия {escape(__version__)}"
            f"<p><b>Как работает</b></p><ul style='margin-left:-20px'>{items}</ul>"
            f"<p>{'<br/>'.join(escape(x) for x in author_lines())}<br/>"
            f"<span style='font-size:small; color:#666666'>{escape(CONTRIBUTOR_LINE)}</span></p>")
