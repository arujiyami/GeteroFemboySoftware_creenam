# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.6: видео на паузу на время съёма (необязательно, включается в настройках).

2.1.8: только ВИДЕО — музыка продолжает играть. Тип берётся у Windows (свойства мультимедиа:
PlaybackType = Video / Music); если Windows тип не сообщила — по программе: браузер — считаем видео,
известные музыкальные плееры и всё остальное — не трогаем (см. classify).

Через системные «Элементы управления мультимедиа» Windows (Global System Media Transport Controls,
Windows.Media.Control): программа просит у Windows список проигрывателей, запоминает те, что сейчас
ИГРАЮТ, и ставит на паузу только их (TryPauseAsync). После снимков — когда мышь и клавиатура
разблокированы — включает обратно только запомненные (TryPlayAsync), если так выбрано в настройках.
Клавиша «Воспроизведение/пауза» (VK_MEDIA_PLAY_PAUSE) не используется: она переключает, а не ставит
на паузу, и могла бы, наоборот, включить остановленное.

Полностью отдельно от съёма: нет пакета winrt, не Windows, Windows ответила ошибкой или не ответила
за ~1 секунду — запись в журнал, и съёмка идёт как обычно. Пользователю ничего не показывается."""
import asyncio
import logging
import sys
import threading
import time

log = logging.getLogger("club")

PAUSE_TIMEOUT_SEC = 1.0      # на всё: список проигрывателей + пауза каждого
RESUME_TIMEOUT_SEC = 1.0
DEFAULT_MEDIA = {"enabled": False, "resume": True}


# MediaPlaybackType (Windows.Media): 0 — Unknown, 1 — Music, 2 — Video, 3 — Image
PLAYBACK_MUSIC, PLAYBACK_VIDEO = 1, 2
BROWSERS = ("chrome", "msedge", "microsoftedge", "firefox", "opera", "yandex", "brave")
MUSIC_APPS = ("spotify", "aimp", "foobar2000", "yandexmusic", "yandex.music", "yandex music", "vkmusic", "vk.music",
              "vk music", "boom", "winamp", "itunes", "applemusic", "apple music", "zunemusic", "zune", "groove")


def classify(playback_type, app_id):
    """«video» — ставить на паузу; «music» / «other» — не трогать.
    playback_type — MediaPlaybackType из свойств мультимедиа (или None, если не прочитался)."""
    try:
        t = int(getattr(playback_type, "value", playback_type))
    except (TypeError, ValueError):
        t = 0
    if t == PLAYBACK_VIDEO:
        return "video"
    if t == PLAYBACK_MUSIC:
        return "music"
    name = str(app_id or "").lower()
    if any(m in name for m in MUSIC_APPS):          # раньше браузеров: «Яндекс Музыка» — не «yandex»-браузер
        return "music"
    if any(b in name for b in BROWSERS):
        return "video"
    return "other"


def media_settings(cfg):
    """(включено, включать обратно) из cfg["media_pause"]. По умолчанию — выключено, включать обратно."""
    mp = (cfg or {}).get("media_pause") or {}
    if not isinstance(mp, dict):
        mp = {}
    return bool(mp.get("enabled", False)), bool(mp.get("resume", True))


# ---------- Windows.Media.Control через пакет winrt ----------
def load_winrt():
    """Модуль winrt.windows.media.control или исключение (ImportError, не Windows)."""
    if sys.platform != "win32":
        raise ImportError("не Windows")
    from winrt.windows.media import control   # noqa: PLC0415  winrt-Windows.Media.Control
    return control


def _init_mta():
    """Свой поток — многопоточное COM-окружение. Уже инициализирован иначе — не страшно."""
    try:
        from winrt import runtime   # noqa: PLC0415
        runtime.init_apartment(runtime.MTA)
    except Exception:  # noqa: BLE001
        pass


class WinrtSession:
    """Обёртка над GlobalSystemMediaTransportControlsSession: status()/pause()/play() — корутины."""

    def __init__(self, control, session):
        self.control = control
        self.session = session
        try:
            self.name = str(session.source_app_user_model_id or "?")
        except Exception:  # noqa: BLE001
            self.name = "?"

    def status(self):
        st = self.session.get_playback_info().playback_status
        enum = self.control.GlobalSystemMediaTransportControlsSessionPlaybackStatus
        if st == enum.PLAYING:
            return "playing"
        if st == enum.PAUSED:
            return "paused"
        return "other"

    async def playback_type(self):
        """MediaPlaybackType из свойств мультимедиа (int) или None."""
        props = await self.session.try_get_media_properties_async()
        t = getattr(props, "playback_type", None)
        t = getattr(t, "value", t)
        return None if t is None else int(t)

    async def pause(self):
        return bool(await self.session.try_pause_async())

    async def play(self):
        return bool(await self.session.try_play_async())


class WinrtMedia:
    """Источник сессий для MediaPauser. Создаётся только если пакет winrt есть."""

    def __init__(self, control):
        self.control = control

    async def sessions(self):
        mgr = await self.control.GlobalSystemMediaTransportControlsSessionManager.request_async()
        return [WinrtSession(self.control, s) for s in (mgr.get_sessions() or [])]

    @staticmethod
    def prepare_thread():
        _init_mta()


async def _ptype(session):
    fn = getattr(session, "playback_type", None)
    return await fn() if fn else None


def default_media():
    return WinrtMedia(load_winrt())


class MediaPauser:
    """pause(): запомнить и поставить на паузу играющие; resume(): включить обратно только запомненные.

    Ничего не бросает наружу и не держит съёмку дольше timeout (работа идёт в своём потоке).
    media_factory() → объект с корутиной sessions() (у сессии: name, status(), корутины pause()/play())."""

    def __init__(self, media_factory=default_media, timeout=PAUSE_TIMEOUT_SEC, resume_timeout=RESUME_TIMEOUT_SEC):
        self.media_factory = media_factory
        self.timeout = timeout
        self.resume_timeout = resume_timeout
        self.paused = []           # сессии, которые МЫ поставили на паузу
        self._media = None
        self._unavailable = None   # причина, почему не работает (чтобы не писать в журнал каждый час)
        self._lock = threading.Lock()

    # ----- внутреннее -----
    def _get_media(self):
        if self._media is None:
            self._media = self.media_factory()
        return self._media

    def _run(self, coro_fn, timeout, name):
        """Выполнить корутину в своём потоке со своим циклом asyncio; ждать не дольше timeout.
        Возвращает (готово, ошибка)."""
        box = {"done": False, "error": None}

        def worker():
            try:
                media = self._get_media()
                prep = getattr(media, "prepare_thread", None)
                if prep:
                    prep()
                asyncio.run(asyncio.wait_for(coro_fn(media), timeout))
                box["done"] = True
            except Exception as e:  # noqa: BLE001  в том числе TimeoutError
                box["error"] = e

        t = threading.Thread(target=worker, name=name, daemon=True)
        t.start()
        t.join(timeout + 0.25)
        if t.is_alive():
            box["error"] = TimeoutError(f"Windows не ответила за {timeout:g} с")
        return box["done"], box["error"], t

    def _note_unavailable(self, err):
        text = f"{type(err).__name__}: {err}" if str(err) else type(err).__name__
        if self._unavailable != text:
            self._unavailable = text
            log.info("Пауза видео недоступна — пропускаю (%s)", text)
        else:
            log.debug("Пауза видео недоступна: %s", text)

    # ----- снаружи -----
    def pause(self):
        """Поставить на паузу то, что играет. Возвращает число сессий, которым отправлена пауза."""
        with self._lock:
            self.paused = []
            started = time.monotonic()

            async def do(media):
                sessions = await media.sessions()
                playing = []
                for s in sessions:
                    try:
                        if s.status() == "playing":
                            playing.append(s)
                    except Exception as e:  # noqa: BLE001
                        log.debug("Медиа: состояние %s не прочиталось: %s", getattr(s, "name", "?"), e)
                # 2.1.8: только видео (музыка играет дальше)
                types = await asyncio.gather(*(_ptype(s) for s in playing), return_exceptions=True)
                videos = []
                for s, t in zip(playing, types):
                    kind = classify(None if isinstance(t, BaseException) else t, getattr(s, "name", ""))
                    if kind == "video":
                        videos.append(s)
                    else:
                        log.debug("Медиа: %s — %s, не трогаю", s.name, "музыка" if kind == "music" else "не видео")
                playing = videos
                # запоминаем ДО паузы: даже если Windows не успеет ответить, после снимков включим обратно
                self.paused.extend(playing)
                results = await asyncio.gather(*(s.pause() for s in playing), return_exceptions=True)
                for s, r in zip(playing, results):
                    if r is not True:
                        log.debug("Медиа: %s — пауза не подтверждена (%r)", s.name, r)

            try:
                done, err, _t = self._run(do, self.timeout, "media-pause")
            except Exception as e:  # noqa: BLE001  например, не удалось создать поток
                done, err = False, e
            if err is not None:
                if isinstance(err, (ImportError, OSError)) or not self.paused:
                    self._note_unavailable(err)
                else:
                    log.info("Пауза видео: не всё успело (%s)", err)
            if self.paused:
                self._unavailable = None
                log.info("Видео на паузе на время съёма: %s (%.1f с)",
                         ", ".join(s.name for s in self.paused), time.monotonic() - started)
            elif done:
                log.debug("Пауза видео: ничего не играет")
            return len(self.paused)

    def resume(self, wait=False):
        """Включить обратно только запомненные (если они ещё на паузе). Не ждёт, если wait=False.
        Возвращает поток (для проверок) или None."""
        with self._lock:
            sessions, self.paused = self.paused, []
        if not sessions:
            return None

        async def do(_media):
            todo = []
            for s in sessions:
                try:
                    st = s.status()
                except Exception:  # noqa: BLE001
                    st = "paused"
                if st == "paused":          # пользователь уже включил сам или закрыл — не трогаем
                    todo.append(s)
            results = await asyncio.gather(*(s.play() for s in todo), return_exceptions=True)
            for s, r in zip(todo, results):
                if r is not True:
                    log.debug("Медиа: %s — включить обратно не удалось (%r)", s.name, r)
            if todo:
                log.info("Музыка/видео включены обратно: %s", ", ".join(s.name for s in todo))

        def run():
            try:
                _done, err, _t = self._run(do, self.resume_timeout, "media-resume-run")
                if err is not None:
                    log.info("Включить музыку/видео обратно не удалось: %s", err)
            except Exception as e:  # noqa: BLE001
                log.info("Включить музыку/видео обратно не удалось: %s", e)

        t = threading.Thread(target=run, name="media-resume", daemon=True)
        t.start()
        if wait:
            t.join(self.resume_timeout + 1)
        return t

    def forget(self):
        with self._lock:
            self.paused = []
