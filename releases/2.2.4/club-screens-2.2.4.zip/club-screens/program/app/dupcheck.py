# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.4: защита от двойной отправки — «скрины за этот час уже в беседе?».

Сообщение считается «скрины уже отправлены», только если ВСЁ сразу:
  * оно от своего профиля (под которым вошли в ВК);
  * отправлено в текущем часу (с ЧЧ:00 до сейчас; ручная отправка может быть и в ЧЧ:30);
  * в нём ровно 2 картинки, обе широкие (~16:9);
  * картинки похожи на последние снимки программы: одна — на снимок Oasys, другая — на iVMS-4200
    (уменьшенная серая картинка, устойчиво к пересжатию ВК).
Быстро (~1–2 с): смотрятся не больше 4 последних сообщений с фото, качаются только превью."""
import io
import logging
from datetime import datetime

log = logging.getLogger("club")

WIDE_MIN, WIDE_MAX = 1.5, 2.0        # 16:9 = 1.78 (с запасом на обрезку краёв)
SIZE = (32, 18)
CORR_MIN = 0.80                      # корреляция уменьшенных картинок со «своим» снимком
MARGIN = 0.05                        # и заметно выше, чем с «чужим» снимком
DIFF_MAX = 28.0                      # средняя разница яркости (0–255) после выравнивания
MAX_MSGS = 4
TIMEOUT = 2.0


def _arr(img):
    import numpy as np
    from PIL import Image
    im = img.convert("L").resize(SIZE, Image.BILINEAR)
    a = np.asarray(im, dtype="float32")
    return a


def signature(source):
    """source — путь, bytes или PIL.Image → массив 18×32."""
    from PIL import Image
    if isinstance(source, (bytes, bytearray)):
        img = Image.open(io.BytesIO(source))
    elif isinstance(source, str):
        img = Image.open(source)
    else:
        img = source
    img.load()
    return _arr(img)


def similarity(a, b):
    """→ (корреляция, средняя разница яркости после выравнивания среднего)."""
    import numpy as np
    x, y = a - a.mean(), b - b.mean()
    den = float(np.sqrt((x * x).sum() * (y * y).sum())) or 1.0
    corr = float((x * y).sum()) / den
    diff = float(np.abs(x - y).mean())
    return corr, diff


def pair_match(shots, imgs):
    """shots — [Oasys, iVMS], imgs — 2 картинки сообщения (подписи). → (совпало, текст)."""
    best = None
    for order in ((0, 1), (1, 0)):
        sc = [similarity(shots[i], imgs[j]) for i, j in zip((0, 1), order)]
        cross = [similarity(shots[i], imgs[j])[0] for i, j in zip((0, 1), order[::-1])]
        ok = all(c >= CORR_MIN and d <= DIFF_MAX for c, d in sc) and all(
            s[0] >= x + MARGIN for s, x in zip(sc, cross))
        cand = (ok, min(c for c, _ in sc), sc, cross)
        if best is None or (cand[0], cand[1]) > (best[0], best[1]):
            best = cand
    ok, _, sc, cross = best
    txt = "сходство с Oasys %.2f, с iVMS %.2f (перекрёстно %.2f/%.2f)" % (sc[0][0], sc[1][0], cross[0], cross[1])
    return ok, txt


def _download(url, timeout=TIMEOUT):
    import requests
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    return r.content


def candidates(page, since, now=None):
    """Отбор по автору/времени/числу и форме картинок (без скачивания). → (список, причины отказа)."""
    now = now or datetime.now()
    start = since.hour * 60 + since.minute
    end = now.hour * 60 + now.minute
    same_day = since.date() == now.date()
    out, why = [], []
    msgs = list((page or {}).get("msgs") or [])[-MAX_MSGS:]
    for i, m in enumerate(reversed(msgs)):
        tag = f"сообщение {i + 1} снизу"
        if m.get("own") is not True:
            why.append(f"{tag}: не от своего профиля" + ("" if m.get("own") is False else " (автор не определён)"))
            continue
        t = m.get("t")
        if t is None or m.get("old_day") or not same_day or not (start <= t <= end):
            why.append(f"{tag}: не в этом часу")
            continue
        imgs = m.get("imgs") or []
        if len(imgs) != 2:
            why.append(f"{tag}: картинок {len(imgs)}, а не 2")
            continue
        ratios = [(float(x.get("w") or 0) / float(x.get("h") or 1)) for x in imgs]
        if not all(WIDE_MIN <= r <= WIDE_MAX for r in ratios):
            why.append(f"{tag}: картинки не 16:9 ({', '.join('%.2f' % r for r in ratios)})")
            continue
        if not all(str(x.get("src", "")).startswith("http") for x in imgs):
            why.append(f"{tag}: нет адресов картинок")
            continue
        out.append((tag, m))
    return out, why


def find(page, paths, since, now=None, download=_download):
    """→ (True/False, причина). paths — последние снимки программы [Oasys, iVMS]."""
    paths = list(paths or [])
    if len(paths) != 2:
        return False, "нет пары последних снимков для сравнения"
    if not (page or {}).get("msgs"):
        return False, "в беседе внизу нет сообщений с фото"
    cands, why = candidates(page, since, now)
    if not cands:
        return False, "; ".join(why) or "подходящих сообщений нет"
    try:
        shots = [signature(p) for p in paths]
    except Exception as e:  # noqa: BLE001
        return False, f"не открылись свои снимки ({e})"
    for tag, m in cands:
        try:
            imgs = [signature(download(x["src"])) for x in m["imgs"]]
        except Exception as e:  # noqa: BLE001
            why.append(f"{tag}: превью не скачались ({type(e).__name__})")
            continue
        ok, txt = pair_match(shots, imgs)
        if ok:
            return True, f"{tag} (в {m['t'] // 60:02d}:{m['t'] % 60:02d}): своё, 2 картинки 16:9, {txt}"
        why.append(f"{tag}: картинки не те ({txt})")
    return False, "; ".join(why)
