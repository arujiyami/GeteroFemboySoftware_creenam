# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.5: проверка, что Oasys действительно переключился на «Карту клуба» и прорисовал её, — до снимка.

Проверки по кругу (каждые ~0,5 с), пока все не пройдут или не выйдет время:
  1) окно отвечает (IsHungAppWindow / SendMessageTimeout) — backend.is_hung(hwnd);
  2) активное окно — это окно Oasys — backend.is_foreground(hwnd);
  3) картинка не пустая (не однотонная заставка/белый экран загрузки);
  4) «Карта клуба» видна — по шаблону templates/oasys_karta_kluba_header.png (если он снят в мастере);
  5) картинка устоялась: два кадра подряд почти одинаковые.
Если к середине срока не готово — один раз повторить переключение (retry). Время вышло — ReadyResult(ok=False)
с понятной причиной; дальше программа снимает «как есть» и предупреждает (см. job.py).

Всё платформенно-независимо: backend и часы подменяются в тестах."""
import logging
import os
import time

log = logging.getLogger("club")

DEFAULT_READY_TIMEOUT_SEC = 10
READY_MIN_SEC, READY_MAX_SEC = 3, 30
READY_POLL_SEC = 0.5
READY_MAX_RETRIES = 1
NOT_READY_NOTE = "Oasys не загрузился — снимок может быть неактуален"

# причины (для журнала и окна)
R_GONE = "окно закрылось"
R_HUNG = "окно не отвечает (зависло или ещё загружается)"
R_BACKGROUND = "окно не на переднем плане"
R_BLANK = "на экране пусто (идёт загрузка?)"
R_NO_VIEW = "«Карта клуба» не видна"
R_CHANGING = "картинка ещё меняется (прорисовывается)"
R_ERROR = "ошибка проверки"


def ready_timeout(value):
    """«Ждать загрузку Oasys до N секунд»: 3…30, по умолчанию 10."""
    try:
        v = int(round(float(value)))
    except (TypeError, ValueError):
        return DEFAULT_READY_TIMEOUT_SEC
    return max(READY_MIN_SEC, min(READY_MAX_SEC, v))


def ready_settings(cfg):
    oc = (cfg or {}).get("oasys_check") or {}
    return bool(oc.get("enabled", True)), ready_timeout(oc.get("timeout_sec", DEFAULT_READY_TIMEOUT_SEC))


def frame_signature(img, size=(96, 54)):
    """Маленький серый слепок кадра для сравнения (numpy float32)."""
    import numpy as np
    small = img.convert("L").resize(size)
    return np.asarray(small, dtype="float32")


def frames_similar(a, b, max_mean_diff=2.5, pixel_diff=24, max_changed=0.01):
    """Два слепка почти одинаковые: средняя разница мала и сильно изменилось не больше 1 % точек
    (мигающий курсор, тикающие часы — допустимо; прорисовка карты — нет)."""
    import numpy as np
    if a is None or b is None or a.shape != b.shape:
        return False
    d = np.abs(a - b)
    return float(d.mean()) <= max_mean_diff and float((d > pixel_diff).mean()) <= max_changed


def frame_blank(img):
    from .vision import is_blank
    return is_blank(img)


def image_problem(img, template=None, confidence=0.8):
    """Проверка уже сделанного снимка (после съёмки iVMS, до отправки): "" — снимок годный, иначе причина.
    Пустой/однотонный кадр — загрузка; есть шаблон «Карта клуба», но его нет на снимке — не тот вид."""
    if img is None:
        return "снимка нет"
    if frame_blank(img):
        return R_BLANK
    if template and os.path.exists(template):
        from . import vision
        if not vision.find_template(vision.pil_to_bgr(img), vision.load_image(template), confidence):
            return R_NO_VIEW + " на снимке"
    return ""


class ReadyResult:
    def __init__(self, ok, reason="", elapsed=0.0, retries=0, polls=0):
        self.ok = ok
        self.reason = reason
        self.elapsed = elapsed
        self.retries = retries
        self.polls = polls

    def __bool__(self):
        return bool(self.ok)

    def __repr__(self):
        return f"ReadyResult(ok={self.ok}, reason={self.reason!r}, elapsed={self.elapsed:.1f}, retries={self.retries})"


def check_once(backend, hwnd, rect, template=None, confidence=0.8, prev=None):
    """Одна проверка. Возвращает (причина или "", слепок кадра или None)."""
    exists = getattr(backend, "window_exists", None)
    if exists is not None and not exists(hwnd):
        return R_GONE, None
    hung = getattr(backend, "is_hung", None)
    if hung is not None and hung(hwnd):
        return R_HUNG, None
    fg = getattr(backend, "is_foreground", None)
    if fg is not None:
        if not fg(hwnd):
            return R_BACKGROUND, None
    elif backend.foreground() != hwnd:
        return R_BACKGROUND, None
    img = backend.grab(rect)
    if frame_blank(img):
        return R_BLANK, None
    if template and os.path.exists(template) and not backend.locate(template, rect, confidence):
        return R_NO_VIEW, None
    sig = frame_signature(img)
    if not frames_similar(prev, sig):
        return R_CHANGING, sig
    return "", sig


def wait_until_ready(backend, hwnd, rect_fn, timeout_sec=DEFAULT_READY_TIMEOUT_SEC, template=None,
                     confidence=0.8, retry=None, max_retries=READY_MAX_RETRIES, name="Oasys",
                     clock=time.monotonic, sleep=time.sleep, poll_sec=READY_POLL_SEC, clamp=True):
    """Ждать готовности окна не дольше timeout_sec. retry() — повторить переключение (не больше max_retries раз,
    когда прошла половина срока). Каждый шаг пишется в журнал."""
    timeout_sec = ready_timeout(timeout_sec) if clamp else max(0.0, float(timeout_sec or 0))
    start = clock()
    deadline = start + timeout_sec
    prev = None
    retries = 0
    polls = 0
    last = None
    if template and not os.path.exists(template):
        log.info("%s: шаблона «Карта клуба» нет (%s) — проверяю отклик, активное окно и устоявшуюся картинку",
                 name, os.path.basename(template))
    log.info("%s: проверяю, что окно загрузилось (не дольше %.0f с)", name, timeout_sec)
    while True:
        polls += 1
        try:
            reason, sig = check_once(backend, hwnd, rect_fn(), template, confidence, prev)
        except Exception as e:  # noqa: BLE001
            reason, sig = f"{R_ERROR}: {e}", None
        elapsed = clock() - start
        if not reason:
            log.info("%s: готов — отвечает, на переднем плане, «Карта клуба» прорисована (%.1f с)", name, elapsed)
            return ReadyResult(True, "", elapsed, retries, polls)
        if reason != last:
            log.info("%s: ещё не готов — %s (%.1f с)", name, reason, elapsed)
            last = reason
        prev = sig
        if reason == R_GONE:
            return ReadyResult(False, reason, elapsed, retries, polls)
        now = clock()
        if retry is not None and retries < max_retries and now - start >= timeout_sec / 2.0 and now < deadline:
            retries += 1
            log.info("%s: повторяю переключение на «Карту клуба» (%d из %d)", name, retries, max_retries)
            try:
                retry()
            except Exception as e:  # noqa: BLE001
                log.warning("%s: повтор переключения не удался: %s", name, e)
            prev = None
            last = None
            continue
        if now >= deadline:
            log.warning("%s: не загрузился за %.0f с — %s", name, timeout_sec, reason)
            return ReadyResult(False, reason, now - start, retries, polls)
        sleep(min(poll_sec, max(0.0, deadline - now)))
