# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: резервная копия настроек и входа в ВК — файл .csbackup.

ВНИМАНИЕ: внутри — cookies профиля встроенного браузера, т. е. ДОСТУП К АККАУНТУ ВК. Поэтому файл
зашифрован: AES-256-GCM, ключ из пароля через PBKDF2-HMAC-SHA256 (600 000 повторов, соль 16 байт).
Пароль нигде не сохраняется и не пишется в журнал. Без пароля файл не открыть (и не восстановить).

Формат: b"CSBACKUP1\\n" + длина заголовка (4 байта) + JSON-заголовок (он же AAD) + шифротекст (zip).
Импорт не трогает работающий браузер: распаковывает в <profile>.import, а подмена профиля делается
при следующем запуске программы — до старта браузера (apply_pending_import)."""
import io
import json
import os
import shutil
import struct
import time
import zipfile

MAGIC = b"CSBACKUP1\n"
ITERATIONS = 600_000
# Кэши браузера не нужны (большие и пересоздаются) — в копию не кладём
SKIP_DIRS = {"cache", "code cache", "gpucache", "shadercache", "grshadercache", "graphitedawncache",
             "dawncache", "dawngraphitecache", "dawnwebgpucache", "cachestorage", "scriptcache", "crashpad"}
SKIP_FILES = {"lockfile", "singletonlock", "singletoncookie", "singletonsocket"}
WARNING = ("В файле резервной копии — вход в ваш аккаунт ВКонтакте. Кто получит файл и пароль, тот сможет "
           "писать от вашего имени. Не пересылайте его и храните пароль отдельно.")


class BackupError(Exception):
    pass


def _key(password, salt, iterations):
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    if not password:
        raise BackupError("Нужен пароль")
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt,
                      iterations=iterations).derive(password.encode("utf-8"))


def _zip_payload(config_path, profile_dir):
    buf = io.BytesIO()
    n = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        if config_path and os.path.isfile(config_path):
            z.write(config_path, "config.yaml")
        if profile_dir and os.path.isdir(profile_dir):
            for root, dirs, files in os.walk(profile_dir):
                dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
                for f in files:
                    if f.lower() in SKIP_FILES:
                        continue
                    full = os.path.join(root, f)
                    rel = os.path.relpath(full, profile_dir).replace(os.sep, "/")
                    try:
                        z.write(full, "browser_profile/" + rel)
                        n += 1
                    except OSError:
                        pass  # файл занят браузером — пропускаем (cookies пишутся атомарно)
    return buf.getvalue(), n


def export_backup(out_path, password, config_path, profile_dir, version="", iterations=ITERATIONS):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    data, n = _zip_payload(config_path, profile_dir)
    salt, nonce = os.urandom(16), os.urandom(12)
    header = json.dumps({"v": 1, "kdf": "pbkdf2-sha256", "iter": iterations, "salt": salt.hex(),
                         "nonce": nonce.hex(), "app": version, "created": time.strftime("%Y-%m-%d %H:%M"),
                         "files": n}, ensure_ascii=False).encode("utf-8")
    ct = AESGCM(_key(password, salt, iterations)).encrypt(nonce, data, header)
    tmp = out_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(MAGIC + struct.pack(">I", len(header)) + header + ct)
    os.replace(tmp, out_path)
    return {"files": n, "size": os.path.getsize(out_path)}


def read_header(path):
    with open(path, "rb") as f:
        blob = f.read()
    if not blob.startswith(MAGIC):
        raise BackupError("Это не файл резервной копии программы (.csbackup)")
    p = len(MAGIC)
    (hl,) = struct.unpack(">I", blob[p:p + 4])
    header = blob[p + 4:p + 4 + hl]
    return json.loads(header.decode("utf-8")), header, blob[p + 4 + hl:]


def decrypt_backup(path, password):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    h, raw, ct = read_header(path)
    if h.get("v") != 1 or h.get("kdf") != "pbkdf2-sha256":
        raise BackupError("Файл сделан более новой версией программы")
    try:
        return AESGCM(_key(password, bytes.fromhex(h["salt"]), int(h["iter"]))).decrypt(
            bytes.fromhex(h["nonce"]), ct, raw)
    except InvalidTag:
        raise BackupError("Неверный пароль или файл повреждён") from None


def _safe_extract(z, dest):
    root = os.path.realpath(dest)
    for info in z.infolist():
        name = info.filename
        target = os.path.realpath(os.path.join(dest, name))
        if name.startswith(("/", "\\")) or ".." in name.replace("\\", "/").split("/") or \
                os.path.commonpath([root, target]) != root:
            raise BackupError(f"Недопустимый путь в архиве: {name}")
    z.extractall(dest)


def import_backup(path, password, config_path, profile_dir):
    """Расшифровать и подготовить: config.yaml заменяется сразу (старый → config.yaml.bak),
    профиль браузера — при следующем запуске. → {"config": bool, "profile": bool}"""
    data = decrypt_backup(path, password)
    staging = profile_dir.rstrip("/\\") + ".import"
    tmp = staging + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        _safe_extract(z, tmp)
    out = {"config": False, "profile": False}
    cfg = os.path.join(tmp, "config.yaml")
    if os.path.isfile(cfg):
        import yaml
        with open(cfg, encoding="utf-8-sig") as f:
            if not isinstance(yaml.safe_load(f), dict):
                raise BackupError("В копии повреждён config.yaml")
        if os.path.exists(config_path):
            shutil.copy2(config_path, config_path + ".bak")
        shutil.copy2(cfg, config_path)
        out["config"] = True
    prof = os.path.join(tmp, "browser_profile")
    if os.path.isdir(prof):
        shutil.rmtree(staging, ignore_errors=True)
        os.replace(prof, staging)
        out["profile"] = True
    shutil.rmtree(tmp, ignore_errors=True)
    return out


def apply_pending_import(profile_dir):
    """При запуске, ДО браузера: подготовленный профиль → на место; старый → <profile>.old."""
    staging = profile_dir.rstrip("/\\") + ".import"
    if not os.path.isdir(staging):
        return False
    old = profile_dir.rstrip("/\\") + ".old"
    shutil.rmtree(old, ignore_errors=True)
    if os.path.isdir(profile_dir):
        os.replace(profile_dir, old)
    os.replace(staging, profile_dir)
    return True
