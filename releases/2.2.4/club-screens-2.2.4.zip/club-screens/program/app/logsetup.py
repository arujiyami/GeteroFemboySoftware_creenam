# Original-Author: Владислав С.
# Created: 2026-10-28
"""Журнал: файл с ротацией + очередь для окна программы."""
import logging
import logging.handlers
import os
import queue

LOG_QUEUE = queue.Queue()
FORMAT = "%(asctime)s [%(levelname)s] %(message)s"


class QueueHandler(logging.Handler):
    def emit(self, record):
        try:
            LOG_QUEUE.put_nowait(self.format(record))
        except Exception:  # noqa: BLE001
            pass


def setup_logging(log_file, console=False):
    logger = logging.getLogger("club")
    logger.setLevel(logging.DEBUG)
    for h in list(logger.handlers):
        logger.removeHandler(h)
    fmt = logging.Formatter(FORMAT, "%d.%m.%Y %H:%M:%S")
    os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
    fh = logging.handlers.RotatingFileHandler(log_file, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    fh.setFormatter(fmt)
    fh.setLevel(logging.DEBUG)
    qh = QueueHandler()
    qh.setFormatter(logging.Formatter("%(asctime)s %(message)s", "%H:%M:%S"))
    qh.setLevel(logging.INFO)
    logger.addHandler(fh)
    logger.addHandler(qh)
    if console:
        sh = logging.StreamHandler()
        sh.setFormatter(fmt)
        sh.setLevel(logging.INFO)
        logger.addHandler(sh)
    return logger
