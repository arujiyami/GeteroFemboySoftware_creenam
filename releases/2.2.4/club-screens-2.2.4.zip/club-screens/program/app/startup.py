# Original-Author: Владислав С.
# Created: 2026-10-28
"""Автозапуск (Планировщик заданий Windows, с наивысшими правами) и ярлык на рабочем столе.

Почему не папка «Автозагрузка»: программе нужны права администратора (чтобы нажимать кнопки в
Oasys/iVMS-4200), а из «Автозагрузки» такие программы Windows не запускает без вопроса.
Задание «Скриншоты клуба» запускается при входе в Windows с наивысшими правами без окна UAC.
Задание создаётся из XML (а не «schtasks /TR …»): так нет ограничения длины команды и снят
стандартный лимит «остановить через 3 дня»."""
import logging
import os
import subprocess
import sys
import tempfile
from xml.sax.saxutils import escape

from . import APP_NAME
from .config import base_dir

log = logging.getLogger("club")
TASK_NAME = APP_NAME
NO_WINDOW = 0x08000000


def old_startup_link():
    appdata = os.environ.get("APPDATA", "")
    return os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup", APP_NAME + ".lnk")


def launch_command(minimized=True):
    """(программа, аргументы) для запуска без чёрного окна консоли."""
    extra = "--minimized" if minimized else ""
    if getattr(sys, "frozen", False):
        return sys.executable, extra
    exe = sys.executable
    pythonw = os.path.join(os.path.dirname(exe), "pythonw.exe")
    if os.path.exists(pythonw):
        exe = pythonw
    return exe, f'"{os.path.join(base_dir(), "main.py")}" {extra}'.strip()


def current_user():
    dom, user = os.environ.get("USERDOMAIN", ""), os.environ.get("USERNAME", "")
    return f"{dom}\\{user}" if dom and user else user


def task_xml(command, arguments, workdir, user):
    """XML задания: при входе пользователя, наивысшие права, без ограничения по времени."""
    u = escape(user)
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo>
    <Description>{escape(APP_NAME)}: ежечасные скриншоты Oasys и iVMS-4200 в беседу ВК</Description>
  </RegistrationInfo>
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <UserId>{u}</UserId>
      <Delay>PT30S</Delay>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{u}</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <WakeToRun>false</WakeToRun>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{escape(command)}</Command>
      <Arguments>{escape(arguments)}</Arguments>
      <WorkingDirectory>{escape(workdir)}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>
"""


def _schtasks(*args):
    return subprocess.run(["schtasks", *args], capture_output=True, text=True, creationflags=NO_WINDOW)


def remove_old_link():
    path = old_startup_link()
    if os.path.exists(path):
        try:
            os.remove(path)
            log.info("Старый ярлык автозапуска удалён (теперь — задание Планировщика)")
        except OSError as e:
            log.warning("Не удалось удалить старый ярлык автозапуска: %s", e)


def is_enabled():
    if sys.platform != "win32":
        return False
    return _schtasks("/Query", "/TN", TASK_NAME).returncode == 0


def set_enabled(enable):
    """Включить/выключить автозапуск. Нужны права администратора (программа уже с ними)."""
    if sys.platform != "win32":
        return
    remove_old_link()
    if not enable:
        r = _schtasks("/Delete", "/TN", TASK_NAME, "/F")
        if r.returncode and is_enabled():
            raise RuntimeError(f"Не удалось убрать автозапуск: {(r.stderr or r.stdout).strip()}")
        return
    exe, args = launch_command(minimized=True)
    xml = task_xml(exe, args, base_dir(), current_user())
    fd, path = tempfile.mkstemp(suffix=".xml")
    os.close(fd)
    try:
        with open(path, "w", encoding="utf-16") as f:
            f.write(xml)
        r = _schtasks("/Create", "/TN", TASK_NAME, "/XML", path, "/F")
    finally:
        os.remove(path)
    if r.returncode:
        raise RuntimeError("Не удалось включить автозапуск (нужны права администратора): "
                           f"{(r.stderr or r.stdout).strip()}")
    log.info("Автозапуск включён: задание «%s» (при входе в Windows, наивысшие права)", TASK_NAME)


def icon_path():
    """Иконка программы (создаётся при первом обращении)."""
    path = os.path.join(base_dir(), "app.ico")
    if not os.path.exists(path):
        from .icon import camera_image
        camera_image().save(path, sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])
    return path


def create_shortcut(path, minimized=False, description=APP_NAME):
    import win32com.client
    target, args = launch_command(minimized)
    shell = win32com.client.Dispatch("WScript.Shell")
    sc = shell.CreateShortCut(path)
    sc.TargetPath = target
    sc.Arguments = args
    sc.WorkingDirectory = base_dir()
    sc.Description = description
    try:
        sc.IconLocation = icon_path()
    except Exception:  # noqa: BLE001
        pass
    sc.save()
    return path


def desktop_shortcut():
    """Ярлык «Скриншоты клуба» на рабочем столе (при запуске Windows спросит разрешение — ответьте «Да»)."""
    import win32com.client
    desktop = win32com.client.Dispatch("WScript.Shell").SpecialFolders("Desktop")
    return create_shortcut(os.path.join(desktop, APP_NAME + ".lnk"), minimized=False)
