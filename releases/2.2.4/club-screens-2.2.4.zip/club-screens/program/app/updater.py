# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: обновление из публичного репозитория GitHub — без токенов и входа.

1) check(): сначала читает файл-манифест latest.json
   (https://raw.githubusercontent.com/<repo>/main/latest.json:
   {version, update_zip_url, sha256, notes, min_version}); если его нет —
   запасной путь: GET https://api.github.com/repos/<repo>/releases/latest (не чаще раза в сутки + кнопка).
2) Ищем архив «…-update.zip»: вложение релиза или ссылка в тексте релиза (файлы в releases/<версия>/).
   SHA-256 — из вложения «….sha256» или из текста релиза. Без SHA-256 не ставим.
3) download(): качаем, сверяем SHA-256 и состав архива (есть program/main.py, нет путей «..»).
4) write_apply_bat(): внешний .bat ждёт выхода программы, копирует текущую версию в backup_prev\\,
   раскладывает новую (НЕ трогая config.yaml, browser_profile, templates, снимки, журналы, .venv),
   ставит зависимости и запускает программу. Откат — ОТКАТИТЬ_ОБНОВЛЕНИЕ.bat (один щелчок).
Во время съёма обновление не начинается (см. MainWindow)."""
import datetime as dt
import hashlib
import json
import os
import re
import urllib.parse
import urllib.request
import zipfile

DEFAULT_REPO = "arujiyami/GeteroFemboySoftware_creenam"
API = "https://api.github.com/repos/{repo}/releases/latest"
ALLOWED_HOSTS = {"api.github.com", "github.com", "objects.githubusercontent.com", "raw.githubusercontent.com",
                 "release-assets.githubusercontent.com", "codeload.github.com"}
MAX_ZIP = 60 * 1024 * 1024
UA = "club-screens-updater"
KEEP_DIRS = ["browser_profile", "browser_profile.old", "browser_profile.import", "templates", "screenshots", "logs",
             ".venv", "state", "queue", "backup_prev", "update"]
KEEP_FILES = ["config.yaml", "config.yaml.bak", "window.ini", "*.csbackup", "*.log", "heartbeat.json"]


class UpdateError(Exception):
    pass


def vtuple(v):
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(x) for x in (nums + ["0", "0", "0"])[:3])


def is_newer(remote, current):
    return vtuple(remote) > vtuple(current)


def _check_url(url):
    u = urllib.parse.urlparse(url)
    if u.scheme != "https" or u.hostname not in ALLOWED_HOSTS:
        raise UpdateError(f"Недопустимый адрес загрузки: {url}")
    return url


def _get(url, timeout=20, limit=MAX_ZIP):
    req = urllib.request.Request(_check_url(url), headers={"User-Agent": UA,
                                                             "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (только https и github)
        _check_url(r.geturl())
        data = r.read(limit + 1)
    if len(data) > limit:
        raise UpdateError("Файл обновления слишком большой")
    return data


def should_check(cfg, today=None):
    u = cfg.get("updates") or {}
    if not u.get("auto_check", True):
        return False
    today = (today or dt.date.today()).isoformat()
    return str(u.get("last_check") or "")[:10] != today


SHA_RX = re.compile(r"\b([0-9a-fA-F]{64})\b")
LINK_RX = re.compile(r"https://[^\s)\"'<>]+")


def parse_release(rel, current, fetch=_get):
    """→ None (нет новее) или {"version", "notes", "zip_url", "sha256", "url"}."""
    tag = rel.get("tag_name") or rel.get("name") or ""
    if rel.get("draft") or rel.get("prerelease") or not is_newer(tag, current):
        return None
    body = rel.get("body") or ""
    assets = {a.get("name", ""): a.get("browser_download_url", "") for a in rel.get("assets") or []}
    zip_name = next((n for n in assets if n.endswith("-update.zip")), None)
    zip_url = assets.get(zip_name) if zip_name else None
    links = LINK_RX.findall(body)
    if not zip_url:
        zip_url = next((x for x in links if x.split("?")[0].endswith("-update.zip")), None)
        zip_name = zip_url.split("?")[0].rsplit("/", 1)[-1] if zip_url else None
    if not zip_url:
        raise UpdateError(f"В выпуске {tag} нет архива обновления (…-update.zip)")
    sha = None
    sha_url = assets.get(zip_name + ".sha256") or next(
        (x for x in links if x.split("?")[0].endswith(zip_name + ".sha256")), None)
    if sha_url:
        m = SHA_RX.search(fetch(sha_url, limit=4096).decode("utf-8", "replace"))
        sha = m.group(1) if m else None
    if not sha:
        for line in body.splitlines():
            m = SHA_RX.search(line)
            if m and (zip_name in line or "update" in line.lower()):
                sha = m.group(1)
                break
    if not sha:
        raise UpdateError(f"В выпуске {tag} нет контрольной суммы SHA-256 архива — обновление не установлено")
    return {"version": ".".join(map(str, vtuple(tag))), "notes": body[:1500], "zip_url": _check_url(zip_url),
            "sha256": sha.lower(), "url": rel.get("html_url", "")}


MANIFEST = "https://raw.githubusercontent.com/{repo}/main/latest.json"


def parse_manifest(m, current):
    """latest.json → None (нет новее) или {"version", "notes", "zip_url", "sha256", "url"}."""
    ver = str(m.get("version") or "")
    if not ver or not is_newer(ver, current):
        return None
    mv = m.get("min_version")
    if mv and vtuple(current) < vtuple(mv):
        raise UpdateError(f"Версию {ver} нельзя поставить поверх {current}: сначала нужна версия {mv} "
                          "(скачайте полный архив)")
    url = str(m.get("update_zip_url") or "")
    if not url.split("?")[0].endswith("-update.zip"):
        raise UpdateError(f"В манифесте версии {ver} нет архива обновления (…-update.zip)")
    sha = str(m.get("sha256") or "")
    if not re.fullmatch(r"[0-9a-fA-F]{64}", sha):
        raise UpdateError(f"В манифесте версии {ver} нет контрольной суммы SHA-256 — обновление не установлено")
    return {"version": ".".join(map(str, vtuple(ver))), "notes": str(m.get("notes") or "")[:1500],
            "zip_url": _check_url(url), "sha256": sha.lower(), "url": url}


def check(repo, current, fetch=_get):
    """Основной путь — latest.json; GitHub Releases — запасной, если манифест недоступен."""
    try:
        raw = fetch(MANIFEST.format(repo=repo), limit=256 * 1024)
    except UpdateError:
        raise
    except Exception:  # noqa: BLE001 — нет манифеста/сети: пробуем Releases
        raw = None
    if raw is not None:
        try:
            m = json.loads(raw.decode("utf-8"))
        except ValueError:
            raise UpdateError("Файл latest.json повреждён — обновление не установлено")
        return parse_manifest(m, current)
    rel = json.loads(fetch(API.format(repo=repo), limit=2 * 1024 * 1024).decode("utf-8"))
    return parse_release(rel, current, fetch)


def verify_zip(path):
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
    for n in names:
        if n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/"):
            raise UpdateError(f"Недопустимый путь в архиве: {n}")
    if "club-screens/program/main.py" not in names:
        raise UpdateError("Это не архив обновления программы")
    bad = [n for n in names if re.search(r"(^|/)(config\.yaml|browser_profile/|window\.ini)", n)
           or n.endswith(".csbackup")]
    if bad:
        raise UpdateError("В архиве обновления лишние личные файлы: " + ", ".join(bad[:3]))
    return names


def download(info, dest_dir, fetch=_get):
    os.makedirs(dest_dir, exist_ok=True)
    data = fetch(info["zip_url"], timeout=120)
    got = hashlib.sha256(data).hexdigest()
    if got != info["sha256"]:
        raise UpdateError("Контрольная сумма архива не совпала — файл повреждён или подменён, обновление отменено")
    path = os.path.join(dest_dir, f"club-screens-{info['version']}-update.zip")
    with open(path, "wb") as f:
        f.write(data)
    verify_zip(path)
    return path


def _bat(lines):
    return "\r\n".join(lines) + "\r\n"


def write_apply_bat(root, zip_path, pid, version):
    """root — папка club-screens (в ней program\\). → путь к ОБНОВИТЬ_СЕЙЧАС.bat (запускать отдельно)."""
    xd = " ".join(f'"{k}"' for k in KEEP_DIRS)
    xf = " ".join(f'"{k}"' for k in KEEP_FILES)
    upd = os.path.join(root, "update")
    os.makedirs(upd, exist_ok=True)
    bat = os.path.join(upd, "apply_update.bat")
    with open(bat, "w", encoding="utf-8", newline="") as f:
        f.write(_bat([
            "@echo off", "chcp 65001 >nul", "setlocal EnableExtensions",
            f"title Обновление программы до {version}",
            'set "ROOT=%~dp0.."', f'set "ZIP={zip_path}"', f"set PID={int(pid)}",
            "echo Жду, пока программа закроется...",
            ":wait", 'tasklist /FI "PID eq %PID%" 2>nul | find "%PID%" >nul',
            "if not errorlevel 1 (timeout /t 1 /nobreak >nul & goto wait)",
            "echo Сохраняю текущую версию для отката...",
            'if exist "%ROOT%\\backup_prev" rmdir /s /q "%ROOT%\\backup_prev"',
            f'robocopy "%ROOT%\\program" "%ROOT%\\backup_prev\\program" /E /XD {xd} __pycache__ /XF {xf} /NFL /NDL /NJH /NJS >nul',
            'copy /y "%ROOT%\\*.bat" "%ROOT%\\backup_prev\\" >nul 2>nul',
            'copy /y "%ROOT%\\*.md" "%ROOT%\\backup_prev\\" >nul 2>nul',
            'copy /y "%ROOT%\\*.pdf" "%ROOT%\\backup_prev\\" >nul 2>nul',
            'set "TMPX=%ROOT%\\update\\x"', 'if exist "%TMPX%" rmdir /s /q "%TMPX%"',
            "powershell -NoProfile -ExecutionPolicy Bypass -Command "
            "\"Expand-Archive -LiteralPath $env:ZIP -DestinationPath $env:TMPX -Force\"",
            'if not exist "%TMPX%\\club-screens\\program\\main.py" (echo Архив не распакован - обновление отменено & pause & exit /b 1)',
            f'robocopy "%TMPX%\\club-screens" "%ROOT%" /E /XD {xd} __pycache__ /XF {xf} /NFL /NDL /NJH /NJS >nul',
            'if exist "%ROOT%\\program\\.venv\\Scripts\\python.exe" "%ROOT%\\program\\.venv\\Scripts\\python.exe" '
            '-m pip install -q -r "%ROOT%\\program\\requirements.txt"',
            'rmdir /s /q "%TMPX%"',
            f"echo Готово: версия {version}. Запускаю программу...",
            'start "" "%ROOT%\\program\\run.bat"', "exit /b 0"]))
    return bat


ROLLBACK_BAT = _bat([
    "@echo off", "rem Original-Author: Vladislav S.", "rem Created: 2026-10-28", "chcp 65001 >nul", "setlocal EnableExtensions",
    "title Откат обновления", 'set "ROOT=%~dp0"',
    'if not exist "%ROOT%backup_prev\\program\\main.py" (echo Предыдущей версии нет - откатывать нечего. & pause & exit /b 1)',
    "echo Закройте программу (значок у часов - Выход) и нажмите любую клавишу.", "pause >nul",
    'robocopy "%ROOT%backup_prev" "%ROOT%." /E /NFL /NDL /NJH /NJS >nul',
    'if exist "%ROOT%program\\.venv\\Scripts\\python.exe" "%ROOT%program\\.venv\\Scripts\\python.exe" '
    '-m pip install -q -r "%ROOT%program\\requirements.txt"',
    "echo Предыдущая версия возвращена. Ваши настройки и вход в ВК не тронуты.",
    'start "" "%ROOT%program\\run.bat"', "exit /b 0"])
