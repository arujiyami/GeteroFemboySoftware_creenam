# Original-Author: Владислав С.
# Created: 2026-10-28
"""Небольшие картинки-подсказки для шагов мастера (рисуются кодом, без файлов)."""
import sys

from PIL import Image, ImageDraw, ImageFont

W, H = 220, 150
BLUE, GREEN, RED, GREY, DARK = "#2f6fd8", "#1f9d55", "#e03b3b", "#c9ced6", "#2b3441"


def _font(size, bold=False):
    names = (["segoeuib.ttf", "arialbd.ttf"] if bold else ["segoeui.ttf", "arial.ttf"]) if sys.platform == "win32" \
        else (["DejaVuSans-Bold.ttf"] if bold else ["DejaVuSans.ttf"])
    for n in names + ["/usr/share/fonts/truetype/dejavu/" + names[-1]]:
        try:
            return ImageFont.truetype(n, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _window(d, box, title_color=DARK):
    x0, y0, x1, y1 = box
    d.rounded_rectangle(box, 8, fill="white", outline=GREY, width=2)
    d.rounded_rectangle((x0, y0, x1, y0 + 16), 8, fill=title_color)
    d.rectangle((x0, y0 + 8, x1, y0 + 16), fill=title_color)
    for i, c in enumerate(("#ff5f57", "#febc2e", "#28c840")):
        d.ellipse((x1 - 50 + i * 14, y0 + 4, x1 - 42 + i * 14, y0 + 12), fill=c)


def _check(d, cx, cy, r=18, color=GREEN):
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=color)
    d.line((cx - r * .45, cy, cx - r * .1, cy + r * .4, cx + r * .5, cy - r * .35), fill="white", width=max(3, r // 5))


def picture(kind):
    img = Image.new("RGB", (W, H), "#eef3fb")
    d = ImageDraw.Draw(img)
    if kind == "welcome":
        _window(d, (20, 20, 120, 100))
        d.rectangle((30, 46, 110, 92), fill="#8fb3e8")
        _window(d, (40, 50, 140, 130))
        d.rectangle((50, 76, 130, 122), fill="#6c8db8")
        d.ellipse((150, 22, 206, 78), fill="white", outline=BLUE, width=4)
        d.line((178, 50, 178, 30), fill=DARK, width=3)
        d.line((178, 50, 192, 50), fill=DARK, width=3)
        d.text((178, 86), "каждый\nчас", font=_font(14, True), fill=BLUE, anchor="ma", align="center")
    elif kind == "vk":
        d.rounded_rectangle((70, 25, 150, 105), 20, fill="#0077ff")
        d.text((86, 46), "VK", font=_font(30, True), fill="white")
        d.text((110, 115), "Вход в браузере", font=_font(14), fill=DARK, anchor="ma")
    elif kind == "chat":
        d.rounded_rectangle((20, 20, 150, 70), 14, fill="white", outline=GREY, width=2)
        d.polygon(((40, 70), (55, 70), (35, 85)), fill="white")
        d.text((32, 34), "Камеры | …", font=_font(15, True), fill=DARK)
        d.rounded_rectangle((70, 80, 200, 130), 14, fill="#cfe1ff")
        d.rectangle((84, 92, 124, 120), fill="#8fb3e8")
        d.rectangle((132, 92, 172, 120), fill="#6c8db8")
    elif kind == "oasys":
        _window(d, (15, 15, 205, 135))
        d.rectangle((15, 31, 40, 135), fill="#1d2633")
        for i in range(5):
            y = 40 + i * 18
            d.rectangle((21, y, 34, y + 11), fill="#7f8ea3")
        d.rectangle((17, 56, 38, 73), outline=RED, width=3)
        for r in range(3):
            for c in range(5):
                d.rectangle((52 + c * 30, 45 + r * 28, 76 + c * 30, 65 + r * 28),
                            fill=("#43b581" if (r + c) % 3 else "#e8a33d"))
        d.line((70, 120, 40, 70), fill=RED, width=3)
    elif kind == "ivms":
        _window(d, (15, 15, 205, 135))
        for r in range(2):
            for c in range(3):
                d.rectangle((22 + c * 60, 26 + r * 44, 78 + c * 60, 66 + r * 44), fill="#3a4a5e")
        d.rectangle((15, 116, 205, 135), fill="#20262e")
        x, y = 184, 119
        d.rectangle((x - 3, y - 2, x + 15, y + 14), outline=RED, width=3)
        for (a, b) in (((x, y + 4), (x, y)), ((x, y), (x + 4, y)), ((x + 12, y), (x + 8, y))):
            d.line((a, b), fill="white", width=2)
        d.line((150, 100, 182, 118), fill=RED, width=3)
    elif kind == "test":
        d.rectangle((15, 35, 100, 95), fill="#43b581", outline=GREY, width=2)
        d.rectangle((120, 35, 205, 95), fill="#3a4a5e", outline=GREY, width=2)
        d.text((40, 100), "1", font=_font(18, True), fill=DARK)
        d.text((155, 100), "2", font=_font(18, True), fill=DARK)
        _check(d, 110, 125, 14)
    elif kind == "done":
        _check(d, W // 2, H // 2 - 8, 44)
        d.text((60, 118), "Готово!", font=_font(20, True), fill=GREEN)
    return img
