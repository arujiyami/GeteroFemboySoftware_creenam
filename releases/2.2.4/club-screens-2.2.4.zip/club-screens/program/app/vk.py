# Original-Author: Владислав С.
# Created: 2026-10-28
"""Отправка фотографий в беседу через официальный VK API — ТОЛЬКО с ключом доступа сообщества.
Необязательный режим для опытных (vk.sender: group_api). Обычный режим — браузер программы (vk_browser.py)."""
import logging
import mimetypes
import os
import time

import requests

log = logging.getLogger("club")


class VKError(Exception):
    def __init__(self, code, message):
        super().__init__(f"Ошибка VK {code}: {message}")
        self.code = code
        self.message = message


def random_id():
    return int.from_bytes(os.urandom(4), "big") & 0x7FFFFFFF


class VKClient:
    RETRY_CODES = {6, 10}  # слишком много запросов / внутренняя ошибка

    def __init__(self, token, api_version="5.199", host="api.vk.com", session=None,
                 timeout=60, sleep=time.sleep):
        if not token:
            raise VKError(0, "не указан токен сообщества (Настройки → «ВКонтакте»)")
        self.token = token
        self.v = str(api_version)
        self.host = host or "api.vk.com"
        self.session = session or requests.Session()
        self.timeout = timeout
        self.sleep = sleep

    def call(self, method, **params):
        data = {k: v for k, v in params.items() if v is not None}
        data.update(access_token=self.token, v=self.v)
        url = f"https://{self.host}/method/{method}"
        for attempt in range(3):
            resp = self.session.post(url, data=data, timeout=self.timeout)
            resp.raise_for_status()
            payload = resp.json()
            if "error" in payload:
                err = payload["error"]
                code = err.get("error_code", 0)
                if code in self.RETRY_CODES and attempt < 2:
                    self.sleep(1.0 + attempt)
                    continue
                raise VKError(code, err.get("error_msg", "неизвестная ошибка"))
            return payload["response"]
        raise VKError(0, "превышено число попыток")

    def upload_message_photo(self, path, peer_id):
        """Загружает файл и возвращает строку вложения photo<owner>_<id>[_<access_key>]."""
        server = self.call("photos.getMessagesUploadServer", peer_id=peer_id)
        mime = mimetypes.guess_type(path)[0] or "image/png"
        ext = os.path.splitext(path)[1] or ".png"
        with open(path, "rb") as f:
            resp = self.session.post(server["upload_url"],
                                     files={"photo": ("photo" + ext, f, mime)}, timeout=self.timeout)
        resp.raise_for_status()
        up = resp.json()
        if not up.get("photo") or up.get("photo") in ("[]", ""):
            raise VKError(0, f"сервер загрузки не принял фото: {up}")
        saved = self.call("photos.saveMessagesPhoto", photo=up["photo"], server=up["server"], hash=up["hash"])
        p = saved[0]
        att = f"photo{p['owner_id']}_{p['id']}"
        if p.get("access_key"):
            att += f"_{p['access_key']}"
        return att

    def send_photos(self, peer_id, paths, message=""):
        """Одно сообщение со всеми картинками (в указанном порядке). Возвращает id сообщения."""
        if not paths:
            raise VKError(0, "нет картинок для отправки")
        if len(paths) > 10:
            raise VKError(0, "VK позволяет не более 10 вложений в одном сообщении")
        attachments = []
        for p in paths:
            attachments.append(self.upload_message_photo(p, peer_id))
            log.info("Загружено в VK: %s", os.path.basename(p))
        params = {"peer_id": int(peer_id), "random_id": random_id(), "attachment": ",".join(attachments)}
        if message:
            params["message"] = message
        result = self.call("messages.send", **params)
        log.info("Сообщение отправлено в беседу %s", peer_id)
        return result

    def send_text(self, peer_id, message):
        """2.2.0: короткое текстовое сообщение (утренняя сводка, если обычной отправки не было)."""
        return self.call("messages.send", peer_id=int(peer_id), random_id=random_id(), message=message)

    def get_conversations(self, limit=600):
        """Список бесед и диалогов: [{'peer_id', 'title', 'type'}]."""
        out, offset = [], 0
        while offset < limit:
            r = self.call("messages.getConversations", count=200, offset=offset, extended=1)
            names = {}
            for u in r.get("profiles", []):
                names[u["id"]] = f"{u.get('first_name', '')} {u.get('last_name', '')}".strip()
            for g in r.get("groups", []):
                names[-g["id"]] = g.get("name", "")
            items = r.get("items", [])
            for item in items:
                conv = item.get("conversation", item)
                peer = conv["peer"]
                ptype = peer.get("type")
                if ptype == "chat":
                    title = conv.get("chat_settings", {}).get("title", "")
                else:
                    title = names.get(peer["id"], "")  # пользователь: id, сообщество: -id
                out.append({"peer_id": peer["id"], "title": title, "type": ptype})
            offset += len(items)
            if not items or offset >= r.get("count", 0):
                break
        return out

    def whoami(self):
        """Название сообщества, которому принадлежит ключ."""
        r = self.call("groups.getById")
        groups = r.get("groups", r) if isinstance(r, dict) else r
        g = groups[0]
        return f"Сообщество: {g.get('name')} (id {g.get('id')})"
