# Original-Author: Владислав С.
# Created: 2026-10-28
"""Работа с окнами и экраном Windows (ctypes/pywin32 + mss + OpenCV).

Клики и клавиши — через SendInput (абсолютные координаты на всём виртуальном рабочем столе),
запасной путь — PostMessage WM_LBUTTONDOWN/UP прямо в окно под точкой.
SetCursorPos/pyautogui больше не используются: они падали с «No error message is available»,
когда Oasys/iVMS запущены от имени администратора."""
import ctypes
import logging
import os
import sys
import time

from PIL import Image

from . import winmatch

log = logging.getLogger("club")
_U32_READY = None

NO_RIGHTS = ("Нет прав нажать кнопку в {name} — запустите «Скриншоты клуба» от имени администратора "
             "(закройте программу и откройте её снова, ответив «Да» на вопрос Windows).")


class InputDenied(Exception):
    """Windows не дал нажать мышью/клавишей в окно программы (обычно — разные права)."""
    retry = True

    def __init__(self, name="программе"):
        super().__init__(NO_RIGHTS.format(name=name))
        self.text = str(self)


def set_dpi_awareness():
    """Учёт масштабирования экрана, чтобы координаты были в реальных пикселях.
    (Окно Qt включает это само; функция нужна для режимов без окна.)"""
    if sys.platform != "win32":
        return
    try:
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):  # PER_MONITOR_AWARE_V2
            return
    except Exception:  # noqa: BLE001
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:  # noqa: BLE001
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass


def _mss():
    import mss
    return mss.MSS() if hasattr(mss, "MSS") else mss.mss()


def grab_rect(rect):
    """Скриншот области (left, top, width, height) в виде PIL.Image."""
    left, top, width, height = rect
    with _mss() as sct:
        shot = sct.grab({"left": int(left), "top": int(top), "width": int(width), "height": int(height)})
    return Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")


def virtual_screen_rect():
    with _mss() as sct:
        m = sct.monitors[0]
    return (m["left"], m["top"], m["width"], m["height"])


# ------------------------------------------------------------------ SendInput (ctypes)
if sys.platform == "win32":
    import ctypes.wintypes as wt

    ULONG_PTR = ctypes.c_size_t

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [("dx", wt.LONG), ("dy", wt.LONG), ("mouseData", wt.DWORD), ("dwFlags", wt.DWORD),
                    ("time", wt.DWORD), ("dwExtraInfo", ULONG_PTR)]

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [("wVk", wt.WORD), ("wScan", wt.WORD), ("dwFlags", wt.DWORD), ("time", wt.DWORD),
                    ("dwExtraInfo", ULONG_PTR)]

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = [("uMsg", wt.DWORD), ("wParamL", wt.WORD), ("wParamH", wt.WORD)]

    class _INPUTUNION(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

    class INPUT(ctypes.Structure):
        _anonymous_ = ("u",)
        _fields_ = [("type", wt.DWORD), ("u", _INPUTUNION)]

MOUSEEVENTF_MOVE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0001, 0x0002, 0x0004
MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_VIRTUALDESK = 0x8000, 0x4000
KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP = 0x0001, 0x0002
WM_LBUTTONDOWN, WM_LBUTTONUP, WM_LBUTTONDBLCLK, MK_LBUTTON = 0x0201, 0x0202, 0x0203, 0x0001

VK = {"esc": 0x1B, "escape": 0x1B, "enter": 0x0D, "return": 0x0D, "tab": 0x09, "space": 0x20,
      "backspace": 0x08, "delete": 0x2E, "del": 0x2E, "insert": 0x2D, "home": 0x24, "end": 0x23,
      "pageup": 0x21, "pagedown": 0x22, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
      "ctrl": 0x11, "control": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "lwin": 0x5B,
      "printscreen": 0x2C, "pause": 0x13}
VK.update({f"f{i}": 0x6F + i for i in range(1, 25)})
EXTENDED = {0x2E, 0x2D, 0x24, 0x23, 0x21, 0x22, 0x25, 0x26, 0x27, 0x28, 0x5B}


def vk_code(key):
    k = str(key).strip().lower()
    if k in VK:
        return VK[k]
    if len(k) == 1 and (k.isdigit() or "a" <= k <= "z"):
        return ord(k.upper())
    raise ValueError(f"Неизвестная клавиша «{key}»")


def absolute_coords(x, y, vrect):
    """Пиксели экрана → 0..65535 для MOUSEEVENTF_ABSOLUTE|VIRTUALDESK."""
    vl, vt, vw, vh = vrect
    ax = int(round((x - vl) * 65535 / max(1, vw - 1)))
    ay = int(round((y - vt) * 65535 / max(1, vh - 1)))
    return max(0, min(65535, ax)), max(0, min(65535, ay))


class WinBackend:
    def __init__(self):
        import win32api  # noqa: F401  (проверка, что pywin32 установлен)
        import win32con  # noqa: F401
        import win32gui  # noqa: F401
        self.u32 = ctypes.windll.user32
        self.own_pid = os.getpid()
        self.name = "программе"   # для понятных ошибок (StepRunner подставляет имя источника)

    # ---------- окна ----------
    @staticmethod
    def _pid(hwnd):
        pid = wt.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value

    @staticmethod
    def exe_of_pid(pid, _cache={}):  # noqa: B006  (кэш имён процессов)
        if pid in _cache:
            return _cache[pid]
        name = ""
        k32 = ctypes.windll.kernel32
        # PROCESS_QUERY_LIMITED_INFORMATION работает и для процессов администратора, и для 32-битных
        h = k32.OpenProcess(0x1000, False, pid)
        if h:
            try:
                buf = ctypes.create_unicode_buffer(1024)
                size = wt.DWORD(1024)
                if k32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                    name = buf.value.split("\\")[-1]
            finally:
                k32.CloseHandle(h)
        if not name:
            try:
                import psutil  # необязательно
                name = psutil.Process(pid).name()
            except Exception:  # noqa: BLE001
                name = ""
        if len(_cache) > 500:
            _cache.clear()
        if name:
            _cache[pid] = name
        return name

    def window_info(self, hwnd):
        import win32con
        import win32gui
        u = self.u32
        ex = win32gui.GetWindowLong(hwnd, win32con.GWL_EXSTYLE)
        cloaked = wt.DWORD()
        try:
            ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(cloaked), 4)  # DWMWA_CLOAKED
        except Exception:  # noqa: BLE001
            cloaked.value = 0
        iconic = bool(u.IsIconic(hwnd))
        if iconic:  # размер свёрнутого окна — по «обычному» положению
            _, _, _, _, (l, t, r, b) = win32gui.GetWindowPlacement(hwnd)
        else:
            l, t, r, b = win32gui.GetWindowRect(hwnd)
        pid = self._pid(hwnd)
        return {"hwnd": hwnd, "title": win32gui.GetWindowText(hwnd), "pid": pid, "exe": self.exe_of_pid(pid),
                "visible": bool(u.IsWindowVisible(hwnd)), "iconic": iconic,
                "tool": bool(ex & win32con.WS_EX_TOOLWINDOW) and not (ex & win32con.WS_EX_APPWINDOW),
                "cloaked": bool(cloaked.value), "owned": bool(win32gui.GetWindow(hwnd, win32con.GW_OWNER)),
                "width": max(0, r - l), "height": max(0, b - t)}

    def all_windows(self):
        """Все видимые окна верхнего уровня (словари, см. winmatch.pick_window)."""
        import win32gui
        hwnds = []
        win32gui.EnumWindows(lambda h, _: hwnds.append(h) or True, None)
        out = []
        for h in hwnds:
            try:
                if self.u32.IsWindowVisible(h):
                    out.append(self.window_info(h))
            except Exception:  # noqa: BLE001
                pass
        return out

    def list_windows(self):
        """[(hwnd, заголовок, exe)] — для «--list-windows» и выбора окна."""
        return [(w["hwnd"], w["title"], w["exe"]) for w in winmatch.picker_rows(self.all_windows(), self.own_pid)]

    def find_window(self, title_regex="", process_regex="", exclude_title_regex="", match="any", name=""):
        wins = self.all_windows()
        best = winmatch.pick_window(wins, title_regex, process_regex, exclude_title_regex, match, self.own_pid)
        if best:
            log.debug("%s: окно «%s» (%s, %d×%d)", name or "окно", best["title"], best["exe"],
                      best["width"], best["height"])
            return best["hwnd"]
        log.warning("%s: окно не найдено (заголовок «%s», процесс «%s»). Видимые окна:\n%s", name or "Источник",
                    title_regex, process_regex, "\n".join(winmatch.describe(wins)))
        return None

    def foreground(self):
        return self.u32.GetForegroundWindow()

    # ---------- проверка готовности окна (2.1.5) ----------
    @staticmethod
    def _private_user32():
        """Свой экземпляр user32 с argtypes — не влияет на ctypes.windll.user32 остального кода."""
        global _U32_READY
        if _U32_READY is None:
            u = ctypes.WinDLL("user32", use_last_error=True)
            u.IsHungAppWindow.argtypes = (wt.HWND,)
            u.IsHungAppWindow.restype = wt.BOOL
            u.IsWindow.argtypes = (wt.HWND,)
            u.IsWindow.restype = wt.BOOL
            u.GetForegroundWindow.argtypes = ()
            u.GetForegroundWindow.restype = wt.HWND
            u.GetAncestor.argtypes = (wt.HWND, wt.UINT)
            u.GetAncestor.restype = wt.HWND
            u.SendMessageTimeoutW.argtypes = (wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM, wt.UINT, wt.UINT,
                                              ctypes.POINTER(ctypes.c_size_t))
            u.SendMessageTimeoutW.restype = ctypes.c_size_t
            _U32_READY = u
        return _U32_READY

    def window_exists(self, hwnd):
        return bool(hwnd) and bool(self._private_user32().IsWindow(hwnd))

    def is_hung(self, hwnd, timeout_ms=1000):
        """True — окно «не отвечает»: IsHungAppWindow или нет ответа на WM_NULL за timeout_ms."""
        u = self._private_user32()
        if not u.IsWindow(hwnd):
            return True
        if u.IsHungAppWindow(hwnd):
            return True
        res = ctypes.c_size_t(0)
        # WM_NULL = 0, SMTO_ABORTIFHUNG = 0x2 | SMTO_BLOCK = 0x1
        ok = u.SendMessageTimeoutW(hwnd, 0, 0, 0, 0x0003, int(timeout_ms), ctypes.byref(res))
        return not ok

    def is_foreground(self, hwnd):
        """Активно ли окно hwnd (или его диалог — то же корневое окно / тот же процесс)."""
        u = self._private_user32()
        fg = u.GetForegroundWindow()
        if not fg or not hwnd:
            return False
        if int(fg) == int(hwnd):
            return True
        GA_ROOTOWNER = 3
        if u.GetAncestor(fg, GA_ROOTOWNER) == u.GetAncestor(hwnd, GA_ROOTOWNER):
            return True
        return self._pid(fg) == self._pid(hwnd)

    def _alt_tap(self):
        self._send_keys([(0x12, False), (0x12, True)])

    def _set_foreground(self, hwnd):
        import win32con
        import win32gui
        u = self.u32
        if u.GetForegroundWindow() == hwnd:
            return True
        try:
            u.AllowSetForegroundWindow(-1)
        except Exception:  # noqa: BLE001
            pass
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, win32con.SW_RESTORE)
        u.SetForegroundWindow(hwnd)
        if u.GetForegroundWindow() == hwnd:
            return True
        # Windows запрещает «красть» фокус: Alt + подключение к потоку активного окна
        fg = u.GetForegroundWindow()
        cur = ctypes.windll.kernel32.GetCurrentThreadId()
        fg_thread = u.GetWindowThreadProcessId(fg, None) if fg else 0
        tgt_thread = u.GetWindowThreadProcessId(hwnd, None)
        attached = []
        try:
            self._alt_tap()
            for t in {fg_thread, tgt_thread}:
                if t and t != cur and u.AttachThreadInput(cur, t, True):
                    attached.append(t)
            u.BringWindowToTop(hwnd)
            u.ShowWindow(hwnd, win32con.SW_SHOW)
            u.SetForegroundWindow(hwnd)
            u.SetFocus(hwnd)
        except Exception:  # noqa: BLE001
            pass
        finally:
            for t in attached:
                u.AttachThreadInput(cur, t, False)
        if u.GetForegroundWindow() != hwnd:
            try:  # последний способ: поверх всех и обратно
                flags = win32con.SWP_NOMOVE | win32con.SWP_NOSIZE
                win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0, flags)
                win32gui.SetWindowPos(hwnd, win32con.HWND_NOTOPMOST, 0, 0, 0, 0, flags)
                u.SwitchToThisWindow(hwnd, True)
            except Exception:  # noqa: BLE001
                pass
        return u.GetForegroundWindow() == hwnd

    def activate(self, hwnd):
        import win32con
        if self.u32.IsIconic(hwnd):
            self.u32.ShowWindow(hwnd, win32con.SW_RESTORE)
            time.sleep(0.4)
        else:
            self.u32.ShowWindow(hwnd, win32con.SW_SHOW)
        if not self._set_foreground(hwnd):
            log.warning("Не удалось вывести окно на передний план (hwnd=%s)", hwnd)

    def set_foreground(self, hwnd):
        """Вернуть ранее активное окно (без изменения размера)."""
        if hwnd and self.u32.IsWindow(hwnd):
            self._set_foreground(hwnd)

    def maximize(self, hwnd):
        import win32con
        self.u32.ShowWindow(hwnd, win32con.SW_MAXIMIZE)

    def restore(self, hwnd):
        import win32con
        self.u32.ShowWindow(hwnd, win32con.SW_RESTORE)

    # ---------- геометрия ----------
    def monitor_rect(self, hwnd):
        import win32api
        info = win32api.GetMonitorInfo(win32api.MonitorFromWindow(hwnd, 2))  # 2 = NEAREST
        l, t, r, b = info["Monitor"]
        return (l, t, r - l, b - t)

    def monitor_by_index(self, index):
        with _mss() as sct:
            mons = sct.monitors
        if not 1 <= index < len(mons):
            raise ValueError(f"Монитор {index} не найден (доступно: {len(mons) - 1})")
        m = mons[index]
        return (m["left"], m["top"], m["width"], m["height"])

    def virtual_screen(self):
        return virtual_screen_rect()

    def window_rect(self, hwnd):
        import win32gui
        rect = wt.RECT()
        # DWMWA_EXTENDED_FRAME_BOUNDS = 9: видимая рамка без тени
        if ctypes.windll.dwmapi.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(rect), ctypes.sizeof(rect)) == 0:
            l, t, r, b = rect.left, rect.top, rect.right, rect.bottom
        else:
            l, t, r, b = win32gui.GetWindowRect(hwnd)
        ml, mt, mw, mh = self.monitor_rect(hwnd)
        if win32gui.GetWindowPlacement(hwnd)[1] == 3:  # развёрнуто: обрезаем по монитору
            l, t, r, b = max(l, ml), max(t, mt), min(r, ml + mw), min(b, mt + mh)
        return (l, t, max(1, r - l), max(1, b - t))

    # ---------- экран ----------
    def grab(self, rect):
        return grab_rect(rect)

    def locate(self, template_path, rect, confidence):
        from . import vision
        hay = vision.pil_to_bgr(self.grab(rect))
        found = vision.find_template(hay, vision.load_image(template_path), confidence)
        if not found:
            return None
        log.debug("Шаблон %s найден (%.2f)", template_path, found[2])
        return (rect[0] + found[0], rect[1] + found[1])

    # ---------- ввод ----------
    def _send(self, inputs):
        arr = (INPUT * len(inputs))(*inputs)
        sent = self.u32.SendInput(len(inputs), arr, ctypes.sizeof(INPUT))
        return sent == len(inputs)

    def _mouse(self, flags, ax=0, ay=0):
        i = INPUT(type=0)
        i.mi = MOUSEINPUT(ax, ay, 0, flags, 0, 0)
        return i

    def _target_denied(self, x, y):
        """Окно под точкой принадлежит процессу «выше нас» по правам?"""
        from .elevation import is_admin, process_elevated
        if is_admin():
            return False
        hwnd = self.u32.WindowFromPoint(wt.POINT(int(x), int(y)))
        if not hwnd:
            return False
        elevated = process_elevated(self._pid(hwnd))
        return elevated is None or elevated

    def _post_click(self, x, y, double=False):
        """Запасной путь: сообщения мыши прямо в окно под точкой."""
        pt = wt.POINT(int(x), int(y))
        hwnd = self.u32.WindowFromPoint(pt)
        if not hwnd:
            return False
        cpt = wt.POINT(int(x), int(y))
        self.u32.ScreenToClient(hwnd, ctypes.byref(cpt))
        child = self.u32.ChildWindowFromPointEx(hwnd, cpt, 0x0001 | 0x0004)  # SKIPINVISIBLE|SKIPTRANSPARENT
        if child and child != hwnd:
            hwnd = child
            cpt = wt.POINT(int(x), int(y))
            self.u32.ScreenToClient(hwnd, ctypes.byref(cpt))
        lp = (cpt.y & 0xFFFF) << 16 | (cpt.x & 0xFFFF)
        msgs = [(WM_LBUTTONDOWN, MK_LBUTTON), (WM_LBUTTONUP, 0)]
        if double:
            msgs += [(WM_LBUTTONDBLCLK, MK_LBUTTON), (WM_LBUTTONUP, 0)]
        ok = True
        for msg, wp in msgs:
            ok = bool(self.u32.PostMessageW(hwnd, msg, wp, lp)) and ok
            time.sleep(0.05)
        return ok

    def click(self, x, y, double=False):
        if self._target_denied(x, y):
            log.warning("Окно под точкой (%s, %s) запущено с правами выше наших", x, y)
            if not self._post_click(x, y, double):
                raise InputDenied(self.name)
            return
        ax, ay = absolute_coords(x, y, virtual_screen_rect())
        base = MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK
        ok = self._send([self._mouse(base | MOUSEEVENTF_MOVE, ax, ay)])
        time.sleep(0.08)
        for _ in range(2 if double else 1):
            ok = self._send([self._mouse(base | MOUSEEVENTF_LEFTDOWN, ax, ay)]) and ok
            time.sleep(0.05)
            ok = self._send([self._mouse(base | MOUSEEVENTF_LEFTUP, ax, ay)]) and ok
            time.sleep(0.08)
        if not ok:
            log.warning("SendInput не сработал (код %s) — пробую PostMessage", ctypes.GetLastError())
            if not self._post_click(x, y, double):
                raise InputDenied(self.name)

    def _send_keys(self, seq):
        inputs = []
        for code, up in seq:
            i = INPUT(type=1)
            flags = (KEYEVENTF_KEYUP if up else 0) | (KEYEVENTF_EXTENDEDKEY if code in EXTENDED else 0)
            i.ki = KEYBDINPUT(code, self.u32.MapVirtualKeyW(code, 0), flags, 0, 0)
            inputs.append(i)
        return self._send(inputs)

    def press(self, key):
        code = vk_code(key)
        if not self._send_keys([(code, False), (code, True)]):
            raise InputDenied(self.name)

    def input_hook_factory(self, on_mouse, on_key):
        """Перехватчик ввода для блокировки на время съёмки (см. app/inputlock.py)."""
        return LowLevelInputHook(on_mouse, on_key)

    def hotkey(self, *keys):
        codes = [vk_code(k) for k in keys]
        seq = [(c, False) for c in codes] + [(c, True) for c in reversed(codes)]
        if not self._send_keys(seq):
            raise InputDenied(self.name)


# ------------------------------------------------------------------ блокировка ввода на время съёмки
class LowLevelInputHook:
    """WH_MOUSE_LL + WH_KEYBOARD_LL в отдельном потоке со своим циклом сообщений.

    on_mouse(msg, flags) / on_key(msg, vk, flags) -> True — проглотить событие. Решения принимает
    app/inputlock.InputBlocker (события SendInput с флагом INJECTED он пропускает). Любая ошибка в
    колбэке — событие пропускается (лучше пропустить нажатие, чем «повесить» мышь).
    BlockInput не используется. Ctrl+Alt+Del система не даёт перехватить — он работает всегда."""

    WH_KEYBOARD_LL, WH_MOUSE_LL, HC_ACTION, WM_QUIT = 13, 14, 0, 0x0012

    def __init__(self, on_mouse, on_key):
        self.on_mouse = on_mouse
        self.on_key = on_key
        self._thread = None
        self._tid = None
        self._ready = None
        self._ok = False
        self._cancel = False

    def start(self, timeout=3.0):
        import threading
        self._ready = threading.Event()
        self._thread = threading.Thread(target=self._run, name="input-lock", daemon=True)
        self._thread.start()
        self._ready.wait(timeout)
        return self._ok

    def _run(self):
        import ctypes.wintypes as wt
        u32 = ctypes.WinDLL("user32", use_last_error=True)   # свой экземпляр: argtypes не влияют на остальной код
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        LRESULT = ctypes.c_ssize_t
        HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wt.WPARAM, wt.LPARAM)

        class MSLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [("pt", wt.POINT), ("mouseData", wt.DWORD), ("flags", wt.DWORD), ("time", wt.DWORD),
                        ("dwExtraInfo", ctypes.c_size_t)]

        class KBDLLHOOKSTRUCT(ctypes.Structure):
            _fields_ = [("vkCode", wt.DWORD), ("scanCode", wt.DWORD), ("flags", wt.DWORD), ("time", wt.DWORD),
                        ("dwExtraInfo", ctypes.c_size_t)]

        u32.SetWindowsHookExW.argtypes = (ctypes.c_int, HOOKPROC, wt.HINSTANCE, wt.DWORD)
        u32.SetWindowsHookExW.restype = wt.HHOOK
        u32.CallNextHookEx.argtypes = (wt.HHOOK, ctypes.c_int, wt.WPARAM, wt.LPARAM)
        u32.CallNextHookEx.restype = LRESULT
        u32.UnhookWindowsHookEx.argtypes = (wt.HHOOK,)
        u32.UnhookWindowsHookEx.restype = wt.BOOL
        u32.GetMessageW.argtypes = (ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT)
        u32.GetMessageW.restype = wt.BOOL
        u32.PeekMessageW.argtypes = (ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT, wt.UINT)
        u32.PeekMessageW.restype = wt.BOOL
        k32.GetModuleHandleW.argtypes = (wt.LPCWSTR,)
        k32.GetModuleHandleW.restype = wt.HMODULE

        def mouse_proc(n_code, w_param, l_param):
            try:
                if n_code == self.HC_ACTION:
                    info = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                    if self.on_mouse(int(w_param), int(info.flags)):
                        return 1
            except Exception:  # noqa: BLE001
                pass
            return u32.CallNextHookEx(None, n_code, w_param, l_param)

        def key_proc(n_code, w_param, l_param):
            try:
                if n_code == self.HC_ACTION:
                    info = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                    if self.on_key(int(w_param), int(info.vkCode), int(info.flags)):
                        return 1
            except Exception:  # noqa: BLE001
                pass
            return u32.CallNextHookEx(None, n_code, w_param, l_param)

        # ссылки на колбэки должны жить, пока стоят хуки
        self._procs = (HOOKPROC(mouse_proc), HOOKPROC(key_proc))
        msg = wt.MSG()
        u32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)   # создать очередь сообщений потока
        self._tid = k32.GetCurrentThreadId()
        hmod = k32.GetModuleHandleW(None)
        h_mouse = u32.SetWindowsHookExW(self.WH_MOUSE_LL, self._procs[0], hmod, 0)
        h_key = u32.SetWindowsHookExW(self.WH_KEYBOARD_LL, self._procs[1], hmod, 0)
        self._ok = bool(h_mouse and h_key)
        if not self._ok:
            log.warning("SetWindowsHookEx не сработал (код %s)", ctypes.get_last_error())
        try:
            self._ready.set()
            while self._ok and not self._cancel:
                r = u32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if r == 0 or r == -1:   # WM_QUIT или ошибка
                    break
        finally:
            for h in (h_mouse, h_key):
                if h:
                    u32.UnhookWindowsHookEx(h)
            self._ok = False
            self._ready.set()

    def stop(self, timeout=2.0):
        import threading
        self._cancel = True
        t = self._thread
        if t is None:
            return
        if self._tid:
            ctypes.windll.user32.PostThreadMessageW(self._tid, self.WM_QUIT, 0, 0)
        if t is not threading.current_thread():
            t.join(timeout)
        self._thread = None


def get_backend():
    if sys.platform != "win32":
        raise RuntimeError("Съёмка окон работает только в Windows")
    return WinBackend()
