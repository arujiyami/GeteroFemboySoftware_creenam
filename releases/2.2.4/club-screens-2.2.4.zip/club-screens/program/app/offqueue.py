# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: очередь без интернета. Нет связи с vk.com — снимки съёма остаются в очереди (state/queue.json)
и уходят, когда связь вернётся: старые первыми, одним сообщением (не больше 10 картинок), с подписью
времени каждого съёма. Уборка старых файлов очередь не трогает; очередь не длиннее offline_queue.max_cycles."""
import json
import os
import socket

VK_LIMIT = 10


def is_online(host="vk.com", port=443, timeout=4.0):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


class OfflineQueue:
    def __init__(self, path, max_cycles=12):
        self.path = path
        self.max_cycles = max(1, int(max_cycles or 12))

    def items(self):
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            return [x for x in data if isinstance(x, dict) and x.get("paths")]
        except (OSError, ValueError):
            return []

    def _save(self, items):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)

    def add(self, stamp, when, paths):
        """→ список выкинутых (самых старых) записей, если очередь переполнена."""
        items = [x for x in self.items() if x["stamp"] != stamp]
        items.append({"stamp": stamp, "time": when.strftime("%d.%m %H:%M"), "paths": list(paths)})
        dropped = items[:-self.max_cycles] if len(items) > self.max_cycles else []
        self._save(items[-self.max_cycles:])
        return dropped

    def stamps(self):
        return {x["stamp"] for x in self.items()}

    def take(self, room=VK_LIMIT):
        """Старые первыми, целыми съёмами, пока влезает в room картинок. Пропавшие файлы отбрасываются."""
        out, n = [], 0
        for x in self.items():
            paths = [p for p in x["paths"] if os.path.exists(p)]
            if not paths:
                continue
            if n + len(paths) > room:
                break
            out.append(dict(x, paths=paths))
            n += len(paths)
        return out

    def remove(self, stamps):
        stamps = set(stamps)
        items = self.items()
        left = [x for x in items if x["stamp"] not in stamps]
        # заодно выкидываем записи, у которых не осталось файлов
        left = [x for x in left if any(os.path.exists(p) for p in x["paths"])]
        if left != items:
            self._save(left)

    def __len__(self):
        return len(self.items())


def caption(entries, current=None):
    """«Не было интернета — снимки по порядку: 03:00, 04:00; сейчас 05:00»."""
    times = [e["time"].split()[-1] if len(entries) < 2 or entries[0]["time"][:5] == entries[-1]["time"][:5]
             else e["time"] for e in entries]
    text = "Не было интернета — снимки по порядку: " + ", ".join(
        f"{t} ({len(e['paths'])} шт.)" for t, e in zip(times, entries))
    if current:
        text += f"; последние — {current}"
    return text
