# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.2: «Проверять в :05, что скрины ушли» (sent_check.enabled, по умолчанию выключено).
Через check_after_min минут после планового съёма (обычно в ЧЧ:05) смотрим журнал съёмов
(logs/cycles.jsonl): снялось ли и ушло ли сообщение за этот час. Если нет — своё заметное окно поверх
всех окон (не уведомление Windows). Чистая логика — без Qt, проверяется тестами."""
from datetime import timedelta

CHECK_AFTER_MIN = 5
PENDING_LIMIT_MIN = 20      # идёт повтор (вторая попытка через ~3 мин) — ждём его итога, но не дольше

NOT_CAPTURED = "not_captured"
NOT_SENT = "not_sent"


def settings(cfg):
    s = (cfg or {}).get("sent_check") or {}
    return {"enabled": bool(s.get("enabled", False)), "sound": bool(s.get("sound", True))}


def target_for(now, minute):
    """Время планового съёма, который проверяется сейчас: последний ЧЧ:minute не позже now."""
    t = now.replace(minute=int(minute or 0) % 60, second=0, microsecond=0)
    if t > now:
        t -= timedelta(hours=1)
    return t


def decide(now, minute, rows, running=True, started_at=None, skipped=(), busy=False, checked=None, done=None):
    """→ (target, verdict). verdict: None — проверять ещё рано / уже проверено / не нужно;
    'ok'; 'skip' (пропуск по просьбе, расписание остановлено, программа запущена позже);
    'pending' (цикл ещё идёт — например, ждёт вторую попытку); или словарь тревоги
    {'reason': NOT_CAPTURED|NOT_SENT, 'text': ..., 'detail': ...}."""
    target = target_for(now, minute)
    if checked == target:
        return target, None
    age = (now - target).total_seconds() / 60
    if age < CHECK_AFTER_MIN:
        return target, None
    if not running or target in set(skipped or ()):
        return target, "skip"
    if started_at is not None and started_at > target - timedelta(minutes=1):
        return target, "skip"
    if done:                     # 2.2.4: час уже закрыт (программа увидела отправку / ручная / найдено в беседе)
        return target, "ok"
    hour = [r for r in rows if target <= r["dt"] < target + timedelta(hours=1)]
    if any(r.get("sent") for r in hour):
        return target, "ok"
    if busy and age < PENDING_LIMIT_MIN:
        return target, "pending"
    planned = [r for r in hour if r.get("planned", True)] or hour
    when = target.strftime("%H:%M")
    if not planned:
        return target, {"reason": NOT_CAPTURED, "text": f"Скрины за {when} не снялись",
                        "detail": "Плановый съём не состоялся (программа зависла, компьютер спал или съём не начался)."}
    r = planned[-1]
    if r.get("shots", 1) == 0:
        return target, {"reason": NOT_CAPTURED, "text": f"Скрины за {when} не снялись",
                        "detail": r.get("err") or "Не удалось снять Oasys и iVMS-4200."}
    if r.get("queued"):
        return target, {"reason": NOT_SENT, "text": f"Скрины за {when} не отправились",
                        "detail": "Нет интернета — снимки ждут в очереди и уйдут, когда связь вернётся."}
    return target, {"reason": NOT_SENT, "text": f"Скрины за {when} не отправились",
                    "detail": r.get("err") or "Отправка в ВК не удалась."}
