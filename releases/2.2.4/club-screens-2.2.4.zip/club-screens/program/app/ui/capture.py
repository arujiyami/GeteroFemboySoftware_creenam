# Original-Author: Владислав С.
# Created: 2026-10-28
"""«Обвести кнопку»: показываем снимок монитора с нужной программой и даём выделить кнопку мышкой."""
import logging
import time

from PySide6.QtCore import QPoint, QRect, Qt, Signal
from PySide6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QWidget

from .common import pil_to_pixmap

log = logging.getLogger("club")
HINT = "Выделите мышкой кнопку, Esc — отмена"
SUB = "Зажмите левую кнопку мыши и обведите кнопку с небольшим запасом"


def screen_for_rect(rect):
    """Экран Qt, на котором лежит прямоугольник rect=(x, y, w, h) в пикселях Windows."""
    screens = QGuiApplication.screens()
    x, y, w, h = rect
    for s in screens:
        g, dpr = s.geometry(), s.devicePixelRatio()
        if abs(g.x() * dpr - x) < 4 and abs(g.y() * dpr - y) < 4:
            return s
    for s in screens:
        g, dpr = s.geometry(), s.devicePixelRatio()
        if QRect(int(g.x() * dpr), int(g.y() * dpr), int(g.width() * dpr), int(g.height() * dpr)).contains(
                QPoint(x + w // 2, y + h // 2)):
            return s
    return QGuiApplication.primaryScreen()


class CaptureOverlay(QWidget):
    """Полноэкранный снимок; выделение переводится в пиксели снимка по пропорции (любой масштаб)."""

    finished = Signal(object)  # PIL.Image | None

    def __init__(self, shot, rect=None):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint |
                         Qt.WindowType.Tool)
        self.shot = shot
        self.pix = pil_to_pixmap(shot)
        self.start = self.end = None
        self._done = False
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        screen = screen_for_rect(rect or (0, 0, shot.width, shot.height))
        self.setScreen(screen)
        self.setGeometry(screen.geometry())

    def open(self):
        self.showFullScreen()
        self.raise_()
        self.activateWindow()
        self.setFocus()

    def _sel(self):
        if not self.start or not self.end:
            return None
        return QRect(self.start, self.end).normalized()

    def paintEvent(self, _):  # noqa: N802
        p = QPainter(self)
        p.drawPixmap(self.rect(), self.pix)
        f = QFont(self.font())
        f.setPointSize(20)
        f.setBold(True)
        p.setFont(f)
        top = QRect(0, 24, self.width(), 50)
        br = p.boundingRect(top, Qt.AlignmentFlag.AlignCenter, HINT)
        f2 = QFont(self.font())
        f2.setPointSize(12)
        box = br.adjusted(-28, -12, 28, 40)
        p.fillRect(box, QColor(27, 27, 27, 235))
        p.setPen(QPen(QColor("#ff4040"), 3))
        p.drawRect(box)
        p.setPen(QColor("white"))
        p.drawText(top, Qt.AlignmentFlag.AlignCenter, HINT)
        p.setFont(f2)
        p.setPen(QColor("#ffe08a"))
        p.drawText(QRect(0, br.bottom() + 4, self.width(), 26), Qt.AlignmentFlag.AlignCenter, SUB)
        r = self._sel()
        if r:
            p.setPen(QPen(QColor("#ff2020"), 2))
            p.drawRect(r)

    def mousePressEvent(self, e):  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton:
            self.start = self.end = e.position().toPoint()
            self.update()
        elif e.button() == Qt.MouseButton.RightButton:
            self._finish(None)

    def mouseMoveEvent(self, e):  # noqa: N802
        if self.start:
            self.end = e.position().toPoint()
            self.update()

    def mouseReleaseEvent(self, e):  # noqa: N802
        if not self.start:
            return
        self.end = e.position().toPoint()
        r = self._sel()
        if r is None or r.width() < 6 or r.height() < 6:
            self.start = self.end = None
            self.update()
            return
        self._finish(self.crop(r))

    def crop(self, r):
        kx = self.shot.width / max(1, self.width())
        ky = self.shot.height / max(1, self.height())
        box = (int(r.left() * kx), int(r.top() * ky), int((r.right() + 1) * kx), int((r.bottom() + 1) * ky))
        return self.shot.crop(box)

    def keyPressEvent(self, e):  # noqa: N802
        if e.key() == Qt.Key.Key_Escape:
            self._finish(None)

    def _finish(self, img):
        if self._done:
            return
        self._done = True
        self.finished.emit(img)
        self.close()


def prepare_capture(backend, source, find, delay=1.2):
    """(в фоне) Показать окно программы и снять его монитор. → (rect, PIL.Image)."""
    hwnd = find(backend, source) if source else None
    if source and not hwnd:
        from ..steps import WindowNotFound
        raise WindowNotFound(f"{source.get('name')}: окно не найдено")
    if hwnd:
        backend.activate(hwnd)
        backend.maximize(hwnd)
    time.sleep(delay)
    rect = backend.monitor_rect(hwnd) if hwnd else backend.virtual_screen()
    return rect, backend.grab(rect)


def find_source_window(backend, source):
    w = source.get("window") or {}
    return backend.find_window(w.get("title_regex", ""), w.get("process_regex", ""),
                               w.get("exclude_title_regex", ""), w.get("match", "any"), source.get("name", ""))
