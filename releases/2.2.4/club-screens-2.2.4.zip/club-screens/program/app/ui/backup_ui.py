# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: «Сохранить резервную копию» / «Восстановить из копии» (.csbackup, шифрование паролем).
Пароль нигде не сохраняется и не пишется в журнал."""
import logging
import os
from datetime import date

from PySide6.QtWidgets import QFileDialog, QInputDialog, QLineEdit, QMessageBox

from .. import APP_NAME, __version__, backup
from ..config import resolve_path
from .common import Task

log = logging.getLogger("club")
MIN_PASSWORD = 8


def _password(parent, title, text):
    pw, ok = QInputDialog.getText(parent, title, text, QLineEdit.EchoMode.Password)
    return pw if ok else None


def _profile_dir(cfg):
    return resolve_path((cfg.get("vk_browser") or {}).get("profile_dir") or "browser_profile")


def export_dialog(parent, main):
    if QMessageBox.warning(parent, APP_NAME, backup.WARNING + "\n\nПродолжить?",
                           QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) \
            != QMessageBox.StandardButton.Yes:
        return
    path, _ = QFileDialog.getSaveFileName(parent, "Сохранить резервную копию",
                                          os.path.join(os.path.expanduser("~"),
                                                       f"club-screens-{date.today():%Y-%m-%d}.csbackup"),
                                          "Резервная копия (*.csbackup)")
    if not path:
        return
    if not path.lower().endswith(".csbackup"):
        path += ".csbackup"
    pw = _password(parent, "Пароль для копии", f"Придумайте пароль (не короче {MIN_PASSWORD} символов).\n"
                   "Без него копию не открыть — программа его не запоминает:")
    if pw is None:
        return
    if len(pw) < MIN_PASSWORD:
        QMessageBox.warning(parent, APP_NAME, f"Пароль короче {MIN_PASSWORD} символов — копия не сохранена.")
        return
    if _password(parent, "Пароль для копии", "Повторите пароль:") != pw:
        QMessageBox.warning(parent, APP_NAME, "Пароли не совпали — копия не сохранена.")
        return
    try:
        main.save_config(quiet=True)
    except Exception:  # noqa: BLE001
        pass

    def done(n):
        log.info("Резервная копия сохранена: %s", os.path.basename(path))
        QMessageBox.information(parent, APP_NAME, f"Копия сохранена:\n{path}\n\n{backup.WARNING}")
    Task(lambda: backup.export_backup(path, pw, main.cfg_path, _profile_dir(main.cfg), __version__), done,
         lambda e: QMessageBox.warning(parent, APP_NAME, f"Копия не сохранена: {e}"), name="backup")


def import_dialog(parent, main):
    path, _ = QFileDialog.getOpenFileName(parent, "Восстановить из копии", os.path.expanduser("~"),
                                          "Резервная копия (*.csbackup)")
    if not path:
        return
    try:
        h = backup.read_header(path)[0]
    except Exception as e:  # noqa: BLE001
        QMessageBox.warning(parent, APP_NAME, f"Это не резервная копия программы: {e}")
        return
    if QMessageBox.question(parent, APP_NAME,
                            f"Копия от {h.get('created', '?')} (версия {h.get('app', '?')}).\n\n"
                            "Текущие настройки и вход в ВК будут заменены (старые настройки — в config.yaml.bak). "
                            "Вход в ВК подставится после перезапуска программы. Продолжить?") \
            != QMessageBox.StandardButton.Yes:
        return
    pw = _password(parent, "Пароль копии", "Пароль, заданный при сохранении копии:")
    if not pw:
        return

    def done(res):
        log.info("Восстановлено из резервной копии")
        QMessageBox.information(parent, APP_NAME, "Готово. Перезапустите программу (значок у часов → «Выход», "
                                "затем снова откройте), чтобы применились настройки и вход в ВК.")
        try:
            main.check_config_file()
        except Exception:  # noqa: BLE001
            pass
    Task(lambda: backup.import_backup(path, pw, main.cfg_path, _profile_dir(main.cfg)), done,
         lambda e: QMessageBox.warning(parent, APP_NAME, f"Не удалось восстановить: {e}"), name="restore")
