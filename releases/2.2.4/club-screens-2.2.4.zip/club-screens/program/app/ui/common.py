# Original-Author: Владислав С.
# Created: 2026-10-28
"""Общее для окон Qt: цвета, стиль, картинки, фоновые задачи, значок."""
import logging
import os
import subprocess
import sys
import threading

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QFont, QIcon, QImage, QPixmap
from PySide6.QtWidgets import QApplication, QCheckBox, QLabel, QMessageBox, QPushButton, QSizePolicy

log = logging.getLogger("club")

BLUE, GREEN, RED, ORANGE, GREY, DARK = "#2f6fd8", "#1f9d55", "#d64545", "#e08a00", "#8a94a6", "#1f2a3a"
VK_BLUE = "#0077ff"

# 2.1.8: цвета и стиль — в theme.py (светлая / тёмная / высокий контраст, «как в Windows»). Здесь остались
# только «смысловые» имена цветов: по ним кнопкам и надписям ставится тон (tone/state) из текущей темы.
from . import theme  # noqa: E402
ACCENT = BLUE
TONE = {BLUE: "accent", VK_BLUE: "accent", GREEN: "ok", RED: "bad", ORANGE: "warn", GREY: "idle", DARK: "idle"}


def tone_of(color):
    """Тон («ok» / «warn» / «bad» / «idle» / «accent») для смыслового цвета BLUE/GREEN/RED/ORANGE/GREY."""
    return TONE.get(color, "idle")


def tone_color(tone):
    """Цвет тона в текущей теме (для того, что рисуется вручную)."""
    return theme.P.get({"accent": "accent_fg"}.get(tone, tone), theme.P["idle"])


def arrow_files():
    """Стрелки ▲▼ для полей-счётчиков и списков (цвет — по текущей теме)."""
    return theme.arrow_files()


def input_style(scope=""):
    """(2.1.8) Стиль полей теперь общий для всего приложения (theme.build_qss) — оставлено для совместимости."""
    return ""


class ToggleSwitch(QCheckBox):
    """Переключатель «вкл/выкл» как в Windows 11. Это обычный QCheckBox (isChecked, toggled, text) —
    только рисуется дорожкой с кружком; текст не рисуется (он — заголовок строки настроек)."""
    TRACK_W, TRACK_H = 40, 20

    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        from PySide6.QtCore import QVariantAnimation
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAccessibleName(text)
        self._pos = 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(120)
        self._anim.valueChanged.connect(self._set_pos)
        self.toggled.connect(self._animate)

    def _set_pos(self, v):
        self._pos = float(v)
        self.update()

    def _animate(self, on):
        self._anim.stop()
        if not self.isVisible():
            self._set_pos(1.0 if on else 0.0)
            return
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def setChecked(self, on):  # noqa: N802 (Qt)
        super().setChecked(on)
        if self._anim.state() != self._anim.State.Running:
            self._set_pos(1.0 if self.isChecked() else 0.0)

    def sizeHint(self):  # noqa: N802 (Qt)
        from PySide6.QtCore import QSize
        return QSize(self.TRACK_W + 4, self.TRACK_H + 4)

    minimumSizeHint = sizeHint

    def hitButton(self, pos):  # noqa: N802 (Qt)
        return self.rect().contains(pos)

    def paintEvent(self, _e):  # noqa: N802 (Qt)
        from PySide6.QtCore import QRectF
        from PySide6.QtGui import QColor, QPainter, QPen
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.TRACK_W, self.TRACK_H
        x0 = (self.width() - w) / 2
        y0 = (self.height() - h) / 2
        track = QRectF(x0 + 0.5, y0 + 0.5, w - 1, h - 1)
        enabled, t = self.isEnabled(), self._pos
        P = theme.P
        accent = QColor(P["accent"] if enabled else P["border"])
        off_border = QColor(P["toggle_off"] if enabled else P["border"])
        knob_on = QColor(P["on_accent"] if enabled else P["card"])
        if t > 0.5:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(accent)
        else:
            p.setPen(QPen(off_border, 1.2))
            p.setBrush(QColor(P["input"] if enabled else P["input_dis"]))
        p.drawRoundedRect(track, h / 2, h / 2)
        d = h - 8 if t <= 0.5 else h - 7
        cx = x0 + h / 2 + t * (w - h)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(knob_on if t > 0.5 else off_border)
        p.drawEllipse(QRectF(cx - d / 2, y0 + h / 2 - d / 2, d, d))
        if self.hasFocus() and self.focusPolicy() != Qt.FocusPolicy.NoFocus:
            p.setPen(QPen(QColor(P["focus"]), 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(track.adjusted(-2, -2, 2, 2), h / 2 + 2, h / 2 + 2)
        p.end()


def help_icon(text):
    """Значок «?» — подробное пояснение во всплывающей подсказке (наведите мышь или щёлкните)."""
    lbl = QLabel("?")
    lbl.setObjectName("helpIcon")
    lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
    lbl.setFixedSize(18, 18)
    lbl.setToolTip(text)
    lbl.setCursor(Qt.CursorShape.WhatsThisCursor)
    lbl.setAccessibleDescription(text)

    def press(_e, lbl=lbl):
        from PySide6.QtWidgets import QToolTip
        QToolTip.showText(lbl.mapToGlobal(lbl.rect().bottomLeft()), lbl.toolTip(), lbl)
    lbl.mousePressEvent = press
    return lbl


STATUS_STYLES = {"ok": "ok", "bad": "bad", "wait": "wait", "muted": "muted", "big": "big"}


def label(text="", kind=None, wrap=True, parent=None):
    lbl = QLabel(text, parent)
    if kind:
        lbl.setObjectName(kind)
    lbl.setWordWrap(wrap)
    lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    return lbl


def set_status(lbl, text, kind="muted"):
    """Строка состояния: ✔ / ✖ / ⏳ — цвет по виду."""
    lbl.setText(text)
    if lbl.objectName() != kind:
        lbl.setObjectName(kind)
        lbl.style().unpolish(lbl)
        lbl.style().polish(lbl)


def big_button(text, color=BLUE, on_click=None):
    b = QPushButton(text)
    b.setProperty("kind", "big")
    b.setProperty("tone", tone_of(color))      # цвет — из темы (accent / ok / bad / warn)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
    if on_click:
        b.clicked.connect(on_click)
    return b


def link_button(text, on_click=None):
    b = QPushButton(text)
    b.setFlat(True)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setObjectName("link")                    # вид — в theme.py (QPushButton#link)
    if on_click:
        b.clicked.connect(on_click)
    return b


def pil_to_pixmap(img):
    img = img.convert("RGBA")
    data = img.tobytes("raw", "RGBA")
    q = QImage(data, img.width, img.height, img.width * 4, QImage.Format.Format_RGBA8888)
    return QPixmap.fromImage(q.copy())


def set_image(lbl, img_or_path, size, empty_text=""):
    """Картинка (PIL или путь) в QLabel, вписанная в size=(w, h)."""
    pm = None
    try:
        if isinstance(img_or_path, str) and os.path.exists(img_or_path):
            pm = QPixmap(img_or_path)
        elif img_or_path is not None and not isinstance(img_or_path, str):
            pm = pil_to_pixmap(img_or_path)
    except Exception:  # noqa: BLE001
        pm = None
    if pm is None or pm.isNull():
        lbl.setPixmap(QPixmap())
        lbl.setText(empty_text)
        return
    lbl.setText("")
    lbl.setPixmap(pm.scaled(size[0], size[1], Qt.AspectRatioMode.KeepAspectRatio,
                            Qt.TransformationMode.SmoothTransformation))


def open_path(path):
    if sys.platform == "win32":
        os.startfile(path)  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def app_icon(badge=None):
    from ..icon import camera_image
    ic = QIcon()
    for s in (16, 24, 32, 48, 64):
        ic.addPixmap(pil_to_pixmap(camera_image(size=s, badge=badge)))
    return ic


class _Signals(QObject):
    done = Signal(object, object)  # результат, ошибка


class Task:
    """Выполнить fn() в фоновом потоке; done(результат) / fail(ошибка) — в потоке окна."""

    _alive = set()

    def __init__(self, fn, done=None, fail=None, name="task"):
        self.sig = _Signals()
        self.sig.done.connect(self._finish, Qt.ConnectionType.QueuedConnection)
        self.fn, self.done_cb, self.fail_cb = fn, done, fail
        Task._alive.add(self)
        threading.Thread(target=self._run, name=name, daemon=True).start()

    def _run(self):
        try:
            res, err = self.fn(), None
        except Exception as e:  # noqa: BLE001
            res, err = None, e
        try:
            self.sig.done.emit(res, err)
        except RuntimeError:
            pass

    def _finish(self, res, err):
        Task._alive.discard(self)
        try:
            if err is not None:
                log.debug("Фоновая задача: %s", err, exc_info=err)
                if self.fail_cb:
                    self.fail_cb(err)
                else:
                    log.error("%s", err)
            elif self.done_cb:
                self.done_cb(res)
        except Exception:  # noqa: BLE001
            log.exception("Ошибка интерфейса")


class GuiCall(QObject):
    """Выполнить функцию в потоке окна из любого потока (и при желании дождаться)."""

    _sig = Signal(object)

    def __init__(self):
        super().__init__()
        self._sig.connect(self._run, Qt.ConnectionType.QueuedConnection)
        self._gui = threading.get_ident()

    def _run(self, box):
        try:
            box["result"] = box["fn"]()
        except Exception as e:  # noqa: BLE001
            box["error"] = e
        box["event"].set()

    def __call__(self, fn, wait=None):
        if threading.get_ident() == self._gui:
            return fn()
        box = {"fn": fn, "event": threading.Event()}
        self._sig.emit(box)
        if wait is not None:
            box["event"].wait(wait)
            if "error" in box:
                raise box["error"]
            return box.get("result")
        return None


def exclude_from_capture(widget, on):
    """Windows 10 2004+: окно программы не попадает на снимки экрана (WDA_EXCLUDEFROMCAPTURE)."""
    if sys.platform != "win32" or widget is None:
        return False
    try:
        import ctypes
        hwnd = int(widget.winId())
        return bool(ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, 0x11 if on else 0))
    except Exception:  # noqa: BLE001
        return False


def info(parent, title, text):
    QMessageBox.information(parent, title, text)


def warn(parent, title, text):
    QMessageBox.warning(parent, title, text)


def ask(parent, title, text):
    return QMessageBox.question(parent, title, text) == QMessageBox.StandardButton.Yes


def later(ms, fn):
    QTimer.singleShot(int(ms), fn)


def set_tone(button, color):
    """Сменить цвет большой кнопки (BLUE / GREEN / RED / ORANGE) — по текущей теме."""
    theme.repolish(button, tone=tone_of(color))


def ensure_font(app, cfg=None):
    f = QFont("Segoe UI" if sys.platform == "win32" else "DejaVu Sans", 10)
    app.setFont(f)
    QApplication.setStyle("Fusion")
    if cfg is not None:
        theme.apply_from_config(cfg, app, force=True)
    else:
        theme.apply(app)


def apply_light_palette(app):
    """(до 2.1.8) Всегда светлая тема. Теперь тема выбирается в настройках — см. theme.apply."""
    theme.apply(app, "light")
