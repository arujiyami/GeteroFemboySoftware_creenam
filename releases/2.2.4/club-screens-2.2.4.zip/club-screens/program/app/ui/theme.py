# Original-Author: Владислав С.
# Created: 2026-10-29
"""Темы оформления (2.1.8): все цвета интерфейса — здесь, в одном месте.

Тема: «system» (как в Windows), «light», «dark», «contrast» (высокий контраст). Стиль окна (QSS) собирается
из шаблона по палитре и ставится на всё приложение сразу — смена темы применяется без перезапуска во всех окнах
(главное окно, мастер, настройки, диалоги). Нарисованные вручную элементы (переключатели, точка состояния)
берут цвета из P при каждой перерисовке.
"""
import logging
import os
import sys

log = logging.getLogger("club")

THEMES = (("system", "Как в Windows"), ("light", "Светлая"), ("dark", "Тёмная"),
          ("contrast", "Высокий контраст"))
ACCENTS = (("blue", "Синий"), ("violet", "Фиолетовый"), ("teal", "Бирюзовый"), ("orange", "Оранжевый"))

# Акцент: (заливка кнопок в светлой теме, заливка в тёмной, цвет акцента как текста/рамки в тёмной).
# Белый текст на заливке — контраст не ниже 4.5:1 (проверяется тестом).
_ACCENT = {
    "blue": ("#1a56c4", "#2158c9", "#8fb8ff"),
    "violet": ("#6532c8", "#6d3bd4", "#c4b2ff"),
    "teal": ("#0b6b63", "#0d7068", "#6fe0d2"),
    "orange": ("#b23c0a", "#b8430f", "#ffb07a"),
}

LIGHT = {
    "name": "light", "dark": False,
    "bg": "#eceff3", "card": "#ffffff", "card_alt": "#f4f6f9", "hover": "#e6eaf0", "pressed": "#d9dfe8",
    "border": "#c2c9d3", "border_strong": "#7c8696", "divider": "#dfe3e9",
    "text": "#0d1520", "text2": "#394455", "text3": "#7b8492", "title": "#0a111b",
    "input": "#ffffff", "input_dis": "#eef0f3",
    "side": "#141c28", "side_text": "#dbe3ee", "side_muted": "#a9b6c8", "side_hover": "#26324a",
    "side_sel": "#ffffff", "side_sel_text": "#0d1520", "side_done": "#7fe0a8",
    "ok": "#11703b", "warn": "#80530a", "bad": "#b0201c", "idle": "#4a5463",
    "ok_bg": "#dcf2e4", "warn_bg": "#fbefd3", "bad_bg": "#fbe1de", "idle_bg": "#e4e8ee",
    "ok_fill": "#157a3e", "bad_fill": "#bf2a2a", "warn_fill": "#9a5b00", "on_fill": "#ffffff",
    "tip_bg": "#111827", "tip_text": "#ffffff",
    "scroll": "#a6afbc", "scroll_hover": "#768092", "seg_bar": "#dde2e9",
    "toggle_off": "#5f6979", "thumb_empty": "#9aa3b0",
}

DARK = {
    "name": "dark", "dark": True,
    "bg": "#15181d", "card": "#1f232a", "card_alt": "#262b33", "hover": "#2c323c", "pressed": "#363d49",
    "border": "#3a414d", "border_strong": "#8792a3", "divider": "#2e343e",
    "text": "#f1f3f6", "text2": "#c2c9d4", "text3": "#7d8696", "title": "#ffffff",
    "input": "#14171c", "input_dis": "#1b1f25",
    "side": "#0c0f13", "side_text": "#d9e0ea", "side_muted": "#9eabbd", "side_hover": "#1f2733",
    "side_sel": "#ffffff", "side_sel_text": "#0d1520", "side_done": "#7fe0a8",
    "ok": "#5ad08a", "warn": "#f2bf4a", "bad": "#ff8a80", "idle": "#b4bcc8",
    "ok_bg": "#173326", "warn_bg": "#3a2d10", "bad_bg": "#43201f", "idle_bg": "#2a2f37",
    "ok_fill": "#167a3e", "bad_fill": "#bd2d2d", "warn_fill": "#9a5b00", "on_fill": "#ffffff",
    "tip_bg": "#f1f3f6", "tip_text": "#0d1520",
    "scroll": "#4b5361", "scroll_hover": "#6c7586", "seg_bar": "#262b33",
    "toggle_off": "#a3acba", "thumb_empty": "#5d6573",
}

CONTRAST = {
    "name": "contrast", "dark": True,
    "bg": "#000000", "card": "#000000", "card_alt": "#101010", "hover": "#1c1c1c", "pressed": "#2a2a2a",
    "border": "#ffffff", "border_strong": "#ffffff", "divider": "#9a9a9a",
    "text": "#ffffff", "text2": "#f0f0f0", "text3": "#a8a8a8", "title": "#ffffff",
    "input": "#000000", "input_dis": "#000000",
    "side": "#000000", "side_text": "#ffffff", "side_muted": "#e0e0e0", "side_hover": "#1c1c1c",
    "side_sel": "#ffe600", "side_sel_text": "#000000", "side_done": "#6dff6d",
    "ok": "#6dff6d", "warn": "#ffe600", "bad": "#ff8c8c", "idle": "#ffffff",
    "ok_bg": "#000000", "warn_bg": "#000000", "bad_bg": "#000000", "idle_bg": "#000000",
    "ok_fill": "#6dff6d", "bad_fill": "#ff8c8c", "warn_fill": "#ffe600", "on_fill": "#000000",
    "accent": "#ffe600", "accent_fg": "#ffe600", "on_accent": "#000000", "accent_hover": "#fff27a",
    "accent_soft": "#3a3500", "accent_soft_text": "#ffffff", "link": "#7fd7ff", "focus": "#7fd7ff",
    "tip_bg": "#ffffff", "tip_text": "#000000",
    "scroll": "#cfcfcf", "scroll_hover": "#ffffff", "seg_bar": "#000000",
    "toggle_off": "#ffffff", "thumb_empty": "#ffffff",
}


def _mix(a, b, t):
    a, b = a.lstrip("#"), b.lstrip("#")
    ca = [int(a[i:i + 2], 16) for i in (0, 2, 4)]
    cb = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(ca, cb))


def luminance(c):
    c = c.lstrip("#")
    out = []
    for i in (0, 2, 4):
        v = int(c[i:i + 2], 16) / 255
        out.append(v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4)
    return 0.2126 * out[0] + 0.7152 * out[1] + 0.0722 * out[2]


def contrast(a, b):
    """Контраст по WCAG 2.x (1…21)."""
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def palette(name="light", accent="blue"):
    """Готовая палитра (словарь цветов) для темы и акцента. name — уже без «system»."""
    if name == "contrast":
        return dict(CONTRAST)
    base = dict(DARK if name == "dark" else LIGHT)
    fill_l, fill_d, fg_d = _ACCENT.get(accent) or _ACCENT["blue"]
    if base["dark"]:
        base.update(accent=fill_d, accent_fg=fg_d, link=fg_d, focus=fg_d,
                    accent_hover=_mix(fill_d, "#ffffff", 0.12), accent_soft=_mix(fill_d, base["card"], 0.62),
                    accent_soft_text="#ffffff")
    else:
        base.update(accent=fill_l, accent_fg=fill_l, link=fill_l, focus=fill_l,
                    accent_hover=_mix(fill_l, "#000000", 0.15), accent_soft=_mix(fill_l, "#ffffff", 0.86),
                    accent_soft_text=_mix(fill_l, "#000000", 0.45))
    base["on_accent"] = "#ffffff"
    return base


# ------------------------------------------------------------------ тема Windows
def windows_prefers_dark(reader=None):
    """True — в Windows включён тёмный режим приложений (HKCU\\...\\Personalize, AppsUseLightTheme = 0).
    reader — для тестов: функция () -> значение AppsUseLightTheme или исключение."""
    if reader is None:
        if sys.platform != "win32":
            return _qt_prefers_dark()
        reader = _read_apps_use_light_theme
    try:
        return int(reader()) == 0
    except Exception:  # noqa: BLE001 — нет ключа (Windows 7/8) — светлая
        return False


def _read_apps_use_light_theme():
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                        r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize") as k:
        return winreg.QueryValueEx(k, "AppsUseLightTheme")[0]


def _qt_prefers_dark():
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QGuiApplication
        return QGuiApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
    except Exception:  # noqa: BLE001
        return False


def resolve(mode, reader=None):
    """«system» → «light»/«dark» по настройке Windows; неизвестное значение → «system»."""
    mode = (mode or "system").strip().lower()
    if mode not in dict(THEMES):
        mode = "system"
    if mode == "system":
        return "dark" if windows_prefers_dark(reader) else "light"
    return mode


# ------------------------------------------------------------------ текущая тема
P = palette("light")          # текущая палитра (меняется на месте при смене темы)
STATE = {"mode": "system", "accent": "blue", "applied": False}
_listeners = []


def on_change(fn):
    """fn() вызывается после смены темы (для элементов со своим рисованием)."""
    _listeners.append(fn)


def color(key):
    return P.get(key, "#ff00ff")


# ------------------------------------------------------------------ стрелки для счётчиков/списков
def arrow_files(col=None):
    """Шевроны ▲▼ цвета col (по теме) — рисуются один раз во временную папку."""
    import tempfile
    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPolygonF
    col = col or P["text2"]
    folder = os.path.join(tempfile.gettempdir(), "club-screens-ui")
    os.makedirs(folder, exist_ok=True)
    out = {}
    for name, pts in (("up", ((5, 13), (10, 8), (15, 13))), ("down", ((5, 8), (10, 13), (15, 8)))):
        path = os.path.join(folder, f"chevron-{name}-{col.lstrip('#')}.png")
        if not os.path.exists(path):
            img = QImage(20, 20, QImage.Format.Format_ARGB32)
            img.fill(0)
            pnt = QPainter(img)
            pnt.setRenderHint(QPainter.RenderHint.Antialiasing)
            pen = QPen(QColor(col))
            pen.setWidthF(2.2)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            pnt.setPen(pen)
            pnt.drawPolyline(QPolygonF([QPointF(x, y) for x, y in pts]))
            pnt.end()
            img.save(path)
        out[name] = path.replace("\\", "/")
    return out


# ------------------------------------------------------------------ шаблон стиля
BASE_QSS = """
QWidget { font-size: 10.5pt; color: %(text)s; }
QMainWindow, QDialog, QMessageBox, #page, #wizard { background: %(bg)s; }
QLabel { background: transparent; }
QLineEdit, QPlainTextEdit, QTextEdit, QListWidget, QAbstractItemView {
    background: %(input)s; color: %(text)s; border: 1px solid %(border_strong)s; border-radius: 6px;
    selection-background-color: %(accent)s; selection-color: %(on_accent)s; }
QLineEdit { padding: 5px 8px; }
QPlainTextEdit, QTextEdit { padding: 4px; }
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QListWidget:focus {
    border: 2px solid %(focus)s; }
QLineEdit:disabled, QPlainTextEdit:disabled { color: %(text3)s; background: %(input_dis)s; border-color: %(border)s; }
QListWidget { padding: 4px; outline: 0; }
QListWidget::item { padding: 6px 8px; border-radius: 6px; color: %(text)s; }
QListWidget::item:hover:!selected { background: %(hover)s; }
QListWidget::item:selected { background: %(accent_soft)s; color: %(accent_soft_text)s; }
QCheckBox, QRadioButton { color: %(text)s; spacing: 8px; background: transparent; }
QCheckBox:disabled, QRadioButton:disabled { color: %(text3)s; }
QPushButton, QToolButton { background: %(card)s; color: %(text)s; border: 1px solid %(border_strong)s;
              border-radius: 6px; padding: 6px 14px; }
QPushButton:hover, QToolButton:hover { background: %(hover)s; }
QPushButton:pressed, QToolButton:pressed { background: %(pressed)s; }
QPushButton:disabled, QToolButton:disabled { color: %(text3)s; background: %(card_alt)s; border-color: %(border)s; }
QPushButton:focus, QToolButton:focus { border: 2px solid %(focus)s; padding: 5px 13px; }
QPushButton:default { border: 2px solid %(accent_fg)s; padding: 5px 13px; }
#nav { background: %(side)s; border: none; color: %(side_text)s; font-size: 11.5pt; outline: 0; }
#nav::item { padding: 10px 14px; margin: 2px 8px; border: none; border-radius: 6px; color: %(side_text)s; }
#nav::item:selected { background: %(side_sel)s; color: %(side_sel_text)s; font-weight: 700; }
#nav::item:hover:!selected { background: %(side_hover)s; color: #ffffff; }
#nav:focus { border: none; }
#side { background: %(side)s; }
#side QLabel { color: %(side_text)s; }
#side #sideTitle { color: #ffffff; font-size: 12.5pt; font-weight: 700; }
#side #sideMuted { color: %(side_muted)s; font-size: 10pt; }
#side #aboutBtn { color: %(side_text)s; background: transparent; border: 1px solid %(side_muted)s;
                  border-radius: 6px; padding: 3px 10px; font-size: 9.5pt; }
#side #aboutBtn:hover { background: %(side_sel)s; color: %(side_sel_text)s; }
#side #aboutBtn:focus { border: 2px solid %(side_text)s; }
#side #sideStep { color: %(side_muted)s; font-size: 11pt; padding: 7px 12px; border-radius: 6px; }
#side #sideStep[state="cur"] { background: %(side_sel)s; color: %(side_sel_text)s; font-weight: 700; }
#side #sideStep[state="done"] { color: %(side_done)s; }
#title { font-size: 19pt; font-weight: 700; color: %(title)s; }
#pageDesc { font-size: 10.5pt; color: %(text2)s; }
#big { font-size: 12pt; color: %(text)s; }
#subTitle { font-size: 12.5pt; font-weight: 700; color: %(title)s; }
#muted, #hint { color: %(text2)s; }
#ok { color: %(ok)s; font-size: 11.5pt; font-weight: 600; }
#bad { color: %(bad)s; font-size: 11.5pt; font-weight: 600; }
#wait { color: %(warn)s; font-size: 11.5pt; font-weight: 600; }
#card { background: %(card)s; border: 1px solid %(border)s; border-radius: 10px; }
#statusCard { background: %(card)s; border: 1px solid %(border)s; border-left: 6px solid %(idle)s;
              border-radius: 10px; }
#statusCard[state="ok"] { background: %(ok_bg)s; border-color: %(ok)s; }
#statusCard[state="warn"] { background: %(warn_bg)s; border-color: %(warn)s; }
#statusCard[state="bad"] { background: %(bad_bg)s; border-color: %(bad)s; }
#statusCard[state="idle"] { background: %(idle_bg)s; border-color: %(idle)s; }
#statusText { font-size: 21pt; font-weight: 700; color: %(text)s; }
#statusText[state="ok"] { color: %(ok)s; }
#statusText[state="warn"] { color: %(warn)s; }
#statusText[state="bad"] { color: %(bad)s; }
#statusText[state="idle"] { color: %(idle)s; }
#statusSub { font-size: 12pt; color: %(text)s; }
#chip { border-radius: 12px; padding: 3px 12px; font-size: 10pt; font-weight: 600;
        background: %(idle_bg)s; color: %(idle)s; border: 1px solid %(idle)s; }
#chip[state="ok"] { background: %(ok_bg)s; color: %(ok)s; border-color: %(ok)s; }
#chip[state="warn"] { background: %(warn_bg)s; color: %(warn)s; border-color: %(warn)s; }
#chip[state="bad"] { background: %(bad_bg)s; color: %(bad)s; border-color: %(bad)s; }
#lastText { font-size: 11pt; color: %(text)s; }
#lastText[state="ok"] { color: %(ok)s; }
#lastText[state="warn"] { color: %(warn)s; }
#lastText[state="bad"] { color: %(bad)s; }
#thumb { background: %(card)s; border: 1px solid %(border)s; border-radius: 6px; color: %(text2)s; }
#previewEmpty { border: 1px dashed %(thumb_empty)s; color: %(text2)s; border-radius: 6px; }
#footer { background: %(card)s; border-top: 1px solid %(border)s; }
#logView { font-family: Consolas, 'DejaVu Sans Mono', monospace; font-size: 9.5pt; }
#mono { font-family: Consolas, 'DejaVu Sans Mono', monospace; font-size: 9.5pt; }
#linkish { text-align: left; color: %(link)s; font-size: 11pt; background: transparent; border: none;
           padding: 4px 2px; }
#linkish:hover { text-decoration: underline; }
QPushButton#link { color: %(link)s; background: transparent; border: none; text-decoration: underline;
                   padding: 2px; text-align: left; }
QPushButton#link:hover { color: %(text)s; background: transparent; }
QPushButton#link:focus { border: 1px dashed %(focus)s; padding: 1px; }
QPushButton[kind="big"] { color: %(on_accent)s; background: %(accent)s; border: 2px solid transparent;
                          border-radius: 8px; padding: 10px 22px; font-size: 12pt; font-weight: 700; }
QPushButton[kind="big"]:hover { background: %(accent_hover)s; }
QPushButton[kind="big"][tone="ok"] { background: %(ok_fill)s; color: %(on_fill)s; }
QPushButton[kind="big"][tone="bad"] { background: %(bad_fill)s; color: %(on_fill)s; }
QPushButton[kind="big"][tone="warn"] { background: %(warn_fill)s; color: %(on_fill)s; }
QPushButton[kind="big"]:focus { border: 2px solid %(text)s; }
QPushButton[kind="big"]:disabled { background: %(hover)s; color: %(text3)s; }
#zoomBar { background: %(card)s; border-top: 1px solid %(border)s; }
#zoomBar QPushButton { padding: 3px 10px; min-width: 18px; }
#zoomBar QPushButton:focus { padding: 2px 9px; }
#zoomBar QPushButton:checked { background: %(accent_soft)s; color: %(accent_soft_text)s; border-color: %(accent_fg)s; }
QGroupBox { color: %(text)s; font-weight: bold; border: 1px solid %(border)s; border-radius: 10px;
            margin-top: 12px; padding: 10px; background: %(card)s; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QToolTip { background: %(tip_bg)s; color: %(tip_text)s; border: 1px solid %(border_strong)s; padding: 6px 8px; }
QMenu { background: %(card)s; color: %(text)s; border: 1px solid %(border_strong)s; }
QMenu::item:selected { background: %(accent_soft)s; color: %(accent_soft_text)s; }
QScrollArea { background: transparent; border: none; }
QScrollArea > QWidget > QWidget#page { background: %(bg)s; }
QScrollBar:vertical { background: transparent; width: 12px; margin: 2px 2px 2px 0; }
QScrollBar::handle:vertical { background: %(scroll)s; border-radius: 4px; min-height: 36px; margin: 0 2px; }
QScrollBar::handle:vertical:hover { background: %(scroll_hover)s; }
QScrollBar:horizontal { background: transparent; height: 12px; margin: 0 2px 2px 2px; }
QScrollBar::handle:horizontal { background: %(scroll)s; border-radius: 4px; min-width: 36px; margin: 2px 0; }
QScrollBar::handle:horizontal:hover { background: %(scroll_hover)s; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0; height: 0; border: none; background: none; }
QScrollBar::add-page, QScrollBar::sub-page { background: none; }
QTabWidget::pane { border: none; }
QTabBar::tab { background: transparent; color: %(text2)s; padding: 8px 18px; border: none;
               border-bottom: 3px solid transparent; font-weight: 600; }
QTabBar::tab:selected { color: %(title)s; border-bottom: 3px solid %(accent_fg)s; }
QTabBar::tab:hover:!selected { color: %(text)s; border-bottom: 3px solid %(border)s; }
"""

INPUT_QSS = """
QSpinBox, QTimeEdit, QDoubleSpinBox {
    background: %(input)s; color: %(text)s; border: 1px solid %(border_strong)s; border-radius: 6px;
    padding: 5px 26px 5px 10px; min-height: 20px; }
QSpinBox:hover, QTimeEdit:hover, QComboBox:hover { border-color: %(text2)s; }
QSpinBox:focus, QTimeEdit:focus, QComboBox:focus, QDoubleSpinBox:focus { border: 2px solid %(focus)s; }
QSpinBox:disabled, QTimeEdit:disabled, QComboBox:disabled { color: %(text3)s; background: %(input_dis)s;
    border-color: %(border)s; }
QSpinBox::up-button, QTimeEdit::up-button, QDoubleSpinBox::up-button {
    subcontrol-origin: border; subcontrol-position: top right; width: 22px; border: none;
    border-top-right-radius: 6px; background: transparent; margin: 2px 2px 0 0; }
QSpinBox::down-button, QTimeEdit::down-button, QDoubleSpinBox::down-button {
    subcontrol-origin: border; subcontrol-position: bottom right; width: 22px; border: none;
    border-bottom-right-radius: 6px; background: transparent; margin: 0 2px 2px 0; }
QSpinBox::up-button:hover, QTimeEdit::up-button:hover, QSpinBox::down-button:hover,
QTimeEdit::down-button:hover { background: %(hover)s; }
QSpinBox::up-arrow, QTimeEdit::up-arrow, QDoubleSpinBox::up-arrow { image: url(%(up)s); width: 10px; height: 10px; }
QSpinBox::down-arrow, QTimeEdit::down-arrow, QDoubleSpinBox::down-arrow { image: url(%(down)s); width: 10px; height: 10px; }
QComboBox { background: %(input)s; color: %(text)s; border: 1px solid %(border_strong)s; border-radius: 6px;
    padding: 5px 30px 5px 10px; min-height: 20px; }
QComboBox::drop-down { subcontrol-origin: padding; subcontrol-position: center right; width: 26px; border: none; }
QComboBox::down-arrow { image: url(%(down)s); width: 10px; height: 10px; }
QComboBox QAbstractItemView { background: %(card)s; color: %(text)s; border: 1px solid %(border_strong)s;
    border-radius: 6px; padding: 4px; selection-background-color: %(accent_soft)s;
    selection-color: %(accent_soft_text)s; outline: 0; }
"""

# Настройки: сетка 8 точек, карточки-группы, строки с тонкими линиями между ними.
SETTINGS_QSS = """
#settingsPage, #settingsBody { background: %(bg)s; }
#pageTitle { font-size: 19pt; font-weight: 700; color: %(title)s; }
#sectionTitle { font-size: 12.5pt; font-weight: 700; color: %(title)s; padding: 0 2px; }
#group { background: %(card)s; border: 1px solid %(border)s; border-radius: 10px; }
#row { background: transparent; border: none; }
#divider { background: %(divider)s; border: none; }
#rowTitle { color: %(text)s; font-size: 10.5pt; font-weight: 600; }
#rowTitle:disabled { color: %(text3)s; }
#hint { color: %(text2)s; font-size: 10pt; }
#value { color: %(text)s; font-weight: 600; }
#helpIcon { color: %(text)s; background: %(hover)s; border: 1px solid %(border_strong)s; border-radius: 9px;
            font-size: 8.5pt; font-weight: 700; }
#helpIcon:hover { color: %(on_accent)s; background: %(accent)s; border-color: %(accent)s; }
#savedOk { color: %(ok)s; font-weight: 600; }
#savedBad { color: %(bad)s; font-weight: 600; }
#advToggle { background: %(card)s; border: 1px solid %(border)s; border-radius: 10px; color: %(text)s;
             font-size: 10.5pt; font-weight: 700; padding: 12px 16px; text-align: left; }
#advToggle:hover { background: %(hover)s; }
#advToggle:focus { border: 2px solid %(focus)s; padding: 11px 15px; }
#seg { background: transparent; border: 1px solid transparent; border-radius: 6px; color: %(text2)s;
       padding: 6px 16px; font-weight: 700; }
#seg:hover { background: %(hover)s; color: %(text)s; }
#seg:checked { background: %(accent)s; color: %(on_accent)s; border: 1px solid %(accent)s; }
#seg:focus { border: 2px solid %(focus)s; padding: 5px 15px; }
#segBar { background: %(seg_bar)s; border: 1px solid %(border)s; border-radius: 8px; }
#settingsPage QSlider { min-height: 22px; }
#settingsPage QSlider::groove:horizontal { height: 4px; background: %(border)s; border-radius: 2px; }
#settingsPage QSlider::sub-page:horizontal { background: %(accent_fg)s; border-radius: 2px; }
#settingsPage QSlider::sub-page:horizontal:disabled { background: %(text3)s; }
#settingsPage QSlider::handle:horizontal {
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 %(accent_fg)s,
                                stop:0.42 %(accent_fg)s, stop:0.5 %(card)s, stop:1 %(card)s);
    border: 1px solid %(border_strong)s; width: 18px; height: 18px; margin: -8px 0; border-radius: 10px; }
#settingsPage QSlider::handle:horizontal:hover {
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 %(accent_fg)s,
                                stop:0.52 %(accent_fg)s, stop:0.6 %(card)s, stop:1 %(card)s); }
#settingsPage QSlider::handle:horizontal:disabled { background: %(card)s; border-color: %(border)s; }
#settingsPage QRadioButton { spacing: 8px; }
#settingsPage QKeySequenceEdit QLineEdit { padding: 5px 8px; }
#themePreview { border: 2px solid transparent; border-radius: 8px; }
"""


def build_qss(pal=None):
    """Полный стиль приложения для палитры pal (по умолчанию — текущей)."""
    pal = dict(pal or P)
    try:
        arrows = arrow_files(pal["text2"])
    except Exception:  # noqa: BLE001 — без картинок стрелок останется стандартный вид
        log.debug("стрелки не нарисованы", exc_info=True)
        arrows = None
    qss = BASE_QSS % pal + SETTINGS_QSS % pal
    if arrows:
        qss += INPUT_QSS % dict(pal, **arrows)
    return qss


def qpalette(pal=None):
    from PySide6.QtGui import QColor, QPalette
    pal = pal or P
    qp = QPalette()
    R = QPalette.ColorRole
    for role, key in ((R.Window, "bg"), (R.WindowText, "text"), (R.Base, "input"), (R.AlternateBase, "card_alt"),
                      (R.ToolTipBase, "tip_bg"), (R.ToolTipText, "tip_text"), (R.Text, "text"),
                      (R.Button, "card"), (R.ButtonText, "text"), (R.BrightText, "bad"), (R.Highlight, "accent"),
                      (R.HighlightedText, "on_accent"), (R.Link, "link"), (R.PlaceholderText, "text3"),
                      (R.Mid, "border"), (R.Midlight, "card_alt"), (R.Dark, "border_strong"), (R.Light, "card")):
        qp.setColor(role, QColor(pal[key]))
    for role in (R.Text, R.WindowText, R.ButtonText):
        qp.setColor(QPalette.ColorGroup.Disabled, role, QColor(pal["text3"]))
    return qp


def apply(app=None, mode=None, accent=None, reader=None):
    """Применить тему ко всему приложению сразу (без перезапуска). Возвращает имя палитры."""
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import QApplication
    app = app or QApplication.instance()
    if mode is not None:
        STATE["mode"] = mode
    if accent is not None:
        STATE["accent"] = accent
    name = resolve(STATE["mode"], reader)
    new = palette(name, STATE["accent"])
    P.clear()
    P.update(new)
    if app is None:
        return name
    app.setPalette(qpalette(P))
    try:
        app.styleHints().setColorScheme(Qt.ColorScheme.Dark if P["dark"] else Qt.ColorScheme.Light)
    except Exception:  # noqa: BLE001 — Qt < 6.8
        pass
    app.setStyleSheet(build_qss(P))
    STATE["applied"] = True
    for fn in list(_listeners):
        try:
            fn()
        except Exception:  # noqa: BLE001
            log.debug("обновление после смены темы", exc_info=True)
    from PySide6.QtWidgets import QWidget
    for w in app.allWidgets():
        try:
            QWidget.update(w)       # не w.update(): у списков свой update(index) (PySide6 6.9)
        except RuntimeError:
            pass
    log.debug("Тема оформления: %s (%s)", name, STATE["mode"])
    return name


def apply_from_config(cfg, app=None, force=False):
    """Тема из config.yaml (app.theme / app.accent). Без force — только если ещё не применяли или поменялась."""
    a = (cfg or {}).get("app") or {}
    mode, accent = str(a.get("theme") or "system"), str(a.get("accent") or "blue")
    if not force and STATE["applied"] and STATE["mode"] == mode and STATE["accent"] == accent:
        return P["name"]
    return apply(app, mode, accent)


def repolish(w, **props):
    """Поменять свойства (state=…, tone=…) и обновить вид по стилю."""
    for k, v in props.items():
        w.setProperty(k, v)
    st = w.style()
    st.unpolish(w)
    st.polish(w)
    w.update()
