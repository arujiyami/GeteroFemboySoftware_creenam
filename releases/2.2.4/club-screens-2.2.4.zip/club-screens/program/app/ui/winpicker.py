# Original-Author: Владислав С.
# Created: 2026-10-28
"""Диалог «Выбрать окно из списка»: если программа не нашла окно Oasys/iVMS-4200 сама."""
import os

from PySide6.QtWidgets import (QAbstractItemView, QDialog, QHBoxLayout, QHeaderView, QPushButton, QTableWidget,
                               QTableWidgetItem, QVBoxLayout)

from ..winmatch import picker_rows, window_rule
from .common import label


class WindowPicker(QDialog):
    def __init__(self, windows, source_name="", parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Выберите окно {source_name}".strip())
        self.resize(780, 460)
        self.rows = picker_rows(windows, own_pid=os.getpid())
        self.rule = None
        lay = QVBoxLayout(self)
        lay.addWidget(label(f"Выберите в списке окно программы {source_name or ''} и нажмите "
                            "«Использовать процесс» (надёжнее) или «Использовать заголовок». "
                            "Крупные окна — сверху.", "big"))
        t = QTableWidget(len(self.rows), 3)
        t.setHorizontalHeaderLabels(["Заголовок окна", "Процесс (exe)", "Размер"])
        t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        t.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for i, w in enumerate(self.rows):
            size = f"{w.get('width', 0)}×{w.get('height', 0)}" + (" (свёрнуто)" if w.get("iconic") else "")
            for j, v in enumerate(((w.get("title") or "").strip() or "(без заголовка)", w.get("exe") or "?", size)):
                t.setItem(i, j, QTableWidgetItem(v))
        if self.rows:
            t.selectRow(0)
        t.doubleClicked.connect(lambda: self.use("process"))
        self.table = t
        lay.addWidget(t, 1)
        if not self.rows:
            lay.addWidget(label("Подходящих окон не найдено. Откройте программу и нажмите «Обновить».", "bad"))
        row = QHBoxLayout()
        for text, use in (("Использовать процесс", "process"), ("Использовать заголовок", "title")):
            b = QPushButton(text)
            b.clicked.connect(lambda _=False, u=use: self.use(u))
            b.setEnabled(bool(self.rows))
            row.addWidget(b)
        row.addStretch(1)
        cancel = QPushButton("Отмена")
        cancel.clicked.connect(self.reject)
        row.addWidget(cancel)
        lay.addLayout(row)

    def selected(self):
        r = self.table.currentRow()
        return self.rows[r] if 0 <= r < len(self.rows) else None

    def use(self, how):
        w = self.selected()
        if not w:
            return
        if how == "process" and not w.get("exe"):
            how = "title"
        self.rule = window_rule(w, how)
        self.chosen = w
        self.accept()


def pick_window_rule(parent, windows, source_name=""):
    """Показать диалог; → словарь для source['window'] или None."""
    d = WindowPicker(windows, source_name, parent)
    return d.rule if d.exec() == QDialog.DialogCode.Accepted else None


def pick_window(parent, windows, source_name=""):
    """2.2.0: то же окно выбора, но → сам выбранный словарь окна (для «Добавить другую программу»)."""
    d = WindowPicker(windows, source_name, parent)
    return getattr(d, "chosen", None) if d.exec() == QDialog.DialogCode.Accepted else None
