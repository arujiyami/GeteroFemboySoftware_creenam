# Original-Author: Владислав С.
# Created: 2026-10-28
"""Окно программы на Qt (PySide6 + встроенный браузер QtWebEngine)."""
