# Original-Author: Владислав С.
# Created: 2026-10-28
"""Права администратора: проверка, перезапуск «от имени администратора», уровень чужого процесса.

Oasys и iVMS-4200 часто работают с правами администратора. Windows не даёт обычной программе
нажимать кнопки в таких окнах (защита UIPI) — отсюда ошибка SetCursorPos «No error message is
available». Поэтому «Скриншоты клуба» сама перезапускается от имени администратора."""
import ctypes
import logging
import os
import subprocess
import sys

log = logging.getLogger("club")

NO_ELEVATE_ARG = "--no-elevate"


def is_admin():
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:  # noqa: BLE001
        return False


def gui_python(exe=None):
    """pythonw.exe рядом с python.exe (без чёрного окна консоли)."""
    exe = exe or sys.executable
    if getattr(sys, "frozen", False):
        return exe
    base = os.path.basename(exe).lower()
    if base == "python.exe":
        cand = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.exists(cand):
            return cand
    return exe


def relaunch_args(argv, script=None):
    """(программа, строка аргументов) для перезапуска той же командой."""
    args = list(argv)
    if getattr(sys, "frozen", False):
        exe, params = sys.executable, args
    else:
        exe = gui_python()
        params = [os.path.abspath(script or sys.argv[0])] + args
    params = [p for p in params if p != NO_ELEVATE_ARG] + [NO_ELEVATE_ARG]
    return exe, subprocess.list2cmdline(params)


def relaunch_as_admin(argv, script=None, cwd=None):
    """Запустить себя же через UAC («Да» в окне Windows). True — новая копия запущена."""
    if sys.platform != "win32":
        return False
    exe, params = relaunch_args(argv, script)
    try:
        rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, cwd or os.getcwd(), 1)
    except Exception as e:  # noqa: BLE001
        log.warning("Не удалось перезапуститься от имени администратора: %s", e)
        return False
    if rc <= 32:  # 5 = отказ в UAC, 1223 = ERROR_CANCELLED
        log.warning("Запуск от имени администратора отменён (код %s) — работаю с обычными правами", rc)
        return False
    return True


def allow_foreground():
    """Разрешить окнам переключаться на передний план (нам и тем, кого мы активируем)."""
    if sys.platform == "win32":
        try:
            ctypes.windll.user32.AllowSetForegroundWindow(-1)  # ASFW_ANY
        except Exception:  # noqa: BLE001
            pass


def process_elevated(pid):
    """True/False — работает ли процесс с правами администратора; None — не удалось узнать
    (обычно это и значит «он выше нас по правам»)."""
    if sys.platform != "win32" or not pid:
        return None
    import ctypes.wintypes as wt
    k32, adv = ctypes.windll.kernel32, ctypes.windll.advapi32
    h = k32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return None
    try:
        tok = wt.HANDLE()
        if not adv.OpenProcessToken(h, 0x0008, ctypes.byref(tok)):  # TOKEN_QUERY
            return None
        try:
            elev = wt.DWORD()
            size = wt.DWORD()
            if not adv.GetTokenInformation(tok, 20, ctypes.byref(elev), ctypes.sizeof(elev),
                                           ctypes.byref(size)):  # TokenElevation
                return None
            return bool(elev.value)
        finally:
            k32.CloseHandle(tok)
    finally:
        k32.CloseHandle(h)


def status_text(admin=None):
    admin = is_admin() if admin is None else admin
    if admin:
        return "Запущено от имени администратора ✔"
    if sys.platform != "win32":
        return "Права администратора: проверяются только в Windows"
    return ("⚠ Запущено без прав администратора — программа может не суметь нажать кнопки в Oasys/iVMS-4200. "
            "Закройте её и запустите снова, ответив «Да» на вопрос Windows.")
