# Original-Author: Владислав С.
# Created: 2026-10-28
"""Поиск окна программы-источника среди открытых окон (чистая логика, без Windows API).

Правила (исправление «Oasys не найден», хотя OASys.Admin запущен):
  * регистр не важен — и в заголовке, и в имени процесса;
  * окно подходит, если совпал заголовок ИЛИ имя процесса (match: any, по умолчанию),
    либо и то и другое (match: all);
  * шаблон заголовка проверяется ещё и по имени exe (OASys.Admin.exe подходит под «oasys»);
  * пропускаются невидимые, нулевого размера, «плавающие» (tool) и скрытые (cloaked) окна,
    а также окна самой программы «Скриншоты клуба»;
  * из подходящих берётся самое большое видимое окно (совпадение по процессу важнее).
"""
import logging
import re

log = logging.getLogger("club")


def compile_rx(pattern):
    """Регулярное выражение без учёта регистра. Ошибочный шаблон ищется как обычный текст."""
    pattern = (pattern or "").strip()
    if not pattern:
        return None
    try:
        return re.compile(pattern, re.IGNORECASE)
    except re.error:
        log.warning("Неверное регулярное выражение «%s» — ищу как обычный текст", pattern)
        return re.compile(re.escape(pattern), re.IGNORECASE)


def _area(w):
    return max(0, int(w.get("width") or 0)) * max(0, int(w.get("height") or 0))


def usable(w, own_pid=None):
    """Можно ли вообще снимать это окно."""
    if own_pid is not None and w.get("pid") == own_pid:
        return False
    if not w.get("visible", True) or w.get("cloaked") or w.get("tool"):
        return False
    if not w.get("iconic") and _area(w) < 100:  # нулевого размера / крошечные служебные окна
        return False
    return True


def match_reason(w, title_rx, proc_rx, exclude_rx=None, mode="any"):
    """'process' | 'title' | None — почему окно подходит."""
    title = w.get("title") or ""
    exe = w.get("exe") or ""
    by_proc = bool(proc_rx and exe and proc_rx.search(exe))
    by_title = bool(title_rx and title_rx.search(title))
    by_exe_name = bool(title_rx and exe and title_rx.search(exe))
    if mode == "all":
        ok = (by_proc or not proc_rx) and (by_title or by_exe_name or not title_rx) and (proc_rx or title_rx)
        if not ok:
            return None
    elif not (by_proc or by_title or by_exe_name):
        return None
    if exclude_rx and exclude_rx.search(title) and not by_proc and not by_exe_name:
        return None  # например, вкладка браузера «Oasys …» в Chrome
    return "process" if (by_proc or by_exe_name) else "title"


def pick_window(windows, title_regex="", process_regex="", exclude_title_regex="", match="any", own_pid=None):
    """windows — список словарей {hwnd, title, exe, pid, visible, iconic, tool, cloaked, owned, width, height}.
    Возвращает словарь лучшего окна или None."""
    title_rx, proc_rx = compile_rx(title_regex), compile_rx(process_regex)
    exclude_rx = compile_rx(exclude_title_regex)
    if not (title_rx or proc_rx):
        return None
    best, best_key = None, None
    for w in windows or []:
        if not usable(w, own_pid):
            continue
        why = match_reason(w, title_rx, proc_rx, exclude_rx, (match or "any").lower())
        if not why:
            continue
        key = (why == "process", not w.get("owned"), _area(w))
        if best_key is None or key > best_key:
            best, best_key = w, key
    return best


def describe(windows, limit=40):
    """Строки для журнала: какие окна вообще видны (когда нужное не нашлось)."""
    lines = []
    for w in windows or []:
        if not w.get("visible", True):
            continue
        flags = [f for f, on in (("tool", w.get("tool")), ("скрыто", w.get("cloaked")),
                                 ("свёрнуто", w.get("iconic")), ("дочернее", w.get("owned"))) if on]
        lines.append(f"  «{(w.get('title') or '').strip()[:70]}» — {w.get('exe') or '?'} "
                     f"{w.get('width', 0)}×{w.get('height', 0)}" + (f" [{', '.join(flags)}]" if flags else ""))
        if len(lines) >= limit:
            lines.append("  …")
            break
    return lines


def picker_rows(windows, own_pid=None):
    """Окна для диалога «Выбрать окно из списка»: только пригодные, с заголовком или exe, крупные сверху."""
    rows = [w for w in windows or [] if usable(w, own_pid) and ((w.get("title") or "").strip() or w.get("exe"))]
    rows.sort(key=lambda w: (-_area(w), (w.get("exe") or "").lower()))
    return rows


def window_rule(w, use="process"):
    """Настройки window: для выбранного вручную окна."""
    exe = w.get("exe") or ""
    title = (w.get("title") or "").strip()
    if use == "process" and exe:
        return {"process_regex": "(?i)^" + re.escape(exe) + "$", "title_regex": "", "match": "any"}
    return {"title_regex": "(?i)^" + re.escape(title) + "$" if title else "", "process_regex": "", "match": "any"}
