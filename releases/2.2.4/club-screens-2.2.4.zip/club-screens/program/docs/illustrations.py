# Original-Author: Владислав С.
# Created: 2026-10-28
"""Иллюстрации для инструкции: снимки пользователя (docs/user_images/N.png) с красными
пометками, а если их нет — упрощённые схемы окон с теми же пометками."""
import os

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
USER = os.path.join(HERE, "user_images")
OUT = os.path.join(HERE, "build")
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
RED = (230, 30, 30)
W, H = 1024, 576


def font(size, bold=False):
    return ImageFont.truetype(FONT_B if bold else FONT, size)


def _schema_oasys(cards=True):
    im = Image.new("RGB", (W, 551), (40, 42, 46))
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, 40, 551), fill=(30, 31, 34))
    for i, y in enumerate((32, 77, 115, 153, 191, 226)):
        d.rounded_rectangle((8, y - 13, 32, y + 13), 4, fill=(70, 160, 220) if i == 1 else (60, 62, 66))
    d.ellipse((498, 8, 530, 40), outline="white")
    d.text((514, 24), "OASYS", font=font(8), fill="white", anchor="mm")
    d.text((80, 72), "Карта клуба", font=font(15, True), fill="white", anchor="lm")
    d.rectangle((80, 90, 530, 113), fill=(70, 160, 220))
    d.text((305, 101), "Режим управления", font=font(11), fill="white", anchor="mm")
    d.rectangle((532, 90, 982, 113), fill=(52, 54, 58))
    d.text((757, 101), "Настройки", font=font(11), fill="white", anchor="mm")
    d.rounded_rectangle((80, 157, 248, 517), 6, fill=(50, 52, 56))
    d.text((164, 175), "Загрузка клуба", font=font(9), fill="white", anchor="mm")
    d.text((164, 193), "7/43", font=font(13, True), fill="white", anchor="mm")
    d.rounded_rectangle((291, 157, 772, 517), 6, fill=(46, 48, 52))
    if cards:
        import random
        rnd = random.Random(3)
        for col in (307, 395, 514, 604, 693, 754):
            for row in range(5):
                c = (230, 120, 30) if rnd.random() < 0.25 else (150, 150, 150)
                d.ellipse((col - 11, 160 + row * 30, col + 11, 182 + row * 30), outline=c, width=2)
        for i in range(7):
            x = 605 + i * 30
            d.ellipse((x - 11, 369, x + 11, 391), outline=(150, 150, 150), width=2)
    d.rounded_rectangle((815, 157, 982, 517), 6, fill=(50, 52, 56))
    d.text((512, 540), "СХЕМА (замените на свой скриншот)", font=font(10), fill=(255, 210, 0), anchor="mm")
    return im


def _schema_ivms():
    im = Image.new("RGB", (W, H), (30, 30, 30))
    d = ImageDraw.Draw(im)
    d.rectangle((0, 0, W, 38), fill=(45, 45, 48))
    d.text((10, 10), "iVMS-4200", font=font(11, True), fill="white")
    d.rectangle((35, 18, 135, 37), fill=(55, 55, 58))
    d.text((85, 27), "Remote Playback", font=font(9), fill="white", anchor="mm")
    d.rectangle((140, 18, 220, 37), fill=(80, 80, 85))
    d.text((180, 27), "Main View", font=font(9, True), fill="white", anchor="mm")
    d.rectangle((0, 38, 155, 515), fill=(40, 40, 42))
    d.text((10, 48), "Мой клуб", font=font(9), fill="white")
    for i in range(12):
        d.text((25, 75 + i * 17), f"Camera {i + 1:02d}_club", font=font(8), fill=(200, 200, 200))
    cw, ch = (1020 - 156) / 4, (512 - 38) / 4
    for r in range(4):
        for c in range(4):
            x0, y0 = 156 + c * cw, 38 + r * ch
            empty = r == 2 and c > 0
            d.rectangle((x0 + 1, y0 + 1, x0 + cw - 1, y0 + ch - 1),
                        fill=(100, 100, 105) if empty else (30, 90 + 20 * ((r + c) % 3), 200))
            if not empty:
                d.text((x0 + 6, y0 + 5), "28-10-2026 02:32:34", font=font(7), fill="white")
    d.rectangle((0, 515, W, 538), fill=(45, 45, 48))
    for x in (938, 960, 981, 1011):
        d.rectangle((x - 7, 519, x + 7, 532), outline="white")
    d.rectangle((0, 538, W, H), fill=(20, 30, 50))
    d.text((512, 300), "СХЕМА (замените на свой скриншот)", font=font(14, True), fill=(255, 210, 0), anchor="mm")
    return im


def _schema_vk(attached=False):
    im = Image.new("RGB", (W, H), (25, 25, 26))
    d = ImageDraw.Draw(im)
    d.rectangle((318, 92, 805, 545), fill=(35, 35, 37))
    d.text((340, 108), "Мессенджер", font=font(11, True), fill="white")
    chats = ["Пётр Петров", "Новое обновление серверов", "Клуб — смены",
             "Камеры | Мой клуб", "Мария Смирнова", "Новости клуба"]
    for i, c in enumerate(chats):
        y = 180 + i * 34
        if i == 3:
            d.rectangle((322, y - 12, 494, y + 18), fill=(55, 55, 60))
        d.ellipse((330, y - 8, 352, y + 14), fill=(70, 110, 170))
        d.text((360, y - 6), c[:26] + ("…" if len(c) > 26 else ""), font=font(8), fill="white")
    d.text((520, 108), "Камеры | Мой клуб", font=font(10, True), fill="white")
    d.rectangle((540, 200, 730, 330), fill=(50, 60, 90))
    d.text((635, 265), "фото Oasys + камеры", font=font(9), fill="white", anchor="mm")
    if attached:
        d.rectangle((505, 455, 557, 498), fill=(60, 60, 64), outline="white")
        d.rectangle((563, 455, 615, 498), fill=(40, 90, 190), outline="white")
    d.rectangle((500, 512, 800, 540), fill=(45, 45, 48))
    d.text((530, 526), "Сообщение", font=font(9), fill=(150, 150, 150), anchor="lm")
    d.polygon([(778, 518), (794, 526), (778, 534)], fill=(70, 140, 230))
    d.text((512, 60), "СХЕМА (замените на свой скриншот)", font=font(14, True), fill=(255, 210, 0), anchor="mm")
    return im


def base(n):
    """Снимок пользователя N (1..6) или схема. Возвращает (картинка, это_схема)."""
    path = os.path.join(USER, f"{n}.png")
    if os.path.exists(path):
        img = Image.open(path).convert("RGB")
        ref_h = 551 if n == 3 else H
        return img.resize((W, ref_h)), False
    return {1: _schema_ivms, 3: _schema_oasys, 4: _schema_oasys,
            5: _schema_vk, 6: lambda: _schema_vk(True)}[n](), True


def annotate(img, marks):
    """marks: [("circle"|"box"|"arrow", координаты, подпись)] в координатах 1024×(551|576)."""
    img = img.copy()
    d = ImageDraw.Draw(img)
    for kind, xy, label in marks:
        if kind == "circle":
            x, y, r = xy
            d.ellipse((x - r, y - r, x + r, y + r), outline=RED, width=4)
            anchor = "lm" if x < img.width / 2 else "rm"
            lx, ly = (x + r + 8, y) if anchor == "lm" else (x - r - 8, y)
        elif kind == "box":
            d.rectangle(xy, outline=RED, width=4)
            anchor = "lb"
            lx, ly = xy[0], xy[1] - 6
            if ly < 22:
                anchor, ly = "lt", xy[3] + 6
        else:  # arrow: (x0, y0, x1, y1)
            x0, y0, x1, y1 = xy
            d.line((x0, y0, x1, y1), fill=RED, width=5)
            import math
            a = math.atan2(y1 - y0, x1 - x0)
            for s in (2.6, -2.6):
                d.line((x1, y1, x1 + 18 * math.cos(a + s), y1 + 18 * math.sin(a + s)), fill=RED, width=5)
            anchor = "lm" if x0 >= x1 else "rm"
            lx, ly = x0 + (6 if anchor == "lm" else -6), y0
        if label:
            f = font(16, True)
            tb = d.textbbox((lx, ly), label, font=f, anchor=anchor)
            dx = max(0, 4 - tb[0]) - max(0, tb[2] - (img.width - 4))
            lx += dx
            tb = d.textbbox((lx, ly), label, font=f, anchor=anchor)
            d.rectangle((tb[0] - 4, tb[1] - 3, tb[2] + 4, tb[3] + 3), fill=(255, 255, 255), outline=RED)
            d.text((lx, ly), label, font=f, fill=RED, anchor=anchor)
    return img


def make_all():
    os.makedirs(OUT, exist_ok=True)
    out = {}

    def save(name, n, marks):
        img, schema = base(n)
        annotate(img, marks).save(os.path.join(OUT, name))
        out[name] = schema

    save("ill_oasys_button.png", 3, [("circle", (20, 77, 22), "1. «Карта клуба»"),
                                     ("box", (74, 58, 200, 86), "")])
    save("ill_oasys_result.png", 4, [("box", (2, 2, 1021, 548), "")])
    save("ill_ivms_fullscreen.png", 1, [("circle", (981, 525, 18), "2. Full Screen"),
                                         ("box", (140, 17, 222, 38), "1. Main View")])
    save("ill_vk_chat.png", 5, [("box", (322, 266, 494, 300), "беседа"),
                                ("arrow", (720, 160, 640, 112), "peer_id = 2000000001 (из адреса)")])
    save("ill_vk_send.png", 6, [("box", (500, 450, 620, 503), "1. Oasys  2. Камеры"),
                                ("circle", (786, 526, 16), "3. одно сообщение")])
    return out


if __name__ == "__main__":
    print(make_all())


def make_countdown(path=None):
    """Схема: рабочий стол, в правом нижнем углу над часами — окошко обратного отсчёта (2.1.4, строка о блокировке — 2.1.5).
    Само окошко — настоящий снимок из make_gui_screens.py (build/countdown_overlay.png), если он есть."""
    from app.scheduler import countdown_hint, countdown_text
    path = path or os.path.join(OUT, "ill_countdown.png")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    W, H, TB = 900, 330, 48
    img = Image.new("RGB", (W, H), (90, 120, 160))
    d = ImageDraw.Draw(img)
    # «окно Oasys» на фоне — показать, что окошко полупрозрачное и ничего не перекрывает целиком
    d.rectangle((380, 40, 880, H - TB - 6), fill=(235, 238, 243), outline=(60, 70, 90))
    d.rectangle((380, 40, 880, 70), fill=(52, 73, 110))
    d.text((392, 55), "Oasys — Карта клуба", font=font(14), fill=(255, 255, 255), anchor="lm")
    for k in range(6):
        y = 86 + k * 30
        d.rectangle((396, y, 860, y + 20), fill=(205, 214, 228) if k % 2 else (220, 228, 240))
    d.rectangle((0, H - TB, W, H), fill=(32, 32, 36))
    d.text((W - 30, H - TB // 2), "05:59", font=font(18), fill=(240, 240, 240), anchor="rm")
    d.rounded_rectangle((W - 132, H - 34, W - 110, H - 14), 4, fill=(47, 111, 219))
    ov_path = os.path.join(OUT, "countdown_overlay.png")
    margin = 12
    if os.path.exists(ov_path):
        ov = Image.open(ov_path).convert("RGBA")
        if ov.width > 420:                      # снимок с масштабом экрана — к логическим пикселям
            ov = ov.resize((ov.width // 2, ov.height // 2), Image.LANCZOS)
        img.paste(ov, (W - ov.width - margin, H - TB - ov.height - margin), ov)
    else:                                       # запасной рисунок, если снимка окошка нет
        box_w, box_h = 400, 84
        x0, y0 = W - box_w - margin, H - TB - box_h - margin
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(layer).rounded_rectangle((x0, y0, x0 + box_w, y0 + box_h), 10, fill=(18, 22, 30, 191))
        img = Image.alpha_composite(img.convert("RGBA"), layer).convert("RGB")
        d = ImageDraw.Draw(img)
        d.text((x0 + 16, y0 + 12), countdown_text(59.5), font=font(18, True), fill=(255, 255, 255))
        head, _, tail = countdown_hint("Ctrl+Alt+Q", 54.5).partition(". ")
        d.text((x0 + 16, y0 + 42), head + ".", font=font(12), fill=(225, 230, 238))
        d.text((x0 + 16, y0 + 60), tail, font=font(12), fill=(225, 230, 238))
    d = ImageDraw.Draw(img)
    d.text((30, 30), "Обратный отсчёт", font=font(20, True), fill=(255, 255, 255))
    d.text((30, 62), "перед съёмкой, справа внизу", font=font(14), fill=(230, 230, 230))
    d.text((30, 84), "щелчки проходят сквозь окошко,", font=font(14), fill=(230, 230, 230))
    d.text((30, 106), "на скриншоты оно не попадает", font=font(14), fill=(230, 230, 230))
    img.save(path)
    return path
