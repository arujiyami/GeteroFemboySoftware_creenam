# Original-Author: Владислав С.
# Created: 2026-10-28
"""Скриншоты клуба — точка входа.

  pythonw main.py               — окно программы (ярлык «Скриншоты клуба»); ВКонтакте открыт прямо в окне
  python main.py --run-once     — один цикл (снять и отправить) без показа окна
  python main.py --list-windows — список окон (для настройки поиска окна)
  python main.py --list-conversations — список бесед ВК с peer_id (через встроенный браузер)

Программа сама перезапускается «от имени администратора» (иначе Windows не даёт нажимать кнопки
в iVMS-4200, запущенной с правами администратора). Отключить: --no-elevate."""
import argparse
import atexit
import os
import sys
import threading

from app import APP_NAME
from app.backend_win import set_dpi_awareness
from app.config import base_dir, load_config, migrate, resolve_path, save_config
from app.elevation import NO_ELEVATE_ARG
from app.inputlock import release_all

# Блокировка мыши/клавиатуры не должна пережить программу ни при каком выходе
atexit.register(release_all, "exit")

INSTANCE_NAME = "ClubScreens_SingleInstance"
_APP = None


def qt_app(argv=None):
    """QApplication создаётся один раз (после переменных окружения WebEngine)."""
    global _APP
    from PySide6.QtWidgets import QApplication
    _APP = QApplication.instance() or QApplication(argv or [sys.argv[0]])
    return _APP


def _fatal(text):
    """Понятное окно с ошибкой (программа запускается без консоли)."""
    print(text, file=sys.stderr)
    try:
        from PySide6.QtWidgets import QMessageBox
        qt_app()
        QMessageBox.critical(None, APP_NAME, text)
    except Exception:  # noqa: BLE001
        pass


def prepare_webengine(admin, save_memory=True, light=False):
    """До создания QApplication: флаги Chromium; под администратором песочница Chromium не запускается.
    save_memory — «Экономить память» (флаги ограничения памяти, см. app/ui/browser.py)."""
    from app.ui.browser import chromium_flags
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = chromium_flags(os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", ""),
                                                              save_memory, light)
    if admin:
        os.environ["QTWEBENGINE_DISABLE_SANDBOX"] = "1"
    from PySide6.QtCore import QCoreApplication, Qt
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)


class SingleInstance:
    """Одна копия программы: мьютекс Windows + локальный канал, чтобы вторая копия показала окно первой."""

    def __init__(self):
        self.mutex = None
        self.server = None

    def already_running(self):
        from PySide6.QtNetwork import QLocalSocket
        sock = QLocalSocket()
        sock.connectToServer(INSTANCE_NAME)
        if sock.waitForConnected(500):
            sock.write(b"show")
            sock.flush()
            sock.waitForBytesWritten(500)
            sock.disconnectFromServer()
            return True
        if sys.platform == "win32":
            import win32api
            import win32event
            import winerror
            self.mutex = win32event.CreateMutex(None, False, INSTANCE_NAME)
            if win32api.GetLastError() == winerror.ERROR_ALREADY_EXISTS:
                return True
        return False

    def listen(self, on_show):
        from PySide6.QtNetwork import QLocalServer
        QLocalServer.removeServer(INSTANCE_NAME)
        self.server = QLocalServer()
        self.server.listen(INSTANCE_NAME)
        self.server.newConnection.connect(lambda: (self.server.nextPendingConnection(), on_show()))


def run_headless(cfg, work):
    """Без окна: встроенный браузер (скрытый) + работа в отдельном потоке. Возвращает результат work()."""
    from app.job import set_browser
    from app.ui.browser import VKBrowser
    from app.ui.common import GuiCall
    app = qt_app()
    browser = VKBrowser(lambda: cfg)
    set_browser(browser)
    gui = GuiCall()
    box = {}

    def worker():
        try:
            box["result"] = work(browser)
        except BaseException as e:  # noqa: BLE001
            box["error"] = e
        gui(app.quit)
    threading.Thread(target=worker, name="headless", daemon=True).start()
    app.exec()
    set_browser(None)
    browser.close()
    if "error" in box:
        raise box["error"]
    return box.get("result")


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    set_dpi_awareness()  # до создания окон и снятия скриншотов
    for stream in (sys.stdout, sys.stderr):
        if stream and hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    p = argparse.ArgumentParser(description=APP_NAME)
    p.add_argument("--config", default=os.path.join(base_dir(), "config.yaml"), help="путь к config.yaml")
    p.add_argument("--minimized", action="store_true", help="запустить свёрнутым в трей")
    p.add_argument("--restarted", action="store_true", help="запуск сторожем после сбоя (служебный)")
    p.add_argument("--run-once", action="store_true", help="снять и отправить один раз и выйти")
    p.add_argument("--no-send", action="store_true", help="с --run-once: только снять, не отправлять")
    p.add_argument("--list-windows", action="store_true", help="показать открытые окна")
    p.add_argument("--list-conversations", action="store_true", help="показать беседы ВК")
    p.add_argument("--create-shortcut", action="store_true", help="создать ярлык на рабочем столе и выйти")
    p.add_argument(NO_ELEVATE_ARG, action="store_true", help="не перезапускаться от имени администратора")
    args = p.parse_args(argv)

    if args.create_shortcut:
        from app import startup
        try:
            print("Ярлык создан:", startup.desktop_shortcut())
        except Exception as e:  # noqa: BLE001
            print("Не удалось создать ярлык:", e)
            return 1
        return 0

    from app import elevation
    console = args.run_once or args.list_windows or args.list_conversations
    admin = elevation.is_admin()
    if sys.platform == "win32" and not admin and not args.no_elevate and not console:
        # До проверки «уже запущено»: копия с правами администратора заменит эту.
        if elevation.relaunch_as_admin(argv, script=os.path.abspath(__file__), cwd=base_dir()):
            return 0

    from app.logsetup import setup_logging
    try:
        cfg = load_config(args.config)
    except Exception as e:  # noqa: BLE001
        _fatal(f"Не удалось прочитать файл настроек config.yaml:\n{e}\n\n"
               "Исправьте файл или удалите его — программа создаст новый и откроет мастер настройки.")
        return 1
    ver_before = (cfg.get("app") or {}).get("config_version")
    notes = migrate(cfg)  # старый токен пользователя стирается из config.yaml
    if notes or ver_before != cfg["app"].get("config_version"):
        try:
            save_config(cfg, args.config)
        except OSError as e:
            notes.append(f"Не удалось сохранить config.yaml: {e}")
    setup_logging(resolve_path(cfg["storage"]["log_file"]), console=console)
    import logging
    log = logging.getLogger("club")
    for note in notes:
        log.warning("Обновление настроек: %s", note)
    log.info("Запуск %s: %s", APP_NAME, elevation.status_text(admin))

    if args.list_windows:
        from app.backend_win import get_backend
        for hwnd, title, exe in get_backend().list_windows():
            print(f"{hwnd:>10}  {exe:<28} {title}")
        return 0

    # 2.2.0: подготовленный импорт резервной копии — до старта браузера; «Лёгкий режим» — по памяти
    from app import backup, lightmode
    prof = resolve_path((cfg.get("vk_browser") or {}).get("profile_dir", "browser_profile"))
    try:
        if backup.apply_pending_import(prof):
            log.warning("Восстановлен вход в ВК из резервной копии (прежний профиль — в %s.old)", prof)
    except OSError:
        log.exception("Не удалось применить резервную копию профиля")
    light = lightmode.is_active(cfg)
    lightmode.set_active(light)
    if light:
        log.warning("Лёгкий режим: занято %s%% памяти — браузер и снимки экономят память", lightmode.ram_percent())
    prepare_webengine(admin, bool((cfg.get("vk_browser") or {}).get("save_memory", True)), light)
    if args.list_conversations:
        if cfg["vk"].get("sender") == "group_api":
            from app.job import make_group_client
            convs = make_group_client(cfg).get_conversations()
        else:
            convs = run_headless(cfg, lambda b: b.run_blocking(lambda: b.flows().list_chats(), 60))
        for c in convs:
            print(f"{c['peer_id']:>12}  {c['type']:<6} {c['title']}")
        return 0
    if args.run_once:
        from app.backend_win import get_backend
        from app.job import JobRunner
        ok = run_headless(cfg, lambda b: JobRunner(lambda: cfg, get_backend).run_cycle(
            send=not args.no_send, manual=True))
        return 0 if ok else 1

    app = qt_app([sys.argv[0]])
    app.setApplicationName(APP_NAME)
    app.setQuitOnLastWindowClosed(False)
    app.aboutToQuit.connect(lambda: release_all("exit"))
    from PySide6.QtWidgets import QMessageBox
    inst = SingleInstance()
    if inst.already_running():
        QMessageBox.information(None, APP_NAME, "Программа уже запущена — её окно открыто, или значок в трее "
                                                "рядом с часами (может прятаться под стрелкой ^).")
        return 0
    from app.backend_win import get_backend
    from app.ui.common import ensure_font
    from app.ui.main_window import MainWindow
    ensure_font(app, cfg)
    if admin:
        elevation.allow_foreground()
    if args.restarted:
        log.warning("Программа перезапущена сторожем после сбоя или зависания")
    win = MainWindow(cfg, args.config, get_backend, start_minimized=args.minimized, admin=admin)
    inst.listen(win.show_window)
    if not win.start_hidden:
        win.show()
    return app.exec()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001
        import logging
        logging.getLogger("club").exception("Программа завершилась с ошибкой")
        _fatal(f"Программа неожиданно остановилась: {exc}\n\n"
               "Подробности записаны в журнал (папка program\\logs). Запустите программу снова.")
        sys.exit(1)
