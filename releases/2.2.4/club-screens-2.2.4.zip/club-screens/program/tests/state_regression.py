# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.3: настроенная программа не должна становиться «Не настроено» от перестановки cookie ВК,
выгрузки страницы и переходов по шагам мастера. Настоящие MainWindow + VKBrowser (Qt WebEngine),
страница ВК — локальная обезличенная копия (tests/fake_vk), в интернет не ходит.
Запуск: python tests/state_regression.py → последняя строка — JSON. Вызывается из tests/test_login_detect.py."""
import copy
import functools
import http.server
import json
import os
import re
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):  # noqa: N802
        self.path = "/convo.html" if re.match(r"^/im/convo/\d+", self.path) else "/im.html"
        return super().do_GET()


class StubBackend:
    def all_windows(self):
        return []

    def find_window(self, *a, **k):
        return None

    def list_windows(self):
        return []


def main():
    from PySide6.QtCore import QByteArray, QTimer
    from PySide6.QtNetwork import QNetworkCookie
    from PySide6.QtWidgets import QApplication, QMessageBox

    from app.config import DEFAULTS, deep_merge, is_configured
    app = QApplication(sys.argv[:1])
    QTimer.singleShot(150000, lambda: os._exit(3))   # страховка от зависания
    from app.ui.main_window import MainWindow
    tmp = tempfile.mkdtemp()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
        Handler, directory=os.path.join(HERE, "fake_vk")))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    cfg = deep_merge(copy.deepcopy(DEFAULTS), {
        "app": {"setup_done": True, "club_name": "Мой клуб", "use_tray": False},
        "storage": {"log_file": os.path.join(tmp, "logs", "app.log")},
        "vk": {"login_ok": True, "account_name": "Иван Иванов", "peer_id": 2000000001,
               "peer_title": "Камеры | Мой клуб"},
        "vk_browser": {"profile_dir": os.path.join(tmp, "profile"), "home_url": url + "/", "im_url": url + "/im",
                       "chat_url": url + "/im/convo/{peer_id}", "save_memory": True}})

    def pump(sec=0.3):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.02)

    def cookie(name, domain):
        c = QNetworkCookie(QByteArray(name.encode()), QByteArray(b"x"))
        c.setDomain(domain)
        c.setPath("/")
        return c

    out, steps = {}, []
    main = MainWindow(cfg, os.path.join(tmp, "config.yaml"), StubBackend, autostart_jobs=False, admin=True)
    main.resize(900, 650)
    main.show()
    pump(1)
    b = main.browser

    def snap(what):
        steps.append({"step": what, "configured": is_configured(main.cfg), "status": main.status()[1],
                      "login_ok": main.cfg["vk"].get("login_ok"), "browser_logged_in": b.logged_in})

    snap("старт")
    sid = cookie("remixsid", ".vk.com")
    b._cookie_added(sid)
    pump()
    snap("cookie добавлена")
    b._cookie_removed(sid)          # ВК обновляет сессию: сначала удаляет…
    out["debounce_ms"] = b._logout_timer.interval()
    out["debounce_active"] = b._logout_timer.isActive()
    pump()
    snap("cookie удалена")
    b._cookie_added(sid)            # …потом ставит новую
    out["debounce_cancelled"] = not b._logout_timer.isActive()
    pump()
    snap("cookie снова добавлена")
    b._cookie_added(cookie("remixsid", ".vk.ru"))
    b._cookie_removed(cookie("remixsid", ".vk.ru"))
    out["vk_ru_removal_keeps_vk_com"] = b.logged_in
    b.ensure_view()
    pump(3)
    b.unload_view()
    pump(1)
    snap("страница создана и выгружена")
    # cookie пропали совсем (таймер 10 с истёк) — сохранённый вход всё равно не сбрасывается
    b._cookie_removed(sid)
    b._logout_timer.stop()
    b._confirm_logout()
    pump(1)
    snap("cookie пропали (после 10 с)")

    # мастер: переходы по шагам не сбрасывают сделанное
    main.open_wizard()
    pump(1)
    w = main.wizard
    keys = [k for k, _, _ in w.pages]
    vk_i, chat_i = keys.index("vk"), keys.index("chat")
    nav = []
    for i in (vk_i, chat_i, vk_i, 0, vk_i):
        w.show_page(i)
        pump(1.5)
        nav.append({"page": keys[i], "next": w.next_btn.isEnabled(),
                    "side_vk": w.side_labels[vk_i].text(), "side_chat": w.side_labels[chat_i].text(),
                    "vk_status": w.vk_status.text() if keys[i] == "vk" else ""})
    out["wizard_nav"] = nav
    w.on_login(None)
    w.on_login({"state": "logged_out"})
    out["wizard_after_transient"] = {"next": w.next_btn.isEnabled(), "vk_status": w.vk_status.text()}
    out["has_already_button"] = w.vk_already_btn.text()
    out["poll_ms"] = w.timer.interval()
    snap("мастер: шаги пройдены туда-обратно")

    # настоящая проверка загруженной страницы: видна форма входа, cookie нет → вход действительно пропал
    w.timer.stop()  # без опроса раз в 2 с: на локальной копии он сразу увидел бы, что вход есть
    out["view_loaded"] = b.view_loaded
    main._login_result({"state": "logged_out", "form": True, "cookie": False, "confirmed_logout": True})
    out["real_logout"] = {"login_ok": main.cfg["vk"].get("login_ok"), "next": w.next_btn.isEnabled(),
                          "configured": is_configured(main.cfg)}
    # «Я уже вошёл — продолжить» (ответ «Да»)
    QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Yes)
    w.vk_already_btn.click()
    pump(0.2)
    out["already"] = {"login_ok": main.cfg["vk"].get("login_ok"), "next": w.next_btn.isEnabled(),
                      "vk_status": w.vk_status.text()}
    out["steps"] = steps
    srv.shutdown()
    print(json.dumps(out, ensure_ascii=False, default=str), flush=True)
    os._exit(0)   # без разбора Qt при выходе


if __name__ == "__main__":
    main()
