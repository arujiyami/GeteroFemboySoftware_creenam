# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.4: окончательная отметка часа, строгая проверка беседы (сравнение картинок), галочка «вручную»."""
import io
import os
import tempfile
import unittest
from datetime import datetime
from unittest import mock

import numpy as np
from PIL import Image, ImageDraw

from app import dupcheck, hourdone, sentcheck
from app.job import JobRunner

PROGRAM = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(PROGRAM)


def scene(seed, w=1920, h=1080):
    rnd = np.random.RandomState(seed)
    im = Image.new("RGB", (w, h), tuple(int(x) for x in rnd.randint(0, 255, 3)))
    d = ImageDraw.Draw(im)
    for _ in range(25):
        x0, y0 = rnd.randint(0, w - 200), rnd.randint(0, h - 150)
        d.rectangle([x0, y0, x0 + rnd.randint(80, 600), y0 + rnd.randint(60, 400)],
                    fill=tuple(int(x) for x in rnd.randint(0, 255, 3)))
    return im


def vk_copy(im, size=(807, 454), q=60):
    b = io.BytesIO()
    im.resize(size).save(b, "JPEG", quality=q)
    return b.getvalue()


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.oasys, self.ivms = scene(1), scene(2)
        self.paths = []
        for n, im in (("o.png", self.oasys), ("i.png", self.ivms)):
            p = os.path.join(self.tmp, n)
            im.save(p)
            self.paths.append(p)
        self.files = {"u1": vk_copy(self.oasys), "u2": vk_copy(self.ivms), "x1": vk_copy(scene(7)),
                      "x2": vk_copy(scene(8))}

    def dl(self, url, timeout=2):
        return self.files[url.split("/")[-1]]

    def msg(self, srcs=("u1", "u2"), own=True, t=22 * 60 + 3, w=807, h=454, old=False):
        return {"own": own, "t": t, "old_day": old,
                "imgs": [{"src": "https://x/" + s, "w": w, "h": h} for s in srcs]}

    def find(self, *msgs, now=datetime(2026, 10, 29, 22, 6)):
        return dupcheck.find({"own": True, "msgs": list(msgs)}, self.paths, datetime(2026, 10, 29, 22, 0),
                             now, download=self.dl)


class Dup(Base):
    def test_recompressed_match(self):
        ok, why = self.find(self.msg())
        self.assertTrue(ok, why)

    def test_swapped_order_match(self):
        self.assertTrue(self.find(self.msg(("u2", "u1")))[0])

    def test_manual_at_30_min(self):
        self.assertTrue(self.find(self.msg(t=22 * 60 + 30), now=datetime(2026, 10, 29, 22, 40))[0])

    def test_other_photos_no(self):
        ok, why = self.find(self.msg(("x1", "x2")))
        self.assertFalse(ok)
        self.assertIn("не те", why)

    def test_same_image_twice_no(self):
        self.assertFalse(self.find(self.msg(("u1", "u1")))[0])

    def test_not_own(self):
        self.assertFalse(self.find(self.msg(own=False))[0])
        self.assertFalse(self.find(self.msg(own=None))[0])

    def test_previous_hour(self):
        self.assertFalse(self.find(self.msg(t=21 * 60 + 59))[0])
        self.assertFalse(self.find(self.msg(old=True))[0])

    def test_three_images(self):
        self.assertFalse(self.find(self.msg(("u1", "u2", "x1")))[0])

    def test_not_wide(self):
        self.assertFalse(self.find(self.msg(w=600, h=600))[0])

    def test_download_fail(self):
        def bad(url, timeout=2):
            raise OSError("net")
        ok, why = dupcheck.find({"msgs": [self.msg()]}, self.paths, datetime(2026, 10, 29, 22), 
                                datetime(2026, 10, 29, 22, 6), download=bad)
        self.assertFalse(ok)

    def test_finds_among_others(self):
        self.assertTrue(self.find(self.msg(), self.msg(("x1", "x2")))[0])


class Hours(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.h = datetime(2026, 10, 29, 22, 0)

    def test_program_mark_permanent(self):
        hourdone.mark(self.root, self.h, hourdone.PROGRAM)
        self.assertEqual(hourdone.done(self.root, self.h), "program")
        hourdone.mark(self.root, self.h, hourdone.MANUAL)
        self.assertEqual(hourdone.done(self.root, self.h), "program")
        self.assertIsNone(hourdone.done(self.root, datetime(2026, 10, 29, 23)))

    def test_manual_checkbox(self):
        hourdone.mark(self.root, self.h, hourdone.MANUAL)
        self.assertEqual(hourdone.done(self.root, self.h, {}), "manual")
        self.assertIsNone(hourdone.done(self.root, self.h, {"dup_guard": {"skip_if_manual": False}}))

    def test_sentcheck_done_ok(self):
        now = datetime(2026, 10, 29, 22, 9)
        self.assertEqual(sentcheck.decide(now, 0, [], done="manual")[1], "ok")


class JobGuard(unittest.TestCase):
    def test_hour_already_sent(self):
        root = tempfile.mkdtemp()
        calls = []

        class S:
            def already_sent(self, peer, paths, since, now=None):
                calls.append(since)
                return True, "ok"

        cfg = {"vk": {"peer_id": 1}}
        j = JobRunner(lambda: cfg, None, vk_factory=lambda c: S(), root=root,
                      now=lambda: datetime(2026, 10, 29, 22, 7))
        with mock.patch.object(j, "latest_paths", return_value=["a", "b"]):
            self.assertTrue(j.hour_already_sent(cfg, datetime(2026, 10, 29, 22, 0), "t"))
        self.assertEqual(hourdone.done(root, datetime(2026, 10, 29, 22)), "chat")
        self.assertTrue(j.hour_already_sent(cfg, datetime(2026, 10, 29, 22, 0), "t"))
        self.assertEqual(len(calls), 1)   # второй раз — по отметке, без браузера
        cfg["dup_guard"] = {"chat_check": False}
        self.assertFalse(j.hour_already_sent(cfg, datetime(2026, 10, 29, 23, 0), "t"))


class Privacy(unittest.TestCase):
    def test_no_forbidden_names(self):
        bad = [bytes.fromhex(h).decode() for h in ("d0a0d183d181d0bbd0b0d0bd",
                                                    "d0a1d0bfd0b8d180d0b8d0b4d0b5d0bdd0bad0be")]
        for d in ("app", "docs"):
            for dp, _, fs in os.walk(os.path.join(PROGRAM, d) if d == "app" else os.path.join(ROOT, d)):
                for f in fs:
                    if f.endswith((".py", ".md", ".txt")):
                        t = open(os.path.join(dp, f), encoding="utf-8", errors="ignore").read()
                        for b in bad:
                            self.assertNotIn(b, t, f)

    def test_doc_exists(self):
        p = os.path.join(ROOT, "docs", "Как работает программа.md")
        self.assertTrue(os.path.exists(p))
