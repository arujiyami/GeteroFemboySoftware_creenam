# Original-Author: Владислав С.
# Created: 2026-10-29
import hashlib
import json
import io
import os
import tempfile
import unittest
import zipfile

from app import updater


def make_zip(extra=()):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("club-screens/program/main.py", "print(1)")
        for n in extra:
            z.writestr(n, "x")
    return buf.getvalue()


class UpdaterTest(unittest.TestCase):
    def rel(self, body="", assets=(), tag="v2.3.0"):
        return {"tag_name": tag, "body": body, "html_url": "https://github.com/a/b/releases/tag/" + tag,
                "assets": [{"name": n, "browser_download_url": "https://github.com/a/b/releases/download/" + n}
                           for n in assets]}

    def test_versions(self):
        self.assertTrue(updater.is_newer("v2.2.1", "2.2.0"))
        self.assertFalse(updater.is_newer("v2.2.0", "2.2.0"))
        self.assertFalse(updater.is_newer("2.1.9", "2.2.0"))
        self.assertIsNone(updater.parse_release(self.rel(tag="v2.2.0"), "2.2.0"))

    def test_sha_asset(self):
        sha = "a" * 64
        fetch = lambda url, **k: (sha + "  x-update.zip\n").encode()
        r = updater.parse_release(self.rel(assets=["x-update.zip", "x-update.zip.sha256"]), "2.2.0", fetch)
        self.assertEqual((r["version"], r["sha256"]), ("2.3.0", sha))

    def test_links_in_body(self):
        sha = "b" * 64
        body = ("Архив: https://raw.githubusercontent.com/a/b/main/releases/2.3.0/club-screens-2.3.0-update.zip\n"
                f"SHA-256 club-screens-2.3.0-update.zip: {sha}\n")
        r = updater.parse_release(self.rel(body=body), "2.2.0", lambda *a, **k: b"")
        self.assertTrue(r["zip_url"].endswith("-update.zip"))
        self.assertEqual(r["sha256"], sha)

    def test_no_sha_refused(self):
        with self.assertRaises(updater.UpdateError):
            updater.parse_release(self.rel(assets=["x-update.zip"]), "2.2.0", lambda *a, **k: b"")

    def test_bad_host(self):
        body = "https://evil.example/x-update.zip " + "c" * 64 + " update"
        with self.assertRaises(updater.UpdateError):
            updater.parse_release(self.rel(body=body), "2.2.0")

    def test_download_verify(self):
        data = make_zip()
        info = {"version": "2.3.0", "zip_url": "https://github.com/x-update.zip",
                "sha256": hashlib.sha256(data).hexdigest()}
        d = tempfile.mkdtemp()
        p = updater.download(info, d, fetch=lambda *a, **k: data)
        self.assertTrue(os.path.exists(p))
        info["sha256"] = "0" * 64
        with self.assertRaises(updater.UpdateError):
            updater.download(info, d, fetch=lambda *a, **k: data)

    def test_zip_must_not_carry_personal(self):
        d = tempfile.mkdtemp()
        for extra in (["club-screens/program/config.yaml"], ["club-screens/../x"],
                      ["club-screens/program/browser_profile/Cookies"]):
            p = os.path.join(d, "u.zip")
            open(p, "wb").write(make_zip(extra))
            with self.assertRaises(updater.UpdateError):
                updater.verify_zip(p)

    def test_should_check(self):
        import datetime as dt
        cfg = {"updates": {"auto_check": True, "last_check": "2026-10-29 10:00"}}
        self.assertFalse(updater.should_check(cfg, dt.date(2026, 10, 29)))
        self.assertTrue(updater.should_check(cfg, dt.date(2026, 10, 30)))
        cfg["updates"]["auto_check"] = False
        self.assertFalse(updater.should_check(cfg, dt.date(2026, 10, 30)))

    def test_apply_bat_keeps_user_data(self):
        root = tempfile.mkdtemp()
        bat = updater.write_apply_bat(root, r"C:\x\u.zip", 1234, "2.3.0")
        text = open(bat, encoding="utf-8", newline="").read()
        for k in ("config.yaml", "browser_profile", "templates", "backup_prev", "Expand-Archive", "PID eq %PID%"):
            self.assertIn(k, text)
        self.assertIn("\r\n", text)
        self.assertIn("backup_prev", updater.ROLLBACK_BAT)


class ManifestTest(unittest.TestCase):
    SHA = "ab" * 32
    URL = ("https://raw.githubusercontent.com/arujiyami/GeteroFemboySoftware_creenam/main/"
           "releases/2.2.1/club-screens-2.2.1-update.zip")

    def _m(self, **kw):
        m = {"version": "2.2.1", "update_zip_url": self.URL, "sha256": self.SHA, "notes": "n", "min_version": "2.2.0"}
        m.update(kw)
        return m

    def test_manifest_primary(self):
        seen = []

        def fetch(url, **kw):
            seen.append(url)
            return json.dumps(self._m()).encode()
        info = updater.check("arujiyami/GeteroFemboySoftware_creenam", "2.2.0", fetch)
        self.assertEqual(info["version"], "2.2.1")
        self.assertEqual(info["sha256"], self.SHA)
        self.assertTrue(seen[0].endswith("/main/latest.json"))
        self.assertEqual(len(seen), 1)

    def test_manifest_not_newer(self):
        self.assertIsNone(updater.parse_manifest(self._m(version="2.2.0"), "2.2.0"))

    def test_manifest_needs_sha_and_min_version(self):
        with self.assertRaises(updater.UpdateError):
            updater.parse_manifest(self._m(sha256=""), "2.2.0")
        with self.assertRaises(updater.UpdateError):
            updater.parse_manifest(self._m(min_version="2.2.0"), "2.1.9")
        with self.assertRaises(updater.UpdateError):
            updater.parse_manifest(self._m(update_zip_url="https://evil.example/x-update.zip"), "2.2.0")

    def test_fallback_to_releases(self):
        rel = {"tag_name": "v2.2.1", "body": self.URL + "\n" + self.SHA + " club-screens-2.2.1-update.zip"}

        def fetch(url, **kw):
            if url.endswith("latest.json"):
                raise OSError("404")
            if url.endswith(".sha256"):
                raise OSError("404")
            return json.dumps(rel).encode()
        info = updater.check("arujiyami/GeteroFemboySoftware_creenam", "2.2.0", fetch)
        self.assertEqual(info["version"], "2.2.1")
