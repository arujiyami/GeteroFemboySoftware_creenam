# Original-Author: Владислав С.
# Created: 2026-10-28
import unittest

from app.config import DEFAULTS
from app.winmatch import describe, pick_window, picker_rows, window_rule


def W(hwnd, title, exe, w=1200, h=800, **kw):
    d = {"hwnd": hwnd, "title": title, "exe": exe, "pid": hwnd * 10, "visible": True, "iconic": False,
         "tool": False, "cloaked": False, "owned": False, "width": w, "height": h}
    d.update(kw)
    return d


def src(name):
    return next(s for s in DEFAULTS["sources"] if s["name"] == name)["window"]


def pick(wins, win, own_pid=None):
    return pick_window(wins, win.get("title_regex", ""), win.get("process_regex", ""),
                       win.get("exclude_title_regex", ""), win.get("match", "any"), own_pid)


class OasysTests(unittest.TestCase):
    def test_found_by_process_even_if_title_unrelated(self):
        wins = [W(1, "Клуб — администратор", "OASys.Admin.exe"), W(2, "Проводник", "explorer.exe")]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 1)

    def test_case_insensitive_title_and_process(self):
        wins = [W(1, "OASYS ADMIN 3.2", "something.exe")]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 1)
        wins = [W(1, "", "oasys.admin.EXE")]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 1)

    def test_exe_name_matches_title_pattern(self):
        self.assertEqual(pick_window([W(5, "Main", "OASys.Admin.exe")], "(?i)oasys")["hwnd"], 5)

    def test_largest_visible_top_level_window_wins(self):
        wins = [W(1, "OASys", "OASys.Admin.exe", 300, 120),          # заставка/уведомление
                W(2, "", "OASys.Admin.exe", 0, 0),                   # нулевого размера
                W(3, "OASys", "OASys.Admin.exe", 1920, 1040),        # главное окно
                W(4, "OASys tip", "OASys.Admin.exe", 2500, 1400, tool=True),
                W(6, "OASys hidden", "OASys.Admin.exe", 2500, 1400, visible=False),
                W(7, "OASys cloaked", "OASys.Admin.exe", 2500, 1400, cloaked=True)]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 3)

    def test_browser_tab_with_oasys_in_title_is_ignored(self):
        wins = [W(1, "oasys — Google Chrome", "chrome.exe", 2000, 1200)]
        self.assertIsNone(pick(wins, src("Oasys")))
        wins.append(W(2, "Админка", "OASys.Admin.exe", 800, 600))
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 2)

    def test_process_match_beats_bigger_title_only_match(self):
        wins = [W(1, "Отчёт oasys.xlsx", "notepad.exe", 2000, 1200), W(2, "Main", "OASys.Admin.exe", 900, 700)]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 2)

    def test_own_window_skipped(self):
        wins = [W(1, "Oasys — Скриншоты клуба", "python.exe", pid=42)]
        self.assertIsNone(pick(wins, {"title_regex": "oasys"}, own_pid=42))

    def test_minimized_window_counts(self):
        wins = [W(1, "OASys", "OASys.Admin.exe", 0, 0, iconic=True)]
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 1)

    def test_invalid_regex_is_plain_text(self):
        self.assertEqual(pick_window([W(1, "Касса (1", "x.exe")], "Касса (1")["hwnd"], 1)

    def test_match_all(self):
        wins = [W(1, "Oasys", "other.exe"), W(2, "Oasys", "OASys.Admin.exe")]
        self.assertEqual(pick_window(wins, "oasys", "^oasys\\.admin", match="all")["hwnd"], 2)


class IvmsTests(unittest.TestCase):
    def test_framework_process(self):
        wins = [W(1, "", "iVMS-4200.Framework.C.exe", 1920, 1080), W(2, "Login", "iVMS-4200.Framework.C.exe", 400, 300)]
        self.assertEqual(pick(wins, src("iVMS-4200"))["hwnd"], 1)

    def test_title(self):
        wins = [W(1, "ivms-4200 client", "Client.exe", 1600, 900)]
        self.assertEqual(pick(wins, src("iVMS-4200"))["hwnd"], 1)

    def test_not_confused_with_oasys(self):
        wins = [W(1, "Main", "OASys.Admin.exe"), W(2, "iVMS-4200", "iVMS-4200.Framework.C.exe")]
        self.assertEqual(pick(wins, src("iVMS-4200"))["hwnd"], 2)
        self.assertEqual(pick(wins, src("Oasys"))["hwnd"], 1)


class PickerTests(unittest.TestCase):
    def test_rows_and_rule(self):
        wins = [W(1, "Small", "a.exe", 200, 100), W(2, "Big", "OASys.Admin.exe", 1900, 1000),
                W(3, "", "", 500, 500), W(4, "Tip", "b.exe", tool=True)]
        rows = picker_rows(wins)
        self.assertEqual([r["hwnd"] for r in rows], [2, 1])
        rule = window_rule(rows[0])
        self.assertEqual(pick_window(wins, rule["title_regex"], rule["process_regex"])["hwnd"], 2)
        rule = window_rule(rows[1], use="title")
        self.assertEqual(pick_window(wins, rule["title_regex"], rule["process_regex"])["hwnd"], 1)

    def test_describe(self):
        lines = describe([W(1, "Main", "OASys.Admin.exe", tool=True)])
        self.assertIn("OASys.Admin.exe", lines[0])
        self.assertIn("tool", lines[0])


if __name__ == "__main__":
    unittest.main()


class StartupXmlTest(unittest.TestCase):
    def test_task_xml(self):
        import xml.dom.minidom
        from app.startup import task_xml
        x = task_xml(r"C:\Py\pythonw.exe", r'"C:\Клуб & Co\main.py" --minimized', r"C:\Клуб & Co", r"PC\Админ")
        xml.dom.minidom.parseString(x.replace('encoding="UTF-16"', 'encoding="UTF-8"').encode("utf-8"))
        self.assertIn("<RunLevel>HighestAvailable</RunLevel>", x)
        self.assertIn("<ExecutionTimeLimit>PT0S</ExecutionTimeLimit>", x)
        self.assertIn("<LogonTrigger>", x)
        self.assertIn("&amp; Co", x)


class ElevationTest(unittest.TestCase):
    def test_relaunch_args(self):
        from app.elevation import NO_ELEVATE_ARG, relaunch_args
        exe, params = relaunch_args(["--minimized", NO_ELEVATE_ARG], script="/x/main.py")
        self.assertTrue(params.endswith("--minimized " + NO_ELEVATE_ARG))
        self.assertEqual(params.count(NO_ELEVATE_ARG), 1)
        self.assertIn("main.py", params)


class InputTest(unittest.TestCase):
    def test_absolute_coords_virtual_desktop(self):
        from app.backend_win import absolute_coords
        self.assertEqual(absolute_coords(-1920, 0, (-1920, 0, 3840, 1080)), (0, 0))
        self.assertEqual(absolute_coords(1919, 1079, (-1920, 0, 3840, 1080)), (65535, 65535))
        x, _ = absolute_coords(0, 0, (-1920, 0, 3840, 1080))
        self.assertAlmostEqual(x, 32776, delta=20)

    def test_vk_codes(self):
        from app.backend_win import vk_code
        self.assertEqual(vk_code("Enter"), 0x0D)
        self.assertEqual(vk_code("f5"), 0x74)
        self.assertEqual(vk_code("a"), 0x41)
