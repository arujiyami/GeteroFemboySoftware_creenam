# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.3: кнопка «Отправить сообщение» нового ВК (data-testid="vkme_composer_send") — поиск по всей странице,
полное нажатие, проверка «поле очистилось», запасной Enter. Разметка — обезличенная настоящая
(tests/fixtures/vk_convo_composer_2026.html)."""
import os
import re
import unittest

from app.vk_browser import PRIORITY_SELECTORS, Flows, merged_settings
from tests.test_login_detect import run_script
from tests.test_vk_browser import FakeDriver, FakeVK

HERE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(HERE, "fixtures", "vk_convo_composer_2026.html")
OLD = ['role=button[name="Отправить"]', '[aria-label="Отправить"]', '[aria-label="Send"]', 'role=button[name="Send"]']


class Selectors(unittest.TestCase):
    def test_priority_first_even_with_old_config(self):
        s = merged_settings({"vk_browser": {"selectors": {"send_button": OLD}}})["selectors"]
        self.assertEqual(s["send_button"][0], '[data-testid="vkme_composer_send"]')
        self.assertIn('[aria-label="Отправить сообщение"]', s["send_button"])
        self.assertTrue(any("ConvoComposer__sendButton" in x for x in s["send_button"]))
        self.assertEqual(s["send_button"][-len(OLD):], OLD)
        for k in ("composer", "attachment_preview", "attachment_remove", "file_input", "attach_button"):
            self.assertEqual(s[k][:len(PRIORITY_SELECTORS[k])], PRIORITY_SELECTORS[k], k)


class Fixture(unittest.TestCase):
    def test_no_personal_data(self):
        html = open(FIX, encoding="utf-8").read()
        # имена заданы кодами, чтобы сами не попали в файлы
        names = [bytes.fromhex(x).decode() for x in ("d0a0d183d181d0bbd0b0d0bd", "d0a1d0bfd0b8d180d0b8d0b4d0b5d0bdd0bad0be")]
        for bad in names + ["vkuserphoto", "userapi", "2000000", "href=", "avatar", "Avatar"]:
            self.assertNotIn(bad, html)
        self.assertIsNone(re.search(r"\bid=\"", html))
        for real in ('data-testid="vkme_composer_send"', 'aria-label="Отправить сообщение"',
                     "ConvoComposer__sendButton--submit", "ConvoMain__composerWrapper", 'data-testid="vkme_composer_input"'):
            self.assertIn(real, html)


class ClickFlow(unittest.TestCase):
    def flows(self):
        return Flows(merged_settings({}))

    def test_cleared_after_click_no_enter(self):
        page = FakeVK()
        page.previews = 2
        r = FakeDriver(page).run(self.flows().click_send(0))
        self.assertEqual(r, "button")
        self.assertNotIn("enter", page.calls)
        self.assertEqual(page.outgoing, 1)

    def test_dead_button_then_enter_once(self):
        page = FakeVK()
        page.previews = 2
        orig = page.call

        def call(fn, a):
            if fn == "click_send":
                page.calls.append(fn)
                return "clicked"           # нажали, но ВК не отправил
            return orig(fn, a)
        page.call = call
        r = FakeDriver(page).run(self.flows().click_send(0))
        self.assertEqual(r, "enter")
        self.assertEqual(page.outgoing, 1)


class RealDom(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r = run_script("send_probe.py", timeout=120)

    def test_new_selectors_click_real_button(self):
        r = self.r["new"]
        self.assertEqual(r["click"], "clicked")
        self.assertEqual((r["sent"], r["decoy"]), (1, 0))
        self.assertEqual(r["state"]["prev"], 0)
        self.assertEqual(r["probe"]["c"]["attachment_preview"], 2)
        self.assertEqual(r["probe"]["c"]["send_button"], 1)
        self.assertIn("в области", r["diag"]["matched"]["send_button"])

    def test_old_config_still_works(self):
        r = self.r["old_config"]
        self.assertEqual((r["sent"], r["decoy"]), (1, 0))

    def test_v222_selectors_reproduce_bug(self):
        r = self.r["v222_selectors"]      # так было в 2.2.2: «1/0» и нажатие мимо
        self.assertTrue(r["diag"]["matched"]["send_button"].startswith("1/0"))
        self.assertEqual(r["sent"], 0)

    def test_dead_button_enter_fallback(self):
        r = self.r["dead"]
        self.assertEqual(r["state"]["prev"], 2)
        self.assertEqual(r["state_after_enter"]["prev"], 0)
        self.assertEqual(r["sent"], 1)

    def test_button_outside_area_found_page_wide(self):
        r = self.r["outside"]
        self.assertEqual((r["click"], r["sent"], r["decoy"]), ("clicked", 1, 0))


if __name__ == "__main__":
    unittest.main()
