# Original-Author: Владислав С.
# Created: 2026-10-28
"""Ежедневная уборка: замок цикла, защита файлов текущей/неудачной отправки, сроки, предел logs, время."""
import copy
import os
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta

from app import AUTHOR_LINE, CONTRIBUTOR_LINE, __version__
from app.about import about_text, how_it_works
from app.cleanup import (FAILED_SUFFIX, busy_minutes, clamp_time, clean_logs, clean_screenshots, next_daily,
                         parse_time)
from app.config import DEFAULTS
from app.job import JobRunner
from app.scheduler import HourlyScheduler

H = 3600


def touch(folder, name, age_h, size=10, now=None):
    p = os.path.join(folder, name)
    with open(p, "wb") as f:
        f.write(b"x" * size)
    t = (now or time.time()) - age_h * H
    os.utime(p, (t, t))
    return p


def shot(stamp, i=1, name="Oasys"):
    return f"{stamp}_{i:02d}_{name}.png"


class Screenshots(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.now = time.time()

    def test_age_retention(self):
        touch(self.d, shot("2026-10-25_06-00"), 30)
        touch(self.d, shot("2026-10-25_06-00", 11, "Камеры"), 30)
        touch(self.d, shot("2026-10-26_05-00"), 23)
        touch(self.d, shot("2026-10-26_07-00"), 1)     # самый свежий
        n, _ = clean_screenshots(self.d, 24, now=self.now)
        self.assertEqual(n, 2)
        self.assertEqual(sorted(os.listdir(self.d)), [shot("2026-10-26_05-00"), shot("2026-10-26_07-00")])

    def test_pending_cycle_kept(self):
        old = touch(self.d, shot("2026-10-20_06-00"), 200)
        touch(self.d, shot("2026-10-20_09-00"), 1)
        clean_screenshots(self.d, 24, protect={"2026-10-20_06-00"}, now=self.now)
        self.assertTrue(os.path.exists(old))

    def test_newest_cycle_always_kept(self):
        p = touch(self.d, shot("2026-10-20_06-00"), 500)
        clean_screenshots(self.d, 24, now=self.now)
        self.assertTrue(os.path.exists(p))

    def test_failed_kept_three_days(self):
        f1 = touch(self.d, shot("2026-10-24_06-00"), 48)
        touch(self.d, "2026-10-24_06-00" + FAILED_SUFFIX, 48)
        f2 = touch(self.d, shot("2026-10-21_06-00"), 80)
        m2 = touch(self.d, "2026-10-21_06-00" + FAILED_SUFFIX, 80)
        ok = touch(self.d, shot("2026-10-24_07-00"), 48)
        touch(self.d, shot("2026-10-26_07-00"), 0.1)
        clean_screenshots(self.d, 24, now=self.now)
        self.assertTrue(os.path.exists(f1))
        self.assertFalse(os.path.exists(f2))
        self.assertFalse(os.path.exists(m2))
        self.assertFalse(os.path.exists(ok))

    def test_only_own_files(self):
        other = [touch(self.d, n, 999) for n in ("photo.png", "notes.txt", "2026-10-01.png", "a_01_b.png")]
        touch(self.d, shot("2026-10-26_07-00"), 0.1)
        clean_screenshots(self.d, 24, now=self.now)
        self.assertTrue(all(os.path.exists(p) for p in other))

    def test_locked_file_skipped(self):
        p = touch(self.d, shot("2026-10-20_06-00"), 100)
        touch(self.d, shot("2026-10-26_07-00"), 0.1)
        import app.cleanup as c
        real = os.remove

        def deny(path):
            if path == p:
                raise PermissionError("занят")
            real(path)
        c.os.remove = deny
        try:
            n, _ = clean_screenshots(self.d, 24, now=self.now)
        finally:
            c.os.remove = real
        self.assertEqual(n, 0)
        self.assertTrue(os.path.exists(p))


class Logs(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.log = os.path.join(self.d, "club-screens.log")
        touch(self.d, "club-screens.log", 0, 100)

    def test_diag_three_days(self):
        old = touch(self.d, "vk_dom_send_20261020_060000.html", 80)
        new = touch(self.d, "vk_send_failed_20261027_060000.png", 10)
        foreign = touch(self.d, "my_notes.html", 500)
        clean_logs(self.d, self.log)
        self.assertFalse(os.path.exists(old))
        self.assertTrue(os.path.exists(new))
        self.assertTrue(os.path.exists(foreign))

    def test_size_cap_oldest_first(self):
        a = touch(self.d, "vk_dom_a_20261027_010000.html", 5, 400)
        b = touch(self.d, "club-screens.log.3", 4, 400)
        c = touch(self.d, "vk_dom_c_20261027_030000.html", 3, 400)
        n, _ = clean_logs(self.d, self.log, cap_bytes=1000)
        self.assertEqual(n, 1)
        self.assertFalse(os.path.exists(a))
        self.assertTrue(os.path.exists(b) and os.path.exists(c) and os.path.exists(self.log))
        clean_logs(self.d, self.log, cap_bytes=300)
        self.assertTrue(os.path.exists(self.log))   # текущий журнал не трогаем


class Timing(unittest.TestCase):
    sched = {"minute": 0, "prewarm_minutes": 5, "attempts": 2, "retry_interval_sec": 180}

    def test_default_window(self):
        busy = busy_minutes(self.sched)
        self.assertIn(55, busy)
        self.assertIn(0, busy)
        self.assertIn(6, busy)
        self.assertNotIn(30, busy)
        self.assertEqual(clamp_time("12:30", self.sched), (12, 30, False))

    def test_clamped_away_from_send(self):
        self.assertEqual(clamp_time("12:57", self.sched), (12, 30, True))
        self.assertEqual(clamp_time("13:02", self.sched), (13, 30, True))
        s = dict(self.sched, minute=30)              # отправка в :30 — уборка после окна
        h, m, moved = clamp_time("12:30", s)
        self.assertTrue(moved)
        self.assertNotIn(m, busy_minutes(s))

    def test_parse_and_next(self):
        self.assertEqual(parse_time("9:05"), (9, 5))
        for bad in ("25:00", "12-30", "abc", "12:60"):
            with self.assertRaises(ValueError):
                parse_time(bad)
        now = datetime(2026, 10, 28, 13, 0)
        self.assertEqual(next_daily(now, 12, 30), datetime(2026, 10, 29, 12, 30))


class Tick:
    def __init__(self, t):
        self.t = t

    def __call__(self):
        return self.t


class SchedulerCleanup(unittest.TestCase):
    def make(self, start, calls, result=(0, 0)):
        clock = Tick(start)
        s = HourlyScheduler(lambda: None, lambda: {"minute": 0, "prewarm_minutes": 5}, now=clock,
                            cleanup=lambda: (calls.append(clock.t), result)[1],
                            cleanup_settings=lambda: {"enabled": True, "time": "12:30"})
        return s, clock

    def test_startup_then_daily(self):
        calls = []
        s, clock = self.make(datetime(2026, 10, 28, 10, 10), calls)
        s.next_cleanup = clock.t + timedelta(seconds=s.cleanup_delay_sec)
        set_ = {"minute": 0, "prewarm_minutes": 5}
        s._maybe_cleanup(clock.t, set_)
        self.assertEqual(calls, [])
        clock.t += timedelta(minutes=2)
        s._maybe_cleanup(clock.t, set_)
        self.assertEqual(len(calls), 1)
        self.assertEqual(s.next_cleanup, datetime(2026, 10, 28, 12, 30))

    def test_not_in_send_window_and_retry_when_busy(self):
        calls = []
        s, clock = self.make(datetime(2026, 10, 28, 11, 58), calls, result=None)
        s.next_cleanup = datetime(2026, 10, 28, 11, 57)
        set_ = {"minute": 0, "prewarm_minutes": 5}
        s._maybe_cleanup(clock.t, set_)
        self.assertEqual(calls, [])                 # окно отправки — ждём
        clock.t = datetime(2026, 10, 28, 12, 20)
        s._maybe_cleanup(clock.t, set_)
        self.assertEqual(len(calls), 1)             # cleanup() вернул None — цикл идёт
        self.assertEqual(s.next_cleanup, clock.t + timedelta(seconds=60))


class JobLock(unittest.TestCase):
    def cfg(self, d):
        c = copy.deepcopy(DEFAULTS)
        c["storage"]["screenshots_dir"] = os.path.join(d, "screenshots")
        c["storage"]["log_file"] = os.path.join(d, "logs", "club-screens.log")
        os.makedirs(c["storage"]["screenshots_dir"])
        return c

    def test_skipped_while_cycle_lock_held(self):
        d = tempfile.mkdtemp()
        cfg = self.cfg(d)
        old = touch(cfg["storage"]["screenshots_dir"], shot("2026-10-01_06-00"), 500)
        touch(cfg["storage"]["screenshots_dir"], shot("2026-10-26_07-00"), 0.1)
        job = JobRunner(lambda: cfg, lambda: None)
        job.lock.acquire()
        try:
            self.assertIsNone(job.cleanup())
            self.assertTrue(os.path.exists(old))
        finally:
            job.lock.release()
        self.assertIsNotNone(job.cleanup())
        self.assertFalse(os.path.exists(old))

    def test_pending_and_failed_cycle_files_kept(self):
        d = tempfile.mkdtemp()
        cfg = self.cfg(d)
        sd = cfg["storage"]["screenshots_dir"]
        pend = touch(sd, shot("2026-10-20_06-00"), 300)
        res = touch(sd, shot("2026-10-20_05-00"), 300)
        touch(sd, shot("2026-10-27_07-00"), 0.1)
        job = JobRunner(lambda: cfg, lambda: None)
        job.last_stamp = "2026-10-20_06-00"            # ожидает повтора
        job.last_result = {"paths": [res]}             # показан как «Последняя отправка»
        job.cleanup()
        self.assertTrue(os.path.exists(pend) and os.path.exists(res))

    def test_cycle_waits_for_cleanup(self):
        d = tempfile.mkdtemp()
        cfg = self.cfg(d)
        cfg["sources"] = []
        job = JobRunner(lambda: cfg, lambda: None)
        job.cleanup_lock.acquire()
        order = []
        t = threading.Thread(target=lambda: (job.run_cycle(False), order.append("cycle")))
        t.start()
        time.sleep(0.2)
        order.append("cleanup done")
        job.cleanup_lock.release()
        t.join(5)
        self.assertEqual(order, ["cleanup done", "cycle"])


class ConfigCheck(unittest.TestCase):
    def test_validate(self):
        from app.config import validate
        cfg = copy.deepcopy(DEFAULTS)
        self.assertEqual(cfg["cleanup"], {"enabled": True, "time": "12:30", "keep_hours": 24})
        self.assertFalse([e for e in validate(cfg) if "уборк" in e.lower()])
        cfg["cleanup"]["time"] = "99:99"
        cfg["cleanup"]["keep_hours"] = 0
        errs = validate(cfg)
        self.assertTrue(any("ЧЧ:ММ" in e for e in errs), errs)
        self.assertTrue(any("keep_hours" in e for e in errs), errs)


class About(unittest.TestCase):
    def test_from_defaults(self):
        text = about_text(DEFAULTS)
        lines = how_it_works(DEFAULTS)
        self.assertTrue(4 <= len(lines) <= 7)
        for part in (__version__, "за 5 минут", "За 60 секунд", "обратный отсчёт", "Ctrl+Alt+Q", "30 секунд", "Ctrl+Alt+Del",
                     "за 5 секунд до съёмки", "сразу после снимков", "до 10 секунд", "Oasys не загрузился",
                     "12:30", "24 часов", "3 дней", "50 МБ", "не удаляются никогда"):
            self.assertIn(part, text)
        tail = text.splitlines()[-2:]
        self.assertEqual(tail, [AUTHOR_LINE, CONTRIBUTOR_LINE])
        self.assertEqual(CONTRIBUTOR_LINE, "Помогал с кодом — Grok Bot")

    def test_reflects_settings(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg["input_lock"]["hotkey"] = "Ctrl+Shift+U"
        cfg["input_lock"]["watchdog_sec"] = 21
        cfg["input_lock"]["early_sec"] = 3
        cfg["oasys_check"]["timeout_sec"] = 25
        cfg["countdown"]["seconds"] = 45
        cfg["cleanup"]["time"] = "12:58"
        cfg["cleanup"]["keep_hours"] = 48
        text = about_text(cfg)
        for part in ("Ctrl+Shift+U", "21 секунду", "За 45 секунд", "12:30", "48 часов", "за 3 секунды до съёмки",
                     "до 25 секунд"):
            self.assertIn(part, text)
        cfg["countdown"]["seconds"] = 0
        cfg["input_lock"]["early_sec"] = 0
        cfg["oasys_check"]["enabled"] = False
        text = about_text(cfg)
        self.assertIn("Обратный отсчёт перед съёмкой выключен", text)
        self.assertIn("блокируются на время съёмки", text)
        self.assertNotIn("Oasys загрузился", text)


if __name__ == "__main__":
    unittest.main()
