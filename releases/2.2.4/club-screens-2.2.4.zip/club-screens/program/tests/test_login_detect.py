# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.3: распознавание входа в ВК (cookie по доменам, новый дизайн ВК) и то, что сохранённая настройка
не «слетает» от временного состояния браузера."""
import copy
import json
import os
import subprocess
import sys
import unittest

from app.config import DEFAULTS, is_configured, migrate
from app.logincheck import CookieTracker, base_domain, decide
from app.vk_browser import DEFAULT_SELECTORS, NEW_LOGGED_IN_SELECTORS, Flows, NotLoggedIn, merged_settings
from app.wizard_logic import step_done

from tests.test_vk_browser import FakeDriver, FakeVK, settings

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def run_script(name, timeout=170):
    try:
        import PySide6.QtWebEngineWidgets  # noqa: F401
    except Exception as e:  # noqa: BLE001
        raise unittest.SkipTest(f"нет Qt WebEngine: {e}")
    env = dict(os.environ, QT_QPA_PLATFORM=os.environ.get("QT_QPA_PLATFORM", "offscreen"))
    p = subprocess.run([sys.executable, os.path.join(HERE, name)], cwd=ROOT, env=env, timeout=timeout,
                       capture_output=True, text=True, encoding="utf-8")
    lines = [ln for ln in p.stdout.splitlines() if ln.startswith("{")]
    if not lines:
        raise AssertionError(f"{name}: нет результата (код {p.returncode})\n{p.stderr[-2000:]}")
    return json.loads(lines[-1])


class CookieTrackerTest(unittest.TestCase):
    def test_domains(self):
        self.assertEqual(base_domain(".vk.com"), "vk.com")
        self.assertEqual(base_domain("login.vk.ru"), "vk.ru")
        self.assertEqual(base_domain(".vk.me"), "")
        self.assertEqual(base_domain("evilvk.com"), "")

    def test_session_on_vk_com_or_vk_ru(self):
        t = CookieTracker()
        self.assertFalse(t.has_session())
        t.add(".vk.ru", "remixnsid")
        self.assertTrue(t.has_session())
        t2 = CookieTracker()
        t2.add(".vk.me", "remixsid")
        t2.add(".vk.com", "remixlang")
        self.assertFalse(t2.has_session())

    def test_removal_on_one_domain_keeps_other(self):
        t = CookieTracker()
        t.add(".vk.com", "remixsid")
        t.add(".vk.ru", "remixsid")
        t.remove(".vk.ru", "remixsid")
        self.assertTrue(t.has_session())
        self.assertEqual(t.names(), {"remixsid": True})
        self.assertEqual(t.names_by_domain(), {".vk.com": ["remixsid"]})

    def test_rotation(self):
        t = CookieTracker()
        t.add(".vk.com", "remixsid")
        t.remove(".vk.com", "remixsid")
        self.assertFalse(t.has_session())
        t.add(".vk.com", "remixsid")
        self.assertTrue(t.has_session())

    def test_no_values_kept(self):
        t = CookieTracker()
        t.add(".vk.com", "remixsid")
        self.assertNotIn("x", repr(t._jar.values()).replace("True", ""))


class DecideTest(unittest.TestCase):
    def test_rule(self):
        self.assertTrue(decide(True, 0, 0))          # cookie, страница без признаков
        self.assertTrue(decide(False, 1, 0))         # cookie не видно, но страница — вход выполнен
        self.assertTrue(decide(None, 1, 0))
        self.assertTrue(decide(True, 1, 1))          # cookie + признаки: «Войти» где-то в виджете не мешает
        self.assertFalse(decide(True, 0, 1))         # форма входа
        self.assertFalse(decide(False, 1, 1))
        self.assertFalse(decide(False, 0, 0))


class FlowsNewUiTest(unittest.TestCase):
    def run_flow(self, page, gen):
        return FakeDriver(page).run(gen)

    def test_dom_markers_without_cookie(self):
        page = FakeVK()
        page.cookies = {}                      # отслеживание cookie ещё ничего не увидело
        page.url = "https://vk.com/feed"
        f = Flows(settings())
        self.assertEqual(self.run_flow(page, f.state()), "ok")
        self.assertFalse(f.confirmed_logout())

    def test_cookie_without_dom_markers(self):
        page = FakeVK()
        page.url = "https://vk.com/feed"
        page.logged_in = False                 # новый дизайн: старых признаков нет, формы входа тоже
        page.counts = lambda keys, box=(): {k: 0 for k in keys}
        f = Flows(settings())
        self.assertEqual(self.run_flow(page, f.state()), "ok")

    def test_login_form_and_no_cookie_is_confirmed_logout(self):
        page = FakeVK(logged_in=False)
        page.url = "https://vk.com/"
        f = Flows(settings())
        self.assertEqual(self.run_flow(page, f.state()), "logged_out")
        self.assertTrue(f.confirmed_logout())
        with self.assertRaises(NotLoggedIn) as cm:
            f.raise_for_state("logged_out")
        self.assertTrue(cm.exception.confirmed)

    def test_unclear_page_is_not_confirmed(self):
        page = FakeVK()
        page.cookies = {}
        page.url = "https://vk.com/feed"
        page.counts = lambda keys, box=(): {k: 0 for k in keys}
        f = Flows(settings())
        self.assertEqual(self.run_flow(page, f.state()), "logged_out")
        self.assertFalse(f.confirmed_logout())  # ни формы, ни признаков — вход не сбрасываем

    def test_login_status_details(self):
        page = FakeVK(logged_in=False)
        r = self.run_flow(page, Flows(settings()).login_status(navigate=True, settle=0))
        self.assertEqual((r["state"], r["form"], r["cookie"], r["confirmed_logout"]),
                         ("logged_out", True, False, True))

    def test_new_selectors_in_defaults(self):
        for s in ('a[href="/im"]', 'a[href^="/im?"]', 'nav [href*="/feed"]', 'a[href="/friends"]'):
            self.assertIn(s, DEFAULT_SELECTORS["logged_in"])
        self.assertEqual(DEFAULT_SELECTORS["logged_in"][:3],
                         ['#top_profile_link', '[data-testid="header-profile-menu-button"]', '#l_msg'])
        yaml_sel = DEFAULTS["vk_browser"]["selectors"]["logged_in"]
        self.assertEqual(yaml_sel, DEFAULT_SELECTORS["logged_in"])


class MigrationTest(unittest.TestCase):
    def test_old_config_gets_new_selectors(self):
        cfg = copy.deepcopy(DEFAULTS)
        old = ['#top_profile_link', '[data-testid="header-profile-menu-button"]', '#l_msg', '.my-own']
        cfg["vk_browser"]["selectors"]["logged_in"] = list(old)
        notes = migrate(cfg)
        got = cfg["vk_browser"]["selectors"]["logged_in"]
        self.assertEqual(got[:4], old)               # свои — на месте и в том же порядке
        for s in NEW_LOGGED_IN_SELECTORS:
            self.assertIn(s, got)
        self.assertTrue(any("нового дизайна" in n for n in notes))
        self.assertEqual(migrate(cfg), [])           # повторно — ничего
        self.assertEqual(cfg["vk_browser"]["selectors"]["logged_in"], got)
        self.assertIn('a[href="/im"]', merged_settings(cfg)["selectors"]["logged_in"])

    def test_default_config_unchanged(self):
        cfg = copy.deepcopy(DEFAULTS)
        self.assertEqual(migrate(cfg), [])


class PersistedStateTest(unittest.TestCase):
    def cfg(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg["app"]["setup_done"] = True
        cfg["vk"].update(login_ok=True, peer_id=2000000001)
        return cfg

    def test_is_configured_uses_saved_settings_only(self):
        self.assertTrue(is_configured(self.cfg()))

    def test_step_done(self):
        cfg = self.cfg()
        self.assertTrue(step_done(cfg, "vk"))
        self.assertTrue(step_done(cfg, "chat"))
        self.assertTrue(step_done(cfg, "welcome"))
        self.assertFalse(step_done(cfg, "test"))
        cfg["vk"]["login_ok"] = False
        self.assertFalse(step_done(cfg, "vk"))


class RealBrowserDomTest(unittest.TestCase):
    """Настоящий Qt WebEngine: обезличенная страница нового дизайна ВК («Иван Иванов»)."""

    @classmethod
    def setUpClass(cls):
        cls.r = run_script("dom_probe.py")

    def test_new_ui_logged_in_by_dom(self):
        r = self.r["in"]
        self.assertEqual(r["state"], "ok", self.r)
        self.assertEqual(r["name"], "Иван Иванов")
        self.assertFalse(r["cookie"])          # входа по cookie нет — узнали по странице
        self.assertEqual(self.r["in_cookies"], [])

    def test_old_selectors_missed_new_ui(self):
        r = self.r["in_old_selectors"]
        self.assertEqual(r["state"], "logged_out")
        self.assertFalse(r["confirmed_logout"])  # и всё равно сохранённый вход не сбросился бы

    def test_logged_out_page(self):
        r = self.r["out"]
        self.assertEqual((r["state"], r["form"], r["confirmed_logout"]), ("logged_out", True, True))

    def test_debug_log_names_selectors(self):
        dbg = "\n".join(self.r["debug"])
        self.assertIn('признаки входа: 1 (a[href="/im"])', dbg)
        self.assertIn('форма входа: 1 (input[name="login"])', dbg)


class RegressionStateTest(unittest.TestCase):
    """Настроено (login_ok) → cookie удалена → добавлена → страница создана и выгружена → «Настроено»."""

    @classmethod
    def setUpClass(cls):
        cls.r = run_script("state_regression.py")

    def test_cookie_rotation_and_unload_keep_configured(self):
        for s in self.r["steps"]:
            self.assertTrue(s["configured"], s)
            self.assertTrue(s["login_ok"], s)
            self.assertNotEqual(s["status"], "Не настроено", s)

    def test_debounce(self):
        self.assertEqual(self.r["debounce_ms"], 10000)
        self.assertTrue(self.r["debounce_active"])
        self.assertTrue(self.r["debounce_cancelled"])
        self.assertTrue(self.r["vk_ru_removal_keeps_vk_com"])

    def test_wizard_keeps_state_across_navigation(self):
        for n in self.r["wizard_nav"]:
            self.assertTrue(n["next"], n)
            self.assertTrue(n["side_chat"].startswith("✔") or n["page"] == "chat", n)
            self.assertTrue(n["side_vk"].startswith("✔") or n["page"] == "vk", n)
            if n["page"] == "vk":
                self.assertTrue(n["vk_status"].startswith("✔"), n)
        self.assertTrue(self.r["wizard_after_transient"]["next"])
        self.assertEqual(self.r["poll_ms"], 2000)

    def test_real_logout_and_manual_confirm(self):
        self.assertTrue(self.r["view_loaded"])
        self.assertEqual(self.r["real_logout"], {"login_ok": False, "next": False, "configured": False})
        self.assertEqual(self.r["has_already_button"], "Я уже вошёл — продолжить")
        self.assertTrue(self.r["already"]["login_ok"])
        self.assertTrue(self.r["already"]["next"])


if __name__ == "__main__":
    unittest.main()
