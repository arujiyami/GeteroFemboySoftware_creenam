# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.6: музыка и видео на паузу на время съёма (Windows.Media.Control). Без Windows: сессии — подделки."""
import asyncio
import copy
import logging
import tempfile
import time
import unittest
from datetime import timedelta
from unittest import mock

from app import mediapause
from app.config import DEFAULT_CONFIG_YAML, DEFAULTS, migrate, validate
from app.job import JobRunner
from app.mediapause import MediaPauser, WinrtMedia, media_settings
from tests.test_oasys_ready import Clock, ReadyBackend
from tests.test_steps_job import FakeVK


class FakeSession:
    def __init__(self, name, status, hang=False, fail=False, ptype=2):
        self.name = name
        self.ptype = ptype          # MediaPlaybackType: 2 — видео (по умолчанию), 1 — музыка, None — неизвестно
        self._status = status
        self.hang = hang
        self.fail = fail
        self.calls = []

    def status(self):
        return self._status

    async def playback_type(self):
        if isinstance(self.ptype, Exception):
            raise self.ptype
        return self.ptype

    async def pause(self):
        self.calls.append("pause")
        if self.hang:
            await asyncio.sleep(30)
        if self.fail:
            raise OSError("отказ")
        self._status = "paused"
        return True

    async def play(self):
        self.calls.append("play")
        self._status = "playing"
        return True


class FakeMedia:
    def __init__(self, sessions, hang_list=False, fail_list=None):
        self.list = sessions
        self.hang_list = hang_list
        self.fail_list = fail_list

    async def sessions(self):
        if self.fail_list:
            raise self.fail_list
        if self.hang_list:
            await asyncio.sleep(30)
        return list(self.list)


def pauser(media, timeout=1.0):
    return MediaPauser(media_factory=lambda: media, timeout=timeout, resume_timeout=timeout)


class Pause(unittest.TestCase):
    def test_pauses_only_playing(self):
        a, b, c = FakeSession("spotify", "playing"), FakeSession("chrome", "paused"), FakeSession("vlc", "other")
        p = pauser(FakeMedia([a, b, c]))
        self.assertEqual(p.pause(), 1)
        self.assertEqual(a.calls, ["pause"])
        self.assertEqual(b.calls, [])
        self.assertEqual(c.calls, [])
        self.assertEqual([s.name for s in p.paused], ["spotify"])

    def test_resume_only_remembered(self):
        a, b = FakeSession("spotify", "playing"), FakeSession("chrome", "paused")   # chrome был на паузе сам
        p = pauser(FakeMedia([a, b]))
        p.pause()
        p.resume(wait=True)
        self.assertEqual(a.calls, ["pause", "play"])
        self.assertEqual(b.calls, [])
        self.assertEqual(p.paused, [])
        p.resume(wait=True)                  # повторно — ничего
        self.assertEqual(a.calls, ["pause", "play"])

    def test_resume_skips_if_user_already_played(self):
        a = FakeSession("spotify", "playing")
        p = pauser(FakeMedia([a]))
        p.pause()
        a._status = "playing"                # пользователь включил сам
        p.resume(wait=True)
        self.assertEqual(a.calls, ["pause"])

    def test_forget(self):
        a = FakeSession("spotify", "playing")
        p = pauser(FakeMedia([a]))
        p.pause()
        p.forget()
        self.assertIsNone(p.resume(wait=True))
        self.assertEqual(a.calls, ["pause"])

    def test_pause_timeout_does_not_block(self):
        a, b = FakeSession("hung", "playing", hang=True), FakeSession("ok", "playing")
        p = pauser(FakeMedia([a, b]), timeout=0.3)
        t0 = time.monotonic()
        n = p.pause()
        self.assertLess(time.monotonic() - t0, 0.9)
        self.assertEqual(n, 2)               # запомнены до паузы — потом включим обратно и «зависший»
        self.assertEqual(b._status, "paused")

    def test_sessions_list_hangs(self):
        p = pauser(FakeMedia([], hang_list=True), timeout=0.3)
        t0 = time.monotonic()
        with self.assertLogs("club", logging.INFO) as cm:
            self.assertEqual(p.pause(), 0)
        self.assertLess(time.monotonic() - t0, 0.9)
        self.assertIn("недоступна", "\n".join(cm.output))

    def test_default_timeout_about_one_second(self):
        p = MediaPauser(media_factory=lambda: FakeMedia([], hang_list=True))
        t0 = time.monotonic()
        p.pause()
        self.assertLess(time.monotonic() - t0, 1.6)

    def test_pause_error_is_swallowed(self):
        a = FakeSession("bad", "playing", fail=True)
        p = pauser(FakeMedia([a]))
        self.assertEqual(p.pause(), 1)       # ошибка — только в журнал
        p.resume(wait=True)

    def test_import_failure_logged_once_no_exception(self):
        def factory():
            raise ImportError("No module named 'winrt'")
        p = MediaPauser(media_factory=factory)
        with self.assertLogs("club", logging.DEBUG) as cm:
            self.assertEqual(p.pause(), 0)
            self.assertEqual(p.pause(), 0)
        infos = [r for r in cm.records if r.levelno == logging.INFO]
        self.assertEqual(len(infos), 1)      # не засоряем журнал каждый час
        self.assertIn("winrt", infos[0].getMessage())
        self.assertIsNone(p.resume())

    def test_load_winrt_not_windows(self):
        with mock.patch.object(mediapause.sys, "platform", "linux"):
            with self.assertRaises(ImportError):
                mediapause.load_winrt()

    def test_settings(self):
        self.assertEqual(media_settings(DEFAULTS), (False, True))
        self.assertEqual(media_settings({}), (False, True))
        self.assertEqual(media_settings({"media_pause": {"enabled": True, "resume": False}}), (True, False))
        self.assertEqual(media_settings({"media_pause": "мусор"}), (False, True))


class WinrtAdapter(unittest.TestCase):
    """Обёртка над API winrt с поддельным модулем control (те же имена, что в winrt-Windows.Media.Control)."""

    def make_control(self, statuses):
        class Status:
            CLOSED, OPENED, CHANGING, STOPPED, PLAYING, PAUSED = range(6)

        class Op:
            def __init__(self, value):
                self.value = value

            def __await__(self):
                if False:
                    yield
                return self.value

        calls = []

        class Sess:
            def __init__(self, i, st):
                self.source_app_user_model_id = f"app{i}"
                self.st = st

            def get_playback_info(self):
                return mock.Mock(playback_status=self.st)

            def try_pause_async(self):
                calls.append(("pause", self.source_app_user_model_id))
                self.st = Status.PAUSED
                return Op(True)

            def try_play_async(self):
                calls.append(("play", self.source_app_user_model_id))
                return Op(True)

            def try_get_media_properties_async(self):     # 2.1.8: MediaPlaybackType.Video (IReference)
                return Op(mock.Mock(playback_type=mock.Mock(value=2)))

        sessions = [Sess(i, getattr(Status, s)) for i, s in enumerate(statuses)]

        class Manager:
            @staticmethod
            def request_async():
                return Op(mock.Mock(get_sessions=lambda: sessions))

        control = mock.Mock(GlobalSystemMediaTransportControlsSessionManager=Manager,
                            GlobalSystemMediaTransportControlsSessionPlaybackStatus=Status)
        return control, calls

    def test_adapter(self):
        control, calls = self.make_control(["PLAYING", "PAUSED", "STOPPED"])
        p = MediaPauser(media_factory=lambda: WinrtMedia(control))
        self.assertEqual(p.pause(), 1)
        self.assertEqual(calls, [("pause", "app0")])
        p.resume(wait=True)
        self.assertEqual(calls, [("pause", "app0"), ("play", "app0")])


class FakePauser:
    def __init__(self, backend, fail=False):
        self.b = backend
        self.fail = fail

    def pause(self):
        self.b.log.append(("media_pause", self.b.clock.t))
        if self.fail:
            raise RuntimeError("сломалось")
        return 1

    def resume(self, wait=False):
        self.b.log.append(("media_resume", self.b.clock.t))

    def forget(self):
        self.b.log.append(("media_forget", self.b.clock.t))


class JobIntegration(unittest.TestCase):
    def make(self, media=None, fail=False, **kw):
        b = ReadyBackend(**kw)
        b.clock = Clock()
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["peer_id"] = 2000000001
        cfg["media_pause"].update(media or {})
        self.vk = FakeVK()
        job = JobRunner(lambda: cfg, lambda: b, vk_factory=lambda c: self.vk, root=tempfile.mkdtemp(),
                        now=b.clock.now, sleep=b.clock.sleep)
        job.media = FakePauser(b, fail)
        self.target = b.clock.now() + timedelta(seconds=5)
        return job, b

    def kinds(self, b):
        return [e[0] if e[0] != "shot" else "shot:" + e[1] for e in b.log
                if e[0] in ("lock", "unlock", "shot", "media_pause", "media_resume", "media_forget")]

    def test_disabled_by_default(self):
        job, b = self.make()
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(self.kinds(b), ["lock", "shot:Oasys", "shot:iVMS", "unlock"])

    def test_pause_at_lock_resume_after_release(self):
        job, b = self.make({"enabled": True})
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(self.kinds(b), ["lock", "media_pause", "shot:Oasys", "shot:iVMS", "unlock", "media_resume"])
        self.assertEqual([e for e in b.log if e[0] == "media_pause"][0][1], 0)     # за 5 с до снимка, вместе с блокировкой
        self.assertEqual(len(self.vk.sent), 1)

    def test_resume_before_recheck(self):
        job, b = self.make({"enabled": True}, hung_checks="always")
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        k = self.kinds(b)
        self.assertEqual(k[:6], ["lock", "media_pause", "shot:Oasys", "shot:iVMS", "unlock", "media_resume"])
        self.assertEqual(k.count("media_pause"), 1)          # пересъёмка — без повторной паузы
        self.assertEqual(k.count("media_resume"), 1)

    def test_resume_off_forgets(self):
        job, b = self.make({"enabled": True, "resume": False})
        job.run_cycle(True, capture_at=self.target)
        k = self.kinds(b)
        self.assertIn("media_forget", k)
        self.assertNotIn("media_resume", k)

    def test_pauser_exception_does_not_break_capture(self):
        job, b = self.make({"enabled": True}, fail=True)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(len(self.vk.sent[0][1]), 2)
        self.assertNotIn("media_resume", self.kinds(b))

    def test_real_pauser_without_winrt(self):
        job, b = self.make({"enabled": True})
        job.media = MediaPauser()             # на Linux winrt нет — тихо пропускается
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(len(self.vk.sent[0][1]), 2)


class Config(unittest.TestCase):
    def test_defaults(self):
        self.assertEqual(DEFAULTS["media_pause"], {"enabled": False, "resume": True})
        self.assertIn("media_pause:", DEFAULT_CONFIG_YAML)

    def test_validate(self):
        cfg = copy.deepcopy(DEFAULTS)
        self.assertEqual(validate(cfg), [])
        cfg["media_pause"]["enabled"] = "да"
        self.assertTrue(any("media_pause.enabled" in e for e in validate(cfg)))
        cfg["media_pause"] = 5
        self.assertTrue(any("media_pause" in e for e in validate(cfg)))

    def test_migrate_adds_section(self):
        cfg = copy.deepcopy(DEFAULTS)
        del cfg["media_pause"]
        migrate(cfg)
        self.assertEqual(cfg["media_pause"], {"enabled": False, "resume": True})
        cfg["media_pause"] = {"enabled": True}
        migrate(cfg)
        self.assertEqual(cfg["media_pause"], {"enabled": True, "resume": True})


class AboutText(unittest.TestCase):
    def test_about_mentions_media_only_when_enabled(self):
        import copy
        from app.about import about_text
        from app.config import DEFAULTS
        cfg = copy.deepcopy(DEFAULTS)
        self.assertNotIn("на паузу видео", about_text(cfg))
        self.assertIn("сохраняются сами", about_text(cfg))
        cfg["media_pause"] = {"enabled": True, "resume": True}
        self.assertIn("включает его обратно", about_text(cfg))
        self.assertIn("музыка играет дальше", about_text(cfg))
        cfg["media_pause"]["resume"] = False
        self.assertIn("обратно не включает", about_text(cfg))


if __name__ == "__main__":
    unittest.main()


class OnlyVideo(unittest.TestCase):
    """2.1.8: на паузу — только видео, музыка играет дальше."""

    def test_classify(self):
        from app.mediapause import classify
        self.assertEqual(classify(2, "Spotify.exe"), "video")         # Windows сказала «видео» — верим
        self.assertEqual(classify(1, "chrome"), "music")
        self.assertEqual(classify(None, "Chrome"), "video")
        self.assertEqual(classify(0, "Microsoft.MicrosoftEdge.Stable_8wekyb3d8bbwe!App"), "video")
        self.assertEqual(classify(None, "308046B0AF4A39CB"), "other")  # Firefox без имени — не трогаем
        self.assertEqual(classify(None, "firefox.exe"), "video")
        for app in ("Spotify.exe", "AIMP.exe", "foobar2000.exe", "Yandex.Music", "winamp.exe",
                    "AppleInc.AppleMusicWin", "Microsoft.ZuneMusic_8wekyb3d8bbwe!Microsoft.ZuneMusic"):
            self.assertEqual(classify(None, app), "music", app)
        self.assertEqual(classify(None, "vlc.exe"), "other")
        self.assertEqual(classify(None, None), "other")

    def test_music_keeps_playing(self):
        v = FakeSession("chrome.exe", "playing", ptype=2)
        m = FakeSession("Spotify.exe", "playing", ptype=1)
        u = FakeSession("Spotify.exe", "playing", ptype=None)      # тип неизвестен — по имени: музыка
        b = FakeSession("msedge.exe", "playing", ptype=OSError("нет свойств"))   # не прочитался — браузер
        o = FakeSession("vlc.exe", "playing", ptype=0)             # неизвестно и не браузер — не трогаем
        p = pauser(FakeMedia([v, m, u, b, o]))
        self.assertEqual(p.pause(), 2)
        self.assertEqual((v.calls, b.calls), (["pause"], ["pause"]))
        self.assertEqual((m.calls, u.calls, o.calls), ([], [], []))
        p.resume(wait=True)
        self.assertEqual(v.calls, ["pause", "play"])
        self.assertEqual(m.calls, [])
