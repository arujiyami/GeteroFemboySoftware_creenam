# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.2: проверка в :05, что скрины ушли."""
import os
import tempfile
import unittest
from datetime import datetime

from app import sentcheck, summary
from app.config import DEFAULTS

T = datetime(2026, 10, 29, 14, 0)


def row(h, m, **kw):
    r = {"dt": datetime(2026, 10, 29, h, m), "ok": True, "sent": True, "planned": True}
    r.update(kw)
    return r


def d(now, rows, **kw):
    kw.setdefault("started_at", datetime(2026, 10, 29, 8, 0))
    return sentcheck.decide(now, 0, rows, **kw)[1]


class Decide(unittest.TestCase):
    def test_too_early(self):
        self.assertIsNone(d(datetime(2026, 10, 29, 14, 4), []))

    def test_ok(self):
        self.assertEqual(d(datetime(2026, 10, 29, 14, 5), [row(14, 0)]), "ok")

    def test_ok_after_retry(self):
        self.assertEqual(d(datetime(2026, 10, 29, 14, 7),
                           [row(14, 0, ok=False, sent=False), row(14, 3)]), "ok")

    def test_not_captured(self):
        v = d(datetime(2026, 10, 29, 14, 5), [row(13, 0)])
        self.assertEqual(v["reason"], sentcheck.NOT_CAPTURED)
        self.assertIn("14:00", v["text"])
        v = d(datetime(2026, 10, 29, 14, 5), [row(14, 0, ok=False, sent=False, shots=0)])
        self.assertEqual(v["reason"], sentcheck.NOT_CAPTURED)

    def test_not_sent(self):
        v = d(datetime(2026, 10, 29, 14, 5), [row(14, 0, ok=False, sent=False, shots=2, err="Нет связи с ВК")])
        self.assertEqual(v["reason"], sentcheck.NOT_SENT)
        self.assertIn("Нет связи", v["detail"])
        v = d(datetime(2026, 10, 29, 14, 5), [row(14, 0, sent=False, queued=True, shots=2)])
        self.assertEqual(v["reason"], sentcheck.NOT_SENT)

    def test_pending_retry_then_decide(self):
        self.assertEqual(d(datetime(2026, 10, 29, 14, 5), [], busy=True), "pending")
        self.assertEqual(d(datetime(2026, 10, 29, 14, 9), [row(14, 3)], busy=False), "ok")
        self.assertIsInstance(d(datetime(2026, 10, 29, 14, 21), [], busy=True), dict)

    def test_skips(self):
        now = datetime(2026, 10, 29, 14, 5)
        self.assertEqual(d(now, [], skipped=[T]), "skip")
        self.assertEqual(d(now, [], running=False), "skip")
        self.assertEqual(d(now, [], started_at=datetime(2026, 10, 29, 14, 2)), "skip")

    def test_checked_once(self):
        self.assertIsNone(sentcheck.decide(datetime(2026, 10, 29, 14, 30), 0, [], checked=T)[1])

    def test_manual_does_not_hide_missing_planned(self):
        v = d(datetime(2026, 10, 29, 14, 30, ), [row(14, 10, planned=False, sent=False, ok=False, shots=2)])
        self.assertEqual(v["reason"], sentcheck.NOT_SENT)

    def test_minute_offset(self):
        self.assertEqual(sentcheck.target_for(datetime(2026, 10, 29, 14, 3), 30), datetime(2026, 10, 29, 13, 30))


class Config(unittest.TestCase):
    def test_default_off(self):
        self.assertFalse(DEFAULTS["sent_check"]["enabled"])
        self.assertFalse(sentcheck.settings(DEFAULTS)["enabled"])
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        with open(os.path.join(here, "config.yaml"), encoding="utf-8") as f:
            self.assertIn("sent_check:\n", f.read())

    def test_summary_shots(self):
        with tempfile.TemporaryDirectory() as t:
            p = os.path.join(t, "c.jsonl")
            summary.record(p, T, False, False, shots=0, error="x")
            r = summary.read(p)[-1]
            self.assertEqual(r["shots"], 0)
            self.assertEqual(r["dt"], T)


class Banner(unittest.TestCase):
    def test_source(self):
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        src = open(os.path.join(here, "app", "ui", "sentalert.py"), encoding="utf-8").read()
        for s in ("WindowStaysOnTopHint", "WA_ShowWithoutActivating", "exclude_from_capture",
                  "Отправить последние скрины", "Снять и отправить сейчас", "Закрыть", "WindowDoesNotAcceptFocus"):
            self.assertIn(s, src)
        self.assertNotIn("showMessage", src)

    def test_qt(self):
        try:
            from PySide6.QtWidgets import QApplication
        except Exception:  # noqa: BLE001
            self.skipTest("нет Qt")
        app = QApplication.instance() or QApplication([])
        from app.ui.sentalert import SentAlert
        calls = []
        a = SentAlert(on_resend=lambda: calls.append("r"), on_send_now=lambda: calls.append("n"),
                      on_close=lambda u: calls.append(("c", u)))
        a.show_alert("Скрины за 14:00 не отправились", "Нет связи", sentcheck.NOT_SENT)
        self.assertTrue(a.isVisible() and a.pulse.isActive())
        a.b_resend.click()
        self.assertEqual(calls, ["r"])
        a.dismiss(by_user=False)
        self.assertFalse(a.isVisible())
        self.assertEqual(calls[-1], ("c", False))
        app.processEvents()


if __name__ == "__main__":
    unittest.main()
