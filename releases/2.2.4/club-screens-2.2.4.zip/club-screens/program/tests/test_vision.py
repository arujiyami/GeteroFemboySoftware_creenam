# Original-Author: Владислав С.
# Created: 2026-10-28
import unittest

import numpy as np

try:
    import cv2  # noqa: F401
    from app.vision import find_template
except ImportError:  # pragma: no cover
    cv2 = None


@unittest.skipIf(cv2 is None, "нет OpenCV")
class VisionTest(unittest.TestCase):
    def test_find_exact_and_scaled(self):
        rng = np.random.default_rng(1)
        hay = (rng.random((400, 600, 3)) * 255).astype(np.uint8)
        tpl = hay[100:140, 300:360].copy()
        x, y, score = find_template(hay, tpl, 0.9)
        self.assertEqual((x, y), (330, 120))
        self.assertGreater(score, 0.99)
        self.assertIsNone(find_template(hay, np.zeros((30, 30, 3), np.uint8) + 7, 0.9))


if __name__ == "__main__":
    unittest.main()
