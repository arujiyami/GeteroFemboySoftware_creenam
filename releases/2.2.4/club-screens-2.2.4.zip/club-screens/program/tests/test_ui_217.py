# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.7: подгонка масштаба страницы входа ВК, размер окна (≈90 % экрана, запоминается в window.ini),
и новые элементы настроек (переключатель, строка-карточка с названием в одну строку)."""
import os
import shutil
import tempfile
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from app.ui.zoomfit import LONG_PAGE, ZOOM_MAX, ZOOM_MIN, fit_zoom  # noqa: E402

try:
    from PySide6.QtWidgets import QApplication, QMainWindow
    HAVE_QT = True
except Exception:  # noqa: BLE001
    HAVE_QT = False


class FitZoom(unittest.TestCase):
    def test_fits_into_view(self):
        z = fit_zoom(1.0, 900, 500, 420, 700)          # 700+16 по высоте в 500 → ≈0.698 → ступень 0.67 (2.1.8)
        self.assertEqual(z, 0.67)
        self.assertTrue(ZOOM_MIN <= z <= ZOOM_MAX)

    def test_never_bigger_than_100(self):
        self.assertEqual(fit_zoom(1.0, 1600, 1000, 420, 600), ZOOM_MAX)
        self.assertEqual(fit_zoom(0.7, 1600, 1000, 420, 400), ZOOM_MAX)

    def test_floor(self):
        self.assertEqual(fit_zoom(1.0, 300, 200, 420, 560), ZOOM_MIN)

    def test_measured_at_other_zoom(self):
        # 2.1.8: место — в пикселях окна, содержимое — в CSS px: от текущего масштаба итог не зависит
        a = fit_zoom(1.0, 900, 500, 420, 700)
        b = fit_zoom(0.8, 900, 500, 420, 700)
        self.assertEqual(a, b)

    def test_long_page_not_shrunk(self):
        # лента/переписка — в LONG_PAGE раз выше окна: обычный масштаб
        self.assertEqual(fit_zoom(1.0, 900, 500, 600, 500 * LONG_PAGE + 100), ZOOM_MAX)

    def test_garbage(self):
        self.assertEqual(fit_zoom(0.8, None, 500, 1, 1), 0.8)
        self.assertTrue(ZOOM_MIN <= fit_zoom(5, "x", 1, 1, 1) <= ZOOM_MAX)


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class Widgets(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_toggle_is_checkbox(self):
        from PySide6.QtWidgets import QCheckBox
        from app.ui.common import ToggleSwitch
        t = ToggleSwitch("Вкл")
        got = []
        t.toggled.connect(got.append)
        self.assertIsInstance(t, QCheckBox)
        self.assertEqual(t.text(), "Вкл")
        t.setChecked(True)
        t.toggle()
        self.assertEqual(got, [True, False])
        self.assertFalse(t.isChecked())
        self.assertGreaterEqual(t.sizeHint().width(), 36)

    def test_row_title_one_line_then_stacks(self):
        from PySide6.QtWidgets import QSlider
        from PySide6.QtCore import Qt
        from PySide6.QtWidgets import QWidget
        from app.ui.settings import Row
        holder = QWidget()                     # дочерний виджет: размер задаём сами, без ограничений окна
        holder.resize(800, 200)
        r = Row("Заранее открывать беседу ВК", "Пояснение", "Справка")
        s = QSlider(Qt.Orientation.Horizontal)
        s.setFixedWidth(240)
        r.add_control(s)
        r.setParent(holder)
        r.resize(760, 80)
        holder.show()
        self.app.processEvents()
        self.assertFalse(r.stacked)
        self.assertGreaterEqual(r.title.width(), r._title_w() - 1)     # название не переносится
        r.resize(380, 120)
        self.app.processEvents()
        self.assertTrue(r.stacked)                                    # узко — элемент под названием
        r.resize(760, 80)
        self.app.processEvents()
        self.assertFalse(r.stacked)
        holder.close()


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class WindowSize(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        try:
            from app.ui.main_window import MainWindow
        except Exception as e:  # noqa: BLE001
            raise unittest.SkipTest(f"нет QtWebEngine: {e}")

        class W(QMainWindow):
            SCREEN_SHARE = MainWindow.SCREEN_SHARE
            MAX_DEFAULT_W = MainWindow.MAX_DEFAULT_W
            _screen_rect = MainWindow._screen_rect
            _state_path = MainWindow._state_path
            _fit_to_screen = MainWindow._fit_to_screen
            _restore_window_state = MainWindow._restore_window_state
            save_window_state = MainWindow.save_window_state
            ensure_big = MainWindow.ensure_big

            def __init__(self, path):
                super().__init__()
                self.cfg_path = path
        cls.W = W

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "config.yaml")

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_ninety_percent_and_min(self):
        w = self.W(self.path)
        w._fit_to_screen()
        scr = w._screen_rect()
        self.assertEqual(w.height(), int(scr.height() * 0.9))
        self.assertEqual(w.width(), min(int(scr.width() * 0.9), w.MAX_DEFAULT_W))
        self.assertLessEqual(w.minimumWidth(), 820)
        self.assertLessEqual(w.minimumHeight(), 560)
        self.assertLess(w.minimumHeight(), w.height())                # окно можно менять

    def test_ensure_big_and_state_file(self):
        w = self.W(self.path)
        w._fit_to_screen()
        w.resize(w.minimumWidth(), w.minimumHeight())
        self.assertTrue(w.ensure_big())
        scr = w._screen_rect()
        self.assertGreaterEqual(w.height(), int(scr.height() * 0.9))
        self.assertFalse(w.ensure_big())                              # уже большое — не трогаем
        w.resize(w.minimumWidth() + 10, w.minimumHeight() + 10)
        w.save_window_state()
        self.assertTrue(os.path.exists(os.path.join(self.dir, "window.ini")))
        w2 = self.W(self.path)
        w2._fit_to_screen()                                           # внутри — восстановление из window.ini
        self.assertEqual((w2.width(), w2.height()), (w.width(), w.height()))


if __name__ == "__main__":
    unittest.main()
