# Original-Author: Владислав С.
# Created: 2026-10-28
import copy
import unittest

from app.config import DEFAULTS, is_configured, wizard_templates, validate
from app.friendly import humanize
from app.job import format_caption
from app.steps import StepError
from app.vk import VKError


class FriendlyTest(unittest.TestCase):
    def test_window_missing(self):
        e = StepError("Oasys: окно не найдено (проверьте, что программа запущена, ...)")
        self.assertTrue(humanize(e, "Oasys").startswith("Oasys не найден — откройте программу Oasys"))

    def test_vk_codes(self):
        self.assertIn("Ключ доступа сообщества", humanize(VKError(5, "User authorization failed")))
        self.assertIn("добавьте сообщество в беседу", humanize(VKError(917, "no access")))
        self.assertIn("попробует", humanize(VKError(6, "Too many")))
        self.assertIn("Ключ доступа сообщества", humanize(VKError(0, "не указан токен сообщества")))

    def test_network(self):
        self.assertIn("интернет", humanize(Exception("HTTPSConnectionPool: Max retries exceeded")))

    def test_blank(self):
        self.assertIn("заблокирован", humanize(StepError("iVMS-4200: снимок получился чёрным"), "iVMS-4200"))

    def test_no_traceback(self):
        t = humanize(ValueError("что-то странное"), "Oasys")
        self.assertNotIn("Traceback", t)
        self.assertIn("Журнал", t)


class ConfigHelpersTest(unittest.TestCase):
    def test_wizard_templates(self):
        oasys, ivms = DEFAULTS["sources"]
        self.assertEqual([t[0] for t in wizard_templates(oasys)], ["templates/oasys_karta_kluba_button.png"])
        w = wizard_templates(ivms)
        self.assertEqual(w[0][0], "templates/ivms_fullscreen_button.png")
        self.assertTrue(w[0][2])
        self.assertFalse(w[1][2])

    def test_is_configured(self):
        cfg = copy.deepcopy(DEFAULTS)
        self.assertFalse(is_configured(cfg))
        cfg["app"]["setup_done"] = True
        self.assertFalse(is_configured(cfg))  # нет входа в ВК
        cfg["vk"]["login_ok"] = True
        self.assertFalse(is_configured(cfg))  # беседа не выбрана
        cfg["vk"]["peer_id"] = 2000000001
        self.assertTrue(is_configured(cfg))
        self.assertEqual(validate(cfg), [])
        cfg["vk"]["sender"] = "group_api"
        self.assertFalse(is_configured(cfg))
        self.assertTrue(validate(cfg))  # нет ключа сообщества
        cfg["vk"]["group_token"] = "g"
        self.assertTrue(is_configured(cfg))
        self.assertEqual(validate(cfg), [])

    def test_migrate_user_token_wiped(self):
        from app.config import migrate
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"].update(token="vk1.a.OLD", token_type="user", account_name="Иван")
        cfg["app"]["setup_done"] = True
        cfg["schedule"].update(attempts=3, retry_interval_sec=120)
        notes = migrate(cfg)
        self.assertNotIn("token", cfg["vk"])
        self.assertNotIn("token_type", cfg["vk"])
        self.assertEqual(cfg["vk"]["sender"], "browser")
        self.assertFalse(cfg["app"]["setup_done"])
        self.assertEqual(cfg["vk"]["group_token"], "")
        self.assertTrue(any("токен пользователя" in n for n in notes))
        self.assertEqual((cfg["schedule"]["attempts"], cfg["schedule"]["retry_interval_sec"]), (2, 180))
        self.assertNotIn("vk1.a.OLD", repr(cfg))
        self.assertEqual(migrate(cfg), [])  # повторно — ничего

    def test_migrate_group_token_kept(self):
        from app.config import migrate
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"].update(token="G", token_type="group")
        migrate(cfg)
        self.assertEqual((cfg["vk"]["sender"], cfg["vk"]["group_token"]), ("group_api", "G"))

    def test_browser_errors_friendly(self):
        from app.vk_browser import NotLoggedIn, CaptchaShown
        self.assertIn("«Настроить заново» → «Вход ВК»", humanize(NotLoggedIn()))
        self.assertIn("vk_captcha_1.png", humanize(CaptchaShown(shot="/x/logs/vk_captcha_1.png")))

    def test_caption_club(self):
        from datetime import datetime
        self.assertEqual(format_caption("{club} {time}", datetime(2026, 1, 1, 4, 0), "Клуб"), "Клуб 04:00")


if __name__ == "__main__":
    unittest.main()
