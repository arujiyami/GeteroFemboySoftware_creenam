# Original-Author: Владислав С.
# Created: 2026-10-29
import os
import tempfile
import unittest

from app import backup


def make(root):
    cfg = os.path.join(root, "config.yaml")
    with open(cfg, "w", encoding="utf-8") as f:
        f.write("app:\n  club_name: Мой клуб\n")
    prof = os.path.join(root, "browser_profile")
    os.makedirs(os.path.join(prof, "Default", "Cache"))
    os.makedirs(os.path.join(prof, "Default", "Local Storage"))
    with open(os.path.join(prof, "Default", "Cookies"), "wb") as f:
        f.write(b"cookie-db")
    with open(os.path.join(prof, "Default", "Local Storage", "x.ldb"), "wb") as f:
        f.write(b"ls")
    with open(os.path.join(prof, "Default", "Cache", "big"), "wb") as f:
        f.write(b"0" * 1000)
    return cfg, prof


class BackupTest(unittest.TestCase):
    def test_roundtrip(self):
        a, b = tempfile.mkdtemp(), tempfile.mkdtemp()
        cfg, prof = make(a)
        out = os.path.join(a, "k.csbackup")
        r = backup.export_backup(out, "секрет-123", cfg, prof, "2.2.0", iterations=1000)
        self.assertEqual(r["files"], 2)       # кэш не попал
        blob = open(out, "rb").read()
        self.assertNotIn(b"cookie-db", blob)
        self.assertNotIn("секрет".encode(), blob)
        cfg2, prof2 = os.path.join(b, "config.yaml"), os.path.join(b, "browser_profile")
        with open(cfg2, "w") as f:
            f.write("old: 1\n")
        res = backup.import_backup(out, "секрет-123", cfg2, prof2)
        self.assertEqual(res, {"config": True, "profile": True})
        self.assertIn("Мой клуб", open(cfg2, encoding="utf-8").read())
        self.assertTrue(os.path.exists(cfg2 + ".bak"))
        self.assertFalse(os.path.exists(prof2))
        self.assertTrue(backup.apply_pending_import(prof2))
        self.assertEqual(open(os.path.join(prof2, "Default", "Cookies"), "rb").read(), b"cookie-db")
        self.assertFalse(backup.apply_pending_import(prof2))

    def test_wrong_password_and_tamper(self):
        a = tempfile.mkdtemp()
        cfg, prof = make(a)
        out = os.path.join(a, "k.csbackup")
        backup.export_backup(out, "pw", cfg, prof, iterations=1000)
        with self.assertRaises(backup.BackupError):
            backup.decrypt_backup(out, "wrong")
        blob = bytearray(open(out, "rb").read())
        blob[-5] ^= 1
        open(out, "wb").write(bytes(blob))
        with self.assertRaises(backup.BackupError):
            backup.decrypt_backup(out, "pw")

    def test_not_backup(self):
        p = os.path.join(tempfile.mkdtemp(), "x.csbackup")
        open(p, "wb").write(b"hello")
        with self.assertRaises(backup.BackupError):
            backup.decrypt_backup(p, "pw")

    def test_zip_slip(self):
        import io
        import zipfile
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("../evil.txt", "x")
        d = tempfile.mkdtemp()
        with zipfile.ZipFile(io.BytesIO(buf.getvalue())) as z, self.assertRaises(backup.BackupError):
            backup._safe_extract(z, os.path.join(d, "t"))
        self.assertFalse(os.path.exists(os.path.join(d, "evil.txt")))

    def test_default_iterations_high(self):
        self.assertGreaterEqual(backup.ITERATIONS, 600_000)
