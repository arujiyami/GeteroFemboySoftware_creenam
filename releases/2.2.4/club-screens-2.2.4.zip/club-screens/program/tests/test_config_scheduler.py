# Original-Author: Владислав С.
# Created: 2026-10-28
import os
import tempfile
import unittest
import threading
import time
from datetime import datetime, timedelta

from app.config import DEFAULTS, deep_merge, load_config, normalize_step, save_config, template_list, validate
from app.scheduler import HourlyScheduler, due_action, next_run, prewarm_at, prewarm_due, run_with_retries


class ConfigTest(unittest.TestCase):
    def test_defaults_valid(self):
        self.assertEqual(validate(DEFAULTS), [])
        self.assertEqual([s["name"] for s in DEFAULTS["sources"]], ["Oasys", "iVMS-4200"])
        self.assertEqual(DEFAULTS["vk"]["peer_id"], 0)  # беседу выбирает пользователь в мастере
        self.assertEqual(DEFAULTS["vk"]["peer_title"], "")

    def test_load_creates_and_roundtrip(self):
        d = tempfile.mkdtemp()
        path = os.path.join(d, "config.yaml")
        cfg = load_config(path)
        self.assertTrue(os.path.exists(path))
        cfg["vk"]["caption"] = "Привет {time}"
        save_config(cfg, path)
        again = load_config(path)
        self.assertEqual(again["vk"]["caption"], "Привет {time}")
        with open(path, encoding="utf-8") as f:
            self.assertIn("Привет", f.read())

    def test_partial_config_merged(self):
        d = tempfile.mkdtemp()
        path = os.path.join(d, "config.yaml")
        with open(path, "w", encoding="utf-8") as f:
            f.write("vk:\n  peer_id: 2000000005\n")
        cfg = load_config(path)
        self.assertEqual(cfg["vk"]["peer_id"], 2000000005)
        self.assertEqual(cfg["vk"]["api_version"], "5.199")
        self.assertEqual(len(cfg["sources"]), 2)

    def test_validation_errors(self):
        cfg = deep_merge(DEFAULTS, {"schedule": {"minute": 75},
                                    "sources": [{"name": "X", "window": {}, "steps": [{"type": "fly"}]}]})
        errs = "\n".join(validate(cfg))
        self.assertIn("minute", errs)
        self.assertIn("fly", errs)
        self.assertIn("screenshot", errs)
        self.assertIn("title_regex", errs)

    def test_templates_listed(self):
        names = [t[1] for t in template_list(DEFAULTS, root=tempfile.mkdtemp())]
        self.assertIn("templates/oasys_karta_kluba_button.png", names)
        self.assertIn("templates/ivms_fullscreen_button.png", names)

    def test_normalize_step(self):
        self.assertEqual(normalize_step("maximize"), {"type": "maximize"})
        self.assertEqual(normalize_step({"wait": {"seconds": 2}}), {"type": "wait", "seconds": 2})


class SchedulerTest(unittest.TestCase):
    def test_next_run_top_of_hour(self):
        self.assertEqual(next_run(datetime(2026, 10, 28, 2, 40, 5)), datetime(2026, 10, 28, 3, 0))
        self.assertEqual(next_run(datetime(2026, 10, 28, 2, 0, 0)), datetime(2026, 10, 28, 3, 0))
        self.assertEqual(next_run(datetime(2026, 10, 28, 23, 59, 59)), datetime(2026, 10, 29, 0, 0))
        self.assertEqual(next_run(datetime(2026, 12, 31, 23, 30)), datetime(2027, 1, 1, 0, 0))
        self.assertEqual(next_run(datetime(2026, 10, 28, 2, 10), minute=15), datetime(2026, 10, 28, 2, 15))

    def test_due_action(self):
        t = datetime(2026, 10, 28, 3, 0)
        self.assertEqual(due_action(datetime(2026, 10, 28, 2, 59, 59), t, 600), "wait")
        self.assertEqual(due_action(datetime(2026, 10, 28, 3, 0, 1), t, 600), "run")
        self.assertEqual(due_action(datetime(2026, 10, 28, 3, 30), t, 600), "skip")

    def test_retries(self):
        calls, waits = [], []

        def fn():
            calls.append(1)
            if len(calls) == 1:
                raise RuntimeError("x")
            return len(calls) == 3

        self.assertTrue(run_with_retries(fn, 3, 100, wait=lambda s: waits.append(s) or False))
        self.assertEqual(len(calls), 3)
        self.assertEqual(waits, [100, 100])
        self.assertFalse(run_with_retries(lambda: False, 2, 1, wait=lambda s: False))


class PrewarmTest(unittest.TestCase):
    def test_default_five_minutes_before(self):
        t = datetime(2026, 10, 28, 6, 0)
        self.assertEqual(prewarm_at(t, 5), datetime(2026, 10, 28, 5, 55))
        self.assertEqual(DEFAULTS["schedule"]["prewarm_minutes"], 5)

    def test_midnight_wrap(self):
        self.assertEqual(prewarm_at(datetime(2026, 10, 29, 0, 0), 5), datetime(2026, 10, 28, 23, 55))
        self.assertEqual(prewarm_at(datetime(2027, 1, 1, 0, 0), 15), datetime(2026, 12, 31, 23, 45))
        # запуск в 00:10 и подготовка за 15 минут — тоже накануне
        self.assertEqual(prewarm_at(datetime(2026, 10, 29, 0, 10), 15), datetime(2026, 10, 28, 23, 55))

    def test_custom_minute_and_minutes(self):
        target = next_run(datetime(2026, 10, 28, 2, 10), minute=30)
        self.assertEqual(prewarm_at(target, 3), datetime(2026, 10, 28, 2, 27))
        self.assertEqual(prewarm_at(datetime(2026, 10, 28, 7, 0), 1), datetime(2026, 10, 28, 6, 59))

    def test_off_and_limits(self):
        t = datetime(2026, 10, 28, 6, 0)
        self.assertIsNone(prewarm_at(t, 0))
        self.assertIsNone(prewarm_at(t, None))
        self.assertIsNone(prewarm_at(t, "x"))
        self.assertEqual(prewarm_at(t, 60), datetime(2026, 10, 28, 5, 45))   # не больше 15 минут
        self.assertIsNone(prewarm_at(t, -3))

    def test_due(self):
        t = datetime(2026, 10, 28, 6, 0)
        at = prewarm_at(t, 5)
        self.assertFalse(prewarm_due(datetime(2026, 10, 28, 5, 54, 59), at, t))
        self.assertTrue(prewarm_due(datetime(2026, 10, 28, 5, 55, 0), at, t))
        self.assertTrue(prewarm_due(datetime(2026, 10, 28, 5, 55, 50), at, t))
        # программу запустили в 5:58 — заранее не открываем, откроется в момент отправки
        self.assertFalse(prewarm_due(datetime(2026, 10, 28, 5, 58), at, t))
        self.assertFalse(prewarm_due(datetime(2026, 10, 28, 6, 0), at, t))
        self.assertFalse(prewarm_due(datetime(2026, 10, 28, 5, 56), None, t))
        mid = datetime(2026, 10, 29, 0, 0)
        self.assertTrue(prewarm_due(datetime(2026, 10, 28, 23, 55, 10), prewarm_at(mid, 5), mid))

    def test_validation(self):
        cfg = deep_merge(DEFAULTS, {"schedule": {"prewarm_minutes": 20}})
        self.assertTrue(any("prewarm_minutes" in e for e in validate(cfg)))
        cfg = deep_merge(DEFAULTS, {"schedule": {"prewarm_minutes": 0}})
        self.assertFalse(any("prewarm_minutes" in e for e in validate(cfg)))

    def _run_scheduler(self, start, minutes, seconds_fake=420, skip=False):
        """Виртуальное время идёт по 30 с на каждый шаг; возвращает, когда что вызывалось."""
        clock = {"t": start}
        events = []
        done = threading.Event()

        def now():
            return clock["t"]
        sch = HourlyScheduler(lambda: events.append(("run", clock["t"])), lambda: {"minute": 0,
                              "prewarm_minutes": minutes, "max_delay_sec": 600}, now=now,
                              prewarm=lambda target: events.append(("prewarm", clock["t"], target)))
        real_stop = sch._stop

        class Tick:
            def is_set(self):
                return real_stop.is_set()

            def clear(self):
                real_stop.clear()

            def set(self):
                real_stop.set()

            def wait(self, sec):
                if skip and clock["t"] == start:
                    sch.skip_next()
                clock["t"] += timedelta(seconds=30)
                if clock["t"] >= start + timedelta(seconds=seconds_fake):
                    real_stop.set()
                    done.set()
                return real_stop.is_set()
        sch._stop = Tick()
        sch.start()
        done.wait(5)
        sch._thread.join(5)
        return events

    def test_scheduler_prewarms_once_then_runs(self):
        ev = self._run_scheduler(datetime(2026, 10, 28, 23, 54, 10), 5)
        kinds = [e[0] for e in ev]
        self.assertEqual(kinds[:2], ["prewarm", "run"])
        self.assertEqual(kinds.count("prewarm"), 1)
        self.assertEqual(ev[0][2], datetime(2026, 10, 29, 0, 0))
        self.assertGreaterEqual(ev[0][1], datetime(2026, 10, 28, 23, 55))
        self.assertGreaterEqual(ev[1][1], datetime(2026, 10, 29, 0, 0))

    def test_scheduler_no_prewarm_when_started_late_or_off(self):
        self.assertEqual([e[0] for e in self._run_scheduler(datetime(2026, 10, 28, 5, 58), 5)], ["run"])
        self.assertEqual([e[0] for e in self._run_scheduler(datetime(2026, 10, 28, 5, 54), 0)], ["run"])

    def test_skip_next(self):
        ev = self._run_scheduler(datetime(2026, 10, 28, 23, 54, 10), 5, seconds_fake=4000, skip=True)
        runs = [e[1] for e in ev if e[0] == "run"]
        self.assertEqual(len(runs), 1)                       # 00:00 пропущен, 01:00 снят
        self.assertGreaterEqual(runs[0], datetime(2026, 10, 29, 1, 0))
        self.assertLess(runs[0], datetime(2026, 10, 29, 1, 1))


if __name__ == "__main__":
    unittest.main()
