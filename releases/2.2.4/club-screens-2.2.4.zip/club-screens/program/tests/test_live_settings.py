# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.5, регрессия: «поставил 15 секунд вместо 60, а плашка всё равно показалась за 60».

Причина: настройки съёмки применялись только кнопкой «Сохранить», а при каждом переходе в раздел
«Настройки» окно перечитывало старые значения (несохранённое молча терялось); правка config.yaml
в Блокноте не действовала до перезапуска. Теперь ползунки действуют сразу, файл перечитывается сам."""
import copy
import os
import tempfile
import time
import types
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtWidgets import QApplication
    HAVE_QT = True
except Exception:  # noqa: BLE001
    HAVE_QT = False

from app.config import DEFAULTS, save_config
from app.scheduler import countdown_settings


class StubMain:
    def __init__(self, cfg, path):
        self.cfg = cfg
        self.cfg_path = path
        self.saves = 0

    def save_config(self, quiet=False):
        self.saves += 1
        save_config(self.cfg, self.cfg_path)


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class LiveSettings(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        from app.ui.settings import SettingsPage
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "config.yaml")
        self.cfg = copy.deepcopy(DEFAULTS)
        self.main = StubMain(self.cfg, self.path)
        self.page = SettingsPage(self.main)
        self.page.load()

    def pump(self, sec):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            self.app.processEvents()
            time.sleep(0.01)

    def test_slider_widgets_and_ranges(self):
        from PySide6.QtWidgets import QSlider
        s = self.page.countdown_seconds
        self.assertIsInstance(s, QSlider)
        self.assertEqual((s.minimum(), s.maximum(), s.singleStep(), s.value()), (0, 60, 1, 60))
        self.assertEqual((self.page.lock_early.minimum(), self.page.lock_early.maximum(),
                          self.page.lock_early.value()), (0, 15, 5))
        self.assertEqual((self.page.oasys_wait.minimum(), self.page.oasys_wait.maximum(),
                          self.page.oasys_wait.value()), (3, 30, 10))
        self.assertEqual(self.page.lock_watchdog.maximum(), 30)
        self.assertFalse(hasattr(self.page, "countdown_enabled"))

    def test_live_label(self):
        s = self.page.countdown_seconds
        s.setValue(15)
        self.assertIn("15", s.value_label.text())
        s.setValue(0)
        self.assertIn("не показывать", s.value_label.text())

    def test_15_applies_at_once_without_save(self):
        self.page.countdown_seconds.setValue(15)
        self.assertEqual(countdown_settings(self.cfg)[0], 15)      # планировщик видит сразу
        self.page.load()                                           # переход в раздел «Настройки» снова
        self.assertEqual(self.page.countdown_seconds.value(), 15)  # не откатилось к 60
        self.assertEqual(countdown_settings(self.cfg)[0], 15)

    def test_debounced_file_write(self):
        from app.config import load_config
        self.page.countdown_seconds.setValue(20)
        self.page.countdown_seconds.setValue(15)
        self.page.lock_early.setValue(7)
        self.page.oasys_wait.setValue(12)
        self.assertEqual(self.main.saves, 0)
        self.pump(0.9)
        self.assertEqual(self.main.saves, 1)                       # одна запись после паузы
        saved = load_config(self.path)
        self.assertEqual(saved["countdown"]["seconds"], 15)
        self.assertNotIn("enabled", saved["countdown"])
        self.assertEqual(saved["input_lock"]["early_sec"], 7)
        self.assertEqual(saved["oasys_check"]["timeout_sec"], 12)

    def test_flush_on_quit(self):
        self.page.countdown_seconds.setValue(33)
        self.page.flush_live()
        self.assertEqual(self.main.saves, 1)
        self.page.flush_live()
        self.assertEqual(self.main.saves, 1)

    def test_zero_disables(self):
        self.page.countdown_seconds.setValue(0)
        self.assertEqual(countdown_settings(self.cfg)[0], 0)

    def test_load_does_not_trigger_save(self):
        self.page.load()
        self.pump(0.6)
        self.assertEqual(self.main.saves, 0)


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class ExternalEdit(unittest.TestCase):
    def test_notepad_edit_reloaded(self):
        from app.ui.main_window import MainWindow
        d = tempfile.mkdtemp()
        path = os.path.join(d, "config.yaml")
        cfg = copy.deepcopy(DEFAULTS)
        save_config(cfg, path)
        calls = []
        me = types.SimpleNamespace(cfg=cfg, cfg_path=path, _cfg_mtime=None,
                                   page_settings=types.SimpleNamespace(load=lambda: calls.append("load")),
                                   refresh=lambda: calls.append("refresh"))
        me._file_mtime = lambda: MainWindow._file_mtime(me)
        me._cfg_mtime = me._file_mtime()
        self.assertFalse(MainWindow.check_config_file(me))         # не менялся — ничего
        with open(path, encoding="utf-8") as f:
            text = f.read()
        self.assertIn("seconds: 60", text)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text.replace("seconds: 60", "seconds: 15", 1))
        os.utime(path, (time.time() + 5, time.time() + 5))
        self.assertTrue(MainWindow.check_config_file(me))
        self.assertEqual(countdown_settings(cfg)[0], 15)
        self.assertEqual(calls, ["load", "refresh"])
        # испорченный файл — прежние настройки остаются
        with open(path, "w", encoding="utf-8") as f:
            f.write("countdown: [\n")
        os.utime(path, (time.time() + 10, time.time() + 10))
        self.assertFalse(MainWindow.check_config_file(me))
        self.assertEqual(countdown_settings(cfg)[0], 15)


if __name__ == "__main__":
    unittest.main()
