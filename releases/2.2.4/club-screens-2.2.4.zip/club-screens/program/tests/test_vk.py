# Original-Author: Владислав С.
# Created: 2026-10-28
import os
import tempfile
import unittest

from app.vk import VKClient, VKError


class Resp:
    def __init__(self, data):
        self.data = data

    def json(self):
        return self.data

    def raise_for_status(self):
        pass


class FakeSession:
    """Имитирует VK API и сервер загрузки."""

    def __init__(self, fail_first=None):
        self.calls = []
        self.fail_first = dict(fail_first or {})
        self.n = 0

    def post(self, url, data=None, files=None, timeout=None):
        self.calls.append((url, data, files))
        if url.startswith("https://upload.example"):
            assert "photo" in files
            return Resp({"server": 77, "photo": '[{"p":1}]', "hash": "h"})
        method = url.rsplit("/", 1)[1]
        if self.fail_first.get(method):
            self.fail_first[method] -= 1
            return Resp({"error": {"error_code": 6, "error_msg": "Too many requests"}})
        if method == "photos.getMessagesUploadServer":
            return Resp({"response": {"upload_url": "https://upload.example/u", "album_id": 1}})
        if method == "photos.saveMessagesPhoto":
            self.n += 1
            return Resp({"response": [{"id": 100 + self.n, "owner_id": 5, "access_key": "k%d" % self.n}]})
        if method == "messages.send":
            return Resp({"response": 999})
        if method == "messages.getConversations":
            return Resp({"response": {"count": 3, "items": [
                {"conversation": {"peer": {"id": 2000000001, "type": "chat", "local_id": 22},
                                  "chat_settings": {"title": "Камеры | Мой клуб"}}},
                {"conversation": {"peer": {"id": 1, "type": "user", "local_id": 1}}},
                {"conversation": {"peer": {"id": -9, "type": "group", "local_id": 9}}}],
                "profiles": [{"id": 1, "first_name": "Павел", "last_name": "Дуров"}],
                "groups": [{"id": 9, "name": "Клуб"}]}})
        if method == "groups.getById":
            return Resp({"response": {"groups": [{"id": 9, "name": "Клуб Иван"}]}})
        return Resp({"error": {"error_code": 5, "error_msg": "User authorization failed"}})


class VKTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.files = []
        for name in ("a.png", "b.png"):
            p = os.path.join(self.tmp, name)
            with open(p, "wb") as f:
                f.write(b"\x89PNG fake")
            self.files.append(p)

    def test_send_two_photos_in_one_message(self):
        s = FakeSession()
        VKClient("tok", session=s, sleep=lambda _: None).send_photos(2000000001, self.files, "")
        methods = [c[0].rsplit("/", 1)[1] for c in s.calls]
        self.assertEqual(methods, ["photos.getMessagesUploadServer", "u", "photos.saveMessagesPhoto",
                                   "photos.getMessagesUploadServer", "u", "photos.saveMessagesPhoto",
                                   "messages.send"])
        send = s.calls[-1][1]
        self.assertEqual(send["attachment"], "photo5_101_k1,photo5_102_k2")  # порядок сохранён
        self.assertEqual(send["peer_id"], 2000000001)
        self.assertIn("random_id", send)
        self.assertNotIn("message", send)
        self.assertEqual(send["access_token"], "tok")
        self.assertEqual(s.calls[0][1]["peer_id"], 2000000001)
        self.assertEqual(s.calls[2][1]["server"], 77)

    def test_caption(self):
        s = FakeSession()
        VKClient("tok", session=s).send_photos(1, self.files[:1], "Отчёт")
        self.assertEqual(s.calls[-1][1]["message"], "Отчёт")

    def test_rate_limit_retry(self):
        s = FakeSession(fail_first={"messages.send": 1})
        VKClient("tok", session=s, sleep=lambda _: None).send_photos(1, self.files[:1])
        self.assertEqual(sum(1 for c in s.calls if c[0].endswith("messages.send")), 2)

    def test_error_raised(self):
        with self.assertRaises(VKError) as cm:
            VKClient("tok", session=FakeSession()).call("unknown.method")
        self.assertEqual(cm.exception.code, 5)

    def test_no_token(self):
        with self.assertRaises(VKError):
            VKClient("")

    def test_conversations(self):
        convs = VKClient("tok", session=FakeSession()).get_conversations()
        self.assertEqual(convs[0], {"peer_id": 2000000001, "title": "Камеры | Мой клуб", "type": "chat"})
        self.assertEqual(convs[1]["title"], "Павел Дуров")
        self.assertEqual(convs[2]["title"], "Клуб")

    def test_whoami(self):
        self.assertEqual(VKClient("tok", session=FakeSession()).whoami(), "Сообщество: Клуб Иван (id 9)")

    def test_no_user_token_login_left(self):
        import app.vk as vkmod
        for name in ("auth_url", "parse_token", "KATE_CLIENT_ID", "AUTH_URL"):
            self.assertFalse(hasattr(vkmod, name), name)


if __name__ == "__main__":
    unittest.main()
