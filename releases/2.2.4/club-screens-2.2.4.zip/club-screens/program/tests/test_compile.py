# Original-Author: Владислав С.
# Created: 2026-10-28
"""Все модули программы компилируются (ловит опечатки в редко открываемых окнах)."""
import os
import py_compile
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class CompileTest(unittest.TestCase):
    def test_all_modules_compile(self):
        files = [os.path.join(d, f) for sub in ("app", "docs", "tests")
                 for d, _, fs in os.walk(os.path.join(ROOT, sub)) for f in fs if f.endswith(".py")]
        files.append(os.path.join(ROOT, "main.py"))
        self.assertGreater(len(files), 10)
        tmp = tempfile.mkdtemp()
        for i, f in enumerate(files):
            with self.subTest(f=os.path.relpath(f, ROOT)):
                py_compile.compile(f, doraise=True, cfile=os.path.join(tmp, f"{i}.pyc"))

    def test_ui_modules_import(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        import importlib
        for m in ("app.ui.settings", "app.ui.wizard", "app.ui.main_window", "app.ui.browser"):
            importlib.import_module(m)
