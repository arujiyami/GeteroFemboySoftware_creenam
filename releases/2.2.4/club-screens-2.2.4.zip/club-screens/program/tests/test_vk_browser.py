# Original-Author: Владислав С.
# Created: 2026-10-28
"""Отправка через встроенный браузер: сценарии (app/vk_browser.Flows) на поддельной странице ВК.
Настоящий JS и Qt WebEngine проверяются отдельно: tests/qt_smoke.py (локальная копия «ВК»)."""
import os
import tempfile
import unittest

from app.scheduler import run_with_retries
from app.vk_browser import (AccountBlocked, BrowserError, BrowserVKSender, CaptchaShown, ChatListTimeout,
                            ChatNotFound, Flows, NotLoggedIn, SendFailed, build_js, decode_js_result,
                            PRIORITY_SELECTORS, merged_settings, parse_chat_items, parse_chat_link, rotate_shots)


class FakeVK:
    """Модель страницы ВК: что на ней видно и как она реагирует на действия сценария."""

    def __init__(self, logged_in=True, input_found=True, multiple=True, send_button=True, visible=False,
                 chats=None, chat_ok=True):
        self.url = "about:blank"
        self.cookies = {"remixsid": "x"} if logged_in else {"remixlang": "0"}
        self.logged_in = logged_in
        self.c = {}            # дополнительные «видимые» элементы: ключ → количество
        self.previews = 0
        self.history = 0
        self.outgoing = 0
        self.input_found, self.multiple = input_found, multiple
        self.has_send_button = send_button
        self.visible = visible
        self.chat_ok = chat_ok
        self.chats = chats if chats is not None else []
        self.typed = ""
        self.calls = []
        self.armed = None
        self.taken = False
        self.on_set_files = None
        self.upload_fails = False
        self.photo_menu = False
        self.pinned = 0          # картинки ВНЕ области ввода (закреплённое, лента) — не должны мешать
        self.drop_ok = False     # принимает ли поле ввода «перетаскивание»
        self.paste_ok = True     # принимает ли «вставку из буфера»
        self.dragged = None
        self.highlighted = 0

    def load(self, url):
        self.url = url
        if not self.logged_in and "/im" in url:
            self.url = "https://vk.com/login?u=2"

    def counts(self, keys, box=()):
        out = {}
        for k in keys:
            if k == "logged_in":
                out[k] = 1 if self.logged_in and "/login" not in self.url else 0
            elif k == "login_form":
                out[k] = 0 if self.logged_in else 1
            elif k == "composer":
                out[k] = 1 if (self.logged_in and self.chat_ok and "/im/convo/" in self.url) else 0
            elif k == "attachment_preview":
                out[k] = self.previews + (0 if k in box else self.pinned)
            elif k == "history_photos":
                out[k] = self.history
            elif k == "outgoing_message":
                out[k] = self.outgoing
            else:
                out[k] = self.c.get(k, 0)
        return out

    def call(self, fn, a):
        self.calls.append(fn)
        if fn == "probe":
            return {"url": self.url, "c": self.counts(a["keys"], a.get("box") or ())}
        if fn == "sig":
            return {"ok": "/im/convo/" in self.url, "prev": self.previews, "prog": 0, "n": 10 + self.previews,
                    "media": 0, "zone": 0, "blob": 0, "h": 40, "consumed": False}
        if fn == "drag":
            self.dragged = a["files"]
            return True
        if fn == "drop":
            if self.drop_ok and self.dragged:
                self.previews += len(self.dragged)
            return True
        if fn == "diag":
            return {"visibility": "visible" if self.visible else "hidden", "url": self.url, "matched": {}}
        if fn == "dump":
            return "<div>[текст 5 симв.]</div>"
        if fn == "highlight":
            self.highlighted += 1
            return ["поле ввода", "скрепка"]
        if fn == "name":
            return "Иван Иванов"
        if fn == "chats":
            return {"items": self.chats, "moved": False}
        if fn == "input_info":
            return {"found": self.input_found, "multiple": self.multiple}
        if fn == "set_files":
            if not self.input_found:
                return {"ok": False}
            if self.upload_fails:
                self.c["upload_error"] = 1
            else:
                self.previews += len(a["files"])
            self.files_names = getattr(self, "files_names", []) + [f["name"] for f in a["files"]]
            return {"ok": True, "n": len(a["files"])}
        if fn == "paste":
            if self.paste_ok:
                self.previews += len(a["files"])
            return True
        if fn == "type":
            self.typed += a["text"]
            return True
        if fn == "click":
            if a["key"] == "attachment_remove" and self.previews:
                self.previews -= 1
                return True
            if a["key"] == "attach_button":
                self.photo_menu = True
                return True
            return False
        if fn == "center":
            return {"x": 10, "y": 20} if (a["key"] == "attach_photo_item" and self.photo_menu) else None
        if fn == "click_send":
            self.send_clicked = True
            if not self.has_send_button:
                return "none"
            self._sent()
            return "clicked"
        if fn == "enter":
            self._sent()
            return True
        if fn == "composer_state":     # 2.2.3: очистилось ли поле после нажатия
            return {"prev": self.previews, "text": 0, "composer": True}
        if fn == "search":
            return True
        if fn == "click_chat":
            self.url = "https://vk.com/im/convo/2000000001"
            return True
        raise AssertionError(fn)

    def _sent(self):
        if self.previews:
            self.history += self.previews
            self.previews = 0
            self.outgoing += 1


class FakeDriver:
    """Выполняет операции сценария мгновенно, с виртуальными часами (как app/ui/browser.FlowRunner)."""

    def __init__(self, page, shot_dir=None):
        self.page = page
        self.t = 0.0
        self.ops = []
        self.shot_dir = shot_dir
        self.saved = {}
        self.logs = []

    def run(self, gen):
        value, error = None, None
        while True:
            try:
                op = gen.throw(error) if error else gen.send(value)
            except StopIteration as e:
                return e.value
            self.ops.append(op[0])
            value, error = None, None
            try:
                value = self.do(op)
            except Exception as e:  # noqa: BLE001  (как в настоящем браузере: ошибка уходит в сценарий)
                error = e

    def do(self, op):
        p, kind = self.page, op[0]
        if kind == "load":
            p.load(op[1])
            return True
        if kind == "js":
            assert "JSON.stringify" in op[1]
            return p.call(op[2], op[3])
        if kind == "sleep":
            self.t += op[1]
            return None
        if kind == "clock":
            self.t += 0.05
            return self.t
        if kind == "cookies":
            return dict(p.cookies)
        if kind == "visible":
            return p.visible
        if kind == "arm_files":
            p.armed = op[1]
            return None
        if kind == "click_real":
            if p.visible and p.armed:
                p.previews += len(p.armed)
                p.taken = True
                return True
            return False
        if kind == "files_taken":
            return p.taken
        if kind == "save_text":
            self.saved[op[1]] = op[2]
            return op[1]
        if kind == "log":
            self.logs.append(op[1])
            return None
        if kind == "shot":
            if not self.shot_dir:
                return None
            path = os.path.join(self.shot_dir, f"vk_{op[1]}.png")
            open(path, "wb").close()
            return path
        raise AssertionError(op)


def settings(extra=None):
    return merged_settings({"vk_browser": extra or {}})


def flows(s=None):
    return Flows(s or settings(), rand=lambda a, b: a)


def two_pngs():
    d = tempfile.mkdtemp()
    out = []
    for n in ("01_Oasys.png", "02_iVMS-4200.png"):
        p = os.path.join(d, n)
        with open(p, "wb") as f:
            f.write(b"\x89PNG fake " + n.encode())
        out.append(p)
    return out


class LinksTest(unittest.TestCase):
    def test_parse_chat_link(self):
        self.assertEqual(parse_chat_link("https://vk.com/im/convo/2000000001"), 2000000001)
        self.assertEqual(parse_chat_link("https://vk.ru/im/convo/2000000001?entrypoint=list_all"), 2000000001)
        self.assertEqual(parse_chat_link("https://vk.com/im?sel=c1"), 2000000001)
        self.assertEqual(parse_chat_link("vk.com/im?sel=123"), 123)
        self.assertEqual(parse_chat_link(" 2000000001 "), 2000000001)
        self.assertIsNone(parse_chat_link("Камеры"))
        self.assertIsNone(parse_chat_link(""))

    def test_parse_chat_items(self):
        items = [{"href": "/im/convo/2000000001", "text": "Камеры | Мой клуб\nИван: фото"},
                 {"href": "/im/convo/2000000001", "text": "дубль"},
                 {"href": "/im/convo/-9", "text": "Клуб"},
                 {"href": "/feed", "text": "Новости"},
                 {"href": "/im/convo/5", "text": ""}]
        out = parse_chat_items(items)
        self.assertEqual(out, [
            {"peer_id": 2000000001, "title": "Камеры | Мой клуб", "type": "chat"},
            {"peer_id": -9, "title": "Клуб", "type": "group"}])


class SelectorsTest(unittest.TestCase):
    def test_defaults_and_override(self):
        s = merged_settings({"vk_browser": {"selectors": {"send_button": "#mySend", "composer": ["#a", "#b"]}}})
        # 2.2.3: точные селекторы текущего ВК всегда впереди, свои — следом
        self.assertEqual(s["selectors"]["send_button"], PRIORITY_SELECTORS["send_button"] + ["#mySend"])
        self.assertEqual(s["selectors"]["composer"], PRIORITY_SELECTORS["composer"] + ["#a", "#b"])
        self.assertIn('[aria-label="Отправить"]', merged_settings({})["selectors"]["send_button"])
        self.assertEqual(s["chat_url"].format(peer_id=2000000001), "https://vk.com/im/convo/2000000001")
        self.assertEqual(s["chat_list_timeout_sec"], 20)

    def test_config_yaml_has_all_selectors(self):
        from app.config import DEFAULTS
        from app.vk_browser import DEFAULT_SELECTORS, DEFAULTS as BD
        self.assertEqual(DEFAULTS["vk_browser"]["selectors"], DEFAULT_SELECTORS)
        for k, v in BD.items():
            self.assertEqual(DEFAULTS["vk_browser"][k], v, k)
        for gone in ("channel", "window", "headless"):
            self.assertNotIn(gone, DEFAULTS["vk_browser"])
        self.assertEqual(DEFAULTS["vk"]["sender"], "browser")
        self.assertEqual(DEFAULTS["vk"]["group_token"], "")

    def test_override_reaches_page_js(self):
        s = settings({"selectors": {"send_button": ["#mySend"]}})
        code = build_js("click_send", s["selectors"], {"key": "send_button"})
        self.assertIn('"#mySend"]', code)
        self.assertIn("JSON.stringify", code)

    def test_decode(self):
        self.assertEqual(decode_js_result('{"v": [1, 2]}'), [1, 2])
        self.assertIsNone(decode_js_result('{"error": "boom"}'))
        self.assertIsNone(decode_js_result(None))


class StateTest(unittest.TestCase):
    def run_flow(self, page, gen):
        return FakeDriver(page).run(gen)

    def test_logged_in_with_name(self):
        page = FakeVK()
        r = self.run_flow(page, flows().login_status(navigate=True))
        self.assertEqual((r["state"], r["name"]), ("ok", "Иван Иванов"))
        self.assertEqual(page.url, "https://vk.com/")

    def test_logged_out(self):
        r = self.run_flow(FakeVK(logged_in=False), flows().login_status(navigate=True))
        self.assertEqual(r["state"], "logged_out")
        self.assertEqual(r["name"], "")

    def test_blocked_and_captcha_by_url(self):
        page = FakeVK()
        page.url = "https://vk.com/blocked"
        self.assertEqual(self.run_flow(page, flows().state()), "blocked")
        page.url = "https://vk.com/challenge?x"
        self.assertEqual(self.run_flow(page, flows().state()), "captcha")
        page.url = "https://vk.com/"
        page.c["captcha"] = 1
        self.assertEqual(self.run_flow(page, flows().state()), "captcha")

    def test_blocked_by_text(self):
        page = FakeVK()
        page.c["blocked_text"] = 1
        self.assertEqual(self.run_flow(page, flows().state(deep=True)), "blocked")
        self.assertEqual(self.run_flow(page, flows().state(deep=False)), "ok")

    def test_no_cookie_names_falls_back_to_page(self):
        page = FakeVK()
        page.cookies = {}
        f = flows(settings({"login_cookies": []}))
        self.assertEqual(self.run_flow(page, f.state()), "ok")


class ChatListTest(unittest.TestCase):
    def test_list(self):
        page = FakeVK(chats=[{"href": "/im/convo/2000000001", "text": "Камеры | Мой клуб\nфото"},
                             {"href": "/im?sel=c5", "text": "Админы"}])
        r = FakeDriver(page).run(flows().list_chats())
        self.assertEqual([c["peer_id"] for c in r], [2000000001, 2000000005])

    def test_timeout_after_20_seconds(self):
        d = FakeDriver(FakeVK(chats=[]))
        with self.assertRaises(ChatListTimeout) as cm:
            d.run(flows().list_chats())
        self.assertLess(d.t, 25)
        self.assertGreaterEqual(d.t, 20)
        self.assertIn("ссылку", cm.exception.text)

    def test_logged_out(self):
        with self.assertRaises(NotLoggedIn):
            FakeDriver(FakeVK(logged_in=False)).run(flows().list_chats())


class SendTest(unittest.TestCase):
    def send(self, page, caption="", s=None, shot_dir=None, peer=2000000001, title=""):
        self.driver = FakeDriver(page, shot_dir)
        return self.driver.run(flows(s).send(peer, two_pngs(), caption, title))

    def test_one_message_two_photos_in_order(self):
        page = FakeVK()
        self.assertEqual(self.send(page), "verified")
        self.assertEqual(page.url, "https://vk.com/im/convo/2000000001")
        self.assertEqual(page.files_names, ["01_Oasys.png", "02_iVMS-4200.png"])
        self.assertEqual(page.outgoing, 1)
        self.assertEqual(page.calls.count("set_files"), 1)

    def test_caption(self):
        page = FakeVK()
        self.send(page, caption="Клуб 12:00")
        self.assertEqual(page.typed, "Клуб 12:00")

    def test_single_file_input(self):
        page = FakeVK(multiple=False)
        self.send(page)
        self.assertEqual(page.calls.count("set_files"), 2)
        self.assertEqual(page.outgoing, 1)

    def test_enter_when_no_button(self):
        page = FakeVK(send_button=False)
        self.assertEqual(self.send(page), "verified")
        self.assertIn("enter", page.calls)

    def test_chooser_last_when_drop_and_paste_fail(self):
        page = FakeVK(input_found=False, visible=True)
        page.paste_ok = False
        self.assertEqual(self.send(page), "verified")
        self.assertTrue(page.taken)
        self.assertIsNone(page.armed)  # после щелчка файлы «разоружены»
        self.assertLess(page.calls.index("drop"), page.calls.index("paste"))
        self.assertIn("click_real", self.driver.ops)
        self.assertEqual(page.outgoing, 1)

    def test_drop_when_no_input(self):
        page = FakeVK(input_found=False, visible=False)
        page.drop_ok = True
        self.assertEqual(self.send(page), "verified")
        self.assertNotIn("paste", page.calls)
        self.assertEqual(page.history, 2)   # прикреплено ровно один раз

    def test_paste_when_hidden_and_no_input(self):
        page = FakeVK(input_found=False, visible=False)
        self.assertEqual(self.send(page), "verified")
        self.assertIn("paste", page.calls)
        self.assertNotIn("click_real", self.driver.ops)
        self.assertEqual(page.history, 2)

    def test_nothing_attached_is_error_not_empty_send(self):
        page = FakeVK(input_found=False, visible=False)
        page.paste_ok = False
        with self.assertRaises(SendFailed) as cm:
            self.send(page, s=settings({"upload_timeout_sec": 3}))
        self.assertNotIn("click_send", page.calls)
        self.assertTrue(cm.exception.retry)
        self.assertTrue(any(k.startswith("dom_") for k in self.driver.saved))

    def test_pictures_outside_composer_do_not_block(self):
        """Ложная ошибка «старые картинки»: картинки в ленте/закрепе не мешают отправке."""
        page = FakeVK()
        page.pinned = 4
        self.assertEqual(self.send(page), "verified")
        self.assertNotIn("click", [c for c in page.calls if c == "click"])  # ничего не удаляли
        self.assertEqual(page.outgoing, 1)

    def test_stuck_old_draft_does_not_block(self):
        page = FakeVK()
        page.previews = 2
        orig = page.call

        def call(fn, a):
            if fn == "click" and a["key"] == "attachment_remove":
                return False   # убрать не получается
            return orig(fn, a)
        page.call = call
        self.assertEqual(self.send(page), "verified")
        self.assertEqual(page.outgoing, 1)

    def test_timeout_thrown_into_flow(self):
        """Общий тайм-аут (как FlowRunner): ошибка бросается в сценарий, он сохраняет сведения."""
        from app.vk_browser import SendTimeout
        page = FakeVK()
        gen = flows().send(2000000001, two_pngs(), "", "")
        d = FakeDriver(page)
        op = next(gen)
        for _ in range(5):
            op = gen.send(d.do(op))
        saved = {}
        with self.assertRaises(SendTimeout):
            op = gen.throw(SendTimeout(90))
            while True:
                if op[0] == "save_text":
                    saved[op[1]] = op[2]
                op = gen.send(d.do(op))
        self.assertNotIn("click_send", page.calls)

    def test_prewarm_single_load_then_send_reuses_page(self):
        page = FakeVK()
        d = FakeDriver(page)
        self.assertEqual(d.run(flows().prewarm(2000000001)), "ready")
        self.assertEqual(d.ops.count("load"), 1)           # одна загрузка страницы, без «проверок входа»
        self.assertEqual(d.run(flows().send(2000000001, two_pngs(), "", "", reuse=True)), "verified")
        self.assertEqual(d.ops.count("load"), 1)           # отправка в уже открытой беседе
        self.assertEqual(page.outgoing, 1)

    def test_reuse_reloads_only_if_composer_missing(self):
        page = FakeVK()
        d = FakeDriver(page)
        d.run(flows().prewarm(2000000001))
        page.load("https://vk.com/feed")                    # беседа «ушла» (например, ВК перекинул на ленту)
        self.assertEqual(d.run(flows().send(2000000001, two_pngs(), "", "", reuse=True)), "verified")
        self.assertEqual(d.ops.count("load"), 2)
        self.assertEqual(page.outgoing, 1)

    def test_prewarm_logged_out_needs_user(self):
        page = FakeVK(logged_in=False)
        with self.assertRaises(NotLoggedIn) as cm:
            FakeDriver(page).run(flows().prewarm(2000000001))
        self.assertTrue(cm.exception.needs_user)

    def test_prewarm_captcha_needs_user(self):
        page = FakeVK()
        page.c["captcha"] = 1
        with self.assertRaises(CaptchaShown):
            FakeDriver(page).run(flows().prewarm(2000000001))

    def test_debug_send_never_clicks_send(self):
        page = FakeVK()
        d = FakeDriver(page)
        rep = d.run(flows().debug_send(2000000001, two_pngs()))
        self.assertNotIn("click_send", page.calls)
        self.assertNotIn("enter", page.calls)
        self.assertEqual(page.outgoing, 0)
        self.assertEqual(page.previews, 0)       # пробные картинки убраны
        self.assertGreaterEqual(page.highlighted, 1)
        self.assertTrue(any("готово" in r for r in rep))
        self.assertIn("dom_debug", d.saved)

    def test_old_draft_cleared(self):
        page = FakeVK()
        page.previews = 3
        self.send(page)
        self.assertEqual(page.history, 2)

    def test_not_logged_in(self):
        with self.assertRaises(NotLoggedIn) as cm:
            self.send(FakeVK(logged_in=False))
        self.assertTrue(cm.exception.needs_user)
        self.assertFalse(cm.exception.retry)

    def test_blocked(self):
        page = FakeVK()
        page.c["blocked_text"] = 1
        page.chat_ok = False
        with self.assertRaises(AccountBlocked):
            self.send(page, s=settings({"page_timeout_sec": 3}))

    def test_chat_not_found(self):
        page = FakeVK(chat_ok=False)
        page.c["chat_not_found"] = 1
        with self.assertRaises(ChatNotFound):
            self.send(page)

    def test_upload_error_is_retryable(self):
        page = FakeVK()
        page.upload_fails = True
        with self.assertRaises(SendFailed) as cm:
            self.send(page)
        self.assertTrue(cm.exception.retry)
        self.assertEqual(page.outgoing, 0)

    def test_captcha_during_upload(self):
        page = FakeVK()

        orig = page.call

        def call(fn, a):
            r = orig(fn, a)
            if fn == "set_files":
                page.c["captcha"] = 1
            return r
        page.call = call
        with self.assertRaises(CaptchaShown):
            self.send(page)
        self.assertEqual(page.outgoing, 0)

    def test_failure_after_click_is_not_retried(self):
        page = FakeVK()
        orig = page.call

        def call(fn, a):
            if fn == "click_send":
                raise RuntimeError("page crashed")
            return orig(fn, a)
        page.call = call
        with self.assertRaises(SendFailed) as cm:
            self.send(page)
        self.assertFalse(cm.exception.retry)
        self.assertIn("повтора не будет", cm.exception.text)

    def test_stuck_previews_after_click(self):
        page = FakeVK()
        page._sent = lambda: None  # кнопка «нажата», но ничего не ушло
        with self.assertRaises(SendFailed) as cm:
            self.send(page, s=settings({"verify_timeout_sec": 3}))
        self.assertTrue(cm.exception.retry)   # 2.2.1: картинки остались в поле — не ушло, повтор безопасен

    def test_error_shot_attached(self):
        d = tempfile.mkdtemp()
        with self.assertRaises(NotLoggedIn) as cm:
            self.send(FakeVK(logged_in=False), shot_dir=d)
        self.assertTrue(cm.exception.shot.endswith("vk_not_logged_in.png"))

    def test_open_by_title(self):
        page = FakeVK()
        self.assertEqual(self.send(page, peer=0, title="Камеры"), "verified")
        self.assertIn("click_chat", page.calls)

    def test_no_retry_on_needs_user(self):
        calls = []

        def attempt():
            calls.append(1)
            raise CaptchaShown()
        ok = run_with_retries(attempt, 2, 180, wait=lambda s: False)
        self.assertFalse(ok)
        self.assertEqual(len(calls), 1)

    def test_rotate_shots(self):
        d = tempfile.mkdtemp()
        for i in range(5):
            p = os.path.join(d, f"vk_{i}.png")
            open(p, "wb").close()
            os.utime(p, (i, i))
        rotate_shots(d, 2)
        self.assertEqual(sorted(os.listdir(d)), ["vk_3.png", "vk_4.png"])


class SenderBridgeTest(unittest.TestCase):
    def test_runs_flow_through_browser(self):
        page = FakeVK()

        class Browser:
            def run_blocking(self, factory, timeout, deadline=None, on_deadline=None):
                self.timeout, self.deadline, self.on_deadline = timeout, deadline, on_deadline
                return FakeDriver(page).run(factory())
        b = Browser()
        r = BrowserVKSender(b, {"vk_browser": {"pause_min_sec": 0, "pause_max_sec": 0}}).send_photos(
            2000000001, two_pngs(), "x")
        self.assertEqual(r, "verified")
        self.assertGreater(b.timeout, 100)
        self.assertEqual(b.deadline, 225)   # 90 + проверка доставки 2×30 + 30 + 2.2.1: загрузка до 90 с (+45)
        self.assertEqual(b.on_deadline().kind, "timeout")

    def test_error_classes(self):
        for cls in (NotLoggedIn, AccountBlocked, CaptchaShown, ChatNotFound):
            e = cls()
            self.assertIsInstance(e, BrowserError)
            self.assertTrue(e.needs_user)
            self.assertFalse(e.retry)
        self.assertTrue(SendFailed("x").retry)


if __name__ == "__main__":
    unittest.main()


class LossyVK(FakeVK):
    """2.2.0: «Отправить» нажато, поле очистилось, а сообщение в беседе не появилось (lost раз подряд)."""

    def __init__(self, lost=1, appear_after=None, **kw):
        super().__init__(**kw)
        self.lost = lost
        self.history, self.outgoing = 4, 2     # в беседе уже есть старые сообщения
        self.clicks = 0

    def _sent(self):
        if self.previews:
            self.clicks += 1
            if self.lost:
                self.lost -= 1
                self.previews = 0
                return
        super()._sent()


class DeliveryTest(unittest.TestCase):
    def send(self, page, s=None):
        self.driver = FakeDriver(page)
        return self.driver.run(flows(s).send(2000000001, two_pngs(), "", ""))

    # 2.2.4: подтверждённая (композер очищен) отправка — окончательная; по истории беседы
    # повтор не делается (удалённое пользователем сообщение не должно вызывать повторную отправку).
    def test_no_resend_when_not_in_history(self):
        page = LossyVK(lost=1)
        self.assertEqual(self.send(page), "sent")
        self.assertEqual(page.clicks, 1)

    def test_no_resend_even_if_never_seen(self):
        page = LossyVK(lost=5)
        self.assertEqual(self.send(page), "sent")
        self.assertEqual(page.clicks, 1)

    def test_history_unreadable(self):
        page = LossyVK(lost=1)
        page.history = page.outgoing = 0
        self.assertEqual(self.send(page), "sent")
        self.assertEqual(page.clicks, 1)

    def test_delivery_check_off(self):
        page = LossyVK(lost=1)
        self.assertEqual(self.send(page, dict(settings(), delivery_check=False)), "sent")
        self.assertEqual(page.clicks, 1)
