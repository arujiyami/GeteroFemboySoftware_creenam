# Original-Author: Владислав С.
# Created: 2026-10-28
"""Проверка входа на НАСТОЯЩЕМ Qt WebEngine по обезличенным страницам из tests/fixtures (локальный сервер,
в интернет не ходит и ни во что не входит). Запуск: python tests/dom_probe.py → последняя строка — JSON.
Вызывается из tests/test_login_detect.py."""
import functools
import http.server
import json
import logging
import os
import sys
import tempfile
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
ROUTES = {"/feed": "vk_new_ui_logged_in.html", "/start": "vk_new_ui_logged_out.html"}


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):  # noqa: N802
        self.path = "/" + ROUTES.get(self.path.split("?")[0], "vk_new_ui_logged_out.html")
        return super().do_GET()


def main():
    from PySide6.QtCore import QObject, Qt, QTimer, Signal
    from PySide6.QtWidgets import QApplication

    from app.config import DEFAULTS, deep_merge
    from app.ui.browser import VKBrowser
    from app.vk_browser import DEFAULT_SELECTORS, NEW_LOGGED_IN_SELECTORS, Flows, merged_settings

    class Quit(QObject):
        go = Signal()

    logs = []

    class Grab(logging.Handler):
        def emit(self, rec):
            logs.append(rec.getMessage())
    lg = logging.getLogger("club")
    lg.setLevel(logging.DEBUG)
    lg.addHandler(Grab())

    app = QApplication(sys.argv[:1])
    quitter = Quit()
    quitter.go.connect(app.quit, Qt.ConnectionType.QueuedConnection)
    tmp = tempfile.mkdtemp()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(
        Handler, directory=os.path.join(HERE, "fixtures")))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    cfg = deep_merge(DEFAULTS, {
        "storage": {"log_file": os.path.join(tmp, "logs", "app.log")},
        "vk_browser": {"profile_dir": os.path.join(tmp, "profile"), "home_url": base + "/feed",
                       "save_memory": True}})
    b = VKBrowser(lambda: cfg)
    b.holder.resize(1000, 700)
    out = {}

    def worker():
        try:
            s = b.settings()
            out["in"] = b.run_blocking(lambda: Flows(s).login_status(navigate=True, settle=0), 60)
            out["in_cookies"] = sorted(b.cookies)
            # как было до 2.1.3 (только старые селекторы) — новый дизайн не распознавался
            old = merged_settings({"vk_browser": dict(cfg["vk_browser"], selectors={
                "logged_in": [x for x in DEFAULT_SELECTORS["logged_in"] if x not in NEW_LOGGED_IN_SELECTORS]})})
            out["in_old_selectors"] = b.run_blocking(lambda: Flows(old).login_status(navigate=True, settle=0), 60)
            s2 = dict(s, home_url=base + "/start")
            out["out"] = b.run_blocking(lambda: Flows(s2).login_status(navigate=True, settle=0), 60)
        except Exception as e:  # noqa: BLE001
            out["error"] = repr(e)
        finally:
            quitter.go.emit()

    threading.Thread(target=worker, daemon=True).start()
    QTimer.singleShot(120000, app.quit)
    app.exec()
    out["debug"] = [m for m in logs if m.startswith("Проверка входа")]
    srv.shutdown()
    print(json.dumps(out, ensure_ascii=False, default=str), flush=True)
    os._exit(0)   # без разбора Qt при выходе


if __name__ == "__main__":
    main()
