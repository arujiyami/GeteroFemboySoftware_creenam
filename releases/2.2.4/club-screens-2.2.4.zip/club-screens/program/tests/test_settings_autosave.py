# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.6: «Настройки» — всё действует и сохраняется само, разделы с подсказками, сброс по умолчанию,
пауза музыки, переход в раздел ничего не сбрасывает."""
import copy
import os
import tempfile
import time
import types
import unittest
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

try:
    from PySide6.QtCore import QTime
    from PySide6.QtWidgets import QApplication, QLabel, QMessageBox
    HAVE_QT = True
except Exception:  # noqa: BLE001
    HAVE_QT = False

from app.config import DEFAULTS, load_config
from app.mediapause import media_settings
from tests.test_live_settings import StubMain


@unittest.skipUnless(HAVE_QT, "нет PySide6")
class Autosave(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        from app.ui.settings import SettingsPage
        self.path = os.path.join(tempfile.mkdtemp(), "config.yaml")
        self.cfg = copy.deepcopy(DEFAULTS)
        self.cfg["vk"]["peer_id"] = 2000000001
        self.main = StubMain(self.cfg, self.path)
        self.page = SettingsPage(self.main)

    def pump(self, sec=0.7):
        end = time.monotonic() + sec
        while time.monotonic() < end:
            self.app.processEvents()
            time.sleep(0.01)

    def test_sections_and_hints(self):
        titles = [w.text() for w in self.page.findChildren(QLabel) if w.objectName() == "sectionTitle"]
        for t in ("Расписание", "Перед съёмом", "Во время съёма", "Проверка Oasys", "Отправка в ВК",
                  "Очистка снимков"):
            self.assertIn(t, titles)
        self.assertEqual(self.page.adv_toggle.text(), "Дополнительно")
        self.assertTrue(self.page.adv_body.isHidden())          # свёрнуто
        hints = [w for w in self.page.findChildren(QLabel) if w.objectName() == "hint"]
        self.assertGreater(len(hints), 20)
        self.assertFalse(any(b.text() == "Сохранить" for b in self.page.findChildren(
            __import__("PySide6.QtWidgets", fromlist=["QPushButton"]).QPushButton)))

    def test_units_in_words(self):
        p = self.page
        p.lock_watchdog.setValue(21)
        self.assertEqual(p.lock_watchdog.suffix(), " секунда")
        p.lock_watchdog.setValue(30)
        self.assertEqual(p.lock_watchdog.suffix(), " секунд")
        p.cleanup_hours.setValue(24)
        self.assertEqual(p.cleanup_hours.suffix(), " часа")
        p.lock_early.setValue(3)
        self.assertEqual(p.lock_early.value_label.text(), "за 3 секунды")
        p.prewarm.setValue(0)
        self.assertEqual(p.prewarm.value_label.text(), "не открывать")

    def test_all_fields_autosave(self):
        p = self.page
        p.sched_minute.setValue(15)
        p.prewarm.setValue(7)
        p.club_name.setText("Мой клуб")
        p.club_name.textEdited.emit("Мой клуб")
        p.peer_title.setText("Отчёты")
        p.peer_title.textEdited.emit("Отчёты")
        p.send_partial.setChecked(False)
        p.cleanup_hours.setValue(48)
        p.cleanup_time.setTime(QTime(3, 15))
        p.keep_last.setValue(100)
        p.image_format.setCurrentIndex(1)
        p.use_tray.setChecked(False)
        p.media_pause.setChecked(True)
        p.media_resume.setChecked(False)
        self.assertEqual(self.main.saves, 0)
        self.pump()
        self.assertEqual(self.main.saves, 1)
        saved = load_config(self.path)
        self.assertEqual(saved["schedule"]["minute"], 15)
        self.assertEqual(saved["schedule"]["prewarm_minutes"], 7)
        self.assertEqual(saved["app"]["club_name"], "Мой клуб")
        self.assertEqual(saved["vk"]["peer_title"], "Отчёты")
        self.assertFalse(saved["schedule"]["send_partial"])
        self.assertEqual(saved["cleanup"]["keep_hours"], 48)
        self.assertEqual(saved["cleanup"]["time"], "03:15")
        self.assertEqual(saved["storage"]["keep_last"], 100)
        self.assertEqual(saved["storage"]["image_format"], "jpg")
        self.assertFalse(saved["app"]["use_tray"])
        self.assertEqual(saved["media_pause"], {"enabled": True, "resume": False})
        self.assertTrue(self.page.saved_label.text().startswith("✓ Сохранено"))

    def test_media_pause_live_and_sub_checkbox(self):
        p = self.page
        self.assertFalse(p.media_pause.isChecked())
        self.assertTrue(p.media_resume.isChecked())
        self.assertFalse(p.media_resume.isEnabled())         # подпункт неактивен, пока пауза выключена
        p.media_pause.setChecked(True)
        self.assertTrue(p.media_resume.isEnabled())
        self.assertEqual(media_settings(self.cfg), (True, True))   # в памяти — сразу

    def test_bad_yaml_not_saved_indicator(self):
        p = self.page
        good = p.vb_text.toPlainText()
        before = copy.deepcopy(self.cfg["vk_browser"])
        p.vb_text.setPlainText("selectors: [")
        self.pump()
        self.assertIn("Страница ВК", p.saved_label.text())
        self.assertEqual(self.cfg["vk_browser"], before)          # испорченное не применяется
        p.vb_text.setPlainText(good)
        self.pump()
        self.assertTrue(p.saved_label.text().startswith("✓"))

    def test_bad_steps_yaml_kept_on_page(self):
        p = self.page
        p.tabs.setCurrentIndex(1)
        self.assertIsNotNone(p.current_src)
        before = copy.deepcopy(self.cfg["sources"][p.current_src]["steps"])
        p.steps_text.setPlainText("steps: [")
        self.pump()
        self.assertIn("шаги", p.saved_label.text())
        self.assertEqual(self.cfg["sources"][p.current_src]["steps"], before)
        self.assertEqual(p.steps_text.toPlainText(), "steps: [")   # текст на месте, ничего не потеряно

    def test_source_edit_autosaves(self):
        p = self.page
        f = p.src_fields["title_regex"]
        f.setText("(?i)моё окно")
        f.textEdited.emit("(?i)моё окно")
        self.pump()
        saved = load_config(self.path)
        self.assertEqual(saved["sources"][p.current_src]["window"]["title_regex"], "(?i)моё окно")

    def test_nav_does_not_discard(self):
        from app.ui.main_window import MainWindow
        p = self.page
        p.vb_text.setPlainText("selectors: [")       # ещё с ошибкой
        p.countdown_seconds.setValue(12)
        me = types.SimpleNamespace(pages=mock.Mock(), update_view_memory=lambda: None, page_settings=p)
        MainWindow._on_nav(me, 2)
        self.assertEqual(p.vb_text.toPlainText(), "selectors: [")
        self.assertEqual(p.countdown_seconds.value(), 12)
        self.assertEqual(self.main.saves, 1)          # отложенное записано сразу

    def test_reset_defaults_with_confirm(self):
        p = self.page
        self.cfg["vk"]["peer_title"] = "Отчёты"
        self.cfg["app"]["club_name"] = "Мой клуб"
        p.load()
        p.countdown_seconds.setValue(5)
        p.sched_minute.setValue(30)
        p.media_pause.setChecked(True)
        with mock.patch.object(QMessageBox, "question", return_value=QMessageBox.StandardButton.No):
            self.assertFalse(p.reset_defaults())
        self.assertEqual(p.countdown_seconds.value(), 5)
        with mock.patch.object(QMessageBox, "question", return_value=QMessageBox.StandardButton.Yes) as q:
            self.assertTrue(p.reset_defaults())
            q.assert_called_once()
        self.assertEqual(p.countdown_seconds.value(), 60)
        self.assertEqual(p.sched_minute.value(), 0)
        self.assertFalse(p.media_pause.isChecked())
        saved = load_config(self.path)
        self.assertEqual(saved["countdown"]["seconds"], 60)
        self.assertEqual(saved["vk"]["peer_id"], 2000000001)      # беседа — не трогается
        self.assertEqual(saved["vk"]["peer_title"], "Отчёты")
        self.assertEqual(saved["app"]["club_name"], "Мой клуб")
        self.assertEqual(len(saved["sources"]), len(DEFAULTS["sources"]))


if __name__ == "__main__":
    unittest.main()
