# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: замер памяти «Лёгкого режима» (app/lightmode.py).

  QT_QPA_PLATFORM=offscreen python tests/smoke/light_mode_mem.py

Дважды запускает отдельный процесс со встроенным браузером и локальной страницей бесед (tests/fake_vk/im.html):
обычные флаги (как по умолчанию, «Экономить память») и флаги «Лёгкого режима». Через 8 секунд меряет память
(RSS) процесса со всеми процессами браузера и печатает таблицу. Только Linux (/proc). В ВК не ходит.
Печатает «ИТОГО: все проверки пройдены», если лёгкий режим не тяжелее обычного."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, ROOT)


def child(light):
    from app.ui.browser import chromium_flags
    os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = chromium_flags("", save_memory=True, light=light)
    from PySide6.QtCore import QTimer, QUrl
    from PySide6.QtWebEngineWidgets import QWebEngineView
    from PySide6.QtWidgets import QApplication
    from app.lightmode import rss_tree_mb
    app = QApplication(sys.argv)
    v = QWebEngineView()
    v.resize(1280, 900)
    v.load(QUrl.fromLocalFile(os.path.join(HERE, "..", "fake_vk", "im.html")))
    v.show()

    def done():
        print(f"RSS {rss_tree_mb():.0f}", flush=True)
        app.quit()
    QTimer.singleShot(8000, done)
    app.exec()


def measure(light):
    out = subprocess.run([sys.executable, __file__, "--child", "1" if light else "0"], capture_output=True,
                         text=True, timeout=120, env=dict(os.environ, QT_QPA_PLATFORM="offscreen")).stdout
    for line in out.splitlines():
        if line.startswith("RSS "):
            return float(line.split()[1])
    raise RuntimeError("замер не удался: " + out[-500:])


def main():
    normal = measure(False)
    light = measure(True)
    print(f"Обычный режим: {normal:.0f} МБ\nЛёгкий режим:  {light:.0f} МБ\nРазница: {normal - light:+.0f} МБ")
    if light <= normal * 1.05:
        print("ИТОГО: все проверки пройдены")
        return 0
    print("ОШИБКА: лёгкий режим заметно тяжелее обычного")
    return 1


if __name__ == "__main__":
    if "--child" in sys.argv:
        child(sys.argv[sys.argv.index("--child") + 1] == "1")
    else:
        sys.exit(main())
