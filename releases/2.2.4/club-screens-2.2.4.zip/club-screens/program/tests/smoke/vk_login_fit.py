# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.1.7: смоук-проверка «вход в ВК целиком в окне» на локальной странице размером со страницу входа ВК
(tests/fake_vk/login_qr.html: карточка входа и QR-код 260×260, всего около 800 CSS px в высоту).

  QT_QPA_PLATFORM=offscreen python tests/smoke/vk_login_fit.py [папка_для_снимков]

Проверяет на нескольких размерах экрана/окна (в т.ч. маленьком):
  * мастер на шаге «Вход в ВК» растягивается почти на весь экран (≈90 % доступной области);
  * страница входа подогнана: QR-код виден целиком, масштаб в пределах 0,6…1,0;
  * после изменения размера окна масштаб подбирается заново;
  * вкладка «ВКонтакте» главного окна делает то же самое.
Печатает «ИТОГО: все проверки пройдены» или список ошибок (код выхода 1). В ВК не входит."""
import copy
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.environ.get("CLUB_ROOT") or os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "docs"))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import make_gui_screens as demo  # noqa: E402  (заглушки Windows, локальный «ВК», временная папка)

FAILS = []
LOGIN_PAGE = os.path.join(HERE, "..", "fake_vk", "login_qr.html")


def check(name, cond, info=""):
    print(("OK   " if cond else "FAIL ") + name, info, flush=True)
    if not cond:
        FAILS.append(name)


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else None
    if out:
        os.makedirs(out, exist_ok=True)
    from PySide6.QtCore import QEventLoop, QTimer
    from PySide6.QtWidgets import QApplication

    from app.ui.common import ensure_font
    app = QApplication(sys.argv[:1])
    ensure_font(app)
    from app.ui.main_window import MainWindow

    def pump(sec=0.5):
        end = time.time() + sec
        while time.time() < end:
            app.processEvents()
            time.sleep(0.02)

    def wait_for(cond, sec=15):
        end = time.time() + sec
        while time.time() < end and not cond():
            pump(0.1)
        return cond()

    def js(view, code):
        res = {}
        loop = QEventLoop()
        view.page().runJavaScript(code, 0, lambda r: (res.__setitem__("r", r), loop.quit()))
        QTimer.singleShot(5000, loop.quit)
        loop.exec()
        return res.get("r")

    def grab(widget, name):
        if out:
            pump(0.3)
            widget.grab().save(os.path.join(out, name))
            print("снимок", name, flush=True)

    # страница входа — рядом с остальными страницами-заглушками
    fake = os.path.join(ROOT, "tests", "fake_vk")
    if not os.path.exists(os.path.join(fake, "login_qr.html")):        # запуск на старой версии (снимки «до»)
        import shutil
        shutil.copy(LOGIN_PAGE, fake)
    srv = demo.serve(fake)                     # тестовые заглушки, не страницы для снимков
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    login = url + "/login_qr.html"
    cfg = demo.deep_merge(copy.deepcopy(demo.DEFAULTS), {
        "vk_browser": {"profile_dir": os.path.join(demo.TMP, "profile"), "home_url": login, "im_url": login,
                       "chat_url": url + "/im/convo/{peer_id}", "login_cookies": []}})
    main = MainWindow(cfg, os.path.join(demo.TMP, "config.yaml"), demo.StubBackend, autostart_jobs=False,
                      admin=True)
    main.resize(1000, 700)                     # как в 2.1.6 по умолчанию
    main.show()
    check("мастер открылся", wait_for(lambda: main.wizard is not None, 5))
    w = main.wizard
    w.club.setText("Мой клуб")
    pump()
    w.next()
    view = None
    check("страница входа загрузилась", wait_for(lambda: main.browser.view is not None
                                                  and main.browser.current_url().startswith(url), 15))
    view = main.browser.view
    w.timer.stop()
    w.on_login({"state": "logged_out"})
    pump(3.0)
    scr = main.screen().availableGeometry()
    print("экран", scr.width(), "x", scr.height(), "окно", main.width(), "x", main.height(),
          "браузер", view.width(), "x", view.height(), "масштаб", round(view.zoomFactor(), 3), flush=True)
    grab(main, "wiz_login.png")
    new = hasattr(main.browser, "fitter")
    if not new:                                # старая версия: только снимок «до»
        print("QR целиком:", js(view, "window.qrFits && qrFits()"))
        return 0
    check("мастер почти на весь экран (≥ 85 % по высоте)", main.height() >= scr.height() * 0.85 or main.isMaximized(),
          f"{main.height()} из {scr.height()}")
    check("браузер занимает большую часть окна", view.height() >= main.height() * 0.5,
          f"{view.height()} из {main.height()}")
    z = view.zoomFactor()
    check("масштаб 0,6…1,0", 0.6 - 1e-6 <= z <= 1.0 + 1e-6, str(round(z, 3)))
    check("QR-код целиком в окне", js(view, "qrFits()") is True, str(main.browser.fitter.last))

    # маленькое окно: масштаб уменьшается, но не меньше 0,6
    main.showNormal()
    main.resize(860, 600)
    pump(2.5)
    z_small = view.zoomFactor()
    check("маленькое окно: масштаб уменьшился", z_small < z or z_small <= 0.6 + 1e-6, f"{z:.3f} → {z_small:.3f}")
    check("маленькое окно: страница входа видна (браузер не схлопнулся)", view.height() >= 300, str(view.height()))
    check("маленькое окно: масштаб не меньше 0,6", z_small >= 0.6 - 1e-6, f"{z_small:.3f}")
    grab(main, "wiz_login_small.png")
    # снова большое окно: масштаб вернулся к большему
    main.ensure_big()
    pump(2.5)
    check("после увеличения окна масштаб не меньше", view.zoomFactor() >= z_small - 1e-6,
          f"{z_small:.3f} → {view.zoomFactor():.3f}")
    check("после увеличения QR-код целиком", js(view, "qrFits()") is True)

    # вкладка «ВКонтакте» главного окна
    main.close_wizard()
    if main.wizard is None:
        main.show_section("vk")
        main.browser.go(login, load=True)
        pump(3.0)
        view = main.browser.view
        check("вкладка ВК: QR-код целиком", js(view, "qrFits()") is True,
              f"масштаб {view.zoomFactor():.3f}, браузер {view.width()}x{view.height()}")
        grab(main, "vk_tab_login.png")
    srv.shutdown()
    print("ИТОГО: все проверки пройдены" if not FAILS else "ИТОГО: ОШИБКИ: " + ", ".join(FAILS), flush=True)
    return 1 if FAILS else 0


if __name__ == "__main__":
    code = main()
    sys.stdout.flush()
    os._exit(code)
