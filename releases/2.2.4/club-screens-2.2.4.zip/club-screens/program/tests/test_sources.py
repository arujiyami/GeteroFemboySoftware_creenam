# Original-Author: Владислав С.
# Created: 2026-10-29
import unittest

from app import sources
from app.config import DEFAULTS, migrate
import copy

W = [{"hwnd": 1, "title": "OASys Admin", "exe": "OASys.Admin.exe", "pid": 10, "width": 1900, "height": 1000},
     {"hwnd": 2, "title": "Блокнот", "exe": "notepad.exe", "pid": 11, "width": 800, "height": 600},
     {"hwnd": 3, "title": "oasys — Google Chrome", "exe": "chrome.exe", "pid": 12, "width": 1900, "height": 1000}]


class SourcesTest(unittest.TestCase):
    def test_detect(self):
        r = {d["kind"]: d["window"] for d in sources.detect_known(W)}
        self.assertEqual(r["oasys"]["hwnd"], 1)
        self.assertIsNone(r["ivms"])

    def test_custom(self):
        s = sources.custom_source(W[1], taken=["notepad"])
        self.assertEqual(s["kind"], "custom")
        self.assertEqual(s["name"], "notepad (2)")
        self.assertIn("notepad", s["window"]["process_regex"])
        self.assertEqual(s["steps"][-1]["type"], "screenshot")

    def test_add_limit(self):
        cfg = {"sources": []}
        for i in range(sources.MAX_SOURCES):
            self.assertTrue(sources.add_source(cfg, sources.custom_source(W[1], taken=[x["name"] for x in cfg["sources"]])))
        self.assertFalse(sources.add_source(cfg, sources.custom_source(W[1])))

    def test_migrate_kind(self):
        cfg = copy.deepcopy(DEFAULTS)
        for s in cfg["sources"]:
            s.pop("kind")
        cfg["sources"].append({"name": "Касса", "window": {"process_regex": "kassa"}, "steps": []})
        cfg["app"]["config_version"] = "2.1.9"
        notes = migrate(cfg)
        self.assertEqual([s["kind"] for s in cfg["sources"]], ["oasys", "ivms", "custom"])
        self.assertEqual(cfg["app"]["config_version"], "2.2.0")
        self.assertTrue(any("2.2.0" in n for n in notes))
        self.assertFalse(cfg["summary"]["enabled"])

    def test_set_enabled(self):
        cfg = copy.deepcopy(DEFAULTS)
        sources.set_enabled_kinds(cfg, {"oasys"})
        self.assertEqual([s["enabled"] for s in cfg["sources"]], [True, False])
