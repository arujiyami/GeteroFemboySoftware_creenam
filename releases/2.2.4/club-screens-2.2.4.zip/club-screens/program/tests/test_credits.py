# Original-Author: Владислав С.
# Created: 2026-10-28
"""Строки об авторе и участниках одинакова в коде, README и AUTHORS.txt."""
import os
import unittest

from app import AUTHOR_LINE, CONTRIBUTOR_LINE

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class Credits(unittest.TestCase):
    def test_exact_line(self):
        self.assertEqual(CONTRIBUTOR_LINE, "Помогал с кодом — Grok Bot")

    def test_in_docs(self):
        for name in ("README.md", "AUTHORS.txt"):
            with open(os.path.join(ROOT, name), encoding="utf-8") as f:
                text = f.read()
                self.assertIn(CONTRIBUTOR_LINE, text, name)
                self.assertIn(AUTHOR_LINE, text, name)
                self.assertLess(text.index(AUTHOR_LINE), text.index(CONTRIBUTOR_LINE), name)


if __name__ == "__main__":
    unittest.main()
