# Original-Author: Владислав С.
# Created: 2026-10-28
"""Проверка встроенного браузера на Qt без экрана (QT_QPA_PLATFORM=offscreen).

  python tests/qt_smoke.py          — локальная копия «ВК»: список бесед, отправка 2 фото одним сообщением
  python tests/qt_smoke.py --public — плюс открытая страница vk.com без входа (должно быть «не вошли»)
                                      и её снимок с фоновой страницы
  --no-save-memory                  — проверить без «Экономить память»

Ещё проверяет память: страницы создаются по требованию и закрываются, процессы страниц завершаются.

Ни в какие учётные записи не входит; на vk.com только открывает главную страницу."""
import functools
import http.server
import os
import re
import sys
import tempfile
import threading
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from app.ui.browser import chromium_flags  # noqa: E402

SAVE_MEMORY = "--no-save-memory" not in sys.argv
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = chromium_flags(os.environ.get("QTWEBENGINE_CHROMIUM_FLAGS", "") +
                                                          " --no-sandbox", SAVE_MEMORY)


def proc_tree():
    """Процессы программы (Linux /proc): [(pid, тип, RSS МБ)]; тип — browser/renderer/gpu-process/…"""
    kids, info = {}, {}
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/stat") as f:
                st = f.read()
            ppid = int(st.rsplit(")", 1)[1].split()[1])
            with open(f"/proc/{d}/cmdline", "rb") as f:
                cmd = f.read().replace(b"\0", b" ").decode("utf-8", "replace")
            with open(f"/proc/{d}/status") as f:
                rss = next((int(x.split()[1]) for x in f if x.startswith("VmRSS:")), 0) / 1024
        except (OSError, ValueError, IndexError):
            continue
        kids.setdefault(ppid, []).append(int(d))
        m = re.search(r"--type=([\w-]+)", cmd)
        info[int(d)] = (m.group(1) if m else "browser", rss)
    out, todo = [], [(os.getpid(), None)]
    while todo:
        p, parent = todo.pop()
        if p in info:
            kind = info[p][0]
            if kind == "zygote" and parent == "zygote":
                kind = "renderer"  # страницы порождает zygote, командная строка у них остаётся «zygote»
            out.append((p, kind, info[p][1]))
            todo.extend((k, kind) for k in kids.get(p, []))
    return out


def wait_renderers_gone(what, limit=15):
    """Процесс страницы завершается не мгновенно — ждём до limit секунд."""
    t = time.monotonic()
    while True:
        time.sleep(1)
        pr = proc_tree()
        if not any(k == "renderer" for _, k, _ in pr) or time.monotonic() - t > limit:
            r = mem_report(what)
            r["sec"] = round(time.monotonic() - t, 1)
            return r


def mem_report(what):
    pr = proc_tree()
    total = sum(r for _, _, r in pr)
    renderers = sum(1 for _, t, _ in pr if t == "renderer")
    kinds = {}
    for _, t, r in pr:
        kinds[t] = kinds.get(t, 0) + r
    print(f"ПАМЯТЬ {what}: всего {total:.0f} МБ, процессов {len(pr)}, страниц (renderer) {renderers}; "
          + ", ".join(f"{k} {v:.0f}" for k, v in sorted(kinds.items())), flush=True)
    return {"total": total, "renderers": renderers, "n": len(pr)}


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):  # noqa: N802
        if re.match(r"^/im/convo/\d+", self.path):
            self.path = "/convo.html"
        elif self.path.startswith("/im"):
            self.path = "/im.html"
        elif self.path in ("/", ""):
            self.path = "/im.html"
        return super().do_GET()


def serve():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Handler, directory=os.path.join(HERE, "fake_vk")))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def make_pngs(d):
    from PIL import Image
    out = []
    for n, c in (("01_Oasys.png", "red"), ("02_iVMS-4200.png", "blue")):
        p = os.path.join(d, n)
        Image.new("RGB", (64, 48), c).save(p)
        out.append(p)
    return out


def main():
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication

    from app.config import DEFAULTS, deep_merge
    from app.ui.browser import VKBrowser
    from app.vk_browser import BrowserVKSender, Flows

    from PySide6.QtCore import QObject, Qt, Signal

    class Quit(QObject):
        go = Signal()

    class Invoker(QObject):
        call = Signal(object)

    app = QApplication(sys.argv)
    invoker = Invoker()
    invoker.call.connect(lambda fn: fn(), Qt.ConnectionType.QueuedConnection)
    quitter = Quit()
    quitter.go.connect(app.quit, Qt.ConnectionType.QueuedConnection)
    tmp = tempfile.mkdtemp()
    srv = serve()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    cfg = deep_merge(DEFAULTS, {
        "storage": {"log_file": os.path.join(tmp, "logs", "app.log")},
        "vk": {"peer_id": 2000000001},
        "vk_browser": {"profile_dir": os.path.join(tmp, "profile"), "home_url": base + "/", "im_url": base + "/im",
                       "chat_url": base + "/im/convo/{peer_id}", "login_cookies": [], "pause_min_sec": 0.1,
                       "pause_max_sec": 0.2, "upload_fallback_wait_sec": 2, "save_memory": SAVE_MEMORY}})
    b = VKBrowser(lambda: cfg)
    b.holder.resize(1000, 700)
    results, fails = {}, []

    def check(name, cond, info=""):
        print(("OK   " if cond else "FAIL ") + name, info)
        if not cond:
            fails.append(name)

    import time
    t0 = time.monotonic()

    def mark(what):
        print(f"[{time.monotonic() - t0:6.1f} с] {what}", flush=True)

    def gui(fn):
        """Выполнить fn в потоке окна и дождаться."""
        ev, box = threading.Event(), {}

        def run():
            try:
                box["r"] = fn()
            finally:
                ev.set()
        invoker.call.emit(run)
        ev.wait(30)
        return box.get("r")

    def worker():
        try:
            time.sleep(2)
            results["mem_idle"] = mem_report("без страниц (ожидание)")
            results["views_idle"] = (b.view is None, b.work_view is None)
            fl = Flows(b.settings())
            results["status"] = b.run_blocking(lambda: fl.login_status(navigate=True), 60)
            mark("chats")
            results["chats"] = b.run_blocking(lambda: fl.list_chats(15), 60)
            mark("send")
            results["send"] = BrowserVKSender(b, cfg).send_photos(2000000001, make_pngs(tmp), "Клуб 12:00")
            box = {}
            pngs = make_pngs(tmp)

            def send_and_read():
                # фоновая страница живёт только на время сценария — проверяем в том же сценарии
                r = yield from Flows(b.settings()).send(2000000001, pngs, "Клуб 12:00")
                mem = mem_report("во время отправки")
                v = yield ("js", "JSON.stringify({v: JSON.parse(document.body.getAttribute('data-sent') || '[]')})",
                           "x", {})
                return r, v, mem
            mark("sent")
            results["send2"], results["sent"], results["mem_send"] = b.run_blocking(send_and_read, 120)
            results["mem_after"] = wait_renderers_gone("после отправки")
            results["work_gone"] = b.work_view is None
            try:
                b.run_blocking(lambda: fl.open_chat(peer_id=None, title="Нет такой"), 60)
            except Exception as e:  # noqa: BLE001
                results["missing"] = e
            # заранее открытая беседа (за 5 минут до отправки): одна загрузка, потом отправка в ней же
            import logging
            seen = []

            class Grab(logging.Handler):
                def emit(self, rec):
                    seen.append(rec.getMessage())
            logging.getLogger("club").addHandler(Grab())
            logging.getLogger("club").setLevel(logging.INFO)
            pw_done = threading.Event()
            gui(lambda: b.prewarm(Flows(b.settings()).prewarm(2000000001), lambda r, e: (
                results.__setitem__("prewarm", (r, e)), pw_done.set()), 600))
            pw_done.wait(60)
            time.sleep(1)
            results["warm"] = (b.warm, b.work_view is not None)
            results["mem_warm"] = mem_report("беседа открыта заранее")
            results["send_warm"] = BrowserVKSender(b, cfg).send_photos(2000000001, pngs, "Клуб 13:00")
            results["reused"] = any("уже открыта заранее" in m for m in seen)
            print("журнал:", [m for m in seen if "заранее" in m], flush=True)
            results["mem_after_warm"] = wait_renderers_gone("после отправки в заранее открытой беседе")
            results["warm_after"] = (b.warm, b.work_view is not None)
            mark("box")
            results["box"] = box
            if "--public" in sys.argv:
                pub = deep_merge(DEFAULTS, {"storage": cfg["storage"]})
                from app.vk_browser import merged_settings

                def public():
                    st = yield from Flows(merged_settings(pub)).login_status(navigate=True)
                    yield ("sleep", 2)
                    png = yield ("shot", "public")
                    url = yield ("js", "JSON.stringify({v: location.href + ' | ' + document.visibilityState})",
                                 "x", {})
                    return st, png, url
                results["public"], results["public_png"], results["public_url"] = b.run_blocking(public, 120)
                mark("public_url")
                # настоящий vk.ru регистрирует service worker — он держит процесс страницы ещё какое-то время
                # после закрытия; проверяем, что процесс всё-таки завершается сам
                results["mem_after_public"] = wait_renderers_gone("после публичной страницы vk.ru", limit=120)
            # видимая страница: создаётся при открытии раздела и выгружается при уходе
            gui(lambda: b.ensure_view())
            time.sleep(4)
            results["mem_view"] = mem_report("открыт раздел «ВКонтакте»")
            results["view_url"] = gui(lambda: b.current_url())
            results["unload"] = gui(lambda: b.unload_view())
            print("выгрузка:", results["unload"], "busy:", b._busy, "вид:", b.view, flush=True)
            results["mem_unloaded"] = wait_renderers_gone("раздел закрыт (страница выгружена)")
            mark("готово")
        except Exception as e:  # noqa: BLE001
            results["error"] = e
        finally:
            quitter.go.emit()  # из рабочего потока — только через сигнал

    threading.Thread(target=worker, daemon=True).start()
    QTimer.singleShot(240000, app.quit)
    app.exec()
    if "error" in results:
        import traceback
        traceback.print_exception(results["error"])
    check("состояние: вошли", (results.get("status") or {}).get("state") == "ok", results.get("status"))
    check("имя из страницы", (results.get("status") or {}).get("name") == "Иван Иванов")
    chats = results.get("chats") or []
    check("список бесед", [c["peer_id"] for c in chats][:2] == [2000000001, 2000000005], [c["title"] for c in chats])
    check("отправка подтверждена", results.get("send") == "verified", results.get("send"))
    sent = results.get("sent") or []
    check("одно сообщение, 2 фото по порядку", len(sent) == 1 and sent[0]["names"] == ["01_Oasys.png", "02_iVMS-4200.png"], sent)
    check("подпись", bool(sent) and sent[0]["text"] == "Клуб 12:00")
    check("отправка (в одном сценарии с проверкой)", results.get("send2") == "verified", results.get("send2"))
    if SAVE_MEMORY:
        check("при запуске страниц нет", results.get("views_idle") == (True, True), results.get("views_idle"))
        mi, ms, ma = results.get("mem_idle") or {}, results.get("mem_send") or {}, results.get("mem_after") or {}
        check("без страниц нет процессов страниц", mi.get("renderers") == 0, mi)
        check("во время отправки есть процесс страницы", ms.get("renderers", 0) >= 1, ms)
        check("после отправки процесс страницы завершился", ma.get("renderers") == 0, ma)
        check("фоновая страница закрыта", results.get("work_gone") is True)
        mv, mu = results.get("mem_view") or {}, results.get("mem_unloaded") or {}
        check("раздел «ВКонтакте» создаёт страницу", mv.get("renderers", 0) >= 1, (mv, results.get("view_url")))
        check("уход из раздела выгружает страницу", mu.get("renderers") == 0, mu)
    if "--public" in sys.argv and SAVE_MEMORY:
        mp = results.get("mem_after_public") or {}
        check("после закрытия vk.ru процесс страницы завершается сам (≤120 с)", mp.get("renderers") == 0, mp)
    check("заранее: беседа открыта и оставлена", results.get("prewarm", (None,))[0] == "ready"
          and results.get("warm") == (True, True), (results.get("prewarm"), results.get("warm")))
    check("заранее: процесс страницы жив до отправки", (results.get("mem_warm") or {}).get("renderers", 0) >= 1)
    check("заранее: отправка без повторной загрузки", results.get("send_warm") == "verified"
          and results.get("reused"), (results.get("send_warm"), results.get("reused")))
    if SAVE_MEMORY:
        check("заранее: после отправки страница закрыта", results.get("warm_after") == (False, False)
              and (results.get("mem_after_warm") or {}).get("renderers") == 0,
              (results.get("warm_after"), results.get("mem_after_warm")))
    check("беседа по названию не найдена → понятная ошибка", "missing" in results, repr(results.get("missing")))
    if "--public" in sys.argv:
        st = results.get("public") or {}
        check("vk.com без входа → «не вошли»", st.get("state") == "logged_out", f"{st} {results.get('public_url')}")
        png = results.get("public_png")
        ok_png, info = False, png
        if png and os.path.exists(png):
            from PIL import Image
            im = Image.open(png).convert("RGB")
            colors = len(set(im.resize((160, 112)).getdata()))
            ok_png, info = colors > 50, f"{png} {im.size} цветов: {colors}"
        check("снимок фоновой страницы не пустой (окно программы скрыто)", ok_png, info)
    b.close()
    srv.shutdown()
    print("ИТОГО:", "все проверки пройдены" if not fails else f"ошибки: {fails}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
