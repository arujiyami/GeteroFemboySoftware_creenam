# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.4/2.1.5: обратный отсчёт перед съёмкой вместо уведомлений Windows — время показа/скрытия, текст,
ползунок 0…60 с (0 — без отсчёта), перенос старых настроек, ранний старт с блокировкой ввода,
окошко Qt (без Windows: QT_QPA_PLATFORM=offscreen)."""
import copy
import os
import threading
import unittest
from datetime import datetime, timedelta

from app import scheduler as sch_mod
from app.config import DEFAULTS, migrate, validate
from app.scheduler import (HourlyScheduler, countdown_clock, countdown_due, countdown_hint, countdown_left,
                           countdown_opacity, countdown_seconds, countdown_settings, countdown_text,
                           countdown_visible)

T = datetime(2026, 10, 29, 0, 0)        # плановая съёмка (через полночь — тоже проверяем)


def at(sec_before):
    return T - timedelta(seconds=sec_before)


class Timing(unittest.TestCase):
    def test_due_window(self):
        self.assertFalse(countdown_due(at(60.5), T, 60))           # рано
        self.assertTrue(countdown_due(at(60), T, 60))               # ровно за минуту
        self.assertTrue(countdown_due(at(30), T, 60))               # запустили программу позже — показываем остаток
        self.assertTrue(countdown_due(at(3), T, 60))
        self.assertFalse(countdown_due(at(2.9), T, 60))             # слишком поздно, не мелькаем
        self.assertFalse(countdown_due(T, T, 60))
        self.assertFalse(countdown_due(at(30), T, 60, shown_for=T))  # уже показан для этой съёмки
        self.assertTrue(countdown_due(at(30), T, 60, shown_for=T - timedelta(hours=1)))
        self.assertFalse(countdown_due(at(30), T, 0))               # выключен
        self.assertFalse(countdown_due(at(30), None, 60))
        self.assertTrue(countdown_due(at(15), T, 15))
        self.assertFalse(countdown_due(at(16), T, 15))
        self.assertTrue(countdown_due(at(1), T, 1))                 # 1 секунда — тоже показываем

    def test_visible_until_just_before_capture(self):
        self.assertTrue(countdown_visible(at(59), T))
        self.assertTrue(countdown_visible(at(0.5), T))
        self.assertFalse(countdown_visible(at(0.3), T))
        self.assertFalse(countdown_visible(T, T))
        self.assertFalse(countdown_visible(T + timedelta(seconds=1), T))
        self.assertFalse(countdown_visible(at(10), None))
        self.assertAlmostEqual(countdown_left(at(12.5), T), 12.5)

    def test_text_counts_down_every_second(self):
        self.assertEqual(countdown_text(59.9), "Съём скриншотов через 0:59")
        self.assertEqual(countdown_text(60), "Съём скриншотов через 1:00")
        self.assertEqual(countdown_text(9.2), "Съём скриншотов через 0:09")
        self.assertEqual(countdown_text(0.4), "Съём скриншотов через 0:00")
        self.assertEqual(countdown_clock(-3), "0:00")
        self.assertEqual(countdown_clock(299), "4:59")
        seen = [countdown_text(countdown_left(at(60) + timedelta(seconds=s + 0.5), T)) for s in range(60)]
        self.assertEqual(seen[0], "Съём скриншотов через 0:59")
        self.assertEqual(seen[-1], "Съём скриншотов через 0:00")
        self.assertEqual(len(set(seen)), 60)                       # каждую секунду новая цифра

    def test_hint(self):
        self.assertEqual(countdown_hint(""), "")
        self.assertEqual(countdown_hint(None), "")
        self.assertIn("Разблокировать: Ctrl+Alt+Q", countdown_hint("Ctrl+Alt+Q"))


class Settings(unittest.TestCase):
    def test_clamps(self):
        # 2.1.5: ползунок 0…60 с, шаг 1; 0 — без отсчёта
        self.assertEqual([countdown_seconds(v) for v in (60, 5, 999, "45", "x", None, 30.6, 0, -4, 15, 1)],
                         [60, 5, 60, 45, 60, 60, 31, 0, 0, 15, 1])
        self.assertEqual([countdown_opacity(v) for v in (75, "80%", 0, 150, "abc")], [75, 80, 30, 100, 75])

    def test_from_config(self):
        self.assertEqual(countdown_settings(DEFAULTS), (60, 75))
        self.assertEqual(countdown_settings({}), (60, 75))
        self.assertEqual(countdown_settings({"countdown": {"seconds": 400, "opacity": 10}}), (60, 30))
        self.assertEqual(countdown_settings({"countdown": {"seconds": 15}}), (15, 75))
        # старый флажок «выключено» (до 2.1.5) — то же, что 0
        self.assertEqual(countdown_settings({"countdown": {"enabled": False, "seconds": 45}}), (0, 75))
        self.assertNotIn("enabled", DEFAULTS["countdown"])
        self.assertEqual(validate(DEFAULTS), [])

    def test_validate_range(self):
        for v, ok in ((0, True), (1, True), (60, True), (61, False), (-1, False), (True, False), ("15", False)):
            cfg = copy.deepcopy(DEFAULTS)
            cfg["countdown"]["seconds"] = v
            self.assertEqual(not validate(cfg), ok, v)

    def test_default_yaml_and_shipped_config(self):
        from app.config import DEFAULT_CONFIG_YAML
        self.assertIn("countdown:", DEFAULT_CONFIG_YAML)
        self.assertIn("0 — не показывать", DEFAULT_CONFIG_YAML)
        self.assertNotIn("notifications:", DEFAULT_CONFIG_YAML)
        path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.yaml")
        with open(path, encoding="utf-8") as f:
            self.assertEqual(f.read().strip(), DEFAULT_CONFIG_YAML.strip())

    def test_old_api_removed(self):
        for name in ("notice_text", "notice_due", "notice_minutes", "DEFAULT_NOTICE_MINUTES"):
            self.assertFalse(hasattr(sch_mod, name), name)


class Migration(unittest.TestCase):
    def old(self, **notifications):
        cfg = copy.deepcopy(DEFAULTS)          # так load_config: DEFAULTS + файл пользователя
        cfg["notifications"] = notifications
        return cfg

    def test_old_enabled_becomes_countdown_on(self):
        cfg = self.old(enabled=True, minutes=[5, 1])
        notes = migrate(cfg)
        self.assertNotIn("notifications", cfg)
        self.assertEqual(cfg["countdown"], {"seconds": 60, "opacity": 75})
        self.assertTrue(any("обратным отсчётом" in n for n in notes), notes)
        self.assertEqual(migrate(cfg), [])                     # повторно — ничего
        self.assertEqual(validate(cfg), [])

    def test_old_disabled_keeps_off(self):
        cfg = self.old(enabled=False, minutes=[10])
        notes = migrate(cfg)
        self.assertEqual(cfg["countdown"]["seconds"], 0)
        self.assertNotIn("enabled", cfg["countdown"])
        self.assertTrue(any("выключен" in n for n in notes), notes)
        self.assertEqual(migrate(cfg), [])
        self.assertEqual(validate(cfg), [])

    def test_214_disabled_flag_becomes_zero(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg["countdown"] = {"enabled": False, "seconds": 30, "opacity": 70}
        notes = migrate(cfg)
        self.assertEqual(cfg["countdown"], {"seconds": 0, "opacity": 70})
        self.assertTrue(any("0 секунд" in n for n in notes), notes)

    def test_214_long_countdown_clamped_to_60(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg["countdown"] = {"enabled": True, "seconds": 120, "opacity": 75}
        notes = migrate(cfg)
        self.assertEqual(cfg["countdown"], {"seconds": 60, "opacity": 75})
        self.assertTrue(any("не длиннее 60" in n for n in notes), notes)
        self.assertEqual(validate(cfg), [])

    def test_other_settings_preserved(self):
        cfg = self.old(enabled=True)
        cfg["input_lock"]["hotkey"] = "Ctrl+Shift+U"
        cfg["schedule"]["minute"] = 0
        cfg["countdown"]["seconds"] = 15
        cfg["countdown"]["opacity"] = 60
        migrate(cfg)
        self.assertEqual(cfg["input_lock"]["hotkey"], "Ctrl+Shift+U")
        self.assertEqual(cfg["countdown"], {"seconds": 15, "opacity": 60})

    def test_garbage_old_section(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg["notifications"] = "да"
        migrate(cfg)
        self.assertNotIn("notifications", cfg)
        self.assertEqual(cfg["countdown"]["seconds"], 60)

    def test_load_old_file(self):
        import tempfile
        from app import config as cmod
        old_yaml = cmod.DEFAULT_CONFIG_YAML.replace(
            "countdown:\n", "notifications:\n  enabled: false\n  minutes: [5, 1]\ncountdown:\n  enabled: true\n")
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "config.yaml")
            with open(path, "w", encoding="utf-8") as f:
                f.write(old_yaml)
            cfg = cmod.load_config(path)
            migrate(cfg)
        self.assertNotIn("notifications", cfg)
        self.assertEqual(cfg["countdown"]["seconds"], 0)


class SchedulerIntegration(unittest.TestCase):
    def _run(self, start, seconds_setting=60, seconds=900, step=1.0):
        clock = {"t": start}
        events = []
        done = threading.Event()
        sch = HourlyScheduler(lambda: events.append(("run", clock["t"])),
                              lambda: {"minute": 0, "max_delay_sec": 600}, now=lambda: clock["t"],
                              countdown=lambda target: events.append(("countdown", clock["t"], target)),
                              countdown_seconds=lambda: seconds_setting)
        real = sch._stop

        class Tick:
            is_set = real.is_set
            clear = real.clear
            set = real.set

            def wait(self, sec):
                clock["t"] += timedelta(seconds=step)
                if clock["t"] >= start + timedelta(seconds=seconds):
                    real.set()
                    done.set()
                return real.is_set()
        sch._stop = Tick()
        sch.start()
        done.wait(10)
        sch._thread.join(10)
        return events

    def test_once_a_minute_before_then_runs_over_midnight(self):
        ev = self._run(datetime(2026, 10, 28, 23, 57, 0), seconds=300)
        self.assertEqual([e[0] for e in ev], ["countdown", "run"])
        self.assertEqual(ev[0][2], T)
        left = countdown_left(ev[0][1], T)
        self.assertTrue(59 <= left <= 60, left)
        self.assertGreaterEqual(ev[1][1], T)

    def test_custom_length(self):
        ev = self._run(datetime(2026, 10, 28, 23, 57, 0), seconds_setting=15, seconds=300)
        self.assertTrue(14 <= countdown_left(ev[0][1], T) <= 15)

    def test_one_second(self):
        ev = self._run(datetime(2026, 10, 28, 23, 59, 0), seconds_setting=1, seconds=120, step=0.25)
        self.assertEqual([e[0] for e in ev], ["countdown", "run"])
        self.assertTrue(0.5 <= countdown_left(ev[0][1], T) <= 1, ev[0])

    def test_started_late_shows_rest_or_nothing(self):
        ev = self._run(at(20), seconds=60)
        self.assertEqual([e[0] for e in ev], ["countdown", "run"])
        self.assertEqual([e[0] for e in self._run(at(2), seconds=60)], ["run"])

    def test_off(self):
        self.assertEqual([e[0] for e in self._run(datetime(2026, 10, 28, 23, 58), seconds_setting=0,
                                                  seconds=180)], ["run"])

    def test_next_hour_again(self):
        ev = self._run(datetime(2026, 10, 28, 5, 58, 30), seconds=3700, step=5)
        self.assertEqual([e[0] for e in ev], ["countdown", "run", "countdown", "run"])


class LiveAndEarly(unittest.TestCase):
    """2.1.5: длина отсчёта меняется на лету; ранний старт цикла за early секунд до съёмки."""

    def _run(self, start, seconds_fn, early=None, seconds=300, step=0.25, on_tick=None):
        clock = {"t": start}
        events = []
        done = threading.Event()
        job = (lambda target: events.append(("run", clock["t"], target))) if early is not None else \
            (lambda: events.append(("run", clock["t"], None)))
        sch = HourlyScheduler(job, lambda: {"minute": 0, "max_delay_sec": 600}, now=lambda: clock["t"],
                              countdown=lambda target: events.append(("countdown", clock["t"], target)),
                              countdown_seconds=seconds_fn,
                              early_seconds=(lambda: early) if early is not None else None)
        real = sch._stop

        class Tick:
            is_set = real.is_set
            clear = real.clear
            set = real.set

            def wait(self, sec):
                clock["t"] += timedelta(seconds=step)
                if on_tick:
                    on_tick(clock["t"])
                if clock["t"] >= start + timedelta(seconds=seconds):
                    real.set()
                    done.set()
                return real.is_set()
        sch._stop = Tick()
        sch.start()
        done.wait(20)
        sch._thread.join(20)
        return events

    def test_regression_15_instead_of_60_applies_without_restart(self):
        # Ошибка 2.1.4: поставили 15 с, а окошко всё равно появилось за 60 с. Значение читается
        # заново на каждом шаге планировщика — меняем его «на ходу», за 5 минут до съёмки.
        cfg = {"countdown": {"seconds": 60, "opacity": 75}}

        def change(t):
            if t >= at(240):
                cfg["countdown"]["seconds"] = 15
        ev = self._run(at(300), lambda: countdown_settings(cfg)[0], seconds=320, on_tick=change)
        shows = [e for e in ev if e[0] == "countdown"]
        self.assertEqual(len(shows), 1)
        self.assertTrue(14.5 <= countdown_left(shows[0][1], T) <= 15, shows)

    def test_slider_zero_disables(self):
        ev = self._run(at(120), lambda: 0, seconds=140)
        self.assertEqual([e[0] for e in ev], ["run"])

    def test_early_start_five_seconds_before(self):
        ev = self._run(at(90), lambda: 30, early=5, seconds=120)
        self.assertEqual([e[0] for e in ev], ["countdown", "run"])
        lock = T - timedelta(seconds=5)
        # отсчёт — за 30 с до блокировки ввода, цикл — за 5 с до съёмки, снимок — в T
        self.assertTrue(29.5 <= countdown_left(ev[0][1], lock) <= 30, ev[0])
        self.assertEqual(ev[0][2], T)
        self.assertTrue(lock <= ev[1][1] <= lock + timedelta(seconds=0.5), ev[1])
        self.assertEqual(ev[1][2], T)

    def test_early_start_not_repeated_for_same_target(self):
        ev = self._run(at(30), lambda: 10, early=5, seconds=60)
        runs = [e for e in ev if e[0] == "run"]
        self.assertEqual(len(runs), 1)
        self.assertEqual(runs[0][2], T)

    def test_early_zero_runs_at_capture_time(self):
        ev = self._run(at(20), lambda: 0, early=0, seconds=40)
        runs = [e for e in ev if e[0] == "run"]
        self.assertEqual(len(runs), 1)
        self.assertTrue(T <= runs[0][1] <= T + timedelta(seconds=0.5))

    def test_lock_helpers(self):
        from app.scheduler import countdown_lock_text, early_seconds, early_settings, lock_at
        self.assertEqual(lock_at(T, 5), T - timedelta(seconds=5))
        self.assertEqual(lock_at(T, 0), T)
        self.assertEqual([early_seconds(v) for v in (5, 0, 15, 16, -1, "x", None, "7")], [5, 0, 15, 15, 0, 5, 5, 7])
        self.assertEqual(early_settings(DEFAULTS), 5)
        self.assertEqual(countdown_lock_text(6.2), "Мышь и клавиатура заблокируются через 7 с")
        self.assertEqual(countdown_lock_text(0), "Мышь и клавиатура заблокируются через 0 с")
        self.assertEqual(countdown_hint("Ctrl+Alt+Q", 4.5),
                         "Мышь и клавиатура заблокируются через 5 с. Разблокировать: Ctrl+Alt+Q")
        for v, ok in ((0, True), (15, True), (16, False), (-1, False)):
            cfg = copy.deepcopy(DEFAULTS)
            cfg["input_lock"]["early_sec"] = v
            self.assertEqual(not validate(cfg), ok, v)


class Overlay(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        try:
            from PySide6.QtWidgets import QApplication
        except ImportError:  # pragma: no cover
            raise unittest.SkipTest("нет PySide6")
        cls.app = QApplication.instance() or QApplication([])

    def make(self, start):
        from app.ui.countdown import CountdownOverlay
        clock = {"t": start}
        w = CountdownOverlay(now=lambda: clock["t"], opacity=75)
        return w, clock

    def test_flags_never_take_focus_or_clicks(self):
        from PySide6.QtCore import Qt
        w, _ = self.make(at(60))
        fl = w.windowFlags()
        for flag in (Qt.WindowType.FramelessWindowHint, Qt.WindowType.WindowStaysOnTopHint,
                     Qt.WindowType.WindowDoesNotAcceptFocus, Qt.WindowType.WindowTransparentForInput):
            self.assertTrue(fl & flag, flag)
        self.assertEqual(fl & Qt.WindowType.Tool, Qt.WindowType.Tool)
        for attr in (Qt.WidgetAttribute.WA_TranslucentBackground, Qt.WidgetAttribute.WA_ShowWithoutActivating,
                     Qt.WidgetAttribute.WA_TransparentForMouseEvents):
            self.assertTrue(w.testAttribute(attr), attr)
        w.close()

    def test_show_tick_hide(self):
        w, clock = self.make(at(60))
        self.assertTrue(w.start(T, "Мышь и клавиатура заблокируются на несколько секунд. Разблокировать: Ctrl+Alt+Q"))
        self.assertTrue(w.isVisible() and w.active)
        self.assertEqual(w.text, "Съём скриншотов через 1:00")
        size = w.size()
        clock["t"] = at(41.5)
        w._tick()
        self.assertEqual(w.text, "Съём скриншотов через 0:41")
        self.assertEqual(w.size(), size)                        # не «прыгает»
        clock["t"] = at(0.2)
        w._tick()
        self.assertFalse(w.isVisible() or w.active)             # исчезло до съёмки
        w.close()

    def test_lock_line_counts_to_lock_and_hides_then(self):
        w, clock = self.make(at(30))
        lock = T - timedelta(seconds=5)
        self.assertTrue(w.start(T, "", 75, lock_at=lock, hotkey="Ctrl+Alt+Q"))
        self.assertEqual(w.text, "Съём скриншотов через 0:30")
        self.assertEqual(w.hint, "Мышь и клавиатура заблокируются через 25 с. Разблокировать: Ctrl+Alt+Q")
        clock["t"] = at(8.5)
        w._tick()
        self.assertEqual(w.hint, "Мышь и клавиатура заблокируются через 4 с. Разблокировать: Ctrl+Alt+Q")
        self.assertEqual(w.text, "Съём скриншотов через 0:08")
        clock["t"] = at(5.2)
        w._tick()
        self.assertFalse(w.isVisible() or w.active)             # исчезло к моменту блокировки
        w.close()

    def test_no_hotkey_no_lock_line(self):
        w, _ = self.make(at(10))
        self.assertTrue(w.start(T, "", 75, lock_at=T - timedelta(seconds=5), hotkey=None))
        self.assertEqual(w.hint, "")
        w.stop()
        w.close()

    def test_bottom_right_of_work_area(self):
        from PySide6.QtGui import QGuiApplication
        from app.ui.countdown import MARGIN
        w, _ = self.make(at(30))
        w.start(T)
        g = QGuiApplication.primaryScreen().availableGeometry()
        geo = w.frameGeometry()
        self.assertEqual(geo.right(), g.right() - MARGIN)
        self.assertEqual(geo.bottom(), g.bottom() - MARGIN)
        self.assertLess(w.width(), g.width() // 2)
        w.stop()
        self.assertFalse(w.isVisible())
        w.close()

    def test_too_late_not_shown_and_restart(self):
        w, clock = self.make(at(0.1))
        self.assertFalse(w.start(T))
        self.assertFalse(w.isVisible())
        clock["t"] = at(30) + timedelta(hours=1)
        self.assertTrue(w.start(T + timedelta(hours=1), opacity=40))
        self.assertEqual(w.opacity, 40)
        img = w.grab().toImage()                                 # рисуется без ошибок
        self.assertFalse(img.isNull())
        w.stop()
        w.close()

    def test_win_helper_noop_elsewhere(self):
        import sys
        from app.ui.countdown import win_click_through
        if sys.platform != "win32":
            self.assertEqual(win_click_through(123), (False, False))
        self.assertEqual(win_click_through(0), (False, False))


if __name__ == "__main__":
    unittest.main()
