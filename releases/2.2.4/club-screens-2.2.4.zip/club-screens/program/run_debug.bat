@echo off
rem Original-Author: Vladislav S.
rem Created: 2026-10-28
chcp 65001 >nul
cd /d "%~dp0"
rem Запуск с консолью: видны все сообщения. Пример: run_debug.bat --run-once
".venv\Scripts\python.exe" main.py %*
pause
