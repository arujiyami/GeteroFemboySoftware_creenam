@echo off
rem Original-Author: Vladislav S.
rem Created: 2026-10-28
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Сначала запустите УСТАНОВИТЬ.bat - он лежит в папке выше.
  pause
  exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" main.py %*
