@echo off
rem Original-Author: Vladislav S.
rem Created: 2026-10-28
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Сначала запустите УСТАНОВИТЬ.bat - он лежит в папке выше.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install pyinstaller
rem --version-file: свойства ClubScreens.exe (автор, версия 2.2.0) — файл version_info.txt.
rem --uac-admin: ClubScreens.exe сразу просит права администратора (нужно для нажатий в iVMS-4200).
rem Qt WebEngine (встроенный браузер) PyInstaller забирает сам через свои hook-файлы PySide6.
rem --collect-all winrt: пауза музыки и видео на время съёма (пакеты winrt-*, их .pyd и msvcp140.dll).
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --uac-admin ^
  --version-file version_info.txt ^
  --name ClubScreens ^
  --hidden-import PySide6.QtWebEngineCore --hidden-import PySide6.QtWebEngineWidgets ^
  --hidden-import PySide6.QtNetwork --collect-submodules win32com ^
  --collect-all winrt --hidden-import winrt.windows.media.control ^
  --hidden-import winrt.windows.foundation --hidden-import winrt.windows.foundation.collections main.py
if errorlevel 1 (
  echo Сборка не удалась.
  pause
  exit /b 1
)
if not exist "dist\ClubScreens\config.yaml" copy /y config.yaml "dist\ClubScreens\" >nul
xcopy /e /i /y templates "dist\ClubScreens\templates" >nul
copy /y ..\README.md "dist\ClubScreens\" >nul
if exist "..\Инструкция.pdf" copy /y "..\Инструкция.pdf" "dist\ClubScreens\" >nul
echo.
echo Готово: папка dist\ClubScreens, запускать ClubScreens.exe
echo Эту папку можно копировать на другой компьютер - Python там не нужен.
echo Папку browser_profile (вход ВК) НЕ копируйте и никому не передавайте.
pause
