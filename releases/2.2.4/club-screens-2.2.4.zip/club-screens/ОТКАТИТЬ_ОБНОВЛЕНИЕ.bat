@echo off
rem Original-Author: Vladislav S.
rem Created: 2026-10-28
chcp 65001 >nul
setlocal EnableExtensions
title Откат обновления
set "ROOT=%~dp0"
if not exist "%ROOT%backup_prev\program\main.py" (echo Предыдущей версии нет - откатывать нечего. & pause & exit /b 1)
echo Закройте программу (значок у часов - Выход) и нажмите любую клавишу.
pause >nul
robocopy "%ROOT%backup_prev" "%ROOT%." /E /NFL /NDL /NJH /NJS >nul
if exist "%ROOT%program\.venv\Scripts\python.exe" "%ROOT%program\.venv\Scripts\python.exe" -m pip install -q -r "%ROOT%program\requirements.txt"
echo Предыдущая версия возвращена. Ваши настройки и вход в ВК не тронуты.
start "" "%ROOT%program\run.bat"
exit /b 0
