# Original-Author: Владислав С.
# Created: 2026-11-01
"""3.0.11: картинка, «найденная» далеко от места записи (живое видео в ней), не используется; записанный
щелчок по Cancel не повторяется, когда вопроса iVMS не было."""
import os
import tempfile
import unittest

from app import __version__
from app.steps import Context, StepRunner
from tests.test_v309 import Be


class Run3011(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        for n in ("step01.png", "step02.png", "step04.png", "step05.png"):
            open(os.path.join(self.dir, n), "wb").close()

    def run_steps(self, be, steps):
        r = StepRunner(be, lambda p: os.path.join(self.dir, p), sleep=lambda s: None)
        ctx = Context({"name": "iVMS-4200", "kind": "ivms"})
        ctx.hwnd = 7
        r.run_steps(steps, ctx)
        return ctx

    @staticmethod
    def img(t, x, y, double=False):
        fb = {"type": "click_xy", "x": x, "y": y, "units": "pixels"}
        st = {"type": "click_image", "template": t, "fallback": dict(fb, double=True) if double else fb}
        if double:
            st["double"] = True
        return st

    VIEW = property(lambda self: self.img("step02.png", 118, 196, True))
    CANCEL = property(lambda self: self.img("step04.png", 1070, 549))
    FULL = property(lambda self: self.img("step05.png", 1836, 977))

    def test_far_match_uses_recorded_place(self):
        be = Be({"step05.png": (853, 528)})          # совпадение в видео с камер
        self.run_steps(be, [self.FULL])
        self.assertEqual(be.clicks, [(1836, 977, False)])

    def test_near_match_used(self):
        be = Be({"step05.png": (1840, 985)})
        self.run_steps(be, [self.FULL])
        self.assertEqual(be.clicks, [(1840, 985, False)])

    def test_no_dialog_recorded_cancel_skipped(self):
        be = Be({"step02.png": (120, 198), "step05.png": (1838, 980)}, dialog="none")
        self.run_steps(be, [self.VIEW, {"type": "wait", "seconds": 1}, self.CANCEL, self.FULL])
        self.assertEqual(be.clicks, [(120, 198, True), (1838, 980, False)])

    def test_no_dialog_edge_step_still_falls_back(self):
        be = Be({"step02.png": (120, 198)}, dialog="none")
        self.run_steps(be, [self.VIEW, self.FULL])     # кнопка у края окна — не Cancel
        self.assertIn((1836, 977, False), be.clicks)

    def test_center_step_without_view_falls_back(self):
        be = Be()
        self.run_steps(be, [self.CANCEL])
        self.assertEqual(be.clicks, [(1070, 549, False)])

    def test_cursor_parked_after_image_click(self):
        be = Be({"step05.png": (1840, 985)})
        moves, shots = [], []
        be.monitor_rect = lambda h: (0, 0, 1920, 1080)
        be.grab = lambda r: shots.append(r) or __import__("PIL.Image").Image.new("RGB", (r[2], r[3]))
        be.move_cursor = lambda x, y: moves.append((x, y))
        self.run_steps(be, [self.FULL, {"type": "screenshot", "mode": "monitor"}])
        self.assertEqual(moves, [(1919, 1079)])

    def test_recorded_trailing_click_kept_and_cursor_not_moved(self):
        be = Be({"step05.png": (1840, 985)})
        moves, shots = [], []
        be.monitor_rect = lambda h: (0, 0, 1920, 1080)
        be.grab = lambda r: shots.append(r) or __import__("PIL.Image").Image.new("RGB", (r[2], r[3]))
        be.move_cursor = lambda x, y: moves.append((x, y))
        self.run_steps(be, [self.FULL, {"type": "click_xy", "x": 1595, "y": 698, "units": "pixels"},
                            {"type": "screenshot", "mode": "monitor"}])
        self.assertIn((1595, 698, False), be.clicks)     # одиночный, не двойной — полный экран не выключит
        self.assertEqual(moves, [])

    def test_version(self):
        self.assertEqual(__version__, "3.0.13")


if __name__ == "__main__":
    unittest.main()
