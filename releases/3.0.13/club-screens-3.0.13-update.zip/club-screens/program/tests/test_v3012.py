# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.12: двойная отправка в клубе с монитором 4:3 (1280×960).
1) Значок статуса профиля у имени (PeerTitle, «StatusIcon») принимался за статус доставки — галочка не
   находилась, доставка «не подтверждалась».
2) Перед повтором своё сообщение отбрасывалось: «картинки не 16:9 (1.33, 1.33)» — и скрины уходили второй раз."""
import html as H
import json
import os
import re
import shutil
import subprocess
import tempfile
import unittest

from PIL import Image

from app import __version__, dupcheck


def shot(d, name, w, h, color):
    p = os.path.join(d, name)
    import random
    rnd = random.Random(sum(color))
    small = Image.new("L", (32, 24))
    small.putdata([rnd.randrange(256) for _ in range(32 * 24)])
    small.resize((w, h)).convert("RGB").save(p)
    return p


FORMATS = {"4:3": (1280, 960), "16:9": (1920, 1080), "21:9": (2560, 1080), "2 монитора": (3840, 1080),
           "5:4": (1280, 1024), "16:10": (1680, 1050)}


def _preview(w, h):
    """Превью ВК: ширина ~167–510, высота по формату."""
    return {"w": 300, "h": int(round(300 * h / float(w)))}


class AnyMonitor(unittest.TestCase):
    """3.0.12: своё сообщение узнаётся при любом формате монитора — формат картинок не проверяется."""

    def setUp(self):
        from datetime import datetime
        self.d = tempfile.mkdtemp()
        self.since = datetime(2026, 11, 3, 0, 0)
        self.now = datetime(2026, 11, 3, 0, 2)

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def _page(self, w, h, text="", n=2):
        pv = _preview(w, h)
        return {"msgs": [{"own": True, "t": 1, "text": text,
                          "imgs": [dict(pv, src=f"https://x/{i}") for i in range(n)]}]}

    def test_candidates_any_format(self):
        for name, (w, h) in FORMATS.items():
            c, why = dupcheck.candidates(self._page(w, h), self.since, self.now)
            self.assertEqual(len(c), 1, (name, why))

    def test_still_needs_2_pictures_own_and_hour(self):
        c, why = dupcheck.candidates(self._page(1280, 960, n=3), self.since, self.now)
        self.assertEqual(c, [])
        page = self._page(1280, 960)
        page["msgs"][0]["own"] = False
        self.assertEqual(dupcheck.candidates(page, self.since, self.now)[0], [])

    def test_content_match_any_format(self):
        for name, (w, h) in FORMATS.items():
            a = shot(self.d, "o.png", w, h, (200, 30, 30))
            b = shot(self.d, "i.png", w, h, (30, 30, 200))
            data = {u: open(p, "rb").read() for u, p in (("https://a", a), ("https://b", b))}
            pv = _preview(w, h)
            ok, txt = dupcheck.content_match([a, b], [dict(pv, src="https://a"), dict(pv, src="https://b")],
                                             download=data.get)
            self.assertTrue(ok, (name, txt))

    def test_found_by_marker_4_3(self):
        """Метка программы читается из уменьшенного превью ВК и при 4:3, 21:9 и двух мониторах."""
        import io
        from datetime import datetime
        from app import marker
        for name, (w, h) in FORMATS.items():
            ps, raws = [], {}
            for i in range(2):
                src = shot(self.d, f"20261103_0000_s{i}.png", w, h, (i * 50 + 9, 60, 90))
                dst = os.path.join(self.d, f"m{i}.png")
                marker.embed(src, dst, marker.path_key(src), b"salt")
                im = Image.open(dst).convert("RGB")
                pv = _preview(w, h)
                bio = io.BytesIO()
                im.resize((pv["w"] * 2, pv["h"] * 2)).save(bio, "JPEG", quality=80)
                raws[f"https://x/{i}"] = bio.getvalue()
                ps.append(src)
            mark = lambda p, r: marker.present(p, r, marker.path_key(p), b"salt")
            st, why = dupcheck.find_status(self._page(w, h), ps, datetime(2026, 11, 3, 0, 0), self.now,
                                           download=raws.get, mark=mark)
            self.assertEqual(st, dupcheck.FOUND, (name, why))

    def test_version(self):
        self.assertEqual(__version__, "3.0.13")


class Monitors(unittest.TestCase):
    """3.0.12: щелчки и курсор при разных мониторах, двух мониторах (левый — отрицательные координаты)
    и разном масштабе (DPI) — окно другого размера, чем при записи."""

    def test_same_size_unchanged(self):
        from app.steps import scaled_xy
        self.assertEqual(scaled_xy(100, 50, (0, 0, 1920, 1080), [1920, 1080]), (100, 50))
        self.assertEqual(scaled_xy(-10, -20, (0, 0, 1920, 1080), None), (1910, 1060))

    def test_left_monitor_negative(self):
        from app.steps import scaled_xy
        # окно на левом мониторе 1280×960: x от -1280
        self.assertEqual(scaled_xy(100, 50, (-1280, 0, 1280, 960), [1280, 960]), (-1180, 50))
        # верхний монитор
        self.assertEqual(scaled_xy(100, 50, (0, -1080, 1920, 1080), None), (100, -1030))

    def test_scaled_other_size(self):
        from app.steps import scaled_xy
        # записано на 1920×1080, теперь окно 1280×960 (4:3) на левом мониторе
        x, y = scaled_xy(960, 540, (-1280, 0, 1280, 960), [1920, 1080])
        self.assertEqual((round(x), round(y)), (-640, 480))
        # 21:9 и отсчёт от правого нижнего края
        x, y = scaled_xy(-100, -100, (0, 0, 2560, 1080), [1920, 1080])
        self.assertEqual((round(x), round(y)), (2560 - 133, 980))
        # масштаб 150% (окно в 1.5 раза больше физических пикселей)
        x, y = scaled_xy(200, 100, (1920, 0, 2880, 1620), [1920, 1080])
        self.assertEqual((round(x), round(y)), (1920 + 300, 150))

    def test_park_point_inside_ivms_monitor(self):
        from app.steps import park_point
        self.assertEqual(park_point((0, 0, 1920, 1080), (0, 0, 1920, 1080)), (1919, 1079))
        # снимок всего экрана (2 монитора разной высоты) — угол внутри монитора iVMS (левый, отрицательный)
        self.assertEqual(park_point((-1280, 0, 3200, 1080), (-1280, 0, 1280, 960)), (-1, 959))
        self.assertEqual(park_point((-1280, -120, 1280, 960), (-1280, -120, 1280, 960)), (-1, 839))
        self.assertEqual(park_point((10, 10, 100, 100), None), (109, 109))

    def test_runner_click_and_park_on_second_monitor(self):
        from app.steps import Context, StepRunner
        calls = []

        class BE:
            def window_rect(self, h):
                return (-1280, 0, 1280, 960)

            def monitor_rect(self, h):
                return (-1280, 0, 1280, 960)

            def virtual_screen(self):
                return (-1280, 0, 3200, 1080)

            def click(self, x, y, double=False):
                calls.append(("click", x, y))

            def move_cursor(self, x, y):
                calls.append(("move", x, y))

            def grab(self, rect):
                calls.append(("grab", rect))
                return Image.new("RGB", (rect[2], rect[3]))

            def activate(self, h):
                pass
        r = StepRunner.__new__(StepRunner)
        r.backend = BE()
        r.sleep = lambda s: None
        r.now = None
        import inspect
        ctx = Context.__new__(Context)
        for k, v in dict(hwnd=1, name="iVMS", source={"kind": "ivms"}, images=[], warnings=[],
                         cursor_placed=False, just_cancelled=False, no_dialog=False).items():
            setattr(ctx, k, v)
        r._step_click_xy({"type": "click_xy", "x": 960, "y": 540, "units": "pixels", "ref": [1920, 1080]}, ctx)
        self.assertEqual(calls[-1], ("click", -640, 480))
        ctx.cursor_placed = False
        r._park_cursor({}, ctx, r.backend.virtual_screen())
        self.assertEqual(calls[-1], ("move", -1, 959))

    def test_recorder_keeps_window_size(self):
        from app import recorder
        st = recorder.events_to_steps([{"kind": "click", "t": 0, "x": 5, "y": 6}], ref=(1280, 960))
        self.assertEqual(st[0]["ref"], [1280, 960])

    def test_absolute_coords_negative(self):
        from app.backend_win import absolute_coords
        v = (-1280, -120, 3200, 1200)
        self.assertEqual(absolute_coords(-1280, -120, v), (0, 0))
        self.assertEqual(absolute_coords(1919, 1079, v), (65535, 65535))
        x, _ = absolute_coords(0, 0, v)
        self.assertAlmostEqual(x, 1280 * 65535 / 3199, delta=1)

    def test_template_found_scaled(self):
        """Шаблон, записанный при 100%, находится в окне при 125% и 75% масштабе."""
        import numpy as np
        from app import vision
        rnd = np.random.RandomState(3)
        tpl = (rnd.rand(40, 60, 3) * 255).astype("uint8")
        import cv2
        for sc in (1.25, 0.75):
            hay = (rnd.rand(400, 600, 3) * 60).astype("uint8")
            t2 = cv2.resize(tpl, None, fx=sc, fy=sc, interpolation=cv2.INTER_CUBIC)
            hay[100:100 + t2.shape[0], 200:200 + t2.shape[1]] = t2
            f = vision.find_template(hay, tpl, 0.7)
            self.assertIsNotNone(f, sc)
            self.assertLess(abs(f[0] - (200 + t2.shape[1] // 2)), 4)


DOM = """<html><body>
<div class="ConvoHistory__messageWrapper"><div class="ConvoMessageWithoutBubble">
 <div class="PeerTitle"><div class="PeerTitle__title">x</div>
  <div class="StatusIcon--size-14 PeerTitle__icon"><img src="https://sun1-1.userapi.com/s.png"></div></div>
 <div class="ConvoMessageWithoutBubble__mediaAttachments"><div class="AttachPhotos__link">
  <img src="https://sun9-1.vkuserphoto.ru/1.jpg" width="167" height="128">
  <img src="https://sun9-1.vkuserphoto.ru/2.jpg" width="167" height="128"></div></div>
 <div class="ConvoMessageInfoWithoutBubbles"><span class="ConvoMessageInfoWithoutBubbles__statusIcon">
  <svg class="vkuiIcon vkuiIcon--check_outline_16"></svg></span>
  <span class="ConvoMessageInfoWithoutBubbles__date">00:00</span></div>
</div></div></body></html>"""


@unittest.skipUnless(shutil.which("google-chrome") or shutil.which("chromium"), "нет браузера для проверки JS")
class StatusIcon(unittest.TestCase):
    def test_delivery_icon_not_profile_badge(self):
        from app import vk_browser
        doc = DOM.replace("</body>", "<script>" + vk_browser.JS_LIB + ";var R;try{R=F.hour_photos({max:3})}catch(e)"
                          "{R={err:String(e)}};var p=document.createElement('pre');p.id='OUT';"
                          "p.textContent=JSON.stringify(R);document.body.appendChild(p);</script></body>")
        d = tempfile.mkdtemp()
        try:
            f = os.path.join(d, "t.html")
            open(f, "w", encoding="utf-8").write(doc)
            exe = shutil.which("google-chrome") or shutil.which("chromium")
            out = subprocess.run([exe, "--headless=new", "--no-sandbox", "--disable-gpu", "--dump-dom",
                                  "file://" + f], capture_output=True, text=True, timeout=90).stdout
        finally:
            shutil.rmtree(d, ignore_errors=True)
        m = re.search(r'<pre id="OUT">(.*?)</pre>', out, re.S)
        self.assertTrue(m, out[-500:])
        r = json.loads(H.unescape(m.group(1)))
        self.assertEqual([x["st"] for x in r["msgs"]], ["ok"], r)


def run_js(doc, call="F.hour_photos({max:3})"):
    from app import vk_browser
    doc = doc.replace("</body>", "<script>" + vk_browser.JS_LIB + ";var R;try{R=" + call + "}catch(e)"
                      "{R={err:String(e)}};var p=document.createElement('pre');p.id='OUT';"
                      "p.textContent=JSON.stringify(R);document.body.appendChild(p);</script></body>")
    d = tempfile.mkdtemp()
    try:
        f = os.path.join(d, "t.html")
        open(f, "w", encoding="utf-8").write(doc)
        exe = shutil.which("google-chrome") or shutil.which("chromium")
        out = subprocess.run([exe, "--headless=new", "--no-sandbox", "--disable-gpu", "--dump-dom",
                              "file://" + f], capture_output=True, text=True, timeout=90).stdout
    finally:
        shutil.rmtree(d, ignore_errors=True)
    m = re.search(r'<pre id="OUT">(.*?)</pre>', out, re.S)
    return json.loads(H.unescape(m.group(1))) if m else {"err": out[-300:]}


MSG = """<div class="ConvoHistory__messageWrapper"><div class="ConvoMessageWithoutBubble">
 <div class="ConvoMessageWithoutBubble__mediaAttachments"><div class="AttachPhotos__link">
  <img src="https://sun9-1.vkuserphoto.ru/1.jpg" width="300" height="225"></div></div>
 <div class="ConvoMessageInfoWithoutBubbles"><span class="ConvoMessageInfoWithoutBubbles__statusIcon">
  <svg class="vkuiIcon--check_outline_16"></svg></span>
  <span class="ConvoMessageInfoWithoutBubbles__date">00:00</span></div></div></div>"""


@unittest.skipUnless(shutil.which("google-chrome") or shutil.which("chromium"), "нет браузера для проверки JS")
class MsgIdJs(unittest.TestCase):
    def test_id_on_item_wrapper(self):
        doc = ("<html><body><div class='list' data-key='list1'>" + "".join(
            "<div class='ConvoHistory__item' data-cmid='%d'>%s</div>" % (100 + i, MSG) for i in range(3))
            + "</div></body></html>")
        r = run_js(doc)
        self.assertEqual([m["mid"] for m in r["msgs"]], ["data-cmid=100", "data-cmid=101", "data-cmid=102"], r)

    def test_real_vk_layout(self):
        # как в настоящем ВК (проверено 03.11.2026): data-itemkey у VirtualScrollItem над messageBlock;
        # у списка бесед data-itemkey="convo_<peer>" — не номер сообщения
        doc = ("<html><body><div data-itemkey='convo_2000000777'>чат</div><section class='ConvoStack'>"
               "<div class='ConvoStack__content'>" + "".join(
                   "<div class='VirtualScrollItem' data-itemkey='%d'><article class='ConvoHistory__messageBlock'>%s"
                   "</article></div>" % (k, MSG) for k in (2, 3)) + "</div></section></body></html>")
        r = run_js(doc)
        self.assertEqual([m["mid"] for m in r["msgs"]], ["data-itemkey=2", "data-itemkey=3"], r)

    def test_non_numeric_key_not_taken(self):
        doc = "<html><body><div data-itemkey='convo_5'>" + MSG + "</div></body></html>"
        self.assertEqual([m["mid"] for m in run_js(doc)["msgs"]], [""])

    def test_shared_container_not_taken(self):
        doc = "<html><body><div data-key='9999'>" + MSG + MSG + "</div></body></html>"
        r = run_js(doc)
        self.assertEqual([m["mid"] for m in r["msgs"]], ["", ""], r)

    def test_dump_shows_id_attr_without_value(self):
        r = run_js("<html><body><div data-cmid='12345' class='x'></div></body></html>",
                   "L.attrs(document.querySelector('[data-cmid]'))")
        self.assertIn('data-cmid="#"', r)
        self.assertNotIn("12345", r)


class MsgId(unittest.TestCase):
    def setUp(self):
        from datetime import datetime
        self.d = tempfile.mkdtemp()
        self.since = datetime(2026, 11, 3, 0, 0)
        self.now = datetime(2026, 11, 3, 0, 2)
        self.paths = [shot(self.d, "o.png", 1280, 960, (1, 2, 3)), shot(self.d, "i.png", 1280, 960, (4, 5, 6))]

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    @staticmethod
    def nodl(url):
        raise AssertionError("по id картинки не качаются")

    def test_store_roundtrip_and_ok_not_overwritten(self):
        from app import msgids
        msgids.save(self.d, self.now, "data-cmid=5", True)
        msgids.save(self.d, self.now, "data-cmid=6", False)
        self.assertEqual(msgids.get(self.d, self.since), {"mid": "data-cmid=5", "ok": True})
        self.assertIsNone(msgids.get(self.d, self.since.replace(hour=1)))
        self.assertTrue(os.path.isfile(os.path.join(self.d, "logs", "sent_msg_ids.json")))

    def test_other_chat_id_ignored(self):
        from app import msgids
        msgids.save(self.d, self.now, "data-itemkey=2", True, peer=2000000777)
        self.assertEqual(msgids.get(self.d, self.since, peer=2000000777)["mid"], "data-itemkey=2")
        self.assertIsNone(msgids.get(self.d, self.since, peer=2000000888))

    def test_found_by_id_any_message(self):
        page = {"msgs": [{"own": None, "t": None, "mid": "data-cmid=5", "imgs": []}]}
        st, why = dupcheck.find_status(page, self.paths, self.since, self.now, download=self.nodl,
                                       mid={"mid": "data-cmid=5", "ok": False})
        self.assertEqual(st, dupcheck.FOUND, why)

    def test_deleted_delivered_not_resent(self):
        page = {"msgs": [{"own": True, "t": 1, "mid": "data-cmid=7", "imgs": []}]}
        st, why = dupcheck.find_status(page, self.paths, self.since, self.now, download=self.nodl,
                                       mid={"mid": "data-cmid=5", "ok": True})
        self.assertEqual(st, dupcheck.FOUND)
        self.assertIn("удалено", why)
        st, _ = dupcheck.find_status({"msgs": []}, self.paths, self.since, self.now, download=self.nodl,
                                     mid={"mid": "data-cmid=5", "ok": True})
        self.assertEqual(st, dupcheck.FOUND)

    def test_unconfirmed_id_missing_falls_back(self):
        page = {"msgs": [{"own": True, "t": 1, "mid": "data-cmid=7", "imgs": [{"src": "https://a", "w": 3, "h": 2}] * 2}]}
        raw = {"https://a": open(self.paths[0], "rb").read()}
        st, why = dupcheck.find_status(page, self.paths, self.since, self.now, download=raw.get,
                                       mid={"mid": "data-cmid=5", "ok": False})
        self.assertNotEqual(st, dupcheck.FOUND, why)   # картинки не те — не своё; дальше обычная проверка

    def test_no_id_old_behaviour(self):
        st, _ = dupcheck.find_status({"msgs": []}, self.paths, self.since, self.now, download=self.nodl, mid=None)
        self.assertEqual(st, dupcheck.MISSING)

    def test_own_new_message_remembers_id(self):
        from app import vk_browser
        f = vk_browser.Flows.__new__(vk_browser.Flows)
        msgs = [{"own": True, "t": 60, "st": "ok", "mid": "data-cmid=9",
                 "imgs": [{"src": "https://a"}, {"src": "https://b"}]}]

        def js(name, **k):
            return {"msgs": msgs}
            yield
        f.js = js
        g = f.own_new_message(2, 60)
        try:
            while True:
                next(g)
        except StopIteration as e:
            self.assertTrue(e.value)
        self.assertEqual(f.last_mid, ("data-cmid=9", True))

    def test_sender_saves_id(self):
        from app import msgids, vk_browser
        s = vk_browser.BrowserVKSender.__new__(vk_browser.BrowserVKSender) if hasattr(
            vk_browser, "BrowserVKSender") else None
        if s is None:
            self.skipTest("нет класса")
        s.root = self.d
        s._save_mid(("data-cmid=3", True), when=self.now, peer=2000000777)
        self.assertEqual(msgids.get(self.d, self.since)["mid"], "data-cmid=3")


if __name__ == "__main__":
    unittest.main()
