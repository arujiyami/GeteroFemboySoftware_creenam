# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.4: защита от двойной отправки — «скрины за этот час уже в беседе?».

Сообщение считается «скрины уже отправлены», только если ВСЁ сразу:
  * оно от своего профиля (под которым вошли в ВК);
  * отправлено в текущем часу (с ЧЧ:00 до сейчас; ручная отправка может быть и в ЧЧ:30);
  * в нём ровно 2 картинки, обе широкие (~16:9);
  * картинки похожи на последние снимки программы: одна — на снимок Oasys, другая — на iVMS-4200
    (уменьшенная серая картинка, устойчиво к пересжатию ВК).
Быстро (~1–2 с): смотрятся не больше 8 последних сообщений с фото, качаются только превью."""
import io
import logging
from datetime import datetime

log = logging.getLogger("club")

WIDE_MIN, WIDE_MAX = 1.5, 2.0        # 16:9 = 1.78 (с запасом на обрезку краёв)
SIZE = (32, 18)
CORR_MIN = 0.80                      # корреляция уменьшенных картинок со «своим» снимком
MARGIN = 0.05                        # и заметно выше, чем с «чужим» снимком
DIFF_MAX = 28.0                      # средняя разница яркости (0–255) после выравнивания
MAX_MSGS = 8                         # 3.0.3: было 4 — чужие фото после своего вытесняли его
TIMEOUT = 2.0


def _arr(img):
    import numpy as np
    from PIL import Image
    im = img.convert("L").resize(SIZE, Image.BILINEAR)
    a = np.asarray(im, dtype="float32")
    return a


def signature(source):
    """source — путь, bytes или PIL.Image → массив 18×32."""
    from PIL import Image
    if isinstance(source, (bytes, bytearray)):
        img = Image.open(io.BytesIO(source))
    elif isinstance(source, str):
        img = Image.open(source)
    else:
        img = source
    img.load()
    return _arr(img)


def similarity(a, b):
    """→ (корреляция, средняя разница яркости после выравнивания среднего)."""
    import numpy as np
    x, y = a - a.mean(), b - b.mean()
    den = float(np.sqrt((x * x).sum() * (y * y).sum())) or 1.0
    corr = float((x * y).sum()) / den
    diff = float(np.abs(x - y).mean())
    return corr, diff


def pair_match(shots, imgs):
    """shots — [Oasys, iVMS], imgs — 2 картинки сообщения (подписи). → (совпало, текст)."""
    best = None
    for order in ((0, 1), (1, 0)):
        sc = [similarity(shots[i], imgs[j]) for i, j in zip((0, 1), order)]
        cross = [similarity(shots[i], imgs[j])[0] for i, j in zip((0, 1), order[::-1])]
        ok = all(c >= CORR_MIN and d <= DIFF_MAX for c, d in sc) and all(
            s[0] >= x + MARGIN for s, x in zip(sc, cross))
        cand = (ok, min(c for c, _ in sc), sc, cross)
        if best is None or (cand[0], cand[1]) > (best[0], best[1]):
            best = cand
    ok, _, sc, cross = best
    txt = "сходство с Oasys %.2f, с iVMS %.2f (перекрёстно %.2f/%.2f)" % (sc[0][0], sc[1][0], cross[0], cross[1])
    return ok, txt


def _download(url, timeout=TIMEOUT):
    import requests
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    return r.content


def content_match(paths, imgs, download=None):
    """3.0.3: подтверждение доставки — картинки своего нового сообщения те же, что только что отправили:
    столько же, все широкие и каждая похожа на свой снимок. → (True/False/None, текст); None — проверить нельзя."""
    download = download or _download
    paths, imgs = list(paths or []), list(imgs or [])
    if len(imgs) != len(paths):
        return False, f"картинок {len(imgs)}, а отправляли {len(paths)}"
    ratios = [(float(x.get("w") or 0) / float(x.get("h") or 1)) for x in imgs]
    if not all(WIDE_MIN <= r <= WIDE_MAX for r in ratios):
        return False, "картинки не 16:9"
    try:
        shots = [signature(p) for p in paths]
        got = [signature(download(x["src"])) for x in imgs]
    except Exception as e:  # noqa: BLE001
        return None, f"превью не скачались ({type(e).__name__})"
    worst = 1.0
    for s in shots:
        best = max(similarity(s, g)[0] for g in got)
        worst = min(worst, best)
    return worst >= CORR_MIN, "наименьшее сходство %.2f" % worst


def candidates(page, since, now=None, hour_tag=None, account=""):
    """Отбор по автору/времени/числу и форме картинок (без скачивания). → (список, причины отказа).
    3.0.3: hour_tag — режим «аккаунт программы»: сообщение должно содержать тег часа («Камеры за 7:00»);
    тогда годится и поздняя отправка в тот же день. account — адрес профиля программы (если задан)."""
    from .tagged import has_tag
    now = now or datetime.now()
    start = since.hour * 60 + since.minute
    end = now.hour * 60 + now.minute
    same_day = since.date() == now.date()
    out, why = [], []
    msgs = list((page or {}).get("msgs") or [])[-MAX_MSGS:]
    for i, m in enumerate(reversed(msgs)):
        tag = f"сообщение {i + 1} снизу"
        if m.get("own") is not True:
            why.append(f"{tag}: не от своего профиля" + ("" if m.get("own") is False else " (автор не определён)"))
            continue
        if account and m.get("own_id") and str(m.get("own_id")).lower() != account:
            why.append(f"{tag}: вошли не в тот аккаунт ВК (не аккаунт программы)")
            continue
        t = m.get("t")
        if hour_tag:
            if not has_tag(m.get("text"), hour_tag):
                why.append(f"{tag}: нет тега часа")
                continue
            if t is None or m.get("old_day") or not same_day or t < start:
                why.append(f"{tag}: не за этот день")
                continue
        elif t is None or m.get("old_day") or not same_day or not (start <= t <= end):
            why.append(f"{tag}: не в этом часу")
            continue
        imgs = m.get("imgs") or []
        if len(imgs) != 2:
            why.append(f"{tag}: картинок {len(imgs)}, а не 2")
            continue
        ratios = [(float(x.get("w") or 0) / float(x.get("h") or 1)) for x in imgs]
        if not all(WIDE_MIN <= r <= WIDE_MAX for r in ratios):
            why.append(f"{tag}: картинки не 16:9 ({', '.join('%.2f' % r for r in ratios)})")
            continue
        if not all(str(x.get("src", "")).startswith("http") for x in imgs):
            why.append(f"{tag}: нет адресов картинок")
            continue
        out.append((tag, m))
    return out, why


FOUND, MISSING, FAILED = "found", "missing", "failed"


def find(page, paths, since, now=None, download=_download, **kw):
    """→ (True/False, причина). paths — последние снимки программы [Oasys, iVMS].
    3.0.4: kw mark — проверка скрытой метки программы (app/marker.py); без метки сообщение не своё."""
    st, why = find_status(page, paths, since, now=now, download=download, **kw)
    return st == FOUND, why


def find_status(page, paths, since, now=None, download=_download, hour_tag=None, account="", mark=None):
    """3.0.2: → (FOUND/MISSING/FAILED, причина). FAILED — проверить не удалось (беседа не прочиталась,
    превью не скачались, нет своих снимков): тогда нельзя утверждать, что скринов нет."""
    paths = list(paths or [])
    if len(paths) != 2:
        return FAILED, "нет пары последних снимков для сравнения"
    if not isinstance(page, dict):
        return FAILED, "беседа не прочиталась"
    if not page.get("msgs"):
        return MISSING, "в беседе внизу нет сообщений с фото"
    cands, why = candidates(page, since, now, hour_tag=hour_tag, account=account)
    if not cands:
        return MISSING, "; ".join(why) or "подходящих сообщений нет"
    try:
        shots = [signature(p) for p in paths]
    except Exception as e:  # noqa: BLE001
        return FAILED, f"не открылись свои снимки ({e})"
    failed = 0
    for tag, m in cands:
        try:
            raw = [download(x["src"]) for x in m["imgs"]]
            imgs = [signature(r) for r in raw]
        except Exception as e:  # noqa: BLE001
            failed += 1
            why.append(f"{tag}: превью не скачались ({type(e).__name__})")
            continue
        ok, txt = pair_match(shots, imgs)
        if ok and mark is not None and not marked(mark, paths, raw):
            log.info("В беседе %s: те же скрины, но без метки программы — отправлено вручную (не считается)", tag)
            why.append(f"{tag}: отправлено вручную (нет метки программы)")
            continue
        if ok:
            return FOUND, f"{tag} (в {m['t'] // 60:02d}:{m['t'] % 60:02d}): своё, 2 картинки 16:9, {txt}"
        why.append(f"{tag}: картинки не те ({txt})")
    return (FAILED if failed else MISSING), "; ".join(why)


def marked(mark, paths, raws):
    """3.0.4: у каждого снимка есть картинка в сообщении со скрытой меткой программы."""
    try:
        return all(any(mark(p, r) for r in raws) for p in paths)
    except Exception:  # noqa: BLE001
        log.debug("метка", exc_info=True)
        return False
