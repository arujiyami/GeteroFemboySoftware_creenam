# Original-Author: Владислав С.
# Created: 2026-10-28
"""Выполнение шагов источника (активировать окно, клики, шаблоны, скриншот)."""
import logging
import os
import time

from .config import normalize_step

log = logging.getLogger("club")


class StepError(Exception):
    pass


class WindowNotFound(StepError):
    pass


class Context:
    def __init__(self, source):
        self.source = source
        self.name = source.get("name", "?")
        self.hwnd = None
        self.images = []
        self.not_ready = None   # 2.1.5: причина, если окно так и не загрузилось (снимок «как есть»)
        self.ready_steps = []   # выполненные шаги wait_ready (для проверки снимка после съёмки)


class StepRunner:
    """backend — объект с операциями над окнами/экраном (см. backend_win.WinBackend)."""

    def __init__(self, backend, resolve_path, sleep=time.sleep, ready_timeout=None, capture_at=None,
                 now=None, clock=time.monotonic, on_not_ready=None, ready_check=True):
        self.backend = backend
        self.resolve = resolve_path
        self.sleep = sleep
        # 2.1.5: проверка готовности (шаг wait_ready): сколько ждать (None — из шага) и включена ли
        self.ready_timeout = ready_timeout
        self.ready_check = ready_check
        self.clock = clock
        self.on_not_ready = on_not_ready      # on_not_ready(имя, причина) — окно не загрузилось
        # Плановый запуск с ранним стартом: первый скриншот — не раньше capture_at (ЧЧ:00)
        self.capture_at = capture_at
        self.now = now
        # Быстрый первый проход: wait_ready ждёт не дольше ready_budget секунд (или до capture_at) и не
        # повторяет переключение; итог — в not_ready, переснимает job.py уже после iVMS.
        self.ready_budget = None
        self.not_ready = {}                   # имя -> причина
        self.contexts = {}                    # имя -> Context последнего run_source

    # ---------- источник целиком ----------
    def run_source(self, source):
        ctx = Context(source)
        self.contexts[ctx.name] = ctx
        self.not_ready.pop(ctx.name, None)
        win = source.get("window") or {}
        if hasattr(self.backend, "name"):
            self.backend.name = ctx.name  # для понятной ошибки «Нет прав нажать кнопку в …»
        ctx.hwnd = self.backend.find_window(
            title_regex=win.get("title_regex", ""), process_regex=win.get("process_regex", ""),
            exclude_title_regex=win.get("exclude_title_regex", ""), match=win.get("match", "any"),
            name=ctx.name)
        if not ctx.hwnd:
            what = " или ".join(x for x in (
                f"процесс «{win['process_regex']}»" if win.get("process_regex") else "",
                f"заголовок «{win['title_regex']}»" if win.get("title_regex") else "") if x)
            raise WindowNotFound(f"{ctx.name}: окно не найдено (искал {what or 'по пустому шаблону'}). "
                                 f"Проверьте, что программа запущена и не свёрнута в трей, или укажите окно "
                                 f"через «Настройки → Источники → Выбрать окно из списка»")
        try:
            self.run_steps(source.get("steps"), ctx)
        finally:
            for step in source.get("exit_steps") or []:
                try:
                    self.run_step(step, ctx)
                except Exception as e:  # noqa: BLE001
                    log.warning("%s: ошибка завершающего шага: %s", ctx.name, e)
        if not ctx.images:
            raise StepError(f"{ctx.name}: не сделано ни одного скриншота")
        return ctx.images

    def run_steps(self, steps, ctx):
        if isinstance(steps, dict):
            steps = [steps]
        for step in steps or []:
            self.run_step(step, ctx)

    def run_step(self, step, ctx):
        step = normalize_step(step)
        handler = getattr(self, "_step_" + str(step.get("type")), None)
        if handler is None:
            raise StepError(f"{ctx.name}: неизвестный шаг «{step.get('type')}»")
        log.debug("%s: шаг %s", ctx.name, step.get("type"))
        handler(step, ctx)

    # ---------- вспомогательное ----------
    def _rect(self, kind, ctx, monitor=None):
        kind = kind or "window"
        if kind == "window":
            return self.backend.window_rect(ctx.hwnd)
        if kind == "monitor":
            if monitor in (None, "window"):
                return self.backend.monitor_rect(ctx.hwnd)
            return self.backend.monitor_by_index(int(monitor))
        if kind in ("screen", "fullscreen"):
            return self.backend.virtual_screen()
        raise StepError(f"неизвестная область «{kind}»")

    def _locate(self, step, ctx):
        """(x, y) на экране или None; 'nofile', если файла шаблона нет."""
        path = self.resolve(step["template"])
        if not os.path.exists(path):
            return "nofile"
        rect = self._rect(step.get("region", "window"), ctx, step.get("monitor"))
        return self.backend.locate(path, rect, float(step.get("confidence", 0.8)))

    # ---------- шаги ----------
    def _step_activate_window(self, step, ctx):
        self.backend.activate(ctx.hwnd)
        self.sleep(float(step.get("delay", 0.5)))

    def _step_maximize(self, step, ctx):
        self.backend.maximize(ctx.hwnd)
        self.sleep(float(step.get("delay", 0.5)))

    def _step_restore(self, step, ctx):
        self.backend.restore(ctx.hwnd)

    def _step_wait(self, step, ctx):
        self.sleep(float(step.get("seconds", 1)))

    def _step_press(self, step, ctx):
        self.backend.press(str(step["key"]))

    def _step_hotkey(self, step, ctx):
        self.backend.hotkey(*[str(k) for k in step["keys"]])

    def _step_click_xy(self, step, ctx):
        left, top, width, height = self._rect(step.get("origin", "window"), ctx, step.get("monitor"))
        x, y = float(step["x"]), float(step["y"])
        units = step.get("units") or ("fraction" if abs(x) <= 1 and abs(y) <= 1 else "pixels")
        if units == "fraction":
            px, py = left + x * width, top + y * height
        else:  # отрицательные пиксели — от правого/нижнего края
            px = left + (x if x >= 0 else width + x)
            py = top + (y if y >= 0 else height + y)
        self.backend.click(int(round(px)), int(round(py)), double=bool(step.get("double")))

    def _step_click_image(self, step, ctx):
        pos = self._locate(step, ctx)
        if pos == "nofile":
            log.warning("%s: нет файла шаблона %s — используется запасной вариант", ctx.name, step["template"])
            pos = None
        if pos:
            dx, dy = step.get("offset", [0, 0])
            self.backend.click(int(pos[0] + dx), int(pos[1] + dy), double=bool(step.get("double")))
            return
        if step.get("fallback"):
            log.info("%s: шаблон %s не найден, запасной вариант", ctx.name, os.path.basename(step["template"]))
            self.run_steps(step["fallback"], ctx)
        elif not step.get("optional"):
            raise StepError(f"{ctx.name}: на экране не найден шаблон {step['template']}")

    def _step_ensure_image_visible(self, step, ctx):
        pos = self._locate(step, ctx)
        if pos == "nofile":
            if step.get("on_missing_template", "run") == "skip":
                log.warning("%s: нет файла шаблона %s — проверка пропущена", ctx.name, step["template"])
                return
            # 3.0.3: необязательный шаблон (wizard: hidden, напр. заголовок «Карта клуба») — не предупреждение:
            # без него шаги исправления (нажать «Карта клуба») выполняются каждый раз, это штатно
            (log.info if step.get("wizard") == "hidden" else log.warning)(
                "%s: нет файла шаблона %s — выполняю шаги исправления", ctx.name, step["template"])
            self.run_steps(step.get("if_missing"), ctx)
            return
        if pos:
            return
        log.info("%s: %s не виден — выполняю шаги исправления", ctx.name, os.path.basename(step["template"]))
        self.run_steps(step.get("if_missing"), ctx)
        if step.get("verify") and not self._locate(step, ctx):
            raise StepError(f"{ctx.name}: после исправления шаблон {step['template']} так и не виден")

    def _step_wait_ready(self, step, ctx):
        """2.1.5: дождаться, что окно отвечает, активно, нужный вид («Карта клуба») виден и прорисован.
        Не дождались — снимаем как есть: причина в ctx.not_ready и on_not_ready()."""
        if not self.ready_check:
            return
        from .readiness import wait_until_ready
        tpl = step.get("template")
        tpl = self.resolve(tpl) if tpl else None
        region = step.get("region", "window")
        quick = self.ready_budget is not None
        if quick:
            # первый проход (ранний старт): ждём не дольше, чем до времени снимка; итог проверим после iVMS
            timeout = self.ready_budget
            if self.capture_at is not None and self.now is not None:
                timeout = max(timeout, (self.capture_at - self.now()).total_seconds())
        else:
            timeout = self.ready_timeout if self.ready_timeout is not None else step.get("timeout_sec", 10)

        def retry():
            self.backend.activate(ctx.hwnd)
            self.run_steps(step.get("retry_steps"), ctx)

        res = wait_until_ready(self.backend, ctx.hwnd, lambda: self._rect(region, ctx, step.get("monitor")),
                               timeout, tpl, float(step.get("confidence", 0.8)),
                               retry=retry if (step.get("retry_steps") is not None and not quick) else None,
                               max_retries=int(step.get("retries", 1)), name=ctx.name, clock=self.clock,
                               sleep=self.sleep, clamp=not quick)
        ctx.ready_steps.append(step)
        if res.ok:
            return
        ctx.not_ready = res.reason or "не загрузился"
        self.not_ready[ctx.name] = ctx.not_ready
        if self.on_not_ready and not quick:
            try:
                self.on_not_ready(ctx.name, ctx.not_ready)
            except Exception:  # noqa: BLE001
                log.debug("on_not_ready", exc_info=True)

    def _wait_capture_time(self, ctx):
        """Ранний старт: снимок — ровно в назначенное время (не раньше), один раз за цикл."""
        at, self.capture_at = self.capture_at, None
        if at is None or self.now is None:
            return
        left = (at - self.now()).total_seconds()
        if left > 0:
            left = min(left, 30.0)
            log.info("%s: готов заранее, снимок в %s (через %.1f с)", ctx.name, at.strftime("%H:%M:%S"), left)
            self.sleep(left)

    def _step_screenshot(self, step, ctx):
        self._wait_capture_time(ctx)
        mode = step.get("mode", "window")
        rect = self._rect("monitor" if mode == "monitor" else mode, ctx, step.get("monitor"))
        img = self.backend.grab(rect)
        log.info("%s: скриншот %sx%s (%s)", ctx.name, img.width, img.height, mode)
        ctx.images.append(img)

    # ---------- 2.2.5: пресет вида (iVMS: Resource → Custom View → «cam») ----------
    def _learned_path(self, name):
        safe = "".join(c if c.isalnum() else "_" for c in name)[:40] or "view"
        return self.resolve(os.path.join("state", f"view_{safe}.png"))

    def _step_select_view(self, step, ctx):
        """Двойной щелчок по виду по названию. Порядок: UI Automation (элемент дерева с таким именем; при
        необходимости — вкладка Resource и раскрытие группы Custom View) → запомненная картинка этой строки
        (сохраняется сама после удачного поиска по имени; только на этом компьютере) → запасные шаги.
        Не нашлось — снимок всё равно делается (с записью в журнал)."""
        name = str(step.get("name") or ctx.source.get("view_preset") or "").strip()
        if not name:
            log.debug("%s: пресет вида не задан — пропуск", ctx.name)
            return
        settle = float(step.get("settle_sec", 3))
        be = self.backend
        how = None
        finder = getattr(be, "find_ui_item", None)
        if finder is not None:
            try:
                pos = finder(ctx.hwnd, name, tab=step.get("tab", "Resource"), group=step.get("group", "Custom View"))
            except Exception as e:  # noqa: BLE001
                log.info("%s: UI Automation недоступна (%s)", ctx.name, e)
                pos = None
            if pos:
                x, y = pos[0], pos[1]
                self._learn(ctx, name, x, y)
                be.click(int(x), int(y), double=True)
                how = "по названию"
        if how is None:
            path = self._learned_path(name)
            if os.path.exists(path):
                p = be.locate(path, self._rect("window", ctx), 0.85)
                if p:
                    be.click(int(p[0]), int(p[1]), double=True)
                    how = "по запомненной картинке"
        if how is None and step.get("fallback"):
            self.run_steps(step["fallback"], ctx)
            how = "по запасным координатам"
        if how is None:
            log.warning("%s: вид «%s» не найден — снимаю как есть", ctx.name, name)
            return
        log.info("%s: выбран вид «%s» (%s), жду раскладку %.1f с", ctx.name, name, how, settle)
        self.sleep(settle)

    def _learn(self, ctx, name, x, y):
        """Запомнить картинку строки вида (для поиска, если UI Automation в следующий раз не ответит)."""
        try:
            path = self._learned_path(name)
            if os.path.exists(path):
                return
            img = self.backend.grab((int(x) - 50, int(y) - 10, 100, 20))
            os.makedirs(os.path.dirname(path), exist_ok=True)
            img.save(path)
        except Exception:  # noqa: BLE001
            log.debug("learn view", exc_info=True)
