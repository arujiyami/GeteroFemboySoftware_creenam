# Original-Author: Владислав С.
# Created: 2026-10-28
"""Планировщик: запуск ровно в начале каждого часа (HH:MM:00) и повторы при ошибках."""
import logging
import math
import threading
import time
from datetime import datetime, timedelta

from .cleanup import DEFAULT_TIME as CLEANUP_TIME, STARTUP_DELAY_SEC, clamp_time, in_busy_window, next_daily

log = logging.getLogger("club")


def next_run(now, minute=0):
    """Ближайшее время HH:minute:00 строго позже now."""
    candidate = now.replace(minute=minute, second=0, microsecond=0)
    if candidate <= now:
        candidate += timedelta(hours=1)
    return candidate


CATCH_UP_DELAY_SEC = 15   # 3.0.3: пропущенный текущий час догоняется сразу (при любом опоздании)
STALL_SEC = 25 * 60   # 3.0.3: дольше этого один цикл не длится — значит, завис
PREWARM_MAX_MIN = 15
PREWARM_GRACE_SEC = 60


def prewarm_at(target, minutes):
    """Когда заранее открыть беседу перед запуском target: за minutes минут (0 — не открывать заранее)."""
    try:
        minutes = int(minutes or 0)
    except (TypeError, ValueError):
        minutes = 0
    minutes = max(0, min(PREWARM_MAX_MIN, minutes))
    if not minutes or target is None:
        return None
    return target - timedelta(minutes=minutes)


def prewarm_due(now, at, target, grace_sec=PREWARM_GRACE_SEC):
    """Пора ли открывать заранее: наступило время at, запуск ещё впереди и опоздали не больше grace_sec
    (если программу запустили позже — браузер откроется в момент отправки, как обычно)."""
    if at is None or target is None or not (at <= now < target):
        return False
    return (now - at).total_seconds() <= grace_sec


# Обратный отсчёт перед съёмкой (2.1.4): своё полупрозрачное окошко в углу экрана вместо уведомлений Windows.
# 2.1.5: длина — ползунок 0…60 с (0 — окошко не показывается), отдельного флажка «включено» больше нет.
DEFAULT_COUNTDOWN_SEC = 60
COUNTDOWN_MIN_SEC = 0
COUNTDOWN_MAX_SEC = 60
DEFAULT_COUNTDOWN_OPACITY = 75     # %
COUNTDOWN_MIN_OPACITY = 30
COUNTDOWN_MAX_OPACITY = 100
# Если до блокировки осталось меньше — отсчёт уже не показываем (программу запустили в последний момент).
# Для коротких отсчётов (1–3 с) порог меньше, см. countdown_min_left().
COUNTDOWN_MIN_LEFT_SEC = 3
# Окошко исчезает за столько секунд до блокировки (и ещё раз прячется перед самой съёмкой)
COUNTDOWN_HIDE_LEAD_SEC = 0.3

# 2.1.5: подготовка (блокировка ввода, Oasys на передний план, «Карта клуба») начинается заранее —
# за early_sec секунд до съёмки, чтобы Oasys успел загрузиться. 0…15, по умолчанию 5.
DEFAULT_EARLY_SEC = 5
EARLY_MIN_SEC, EARLY_MAX_SEC = 0, 15


def _clamp_int(value, default, lo, hi):
    try:
        v = int(round(float(str(value).strip().rstrip("%"))))
    except (TypeError, ValueError, AttributeError):
        return default
    return max(lo, min(hi, v))


def countdown_seconds(value):
    """Длина обратного отсчёта в секундах: 0…60 (0 — выключен), по умолчанию 60."""
    return _clamp_int(value, DEFAULT_COUNTDOWN_SEC, COUNTDOWN_MIN_SEC, COUNTDOWN_MAX_SEC)


def countdown_opacity(value):
    """Непрозрачность окошка в процентах: 30…100, по умолчанию 75."""
    return _clamp_int(value, DEFAULT_COUNTDOWN_OPACITY, COUNTDOWN_MIN_OPACITY, COUNTDOWN_MAX_OPACITY)


def countdown_settings(cfg):
    """(секунды 0…60, непрозрачность %) из cfg["countdown"]. 0 секунд — окошко не показывается.
    Старый флажок enabled: false (до 2.1.5) тоже означает 0."""
    cd = (cfg or {}).get("countdown") or {}
    seconds = countdown_seconds(cd.get("seconds", DEFAULT_COUNTDOWN_SEC))
    if cd.get("enabled", True) is False:
        seconds = 0
    return seconds, countdown_opacity(cd.get("opacity", DEFAULT_COUNTDOWN_OPACITY))


def early_seconds(value):
    """За сколько секунд до съёмки начинать подготовку и блокировать ввод: 0…15, по умолчанию 5."""
    return _clamp_int(value, DEFAULT_EARLY_SEC, EARLY_MIN_SEC, EARLY_MAX_SEC)


def early_settings(cfg):
    return early_seconds(((cfg or {}).get("input_lock") or {}).get("early_sec", DEFAULT_EARLY_SEC))


def lock_at(target, early_sec):
    """Когда начнётся подготовка/блокировка ввода перед съёмкой target."""
    if target is None:
        return None
    return target - timedelta(seconds=max(0, int(early_sec or 0)))


def countdown_left(now, target):
    """Сколько секунд осталось до target (дробное; <= 0 — уже пора)."""
    if target is None:
        return 0.0
    return (target - now).total_seconds()


def countdown_min_left(seconds):
    """Порог «слишком поздно показывать»: 3 с, а для отсчёта в 1–3 с — меньше, чтобы и он успел показаться."""
    return max(0.4, min(float(COUNTDOWN_MIN_LEFT_SEC), float(seconds) - 0.6))


def countdown_due(now, target, seconds, shown_for=None, min_left=None):
    """Пора ли показать обратный отсчёт к target (моменту блокировки ввода): осталось не больше seconds,
    но не меньше min_left, и для этого target он ещё не показывался (shown_for). seconds <= 0 — выключен."""
    if target is None or not seconds or seconds <= 0 or shown_for == target:
        return False
    if min_left is None:
        min_left = countdown_min_left(seconds)
    left = countdown_left(now, target)
    return min_left <= left <= seconds


def countdown_visible(now, target, hide_lead=COUNTDOWN_HIDE_LEAD_SEC):
    """Показывать ли окошко сейчас: да, пока до target (блокировки) больше hide_lead секунд."""
    return target is not None and countdown_left(now, target) > hide_lead


def countdown_clock(left):
    """Секунды → «М:СС» (вниз до 0:00)."""
    sec = max(0, int(left))
    return f"{sec // 60}:{sec % 60:02d}"


def countdown_text(left):
    """Главная строка окошка: «Съём скриншотов через 0:59»."""
    return f"Съём скриншотов через {countdown_clock(left)}"


def countdown_lock_text(lock_left):
    """Строка про блокировку: «Мышь и клавиатура заблокируются через 7 с»."""
    sec = max(0, int(math.ceil(lock_left - 1e-9)))
    return f"Мышь и клавиатура заблокируются через {sec} с"


def countdown_hint(unlock_hotkey=None, lock_left=None):
    """Вторая (и третья) строка окошка, если включена блокировка ввода:
    «Мышь и клавиатура заблокируются через 7 с. Разблокировать: Ctrl+Alt+Q»."""
    if not unlock_hotkey:
        return ""
    first = countdown_lock_text(lock_left) if lock_left is not None else \
        "Мышь и клавиатура заблокируются на несколько секунд"
    return f"{first}. Разблокировать: {unlock_hotkey}"


def plural_ru(n, one, few, many):
    """1 минуту, 2 минуты, 5 минут, 11 минут, 21 минуту…"""
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def minutes_text(n):
    return f"{n} {plural_ru(n, 'минуту', 'минуты', 'минут')}"


def due_action(now, target, max_delay_sec):
    """'wait' — ещё рано, 'run' — пора, 'skip' — слишком поздно (компьютер спал)."""
    if now < target:
        return "wait"
    if (now - target).total_seconds() <= max_delay_sec:
        return "run"
    return "skip"


def run_with_retries(fn, attempts, interval_sec, wait=None, on_error=None):
    """Вызывает fn() до attempts раз, пока она не вернёт True. wait(sec) -> True, если надо прервать.
    Ошибка с атрибутом retry=False (капча, блокировка, нет входа) прекращает повторы сразу."""
    attempts = max(1, int(attempts))
    for i in range(1, attempts + 1):
        try:
            if fn():
                return True
        except Exception as e:  # noqa: BLE001
            if on_error:
                on_error(i, e)
            if getattr(e, "retry", True) is False:
                return False
        if i < attempts and wait and wait(interval_sec):
            return False
    return False


class HourlyScheduler:
    """Фоновый поток: раз в час вызывает job()."""

    def __init__(self, job, get_settings, now=datetime.now, prewarm=None, countdown=None, countdown_seconds=None,
                 cleanup=None, cleanup_settings=None, early_seconds=None, catch_up=None):
        # job() — или job(target), если задан early_seconds: тогда цикл запускается за early_seconds() секунд
        # до target (подготовка Oasys и блокировка ввода), а сам снимок делается в target.
        self.job = job
        # 3.0.3: catch_up(slot) — догоняющий запуск, если плановый ЧЧ:ММ пропущен (программа была закрыта,
        # упала и перезапущена сторожем, компьютер спал, часы перевели). Сам решает, не отправлен ли час.
        self.catch_up = catch_up
        self._caught = set()
        self.early_seconds = early_seconds
        # cleanup() -> None, если сейчас нельзя (идёт цикл) — тогда повтор через минуту;
        # cleanup_settings() -> dict(enabled=True, time="12:30"). Уборка — в этом же потоке, поэтому
        # с плановым циклом не пересекается; с ручной отправкой — через замок в JobRunner.
        self.cleanup = cleanup
        self.cleanup_settings = cleanup_settings
        self.next_cleanup = None
        self.cleanup_delay_sec = STARTUP_DELAY_SEC
        # countdown(target) — показать обратный отсчёт до съёмки target (не должен долго блокировать);
        # countdown_seconds() -> 60 (0 — отсчёт выключен; читается заново каждые полсекунды, поэтому
        # изменение в настройках действует сразу). Отсчёт идёт к моменту блокировки ввода (target − early),
        # показывается один раз на каждый плановый запуск.
        self.countdown = countdown
        self.countdown_seconds = countdown_seconds
        self._countdown_for = None
        self.prewarm = prewarm    # prewarm(target) — заранее открыть беседу (не должен долго блокировать)
        self.next_prewarm = None
        self._prewarmed = None
        self.get_settings = get_settings  # -> dict(minute=..., max_delay_sec=...)
        self.now = now
        self._stop = threading.Event()
        self._thread = None
        self.next_target = None
        # 2.2.0: «Пропустить ближайший съём» (меню у часов): этот target не снимается
        self.skip_target = None
        self.skipped = []          # 2.2.2: пропущенные по просьбе съёмы (проверка в :05 их не трогает)
        self.started_at = None     # 2.2.2: когда запущено расписание

    def skip_next(self, on=True):
        """Пропустить (или вернуть) ближайший плановый съём. → target или None."""
        self.skip_target = self.next_target if on else None
        if self.skip_target:
            log.info("Ближайший съём %s будет пропущен (по вашей просьбе)", self.skip_target.strftime("%H:%M"))
        return self.skip_target

    @property
    def skipping(self):
        return self.skip_target is not None and self.skip_target == self.next_target

    def healthy(self, clock=None):
        """3.0.3: для сторожа. False — поток расписания умер сам (не остановлен) или не отзывался
        дольше STALL_SEC (завис цикл). Тогда отметка сторожу не пишется, и он перезапускает программу."""
        if self._thread is None or self._stop.is_set():
            return True
        if not self._thread.is_alive():
            return False
        t = getattr(self, "_tick", None)
        return t is None or (clock or time.monotonic)() - t <= STALL_SEC

    @property
    def running(self):
        return self._thread is not None and self._thread.is_alive() and not self._stop.is_set()

    def start(self):
        if self.running:
            return
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=5)  # дождаться остановки прежнего потока
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="scheduler", daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
        self.next_target = None
        self.next_prewarm = None

    def _plan(self, s, after=None):
        """Следующий запуск строго позже max(сейчас, after): после раннего старта цикла (до target)
        тот же target повторно не планируется."""
        now = self.now()
        self.next_target = next_run(max(now, after) if after is not None else now, s.get("minute", 0))
        self._planned_minute = s.get("minute", 0)
        self.next_prewarm = prewarm_at(self.next_target, s.get("prewarm_minutes", 5)) if self.prewarm else None

    def early(self):
        """Сколько секунд до съёмки начинается подготовка (0, если ранний старт не используется)."""
        if not self.early_seconds:
            return 0
        try:
            return early_seconds(self.early_seconds())
        except Exception:  # noqa: BLE001
            return 0

    def start_at(self, target=None):
        """Момент запуска цикла для target: target − early()."""
        target = target or self.next_target
        return lock_at(target, self.early()) if target is not None else None

    def _maybe_countdown(self, now, start=None):
        target = self.next_target
        start = start or target
        try:
            seconds = int(self.countdown_seconds() if self.countdown_seconds else DEFAULT_COUNTDOWN_SEC)
        except Exception:  # noqa: BLE001
            seconds = 0
        if self._countdown_for == target or not countdown_due(now, start, seconds):
            return
        self._countdown_for = target
        try:
            self.countdown(target)
        except Exception:  # noqa: BLE001
            log.exception("Ошибка обратного отсчёта перед съёмкой")

    def _cleanup_cfg(self):
        try:
            c = dict(self.cleanup_settings() if self.cleanup_settings else {})
        except Exception:  # noqa: BLE001
            c = {}
        return c

    def plan_cleanup(self, now, s):
        c = self._cleanup_cfg()
        try:
            h, m, moved = clamp_time(c.get("time", CLEANUP_TIME), s)
        except ValueError:
            h, m, moved = clamp_time(CLEANUP_TIME, s)
        if moved:
            log.info("Уборка перенесена на %02d:%02d — чтобы не совпасть с отправкой", h, m)
        self.next_cleanup = next_daily(now, h, m)
        return self.next_cleanup

    def _maybe_cleanup(self, now, s):
        if self.next_cleanup is None or now < self.next_cleanup:
            return
        if not self._cleanup_cfg().get("enabled", True):
            self.plan_cleanup(now, s)
            return
        if in_busy_window(now, s):
            return            # подождём конца окна отправки
        try:
            done = self.cleanup()
        except Exception:  # noqa: BLE001
            log.exception("Ошибка уборки")
            done = True
        if done is None:      # идёт цикл (например, «Отправить сейчас») — попробуем через минуту
            self.next_cleanup = now + timedelta(seconds=60)
        else:
            self.plan_cleanup(now, s)

    def _maybe_catch_up(self, slot, s):
        if not self.catch_up or slot in self._caught or slot in (self.skipped or []):
            return
        late = (self.now() - slot).total_seconds()
        if late <= 0:
            return
        self._caught.add(slot)
        if late >= 3600:     # уже наступил следующий час: старый час не снять, снимается только текущий
            log.warning("Пропущен час %s — снимать его уже поздно (снимается только текущий час)",
                        slot.strftime("%d.%m %H:%M"))
            return
        log.warning("Плановый запуск %s пропущен — догоняющий запуск, опоздание %d мин", slot.strftime("%H:%M"),
                    int(late // 60))
        try:
            self.catch_up(slot)
        except Exception:  # noqa: BLE001
            log.exception("Ошибка догоняющего запуска")

    def _loop(self):
        s = self.get_settings()
        self._plan(s)
        # после запуска — не сразу: даём окну и браузеру ВК подняться
        self._pending_catch = (self.next_target - timedelta(hours=1),
                               self.now() + timedelta(seconds=CATCH_UP_DELAY_SEC))
        if self.cleanup:
            # один раз вскоре после запуска, дальше — раз в день
            self.next_cleanup = self.now() + timedelta(seconds=self.cleanup_delay_sec)
        self.started_at = self.now()
        log.info("Планировщик запущен. Следующий запуск: %s", self.next_target.strftime("%d.%m %H:%M"))
        while not self._stop.is_set():
            self._tick = time.monotonic()
            s = self.get_settings()
            if s.get("minute", 0) != getattr(self, "_planned_minute", s.get("minute", 0)):
                # 2.1.6: минуту поменяли в настройках — сразу перепланировать, без перезапуска расписания
                self._plan(s)
                log.info("Минута съёма изменена. Следующий запуск: %s", self.next_target.strftime("%d.%m %H:%M"))
            now = self.now()
            target = self.next_target
            start = self.start_at(target)
            action = due_action(now, start, s.get("max_delay_sec", 600))
            if self.skipping and action == "run":
                log.warning("Съём %s пропущен по вашей просьбе", target.strftime("%H:%M"))
                self.skipped = (self.skipped + [target])[-5:]
                self.skip_target = None
                action = "skipped"
            if self.skipping and action == "wait":
                self._prewarmed = self._countdown_for = target    # ни подготовки, ни отсчёта
            if self.prewarm and action == "wait" and self._prewarmed != self.next_target:
                at = prewarm_at(self.next_target, s.get("prewarm_minutes", 5))
                self.next_prewarm = at
                if prewarm_due(now, at, self.next_target):
                    self._prewarmed = self.next_target
                    log.info("Заранее открываю беседу к отправке в %s", self.next_target.strftime("%H:%M"))
                    try:
                        self.prewarm(self.next_target)
                    except Exception:  # noqa: BLE001
                        log.exception("Ошибка подготовки браузера")
            if self.countdown and action == "wait":
                self._maybe_countdown(now, start)
            if self.cleanup and action == "wait":
                self._maybe_cleanup(now, s)
            pc = getattr(self, "_pending_catch", None)
            if pc and action == "wait" and now >= pc[1]:
                self._pending_catch = None
                self._maybe_catch_up(pc[0], s)
            if action == "run":
                if start < target:
                    log.info("Плановый запуск %s: подготовка за %d с до съёмки", target.strftime("%H:%M"),
                             int((target - start).total_seconds()))
                else:
                    log.info("Плановый запуск %s", target.strftime("%H:%M"))
                try:
                    if self.early_seconds:
                        self.job(target)
                    else:
                        self.job()
                except Exception:  # noqa: BLE001
                    log.exception("Ошибка планового запуска")
            elif action == "skip":
                log.warning("Пропуск запуска %s: компьютер был недоступен (спал?)",
                            self.next_target.strftime("%H:%M"))
                self._maybe_catch_up(target, s)
            if action != "wait":
                self._plan(s, after=target)
                log.info("Следующий запуск: %s", self.next_target.strftime("%d.%m %H:%M"))
            # перед стартом проверяем чаще, чтобы короткий отсчёт (1–2 с) и ранний старт не опаздывали
            ahead = (start - now).total_seconds() if action == "wait" else 999
            self._stop.wait(0.25 if 0 < ahead <= 70 else 0.5)
        log.info("Планировщик остановлен")
