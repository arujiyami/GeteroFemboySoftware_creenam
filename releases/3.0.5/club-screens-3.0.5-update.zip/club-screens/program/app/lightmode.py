# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: «Лёгкий режим» — когда на компьютере клуба мало свободной памяти.

Включается сам (mode: auto), если при запуске занято больше ram_percent % ОЗУ, или всегда (on).
Что меняется (замер: tests/smoke/light_mode_mem.py):
* браузер: строже ограничения Chromium (куча JavaScript, без кэша на диске, без «вперёд-назад»),
  кэш в памяти вместо 50 МБ на диске;
* беседа не открывается заранее, рабочая страница закрывается сразу после отправки;
* снимки сохраняются в JPEG (качество 80) и уменьшаются до 1920 точек по ширине.
Флаги браузера применяются при запуске программы (Chromium не меняет их на ходу).

Замер 2026-10-29 (Linux, offscreen, локальная страница бесед, PySide6 6.9): обычный режим ≈ 465–468 МБ,
лёгкий ≈ 467–468 МБ — на маленькой странице флаги почти ничего не дают (разница в пределах погрешности).
Основная экономия — в остальном: снимок 2560×1440 занимает 628 КБ в PNG и 178 КБ в JPEG 80 после уменьшения
(в 3,5 раза меньше памяти при отправке и места на диске), а страница ВК не висит открытой между съёмами.
На настоящей странице ВК (тяжёлый JavaScript) ограничение кучи 128 МБ должно помогать сильнее — это
не замерено: нет доступа к настоящему ВК и Windows."""
import ctypes
import os
import sys

LIGHT_FLAGS = ("--js-flags=--max-old-space-size=128 --disk-cache-size=1 --media-cache-size=1 "
               "--disable-features=BackForwardCache,MediaRouter,OptimizationHints,Translate "
               "--disable-background-networking --disable-component-update --disable-sync "
               "--renderer-process-limit=1 --disable-gpu --disable-extensions --disable-spell-checking")
MAX_WIDTH = 1920
JPEG_QUALITY = 80


def ram_percent():
    """Сколько процентов ОЗУ занято (0–100) или None."""
    try:
        if sys.platform == "win32":
            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
                return int(m.dwMemoryLoad)
            return None
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k] = int(v.split()[0])
        return round(100 * (1 - info["MemAvailable"] / info["MemTotal"]))
    except Exception:  # noqa: BLE001
        return None


def is_active(cfg, percent=None):
    lm = cfg.get("light_mode") or {}
    mode = str(lm.get("mode", "auto")).lower()
    # 3.0.3: только по галочке в «Настройках»; сам по нехватке памяти больше не включается
    return mode == "on"


_ACTIVE = False


def set_active(v):
    global _ACTIVE
    _ACTIVE = bool(v)


def active():
    """Решение, принятое при запуске (main.py)."""
    return _ACTIVE


def shrink(img):
    """Уменьшить снимок до MAX_WIDTH по ширине (пропорционально)."""
    w, h = img.size
    if w <= MAX_WIDTH:
        return img
    from PIL import Image
    return img.resize((MAX_WIDTH, max(1, round(h * MAX_WIDTH / w))), Image.Resampling.BILINEAR)


def rss_tree_mb(pid=None):
    """Память (RSS, МБ) процесса и всех его потомков — для замера (только Linux/proc)."""
    pid = pid or os.getpid()
    kids = {}
    for d in os.listdir("/proc"):
        if d.isdigit():
            try:
                with open(f"/proc/{d}/stat") as f:
                    ppid = int(f.read().rsplit(")", 1)[1].split()[1])
                kids.setdefault(ppid, []).append(int(d))
            except OSError:
                pass
    total, stack = 0, [pid]
    while stack:
        p = stack.pop()
        try:
            with open(f"/proc/{p}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        total += int(line.split()[1])
        except OSError:
            pass
        stack += kids.get(p, [])
    return total / 1024
