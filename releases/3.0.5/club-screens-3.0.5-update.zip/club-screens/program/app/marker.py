# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.4: незаметная метка «это отправила программа».

Перед отправкой в копию каждого скриншота (файлы в папке не меняются!) в левый верхний угол добавляется
едва заметный узор из 16×4 квадратиков (яркость ±AMP). Узор — 64 бита, вычисляется из часа съёма и
случайной «соли» этой установки (файл marker_salt.txt рядом с данными программы, в нём только
случайные байты). Проверка сравнивает картинку из беседы с исходным снимком с диска: разница в углу
должна совпасть с узором этого часа. Если человек отправил те же файлы из папки вручную — в них метки нет.
Узор крупный (квадрат = 1/80 ширины), поэтому переживает пересжатие ВК в JPEG и уменьшение превью."""
import hashlib
import hmac
import io
import os
import secrets

import numpy as np
from PIL import Image

COLS, ROWS = 16, 4
AMP = 8          # ±8 из 255 по яркости: глазом на скриншоте не видно
MIN_CORR = 0.6   # совпадение узора (корреляция) для «метка есть»
_salt = None


def salt(root):
    global _salt
    if _salt is None:
        p = os.path.join(root, "marker_salt.txt")
        try:
            with open(p, encoding="ascii") as f:
                _salt = bytes.fromhex(f.read().strip())
        except (OSError, ValueError):
            _salt = secrets.token_bytes(16)
            try:
                os.makedirs(root, exist_ok=True)
                with open(p, "w", encoding="ascii") as f:
                    f.write(_salt.hex())
            except OSError:
                pass
    return _salt


def hour_key(when):
    return when.strftime("%Y-%m-%d %H")


def bits(key, salt_=b""):
    d = hmac.new(salt_ or b"club-screens", key.encode(), hashlib.sha256).digest()
    v = np.unpackbits(np.frombuffer(d[:8], dtype=np.uint8)).astype(np.float32)
    return v * 2 - 1     # ±1


def _cell(w):
    return max(4, w // 80)


def _open(src):
    if isinstance(src, (bytes, bytearray)):
        src = io.BytesIO(src)
    im = Image.open(src)
    im.load()
    return im.convert("RGB")


def _corner(im, w0):
    """Угол с узором (в долях ширины, чтобы совпадал при любом масштабе) → массив float."""
    w, h = im.size
    c = _cell(w0) * w / float(w0)
    box = (0, 0, min(w, int(round((COLS + 1) * c))), min(h, int(round((ROWS + 1) * c))))
    return np.asarray(im.crop(box), dtype=np.float32), c


def embed(src_path, dst_path, key, salt_=b""):
    """Копия снимка с меткой. Формат по расширению dst_path (PNG/JPEG). Меняется только угол."""
    im = _open(src_path)
    w = im.size[0]
    c = _cell(w)
    a, _ = _corner(im, w)
    b = bits(key, salt_).reshape(ROWS, COLS)
    a[:ROWS * c, :COLS * c] = _squeeze(a[:ROWS * c, :COLS * c])   # без упора в 0/255 (белый/чёрный угол)
    for r in range(ROWS):
        for k in range(COLS):
            a[r * c:(r + 1) * c, k * c:(k + 1) * c] += AMP * b[r, k]
    im.paste(Image.fromarray(np.clip(a, 0, 255).round().astype(np.uint8)), (0, 0))
    if dst_path.lower().endswith((".jpg", ".jpeg")):
        im.save(dst_path, quality=95)
    else:
        im.save(dst_path)
    return dst_path


def _squeeze(a):
    return AMP + a * ((255.0 - 2 * AMP) / 255.0)


def _cells(a, c):
    """Средняя яркость середины каждого квадратика (c — размер квадратика в пикселях этой картинки)."""
    y = a.mean(axis=2)
    out = np.zeros(ROWS * COLS, dtype=np.float32)
    for r in range(ROWS):
        for k in range(COLS):
            y0, y1 = int(round((r + .25) * c)), int(round((r + .75) * c))
            x0, x1 = int(round((k + .25) * c)), int(round((k + .75) * c))
            out[r * COLS + k] = y[y0:max(y1, y0 + 1), x0:max(x1, x0 + 1)].mean()
    return out


def score(original_path, got, key, salt_=b""):
    """Корреляция разницы «картинка из беседы − исходный снимок» в углу с узором часа (−1…1)."""
    o, g = _open(original_path), _open(got)
    w0 = o.size[0]
    ga, c = _corner(g, w0)
    oa, _ = _corner(o, w0)
    if oa.shape != ga.shape:
        oa = np.asarray(Image.fromarray(oa.astype(np.uint8)).resize((ga.shape[1], ga.shape[0]), Image.BILINEAR),
                        dtype=np.float32)
    d = _cells(ga, c) - _squeeze(_cells(oa, c))
    d = d - d.mean()
    b = bits(key, salt_)
    n = float(np.linalg.norm(d)) * float(np.linalg.norm(b))
    return float(d @ b) / n if n > 1e-6 else 0.0


def present(original_path, got, key, salt_=b""):
    return score(original_path, got, key, salt_) >= MIN_CORR


def path_key(path):
    """Ключ метки по имени снимка: «2026-10-31_21-00_10_Oasys.png» → «2026-10-31_21» (час съёма)."""
    from datetime import datetime
    from .cleanup import shot_stamp
    st = shot_stamp(os.path.basename(path)) or datetime.now().strftime("%Y-%m-%d_%H")
    return st[:13]


def marked_copies(paths, root, folder):
    """Копии снимков с меткой во временной папке folder (исходные файлы не меняются)."""
    s = salt(root)
    out = []
    for i, p in enumerate(paths):
        dst = os.path.join(folder, os.path.basename(p))
        if os.path.exists(dst):
            dst = os.path.join(folder, "%d_%s" % (i, os.path.basename(p)))
        out.append(embed(p, dst, path_key(p), s))
    return out


def checker(root):
    """→ функция (исходный снимок, байты картинки из беседы) → есть ли метка программы за час этого снимка."""
    s = salt(root)
    return lambda path, raw: present(path, raw, path_key(path), s)
