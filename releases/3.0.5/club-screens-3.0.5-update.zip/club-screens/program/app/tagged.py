# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.3: режим «отдельный аккаунт программы + подпись-тег часа».

Программа входит в ВК под своим отдельным аккаунтом и к каждому сообщению со скринами добавляет подпись-тег
часа, например «Камеры за 7:00». Если снято позже (догоняющий запуск, повтор после 5 минут) — тег всё равно
называет нужный час, а к нему дописывается «(снято в 7:23)». Проверки «скрины на месте» и «час уже отправлен»
в этом режиме ищут сообщение по тегу часа И сравнивают картинки (одного тега мало: важно, что скрины те).
Режим выключен по умолчанию и включается отдельной вкладкой «Аккаунт программы» в «Настройках»."""
import re
from datetime import timedelta

DEFAULTS = {
    "enabled": False,
    "caption": "Камеры за {hour}",          # {hour} — 7:00, {time} — 07:00, {date} — 31.10.2026
    "late_suffix": " (снято в {shot})",      # {shot} — время съёмки, если позже late_after_min
    "late_after_min": 5,
    "account_id": "",                        # необязательно: адрес профиля программы (id123 или короткое имя)
}


def settings(cfg):
    t = dict(DEFAULTS)
    t.update((cfg or {}).get("tagged") or {})
    t["enabled"] = bool(t.get("enabled"))
    try:
        t["late_after_min"] = max(0, min(59, int(t.get("late_after_min", 5))))
    except (TypeError, ValueError):
        t["late_after_min"] = 5
    t["caption"] = str(t.get("caption") or DEFAULTS["caption"])
    t["late_suffix"] = str(t.get("late_suffix") if t.get("late_suffix") is not None else DEFAULTS["late_suffix"])
    t["account_id"] = normalize_account(t.get("account_id"))
    return t


def enabled(cfg):
    return settings(cfg)["enabled"]


def normalize_account(text):
    """«https://vk.com/id123», «vk.com/club_pc», «@club_pc» → «id123» / «club_pc»."""
    s = str(text or "").strip()
    s = re.sub(r"^(https?://)?(m\.)?vk\.(com|ru)/", "", s, flags=re.I).strip("/@ ")
    return s.split("?")[0].lower()


def slot_for(when, minute=0):
    """Плановый съём, к которому относится момент when (последний ЧЧ:minute не позже when)."""
    s = when.replace(minute=int(minute or 0) % 60, second=0, microsecond=0)
    return s if s <= when else s - timedelta(hours=1)


def _fmt(template, slot, shot=None):
    try:
        return template.format(hour=f"{slot.hour}:{slot.minute:02d}", time=slot.strftime("%H:%M"),
                               date=slot.strftime("%d.%m.%Y"),
                               shot=f"{(shot or slot).hour}:{(shot or slot).minute:02d}")
    except (KeyError, IndexError, ValueError):
        return template


def tag_for(cfg, slot):
    """Тег часа без пометки об опоздании — по нему ищется сообщение в беседе."""
    return _fmt(settings(cfg)["caption"], slot).strip()


def caption_for(cfg, slot, shot):
    """Подпись к отправке: тег часа + «(снято в …)», если снято позже late_after_min."""
    t = settings(cfg)
    text = tag_for(cfg, slot)
    if shot is not None and (shot - slot).total_seconds() > t["late_after_min"] * 60:
        text += _fmt(t["late_suffix"], slot, shot)
    return text


def norm(text):
    s = str(text or "").lower().replace("ё", "е").replace("\u00a0", " ")
    s = re.sub(r"(?<!\d)0(\d):", r"\1:", s)       # «07:00» и «7:00» — одно и то же
    return re.sub(r"\s+", " ", s).strip()


def has_tag(text, tag):
    """Тег часа есть в тексте сообщения («за 7:00» не путается с «за 17:00»)."""
    t = norm(tag)
    if not t:
        return False
    return re.search(r"(?<!\d)" + re.escape(t) + r"(?!\d)", norm(text)) is not None
