# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.4: доставка — только по подтверждению сервера ВК; скрытая метка программы на отправляемых снимках."""
import io
import os
import shutil
import tempfile
import unittest
from datetime import datetime

import numpy as np
from PIL import Image

from app import dupcheck, marker, vk_browser


def _shot(folder, name, kind=0):
    rng = np.random.default_rng(kind)
    h, w = 1080, 1920
    if kind == 2:
        a = np.full((h, w, 3), 255, np.uint8)                       # белый угол (упор в 255)
    else:
        y, x = np.mgrid[0:h, 0:w]
        a = np.stack([(x * 255 // w), (y * 255 // h), ((x + y) % 256)], -1).astype(np.uint8)
        if kind == 1:
            a = np.ascontiguousarray(255 - a[:, ::-1])                   # другой «экран»
        a[::7] = rng.integers(0, 255, (len(a[::7]), w, 3), dtype=np.uint8)   # «текст» и мелкие детали
    p = os.path.join(folder, name)
    Image.fromarray(a).save(p)
    return p


def _vk(path, width, q):
    """Как ВК: уменьшение + пересжатие в JPEG."""
    im = Image.open(path).convert("RGB").resize((width, width * 9 // 16), Image.BICUBIC)
    b = io.BytesIO()
    im.save(b, "JPEG", quality=q)
    return b.getvalue()


class Marker(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.out = tempfile.mkdtemp()
        marker._salt = None
        self.paths = [_shot(self.d, "2026-10-31_21-00_10_Oasys.png", 0),
                      _shot(self.d, "2026-10-31_21-00_20_iVMS-4200.png", 1)]

    def tearDown(self):
        marker._salt = None
        shutil.rmtree(self.d, ignore_errors=True)
        shutil.rmtree(self.out, ignore_errors=True)

    def test_survives_jpeg_and_scaling_and_files_untouched(self):
        before = [open(p, "rb").read() for p in self.paths]
        sent = marker.marked_copies(self.paths, self.d, self.out)
        self.assertEqual(before, [open(p, "rb").read() for p in self.paths])    # исходники без метки
        diff = np.abs(np.asarray(Image.open(sent[0]), int) - np.asarray(Image.open(self.paths[0]), int)).max()
        self.assertLessEqual(diff, 2 * marker.AMP)                                # глазом не видно
        check = marker.checker(self.d)
        for w in (1920, 1280, 807, 604, 510):
            for q in (70, 78, 85):
                for p, s in zip(self.paths, sent):
                    self.assertTrue(check(p, _vk(s, w, q)), (w, q))
                    self.assertFalse(check(p, _vk(p, w, q)), (w, q))             # те же файлы вручную

    def test_white_corner(self):
        p = _shot(self.d, "2026-10-31_21-00_10_Oasys.png", 2)
        s = marker.marked_copies([p], self.d, self.out)[0]
        self.assertTrue(marker.checker(self.d)(p, _vk(s, 604, 70)))

    def test_other_hour_or_other_install_not_ours(self):
        s = marker.marked_copies(self.paths[:1], self.d, self.out)[0]
        raw = _vk(s, 807, 80)
        self.assertLess(marker.score(self.paths[0], raw, "2026-10-31_20", marker.salt(self.d)), marker.MIN_CORR)
        self.assertLess(marker.score(self.paths[0], raw, "2026-10-31_21", b"other"), marker.MIN_CORR)

    def test_manual_send_of_same_files_not_counted(self):
        sent = marker.marked_copies(self.paths, self.d, self.out)
        imgs = [{"src": "http://x/%d" % i, "w": 1920, "h": 1080} for i in range(2)]
        page = {"msgs": [{"own": True, "t": 21 * 60 + 5, "imgs": imgs}]}
        since, now = datetime(2026, 10, 31, 21, 0), datetime(2026, 10, 31, 21, 7)
        manual = {"http://x/0": _vk(self.paths[0], 807, 80), "http://x/1": _vk(self.paths[1], 807, 80)}
        prog = {"http://x/0": _vk(sent[0], 807, 80), "http://x/1": _vk(sent[1], 807, 80)}
        mark = marker.checker(self.d)
        st, why = dupcheck.find_status(page, self.paths, since, now, download=manual.get, mark=mark)
        self.assertEqual(st, dupcheck.MISSING)
        self.assertIn("вручную", why)
        st, why = dupcheck.find_status(page, self.paths, since, now, download=prog.get, mark=mark)
        self.assertEqual(st, dupcheck.FOUND, why)


def _run(g):
    try:
        while True:
            next(g)
    except StopIteration as e:
        return e.value


class Ack(unittest.TestCase):
    def _fl(self, m):
        fl = vk_browser.Flows.__new__(vk_browser.Flows)

        def js(name, **k):
            return {"msgs": [m]}
            yield
        fl.js = js
        return fl

    def test_only_server_acked_message_counts(self):
        http = [{"src": "https://sun9-1.userapi.com/a.jpg"}] * 2
        cases = [({"st": "ok", "imgs": http}, True),
                 ({"st": "pending", "imgs": http}, False),          # часики
                 ({"st": "error", "imgs": http}, False),
                 ({"st": "", "imgs": http}, False),                 # нет галочки — не подтверждено
                 ({"st": "ok", "imgs": [{"src": "blob:https://vk.ru/1"}] * 2}, False),
                 ({"st": "ok", "imgs": [{"src": "data:image/png;base64,"}] * 2}, False)]
        for m, want in cases:
            m = dict(m, own=True, t=420)
            self.assertEqual(_run(self._fl(m).own_new_message(2, 420)), want, m)


class CheckContent(unittest.TestCase):
    def test_acked_message_without_marker_is_mismatch(self):
        d = tempfile.mkdtemp()
        try:
            p = _shot(d, "2026-10-31_21-00_10_Oasys.png")
            s = marker.marked_copies([p], d, tempfile.mkdtemp(dir=d))[0]
            sender = vk_browser.BrowserVKSender.__new__(vk_browser.BrowserVKSender)
            sender.root = d
            msg = {"imgs": [{"src": "http://x"}]}
            orig = dupcheck._download
            try:
                dupcheck._download = lambda u: _vk(s, 807, 80)
                self.assertEqual(sender.check_content("verified", [p], msg), "verified")
                dupcheck._download = lambda u: _vk(p, 807, 80)
                self.assertEqual(sender.check_content("verified", [p], msg), "mismatch")
            finally:
                dupcheck._download = orig
        finally:
            marker._salt = None
            shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
