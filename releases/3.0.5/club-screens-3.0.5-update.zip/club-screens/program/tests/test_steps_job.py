# Original-Author: Владислав С.
# Created: 2026-10-28
import copy
import os
import tempfile
import unittest
from datetime import datetime

from PIL import Image

from app.config import DEFAULTS
from app.job import JobRunner
from app.steps import StepError, StepRunner


class FakeBackend:
    def __init__(self, found=None, windows=("Oasys", "iVMS-4200")):
        self.actions = []
        self.found = found or {}
        self.windows = list(windows)
        self.fg = 99

    def find_window(self, title_regex="", process_regex="", exclude_title_regex="", match="any", name=""):
        import re
        for i, t in enumerate(self.windows):
            if re.search(title_regex, t):
                return i + 1
        return None

    def foreground(self):
        return self.fg

    def set_foreground(self, h):
        self.actions.append(("fg", h))
        self.fg = h

    def activate(self, h):
        self.actions.append(("activate", h))
        self.fg = h

    def maximize(self, h):
        self.actions.append(("max", h))

    def restore(self, h):
        self.actions.append(("restore", h))

    def window_rect(self, h):
        return (0, 0, 1000, 500)

    def monitor_rect(self, h):
        return (-1920, 0, 1920, 1080)

    def monitor_by_index(self, i):
        return (0, 0, 800, 600)

    def virtual_screen(self):
        return (-1920, 0, 3840, 1080)

    blank = False

    def grab(self, rect):
        self.actions.append(("grab", rect))
        img = Image.new("RGB", (rect[2], rect[3]))
        if not self.blank:
            img.paste((200, 200, 200), (0, 0, rect[2] // 2, rect[3]))
        return img

    def locate(self, path, rect, conf):
        self.actions.append(("locate", os.path.basename(path)))
        return self.found.get(os.path.basename(path))

    def click(self, x, y, double=False):
        self.actions.append(("click", x, y))

    def press(self, k):
        self.actions.append(("press", k))

    def hotkey(self, *k):
        self.actions.append(("hotkey",) + k)


class StepsTest(unittest.TestCase):
    def setUp(self):
        self.tpl_dir = tempfile.mkdtemp()

    def runner(self, backend, with_templates=()):
        for name in with_templates:
            Image.new("RGB", (10, 10)).save(os.path.join(self.tpl_dir, name))
        return StepRunner(backend, lambda p: os.path.join(self.tpl_dir, os.path.basename(p)), sleep=lambda s: None)

    def test_oasys_already_on_map(self):
        b = FakeBackend(found={"oasys_karta_kluba_header.png": (50, 50)})
        imgs = self.runner(b, ["oasys_karta_kluba_header.png"]).run_source(DEFAULTS["sources"][0])
        self.assertEqual(len(imgs), 1)
        self.assertFalse([a for a in b.actions if a[0] == "click"])
        # снимок всего монитора с окном Oasys — вместе с панелью задач
        self.assertIn(("grab", (-1920, 0, 1920, 1080)), b.actions)

    def test_oasys_switches_by_template(self):
        b = FakeBackend(found={"oasys_karta_kluba_button.png": (20, 70)})
        self.runner(b, ["oasys_karta_kluba_header.png", "oasys_karta_kluba_button.png"]).run_source(
            DEFAULTS["sources"][0])
        self.assertIn(("click", 20, 70), b.actions)

    def test_oasys_no_templates_fallback_xy(self):
        b = FakeBackend()
        self.runner(b).run_source(DEFAULTS["sources"][0])
        self.assertIn(("click", 19, 70), b.actions)  # 0.019*1000, 0.14*500

    def test_ivms_fullscreen_monitor_and_esc(self):
        b = FakeBackend(found={"ivms_fullscreen_button.png": (958, 456), "ivms_main_view_tab.png": (170, 20)})
        imgs = self.runner(b, ["ivms_fullscreen_button.png", "ivms_main_view_tab.png"]).run_source(
            DEFAULTS["sources"][1])
        self.assertEqual(imgs[0].size, (1920, 1080))
        self.assertLess(b.actions.index(("click", 958, 456)), b.actions.index(("grab", (-1920, 0, 1920, 1080))))
        self.assertEqual(b.actions[-1], ("press", "esc"))

    def test_exit_steps_run_on_failure(self):
        src = copy.deepcopy(DEFAULTS["sources"][1])
        src["steps"].insert(0, {"type": "click_image", "template": "x.png"})  # нет fallback -> ошибка
        b = FakeBackend()
        Image.new("RGB", (10, 10)).save(os.path.join(self.tpl_dir, "x.png"))
        with self.assertRaises(StepError):
            self.runner(b).run_source(src)
        self.assertIn(("press", "esc"), b.actions)

    def test_window_not_found(self):
        with self.assertRaises(StepError):
            self.runner(FakeBackend(windows=[])).run_source(DEFAULTS["sources"][0])

    def test_click_xy_pixels_negative(self):
        b = FakeBackend()
        r = self.runner(b)
        from app.steps import Context
        ctx = Context({"name": "t"})
        ctx.hwnd = 1
        r.run_step({"type": "click_xy", "x": -10, "y": 20, "units": "pixels"}, ctx)
        self.assertEqual(b.actions[-1], ("click", 990, 20))


class FakeVK:
    def __init__(self, fail=0):
        self.sent = []
        self.fail = fail

    def send_photos(self, peer, paths, message):
        if self.fail:
            self.fail -= 1
            raise RuntimeError("сеть недоступна")
        self.sent.append((peer, [os.path.basename(p) for p in paths], message))


class JobTest(unittest.TestCase):
    def make(self, backend, vk, cfg_patch=None):
        root = tempfile.mkdtemp()
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["caption"] = "{date} {time}"
        cfg["vk"]["peer_id"] = 2000000001
        for k, v in (cfg_patch or {}).items():
            cfg["schedule"][k] = v
        job = JobRunner(lambda: cfg, lambda: backend, vk_factory=lambda c: vk, root=root,
                        now=lambda: datetime(2026, 10, 28, 3, 0), sleep=lambda s: None)
        job.online = lambda: True     # без настоящих сетевых проверок
        return job, root

    def test_full_cycle_one_message_in_order(self):
        vk = FakeVK()
        job, root = self.make(FakeBackend(), vk)
        self.assertTrue(job.run_cycle())
        self.assertEqual(len(vk.sent), 1)
        peer, files, msg = vk.sent[0]
        self.assertEqual(peer, 2000000001)
        self.assertEqual(files, ["2026-10-28_03-00_10_Oasys.png", "2026-10-28_03-00_20_iVMS-4200.png"])
        self.assertEqual(msg, "28.10.2026 03:00")

    def test_send_retry(self):
        vk = FakeVK(fail=1)
        job, _ = self.make(FakeBackend(), vk)
        self.assertTrue(job.run_cycle())
        self.assertEqual(len(vk.sent), 1)

    def test_partial_on_last_attempt(self):
        vk = FakeVK()
        job, _ = self.make(FakeBackend(windows=["Oasys"]), vk)
        self.assertTrue(job.run_cycle())
        self.assertEqual(vk.sent[0][1], ["2026-10-28_03-00_10_Oasys.png"])

    def test_no_partial(self):
        vk = FakeVK()
        job, _ = self.make(FakeBackend(windows=["Oasys"]), vk, {"send_partial": False})
        self.assertFalse(job.run_cycle())
        self.assertEqual(vk.sent, [])

    def test_last_result_ok(self):
        vk = FakeVK()
        job, _ = self.make(FakeBackend(), vk)
        seen = []
        job.on_result = seen.append
        job.run_cycle()
        r = job.last_result
        self.assertTrue(r["ok"] and r["sent"])
        self.assertEqual(len(r["paths"]), 2)
        self.assertEqual(r["errors"], {})
        self.assertEqual(seen, [r])

    def test_last_result_partial_has_friendly_error(self):
        job, _ = self.make(FakeBackend(windows=["Oasys"]), FakeVK())
        job.run_cycle()
        r = job.last_result
        self.assertTrue(r["sent"] and r["partial"])
        self.assertIn("iVMS-4200 не найден", r["errors"]["iVMS-4200"])

    def test_blank_screen_is_error(self):
        b = FakeBackend()
        b.blank = True
        vk = FakeVK()
        job, _ = self.make(b, vk, {"send_partial": False})
        self.assertFalse(job.run_cycle())
        self.assertIn("чёрным", job.last_result["errors"]["Oasys"])
        self.assertEqual(vk.sent, [])

    def test_send_error_friendly(self):
        from app.vk import VKError

        class BadVK(FakeVK):
            def send_photos(self, *a):
                raise VKError(5, "User authorization failed")
        job, _ = self.make(FakeBackend(), BadVK(), {"attempts": 1})
        self.assertFalse(job.run_cycle())
        self.assertIn("ключ доступа сообщества", job.last_result["send_error"].lower())

    def test_needs_user_error_no_retry_and_hold(self):
        from app.vk_browser import NotLoggedIn

        class LoggedOut(FakeVK):
            calls = 0

            def send_photos(self, *a):
                LoggedOut.calls += 1
                raise NotLoggedIn()
        vk = LoggedOut()
        job, _ = self.make(FakeBackend(), vk)
        self.assertFalse(job.run_cycle())
        self.assertEqual(LoggedOut.calls, 1)  # без повторов
        self.assertIn("Вход ВК", job.hold)
        self.assertFalse(job.run_cycle())  # плановый запуск пропущен
        self.assertEqual(LoggedOut.calls, 1)
        self.assertFalse(job.run_cycle(manual=True))  # кнопка «Отправить сейчас» пробует
        self.assertEqual(LoggedOut.calls, 2)

    def test_hold_cleared_by_success(self):
        vk = FakeVK()
        job, _ = self.make(FakeBackend(), vk)
        job.hold = "капча"
        self.assertFalse(job.run_cycle())
        self.assertTrue(job.run_cycle(manual=True))
        self.assertIsNone(job.hold)
        self.assertTrue(job.run_cycle())

    def test_retry_limits(self):
        waits = []
        vk = FakeVK(fail=5)
        job, _ = self.make(FakeBackend(), vk, {"attempts": 5, "retry_interval_sec": 10})
        job.sleep = waits.append
        self.assertFalse(job.run_cycle())
        self.assertEqual(vk.fail, 3)  # было 5, ушло 2 попытки
        self.assertEqual([w for w in waits if w >= 60], [60])  # 3.0.3: максимум 2 попытки, пауза 1 минута

    def test_capture_preview_no_send(self):
        vk = FakeVK()
        job, _ = self.make(FakeBackend(windows=["Oasys"]), vk)
        done, errors = job.capture_preview()
        self.assertEqual(list(done), ["Oasys"])
        self.assertIn("iVMS-4200", errors)
        self.assertEqual(vk.sent, [])
        job.send_paths(done["Oasys"])
        self.assertEqual(len(vk.sent), 1)

    def test_input_locked_only_during_capture(self):
        """Мышь/клавиатура заблокированы только пока снимаем; отправка — без блокировки; снятие — всегда."""
        log = []

        class Hook:
            def __init__(self, m, k):
                self.on_mouse = m

            def start(self):
                log.append("lock")
                return True

            def stop(self):
                log.append("unlock")

        class LockBackend(FakeBackend):
            def input_hook_factory(self, m, k):
                self.hook = Hook(m, k)
                return self.hook

            def grab(self, rect):
                log.append(("grab", self.hook.on_mouse(0x0200, 0)))   # пользовательская мышь глотается
                return super().grab(rect)

        class VK(FakeVK):
            def __init__(self, job_ref):
                super().__init__()
                self.job_ref = job_ref

            def send_photos(self, peer, paths, message):
                log.append(("send", self.job_ref[0].input_locked))
                super().send_photos(peer, paths, message)
        ref = []
        b = LockBackend()
        job, _ = self.make(b, VK(ref))
        ref.append(job)
        self.assertTrue(job.run_cycle())
        self.assertEqual(log[0], "lock")
        self.assertEqual(log[-2:], ["unlock", ("send", False)])
        self.assertTrue(all(x[1] for x in log if isinstance(x, tuple) and x[0] == "grab"))
        self.assertFalse(job.input_locked)

        # выключено в настройках — хук не ставится
        log.clear()
        job, _ = self.make(LockBackend(), FakeVK())
        job.cfg_getter()["input_lock"]["enabled"] = False
        job.capture_preview()
        self.assertNotIn("lock", log)

        # ошибка в съёмке — блокировка всё равно снимается
        log.clear()

        class Boom(LockBackend):
            def foreground(self):
                raise KeyboardInterrupt

        job, _ = self.make(Boom(), FakeVK())
        with self.assertRaises(KeyboardInterrupt):
            job.capture_preview()
        self.assertEqual(log, ["lock", "unlock"])
        self.assertFalse(job.input_locked)


if __name__ == "__main__":
    unittest.main()
