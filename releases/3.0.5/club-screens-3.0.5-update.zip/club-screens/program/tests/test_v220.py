# Original-Author: Владислав С.
# Created: 2026-10-29
"""2.2.0: очередь без интернета, утренняя сводка, сторож, лёгкий режим, связка в JobRunner."""
import copy
import os
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta

from PIL import Image

from app import lightmode, offqueue, summary, watchdog
from app.config import DEFAULTS


def _touch(d, name):
    p = os.path.join(d, name)
    with open(p, "wb") as f:
        f.write(b"x")
    return p


class QueueTest(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.d, True)
        self.q = offqueue.OfflineQueue(os.path.join(self.d, "state", "queue.json"), max_cycles=3)

    def test_oldest_first_limit_and_caption(self):
        for h in range(5):
            self.q.add(f"s{h}", datetime(2026, 10, 29, h), [_touch(self.d, f"{h}a.png"), _touch(self.d, f"{h}b.png")])
        self.assertEqual(len(self.q), 3)                       # не длиннее max_cycles
        self.assertEqual(self.q.stamps(), {"s2", "s3", "s4"})
        got = self.q.take(5)
        self.assertEqual([e["stamp"] for e in got], ["s2", "s3"])   # старые первыми, целыми съёмами
        cap = offqueue.caption(got, "05:00")
        self.assertIn("02:00", cap)
        self.assertLess(cap.index("02:00"), cap.index("03:00"))
        self.q.remove(e["stamp"] for e in got)
        self.assertEqual(self.q.stamps(), {"s4"})

    def test_missing_files_dropped(self):
        self.q.add("a", datetime(2026, 10, 29, 1), [os.path.join(self.d, "nope.png")])
        self.assertEqual(self.q.take(), [])


class SummaryTest(unittest.TestCase):
    def test_due_and_text(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        cfg = copy.deepcopy(DEFAULTS)
        now = datetime(2026, 10, 29, 9, 0)
        self.assertFalse(summary.due(cfg, now))                # по умолчанию выключено
        cfg["summary"]["enabled"] = True
        self.assertTrue(summary.due(cfg, now))
        self.assertFalse(summary.due(cfg, now - timedelta(minutes=1)))
        self.assertFalse(summary.standalone_due(cfg, now + timedelta(minutes=30)))
        self.assertTrue(summary.standalone_due(cfg, now + timedelta(minutes=70)))
        lp = summary.last_sent_path(d)
        summary.set_last_sent(lp, now)
        self.assertFalse(summary.due(cfg, now, summary.get_last_sent(lp)))
        log = summary.log_path(d)
        summary.record(log, datetime(2026, 10, 29, 2), True, True)
        summary.record(log, datetime(2026, 10, 29, 3), True, False, queued=True)
        summary.record(log, datetime(2026, 10, 29, 4), False, False)
        t = summary.text(summary.read(log), now)
        self.assertTrue(t.startswith("За ночь отправлено 1 из 3"), t)
        self.assertIn("в 03:00 не было интернета", t)
        self.assertIn("в 04:00 не отправлено", t)


class WatchdogTest(unittest.TestCase):
    def test_decide(self):
        alive = lambda pid: pid == 5  # noqa: E731
        self.assertEqual(watchdog.decide(None, 100, 300, alive), "stop")
        self.assertEqual(watchdog.decide({"pid": 5, "t": 100, "stopped": True}, 100, 300, alive), "stop")
        self.assertEqual(watchdog.decide({"pid": 5, "t": 100}, 200, 300, alive), "ok")
        self.assertEqual(watchdog.decide({"pid": 5, "t": 100}, 500, 300, alive), "hung")
        self.assertEqual(watchdog.decide({"pid": 6, "t": 100}, 110, 300, alive), "crashed")
        self.assertEqual(watchdog.decide({"pid": 0, "t": 100}, 200, 300, alive), "ok")   # запускается

    def test_watch_restarts_crashed_once(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d, True)
        watchdog.beat(watchdog.hb_path(d), pid=12345, now=1000)
        calls = []
        orig = watchdog.restart
        watchdog.restart = lambda p: calls.append(p)
        try:
            r = watchdog.watch(d, 300, sleep=lambda s: None, clock=lambda: 1010, alive=lambda p: False, max_loops=3)
        finally:
            watchdog.restart = orig
        self.assertEqual(r, "loops")
        self.assertEqual(calls, [d])          # после перезапуска ждёт новую отметку, не плодит копии
        watchdog.beat(watchdog.hb_path(d), stopped=True)
        self.assertEqual(watchdog.watch(d, 300, sleep=lambda s: None, max_loops=2), "stop")


class LightTest(unittest.TestCase):
    def test_modes_and_shrink(self):
        cfg = copy.deepcopy(DEFAULTS)
        self.assertFalse(lightmode.is_active(cfg, 91))   # 3.0.3: по памяти сам не включается
        self.assertFalse(lightmode.is_active(cfg, 50))
        cfg["light_mode"]["mode"] = "off"
        self.assertFalse(lightmode.is_active(cfg, 99))
        cfg["light_mode"]["mode"] = "on"
        self.assertTrue(lightmode.is_active(cfg, 10))
        self.assertEqual(lightmode.shrink(Image.new("RGB", (3840, 2160))).size, (1920, 1080))
        self.assertEqual(lightmode.shrink(Image.new("RGB", (800, 600))).size, (800, 600))
        self.assertIsInstance(lightmode.ram_percent(), (int, type(None)))


class JobIntegration(unittest.TestCase):
    def make(self, vk, clock, patch=None):
        from app.job import JobRunner
        from tests.test_steps_job import FakeBackend
        root = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, root, True)
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["caption"] = "{time}"
        cfg["vk"]["peer_id"] = 2000000001
        cfg["schedule"]["attempts"] = 2
        for sec, kv in (patch or {}).items():
            cfg[sec].update(kv)
        job = JobRunner(lambda: cfg, lambda: FakeBackend(), vk_factory=lambda c: vk, root=root,
                        now=lambda: clock["t"], sleep=lambda s: None)
        return job, root

    def test_offline_queue_then_merged(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 3, 0)}
        vk = FakeVK(fail=1)
        job, root = self.make(vk, clock)
        job.online = lambda: False
        self.assertTrue(job.run_cycle())                 # «успех»: в очереди, без повторов
        self.assertEqual(vk.sent, [])
        self.assertEqual(job.last_result["queued"], 1)
        self.assertIn("03-00", next(iter(job.protected_stamps() - {None})))   # уборка не трогает
        from app.ui.main_window import result_text
        self.assertIn("очеред", result_text(job.last_result)[0])
        clock["t"] = datetime(2026, 10, 29, 4, 0)
        job.online = lambda: True
        self.assertTrue(job.run_cycle())
        peer, files, msg = vk.sent[0]
        self.assertEqual(len(files), 4)
        self.assertTrue(files[0].startswith("2026-10-29_03-00"))     # старые первыми
        self.assertIn("Не было интернета", msg)
        self.assertEqual(len(job.queue()), 0)
        rows = summary.read(summary.log_path(root))
        self.assertEqual([(r["queued"], r["sent"]) for r in rows], [(True, False), (False, True)])

    def test_flush_queue(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 3, 0)}
        vk = FakeVK(fail=1)
        job, root = self.make(vk, clock)
        job.online = lambda: False
        job.run_cycle()
        self.assertIsNone(job.flush_queue())             # связи всё ещё нет
        job.online = lambda: True
        self.assertEqual(job.flush_queue(), 1)
        self.assertEqual(len(vk.sent), 1)
        self.assertIsNone(job.flush_queue())              # очередь пуста — ничего не шлёт

    def test_summary_carried_once(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 9, 0)}
        vk = FakeVK()
        job, root = self.make(vk, clock, {"summary": {"enabled": True, "time": "09:00"}})
        summary.record(summary.log_path(root), datetime(2026, 10, 29, 3), True, True)
        job.run_cycle()
        self.assertIn("За ночь отправлено", vk.sent[0][2])
        clock["t"] = datetime(2026, 10, 29, 10, 0)
        job.run_cycle()
        self.assertNotIn("За ночь", vk.sent[1][2])
        clock["t"] = datetime(2026, 10, 29, 11, 0)
        vk.send_text = lambda *a: self.fail("уже отправлено")
        self.assertFalse(job.send_summary_if_due())

    def test_summary_standalone(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 10, 10)}
        vk = FakeVK()
        texts = []
        vk.send_text = lambda peer, text: texts.append(text)
        job, root = self.make(vk, clock, {"summary": {"enabled": True, "time": "09:00"}})
        self.assertTrue(job.send_summary_if_due())
        self.assertFalse(job.send_summary_if_due())      # один раз в день
        self.assertEqual(len(texts), 1)

    def test_summary_off_by_default(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 10, 10)}
        vk = FakeVK()
        job, _ = self.make(vk, clock)
        self.assertFalse(job.send_summary_if_due())
        job.run_cycle()
        self.assertNotIn("За ночь", vk.sent[0][2])

    def test_unconfirmed_warning(self):
        from app.vk_browser import DeliveryUnconfirmed
        from tests.test_steps_job import FakeVK

        class VK(FakeVK):
            calls = 0

            def send_photos(self, *a):
                VK.calls += 1
                raise DeliveryUnconfirmed()
        clock = {"t": datetime(2026, 10, 29, 3, 0)}
        job, _ = self.make(VK(), clock)
        job.online = lambda: True
        self.assertFalse(job.run_cycle())
        self.assertEqual(VK.calls, 2)                  # 3.0.4: не подтверждено ВК — вторая попытка (после проверки беседы)
        self.assertIn("ВКонтакте", job.last_result["warnings"])

    def test_light_mode_jpeg(self):
        from tests.test_steps_job import FakeVK
        clock = {"t": datetime(2026, 10, 29, 3, 0)}
        vk = FakeVK()
        job, _ = self.make(vk, clock)
        lightmode.set_active(True)
        try:
            job.run_cycle()
        finally:
            lightmode.set_active(False)
        self.assertTrue(all(f.endswith(".jpg") for f in vk.sent[0][1]))
