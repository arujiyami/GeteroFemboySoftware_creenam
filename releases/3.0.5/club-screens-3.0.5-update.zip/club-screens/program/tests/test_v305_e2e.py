# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.5: сквозной прогон часа на поддельном ВК и виртуальном времени: :55 — заранее открыть беседу,
:00 — снимки и отправка (зависшие картинки, повторное прикрепление, любой порядок), проверки :05/:07/:10,
догон после перезапуска, кнопка «Отправить сейчас», вторая попытка."""
import unittest
from datetime import datetime, timedelta

from app import scheduler, sentcheck
from tests.test_v305_upload import NAMES, UPage, real_pngs
from tests.test_vk_browser import FakeDriver, flows

T = datetime(2026, 10, 29, 14, 0)


class RealFlowVK:
    """send_photos идёт через настоящий сценарий Flows.send на поддельной странице ВК."""

    def __init__(self, plans, reverse=False):
        self.plans, self.reverse, self.pages, self.times = list(plans), reverse, [], []

    def send_photos(self, peer, paths, msg):
        page = UPage(self.plans.pop(0) if len(self.plans) > 1 else self.plans[0], self.reverse)
        self.pages.append(page)
        d = FakeDriver(page)
        try:
            d.run(flows().send(peer, real_pngs(), msg, ""))
        finally:
            self.times.append(d.t)
        return "verified"


def job_with(vk):
    from tests.test_v221 import JobTest
    t = JobTest()
    t._cleanups = []
    job, root, cfg = t.make(vk)
    job.hour_already_sent = lambda *a, **k: False
    return job


def checks(sent, started=T - timedelta(hours=1)):
    rows = [{"dt": T, "sent": sent, "shots": 2, "err": None if sent else "Картинки не загрузились"}]
    return [sentcheck.decide(T + timedelta(minutes=m), 0, rows, started_at=started)[1] for m in (5, 7, 10)]


class HourCycle(unittest.TestCase):
    def test_prep_at_55(self):
        at = scheduler.prewarm_at(T, 5)
        self.assertEqual(at, T - timedelta(minutes=5))
        self.assertTrue(scheduler.prewarm_due(at + timedelta(seconds=10), at, T))
        self.assertFalse(scheduler.prewarm_due(T, at, T))

    def test_hour_with_stalls_reattach_then_checks_ok(self):
        vk = RealFlowVK([lambda f, n: "stuck" if f == NAMES[1] and n == 1 else "ok"], reverse=True)
        job = job_with(vk)
        with self.assertLogs("club", "INFO") as lg:
            self.assertTrue(job.run_cycle())
        self.assertEqual(vk.pages[0].sent_sets[-1], sorted(NAMES))
        self.assertTrue(any("WARNING" in m and "Прикрепляю заново (1 из 3 раз)" in m for m in lg.output))
        self.assertTrue(all(v in ("ok", None) for v in checks(True)))
        self.assertEqual(checks(True)[0], "ok")

    def test_first_attempt_gives_up_second_succeeds(self):
        vk = RealFlowVK([lambda f, n: "stuck", lambda f, n: "ok"])
        job = job_with(vk)
        with self.assertLogs("club", "INFO") as lg:
            self.assertTrue(job.run_cycle())
        self.assertEqual(len(vk.pages), 2)
        self.assertTrue(any("сдаюсь" in m for m in lg.output))
        self.assertTrue(any("Попытка 2 из 2" in m for m in lg.output))
        self.assertLess(sum(vk.times), 300)

    def test_both_attempts_fail_banner_at_05(self):
        vk = RealFlowVK([lambda f, n: "stuck"])
        job = job_with(vk)
        with self.assertLogs("club", "INFO"):
            self.assertFalse(job.run_cycle())
        self.assertEqual(len(vk.pages), 2)                   # не больше 2 попыток
        self.assertIn("не загрузились", job.last_result["send_error"])
        v = checks(False)[0]
        self.assertEqual(v["reason"], sentcheck.NOT_SENT)
        self.assertLess(sum(vk.times), 400)

    def test_catch_up_after_restart_no_false_banner(self):
        self.assertEqual(checks(False, started=T + timedelta(minutes=3)), ["skip"] * 3)

    def test_manual_button_one_attempt(self):
        vk = RealFlowVK([lambda f, n: "stuck"])
        job = job_with(vk)
        with self.assertLogs("club", "INFO"):
            ok = job.run_cycle(manual=True)
        self.assertFalse(ok)
        self.assertLessEqual(len(vk.pages), 2)

    def test_same_image_twice_never_sent(self):
        vk = RealFlowVK([lambda f, n: "as:" + NAMES[0] if f == NAMES[1] else "ok"])
        job = job_with(vk)
        with self.assertLogs("club", "INFO"):
            self.assertFalse(job.run_cycle())
        for p in vk.pages:
            self.assertEqual(p.sent_sets, [])                # две одинаковые так и не ушли
            self.assertNotIn("click_send", p.calls)


if __name__ == "__main__":
    unittest.main()
