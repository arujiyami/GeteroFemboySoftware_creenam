# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.5: зависшая загрузка беседы — 30 с, одна перезагрузка, ещё 30 с; ни одна проверка страницы не ждёт без предела."""
import unittest

from app.vk_browser import JS_TIMED_OUT, ChatNotReady, PageNotResponding
from tests.test_vk_browser import FakeDriver, FakeVK, flows, two_pngs


class HungDriver(FakeDriver):
    """Как настоящий браузер: зависшая страница не отвечает на JS — ответ «не ответила» через тайм-аут."""

    def do(self, op):
        if op[0] == "js":
            cap = op[4] if len(op) > 4 else 20
            self.caps.append(cap)
            if self.page.hung():
                self.t += cap
                return {JS_TIMED_OUT: True}
        if op[0] == "load":
            self.loads.append(self.t)
            if self.page.load_hangs:
                self.t += op[2]               # loadFinished так и не пришёл — ждали весь тайм-аут
        return super().do(op)

    def __init__(self, page):
        super().__init__(page)
        self.caps, self.loads = [], []


class Page(FakeVK):
    def __init__(self, ready_after_loads=99, hung_until_load=0, hang_after_calls=None):
        super().__init__()
        self.n_loads, self.ready_after, self.hung_until = 0, ready_after_loads, hung_until_load
        self.hang_after = hang_after_calls
        self.load_hangs = False

    def load(self, url):
        self.n_loads += 1
        super().load(url)

    def hung(self):
        if self.hang_after is not None and len(self.calls) >= self.hang_after:
            return True
        return self.n_loads < self.hung_until

    def counts(self, keys, box=()):
        out = super().counts(keys, box)
        if "composer" in out and self.n_loads < self.ready_after:
            out["composer"] = 0
        return out


class OpenChat(unittest.TestCase):
    def run_open(self, page):
        d = HungDriver(page)
        err = None
        try:
            d.run(flows().open_chat(2000000001))
        except Exception as e:  # noqa: BLE001
            err = e
        return d, err

    def test_never_ready_one_reload_then_fails_within_about_a_minute(self):
        page = Page()
        d, err = self.run_open(page)
        self.assertIsInstance(err, ChatNotReady)
        self.assertTrue(err.retry)                    # дальше — обычный повтор через минуту
        self.assertEqual(page.n_loads, 2)             # ровно одна перезагрузка
        self.assertLess(d.t, 70)

    def test_ready_after_reload(self):
        page = Page(ready_after_loads=2)
        d, err = self.run_open(page)
        self.assertIsNone(err)
        self.assertEqual(page.n_loads, 2)

    def test_ready_at_once_no_reload(self):
        page = Page(ready_after_loads=1)
        d, err = self.run_open(page)
        self.assertIsNone(err)
        self.assertEqual(page.n_loads, 1)

    def test_hung_page_and_hung_load_bounded(self):
        """Как 31.10 22:00: страница не отвечает. Раньше — 3,5 минуты; теперь не больше ~2×35 с (+5 с разбор)."""
        page = Page(hung_until_load=99)
        page.load_hangs = True
        d, err = self.run_open(page)
        self.assertIsInstance(err, ChatNotReady)
        self.assertEqual(page.n_loads, 2)
        self.assertLessEqual(d.t, 80)         # 2×(30 + 5 с последней проверки) + 5 с разбор
        self.assertTrue(all(c <= 30 for c in d.caps))

    def test_hung_first_load_recovers_after_reload(self):
        page = Page(ready_after_loads=1, hung_until_load=2)
        d, err = self.run_open(page)
        self.assertIsNone(err)
        self.assertEqual(page.n_loads, 2)


class SendPath(unittest.TestCase):
    def test_page_hangs_while_attaching_fails_fast_with_retry(self):
        page = Page(ready_after_loads=1)
        page.hang_after = 0
        d = HungDriver(page)
        page.hang_after = None
        gen = flows().send(2000000001, two_pngs())
        # открываем нормально, потом страница «зависает»
        orig = page.call

        def call(fn, a):
            if fn == "sig":
                page.hang_after = len(page.calls)
            return orig(fn, a)
        page.call = call
        with self.assertRaises(PageNotResponding) as cm:
            d.run(gen)
        self.assertTrue(cm.exception.retry)
        self.assertLess(d.t, 60)                       # не минуты: первая же неотвеченная проверка — ошибка

    def test_reused_hung_warm_page_reloads(self):
        page = Page(ready_after_loads=1)
        page.url = "https://vk.com/im/convo/2000000001"
        page.hang_after = 0
        d = HungDriver(page)

        def load(url, _l=page.load):
            page.hang_after = None
            _l(url)
        page.load = load
        d.run(flows().open_chat(2000000001, reuse=True))
        self.assertEqual(page.n_loads, 1)
        self.assertLessEqual(d.caps[0], 10)


if __name__ == "__main__":
    unittest.main()
