# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.5: картинка не загрузилась за 30 с или ВК показал ошибку — убрать только её и прикрепить заново
(не больше 3 раз). Порядок не важен; отправка — только когда есть ОБА снимка (Oasys и iVMS), по одному."""
import base64
import os
import tempfile
import unittest

from PIL import Image, ImageDraw

from app.vk_browser import SendFailed, image_print, match_print
from tests.test_vk_browser import FakeDriver, FakeVK, flows

NAMES = ("01_Oasys.png", "02_iVMS-4200.png")


def real_pngs():
    d = tempfile.mkdtemp()
    out = []
    for k, n in enumerate(NAMES):
        im = Image.new("RGB", (320, 180), (20, 20, 20))
        dr = ImageDraw.Draw(im)
        if k == 0:
            dr.rectangle([0, 0, 160, 180], fill=(240, 240, 240))      # светлая левая половина
        else:
            dr.rectangle([0, 90, 320, 180], fill=(240, 240, 240))     # светлая нижняя половина
        p = os.path.join(d, n)
        im.save(p)
        out.append(p)
    return out


class UPage(FakeVK):
    """plan(name, n) для n-го прикрепления файла name: 'ok' / 'stuck' / 'error' / 'dup' (два превью) /
    'as:<имя>' (на превью оказалась другая картинка). reverse — ВК показывает превью в обратном порядке."""

    def __init__(self, plan, reverse=False):
        self.items, self.names, self.fps = [], [], []
        super().__init__()
        self.plan, self.reverse, self.tries, self.sent_sets, self.attached = plan, reverse, {}, [], []
        self.data = {}

    @property
    def previews(self):
        return len(self.items)

    @previews.setter
    def previews(self, v):
        if v == 0 and self.items:
            self.sent_sets.append(sorted(self.names))
        del self.items[v:], self.names[v:], self.fps[v:]

    def att_items(self):
        return ["ok" if s == "ok" else ("error" if s == "error" else "loading") for s in self.items]

    def counts(self, keys, box=()):
        out = super().counts(keys, box)
        if "upload_progress" in out:
            out["upload_progress"] = sum(1 for s in self.items if s == "stuck")
        if "send_button" in out:
            out["send_button"] = 0 if any(s != "ok" for s in self.items) else 1
        return out

    def add(self, st, name):
        pos = 0 if self.reverse else len(self.items)
        self.items.insert(pos, st)
        self.names.insert(pos, name)
        self.fps.insert(pos, image_print(self.data[name]))

    def call(self, fn, a):
        if fn == "set_files":
            self.calls.append(fn)
            for f in a["files"]:
                self.data[f["name"]] = base64.b64decode(f["data"])
                n = self.tries[f["name"]] = self.tries.get(f["name"], 0) + 1
                st = self.plan(f["name"], n)
                self.attached.append(f["name"])
                if st == "dup":
                    self.add("ok", f["name"])
                    self.add("ok", f["name"])
                elif st.startswith("as:"):
                    other = st[3:]
                    self.data.setdefault(other, self.data[f["name"]])
                    self.add("ok", other)
                else:
                    self.add(st, f["name"])
            return {"ok": True, "n": len(a["files"])}
        if fn == "att_state":
            self.calls.append(fn)
            return {"items": self.att_items(), "fps": list(self.fps)}
        if fn == "remove_idx":
            self.calls.append(fn)
            for i in sorted(a["idx"], reverse=True):
                del self.items[i], self.names[i], self.fps[i]
            return len(a["idx"])
        if fn == "click_send":
            assert sorted(self.names) == sorted(NAMES) and all(s == "ok" for s in self.items), (self.names, self.items)
        return super().call(fn, a)


class UploadReattach(unittest.TestCase):
    def run_logged(self, plan, reverse=False):
        page = UPage(plan, reverse)
        d = FakeDriver(page)
        paths = real_pngs()
        with open(paths[0], "rb") as f:
            page.data[NAMES[0]] = f.read()
        err = None
        with self.assertLogs("club", "INFO") as lg:
            try:
                d.run(flows().send(2000000001, paths, "", ""))
            except Exception as e:  # noqa: BLE001
                err = e
        warn = [m for m in lg.output if m.startswith("WARNING")]
        return page, d, err, warn

    def sent_both(self, page):
        self.assertEqual(page.sent_sets[-1], sorted(NAMES))        # оба снимка, по одному, порядок не важен

    def has(self, warn, *parts):
        self.assertTrue(any(all(p in m for p in parts) for m in warn), (parts, warn))

    def test_prints_tell_shots_apart(self):
        a, b = real_pngs()
        pa, pb = image_print(a), image_print(b)
        self.assertEqual(match_print(pa, [pa, pb]), 0)
        self.assertEqual(match_print(pb, [pa, pb]), 1)
        self.assertIsNone(match_print(None, [pa, pb]))

    def test_stuck_second_only_it_reattached(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck" if f == NAMES[1] and n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.assertEqual(page.attached, [NAMES[0], NAMES[1], NAMES[1]])
        self.has(warn, "«02_iVMS-4200.png» не загрузилась за 30 с")
        self.has(warn, "Прикрепляю заново (1 из 3 раз): 02_iVMS-4200.png")
        self.has(warn, "загрузились после повторного прикрепления")
        self.assertLess(d.t, 45)

    def test_stuck_first_only_it_reattached_order_free(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck" if f == NAMES[0] and n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.assertEqual(page.attached, [NAMES[0], NAMES[1], NAMES[0]])   # iVMS не трогали
        self.assertEqual(page.sent_sets[-1], sorted(NAMES))

    def test_stuck_both(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck" if n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.assertEqual(len(page.attached), 4)

    def test_error_icon_handled_at_once(self):
        page, d, err, warn = self.run_logged(lambda f, n: "error" if f == NAMES[0] and n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.has(warn, "ошибку загрузки на превью «01_Oasys.png»")
        self.assertLess(d.t, 15)

    def test_recovers_on_second_reattach(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck" if n <= 2 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.has(warn, "Прикрепляю заново (2 из 3 раз)")
        self.assertLess(d.t, 110)

    def test_never_recovers_gives_up(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck")
        self.assertIsInstance(err, SendFailed)
        self.assertTrue(err.retry)
        self.assertNotIn("click_send", page.calls)
        self.assertEqual(page.tries, {NAMES[0]: 4, NAMES[1]: 4})
        self.has(warn, "Прикрепляю заново (3 из 3 раз)")
        self.has(warn, "сдаюсь")
        self.assertLessEqual(d.t, 180)

    def test_error_every_time_bounded(self):
        page, d, err, warn = self.run_logged(lambda f, n: "error")
        self.assertIsInstance(err, SendFailed)
        self.assertNotIn("click_send", page.calls)
        self.assertLess(d.t, 60)

    def test_duplicate_preview_after_reattach_extra_removed(self):
        page, d, err, warn = self.run_logged(
            lambda f, n: {1: "stuck", 2: "dup"}.get(n, "ok") if f == NAMES[1] else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.has(warn, "лишняя картинка", "«02_iVMS-4200.png»")

    def test_two_same_images_fixed_by_attaching_missing(self):
        """ВК показал Oasys вместо iVMS: две одинаковые — лишняя убирается, недостающий iVMS прикрепляется."""
        page, d, err, warn = self.run_logged(lambda f, n: "as:" + NAMES[0] if f == NAMES[1] and n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.has(warn, "две одинаковые", "01_Oasys.png")
        self.has(warn, "нет картинки «02_iVMS-4200.png»")
        self.assertEqual(page.tries[NAMES[1]], 2)

    def test_reverse_order_accepted(self):
        page, d, err, warn = self.run_logged(lambda f, n: "ok", reverse=True)
        self.assertIsNone(err)
        self.sent_both(page)
        self.assertEqual(page.attached, list(NAMES))                 # ничего не перекладывали

    def test_reverse_order_with_stuck(self):
        page, d, err, warn = self.run_logged(lambda f, n: "stuck" if f == NAMES[0] and n == 1 else "ok",
                                             reverse=True)
        self.assertIsNone(err)
        self.sent_both(page)
        self.has(warn, "«01_Oasys.png» не загрузилась")


class ContentCheck(unittest.TestCase):
    """Сверка отправленного сообщения: любой порядок, но обе картинки с меткой; две одинаковые — нет."""

    def test_marked_any_order_rejects_same_twice(self):
        from app import dupcheck
        mark = lambda p, raw: raw == p                               # noqa: E731
        self.assertTrue(dupcheck.marked(mark, ["o", "i"], ["i", "o"]))
        self.assertTrue(dupcheck.marked(mark, ["o", "i"], ["o", "i"]))
        self.assertFalse(dupcheck.marked(mark, ["o", "i"], ["o", "o"]))


if __name__ == "__main__":
    unittest.main()
