# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.5: проверка надёжности «30 с + перезагрузка + 30 с» на тяжёлых случаях (виртуальное время)."""
import threading
import unittest
from datetime import datetime, timedelta
from types import SimpleNamespace

from app import sentcheck
from app.vk_browser import ChatNotReady, PageNotResponding, StillInComposer
from tests.test_v305 import HungDriver, Page
from tests.test_vk_browser import flows, two_pngs

ATTEMPT_MAX = 90      # одна попытка с зависшей страницей: 2×30 с + разбор + запас


class TimedPage(Page):
    """Поле ввода появляется в момент ready_at (секунды от начала) — как медленно грузящийся ВК."""

    def __init__(self, ready_at, from_last_load=False):
        super().__init__(ready_after_loads=0)
        self.ready_at, self.from_last_load, self.d, self.last_load_t = ready_at, from_last_load, None, 0.0

    def load(self, url):
        super().load(url)
        self.last_load_t = self.d.t if self.d else 0.0

    def counts(self, keys, box=()):
        out = super().counts(keys, box)
        base = self.last_load_t if self.from_last_load else 0.0
        if "composer" in out and self.d.t - base < self.ready_at:
            out["composer"] = 0
        return out


def run(page, gen_fn, reuse=False):
    d = HungDriver(page)
    if isinstance(page, TimedPage):
        page.d = d
    err = None
    try:
        d.run(gen_fn())
    except Exception as e:  # noqa: BLE001
        err = e
    return d, err


def open_(page, reuse=False):
    return run(page, lambda: flows().open_chat(2000000001, reuse=reuse))


def send(page, reuse=False):
    return run(page, lambda: flows().send(2000000001, two_pngs(), "", "", reuse))


class Scenarios(unittest.TestCase):
    def test_page_never_loads(self):
        p = Page(hung_until_load=99)
        p.load_hangs = True
        d, err = send(p)
        self.assertIsInstance(err, ChatNotReady)
        self.assertTrue(err.retry)
        self.assertEqual(p.n_loads, 2)
        self.assertLessEqual(d.t, ATTEMPT_MAX)

    def test_ready_at_25_no_reload(self):
        p = TimedPage(25)
        d, err = open_(p)
        self.assertIsNone(err)
        self.assertEqual(p.n_loads, 1)
        self.assertLess(d.t, 30)

    def test_ready_at_35_after_reload(self):
        p = TimedPage(35)
        d, err = open_(p)
        self.assertIsNone(err)
        self.assertEqual(p.n_loads, 2)

    def test_ready_at_65_fails_then_second_attempt_ok(self):
        p = TimedPage(65)
        d, err = open_(p)
        self.assertIsInstance(err, ChatNotReady)
        self.assertEqual(p.n_loads, 2)
        self.assertLessEqual(d.t, ATTEMPT_MAX)
        p2 = TimedPage(0)          # через минуту ВК уже грузится нормально
        _, err2 = open_(p2)
        self.assertIsNone(err2)

    def test_reload_itself_hangs(self):
        p = Page()
        orig = p.load

        def load(url):
            orig(url)
            if p.n_loads == 2:
                p.load_hangs, p.hung_until = True, 99
        p.load = load
        d, err = open_(p)
        self.assertIsInstance(err, ChatNotReady)
        self.assertEqual(p.n_loads, 2)
        self.assertLessEqual(d.t, ATTEMPT_MAX)

    def test_loadfinished_never_fires_but_page_usable(self):
        """Найдено этим тестом: загрузка съедала все 30 с, и готовая беседа ни разу не проверялась."""
        p = Page(ready_after_loads=1)
        p.load_hangs = True
        d, err = open_(p)
        self.assertIsNone(err)
        self.assertEqual(p.n_loads, 1)
        self.assertLessEqual(d.t, 40)

    def test_js_callback_never_returns(self):
        p = Page(ready_after_loads=1, hung_until_load=99)
        d, err = send(p)
        self.assertIsInstance(err, ChatNotReady)
        self.assertLessEqual(d.t, ATTEMPT_MAX)
        self.assertTrue(all(c <= 30 for c in d.caps))
        self.assertLessEqual(len(d.caps), 400)        # нет бесконечного цикла

    def test_loads_but_composer_missing(self):
        p = Page()
        d, err = send(p)
        self.assertIsInstance(err, ChatNotReady)
        self.assertEqual(p.n_loads, 2)
        self.assertLessEqual(d.t, ATTEMPT_MAX)

    def test_network_drop_mid_attempt(self):
        p = Page(ready_after_loads=1)
        orig = p.call

        def call(fn, a):
            if fn == "sig" and p.hang_after is None:
                p.hang_after = len(p.calls)     # связь пропала: страница больше не отвечает
            return orig(fn, a)
        p.call = call
        d, err = send(p)
        self.assertIsInstance(err, PageNotResponding)
        self.assertTrue(err.retry)
        self.assertLessEqual(d.t, ATTEMPT_MAX)

    def test_hang_after_click_never_retried(self):
        p = Page(ready_after_loads=1)
        orig = p.call

        def call(fn, a):
            r = orig(fn, a)
            if fn == "click_send":
                p.hang_after = len(p.calls)      # нажали «Отправить» — и страница зависла
            return r
        p.call = call
        d, err = send(p)
        self.assertIsNotNone(err)
        self.assertFalse(err.retry)              # сообщение могло уйти — повтора нет (нет двойной отправки)
        self.assertLessEqual(d.t, ATTEMPT_MAX)

    def test_hang_on_preopened_page_at_55(self):
        p = Page(ready_after_loads=1)
        p.url = "https://vk.com/im/convo/2000000001"
        p.hang_after = 0

        def load(url, _l=p.load):
            p.hang_after = None
            _l(url)
        p.load = load
        d, err = send(p, reuse=True)
        self.assertIsNone(err)
        self.assertEqual(p.n_loads, 1)
        self.assertLessEqual(d.caps[0], 10)


class JobLevel(unittest.TestCase):
    def make(self, fail_with):
        from tests.test_v221 import JobTest
        calls, waits = [], []

        class VK:
            def send_photos(self, peer, paths, msg):
                calls.append(1)
                e = fail_with(len(calls))
                if e:
                    raise e
                return "verified"
        t = JobTest()
        t._cleanups = []
        job, root, cfg = t.make(VK())
        job.sleep = lambda s: waits.append(s)
        job.hour_already_sent = lambda *a, **k: False
        return job, calls, waits

    def test_both_attempts_fail_max_two_then_banner(self):
        job, calls, waits = self.make(lambda n: ChatNotReady(30))
        self.assertFalse(job.run_cycle())
        self.assertEqual(len(calls), 2)                     # не больше 2 попыток в час
        self.assertIn(60, waits)
        self.assertIn("не загрузилась", job.last_result["send_error"])
        # :05 — красное окно «не отправились»
        target = datetime(2026, 10, 29, 14, 0)
        _, v = sentcheck.decide(target + timedelta(minutes=5), 0,
                                [{"dt": target, "sent": False, "shots": 2, "err": job.last_result["send_error"]}])
        self.assertEqual(v["reason"], sentcheck.NOT_SENT)
        # худший случай по времени: 2 попытки × ATTEMPT_MAX + 60 с ожидания — в пределах ~5 минут
        self.assertLessEqual(2 * ATTEMPT_MAX + 60, 5 * 60)

    def test_second_attempt_succeeds(self):
        job, calls, _ = self.make(lambda n: PageNotResponding("x") if n == 1 else None)
        self.assertTrue(job.run_cycle())
        self.assertEqual(len(calls), 2)

    def test_no_retry_after_possible_send(self):
        def f(n):
            e = PageNotResponding("x")
            e.retry = False
            return e
        job, calls, _ = self.make(f)
        self.assertFalse(job.run_cycle())
        self.assertEqual(len(calls), 1)                     # нет двойной отправки


class CheckOverlapAndRestart(unittest.TestCase):
    def mixin(self, locked):
        from app.ui.services import ServicesMixin
        lock = threading.Lock()
        if locked:
            lock.acquire()
        o = SimpleNamespace(cfg={"schedule": {"minute": 0}, "sent_check": {"enabled": True}}, scheduler=SimpleNamespace(running=True),
                            job=SimpleNamespace(lock=lock))
        return o, ServicesMixin.sent_check_tick

    def test_check_at_05_during_attempt_waits(self):
        o, tick = self.mixin(True)
        now = datetime(2026, 10, 31, 22, 5)
        self.assertEqual(tick(o, now), "pending")
        self.assertFalse(o._presence_done.get(datetime(2026, 10, 31, 22, 0)))   # не засчитана — повторится

    def test_restart_mid_wait_no_false_banner(self):
        target = datetime(2026, 10, 31, 22, 0)
        self.assertTrue(sentcheck.skip_reason(target, started_at=target + timedelta(minutes=1, seconds=30)))
        _, v = sentcheck.decide(target + timedelta(minutes=5), 0, [], started_at=target + timedelta(seconds=90))
        self.assertEqual(v, "skip")


if __name__ == "__main__":
    unittest.main()
