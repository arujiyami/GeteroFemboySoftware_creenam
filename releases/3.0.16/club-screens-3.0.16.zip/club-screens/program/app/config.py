# Original-Author: Владислав С.
# Created: 2026-10-28
"""Загрузка, проверка и сохранение настроек (config.yaml)."""
import copy
import os
import sys

import yaml

from .cleanup import parse_time as parse_cleanup_time
from .inputlock import DEFAULT_HOTKEY, parse_hotkey

STEP_TYPES = {
    "activate_window", "maximize", "restore", "wait", "click_xy", "click_image",
    "press", "hotkey", "ensure_image_visible", "screenshot", "wait_ready", "select_view",
}

DEFAULT_CONFIG_YAML = r'''# =====================================================================
#  Скриншоты клуба — файл настроек (кодировка UTF-8)
#  Пути указываются относительно папки программы.
#  Настройки можно менять в окне программы — тогда комментарии
#  в этом файле будут перезаписаны (останется только этот заголовок).
# =====================================================================

vk:
  # Как отправлять:
  #   browser   — от ВАШЕГО профиля через окно браузера программы (по умолчанию, вход один раз в мастере)
  #   group_api — от имени сообщества через официальный API ВК (токен сообщества; сообщество
  #               должно быть добавлено в беседу). Для опытных, по умолчанию выключено.
  sender: browser
  # Вход в ВК выполнен в браузере программы (заполняется само)
  login_ok: false
  # Чьё имя показывается после входа (заполняется само)
  account_name: ""
  # peer_id беседы: 2000000000 + номер беседы.
  # Адрес vk.com/im/convo/2000000001 -> peer_id = 2000000001
  peer_id: 0
  # Название выбранной беседы (заполняется само)
  peer_title: ""
  # Если peer_id пустой (0) — найти беседу поиском по этому названию
  chat_search_title: ""
  # Подпись к сообщению. Пусто — отправлять только картинки.
  # Можно использовать {date}, {time} и {club}, например: "{club}: {date} {time}"
  caption: ""
  # Только для sender: group_api — ключ доступа сообщества
  # (Управление сообществом -> Работа с API -> Ключи доступа, право «сообщения сообщества»).
  # НИКОМУ НЕ ПЕРЕДАВАЙТЕ ЕГО И ФАЙЛ config.yaml!
  group_token: ""
  api_version: "5.199"
  api_host: api.vk.com

# ---------------------------------------------------------------------
#  Браузер программы (sender: browser). Профиль браузера с входом в ВК хранится
#  ТОЛЬКО на этом компьютере в папке browser_profile. НЕ ПЕРЕДАВАЙТЕ ЭТУ ПАПКУ НИКОМУ.
# ---------------------------------------------------------------------
vk_browser:
  profile_dir: browser_profile
  # Свой User-Agent браузера. Пусто — стандартный (рекомендуется, ничего не подделываем).
  user_agent: ""
  # Сколько секунд ждать список бесед в мастере, потом — подсказка вставить ссылку
  chat_list_timeout_sec: 20
  home_url: https://vk.com/
  im_url: https://vk.com/im
  chat_url: https://vk.com/im/convo/{peer_id}
  # Паузы «как у человека» между действиями, секунды (случайно в этом диапазоне)
  pause_min_sec: 0.8
  pause_max_sec: 2.2
  # Ожидания, секунды
  page_timeout_sec: 30
  upload_timeout_sec: 90
  # 2.2.1: как часто проверять, догрузил ли ВК картинки; беседа, открытая заранее раньше этого срока — перезагружается
  upload_poll_sec: 1.0
  warm_max_age_sec: 60
  upload_stuck_sec: 30       # 3.0.5: картинка не загрузилась за 30 с — убрать и прикрепить заново
  upload_reattach_max: 3     # 3.0.5: не больше 3 повторных прикреплений за попытку
  verify_timeout_sec: 20
  # 3.0.4: после «Отправить» ждать столько секунд, что сервер ВК принял сообщение (галочка); нет — не дошло (3.0.8: 40)
  ack_wait_sec: 40
  # Если превью картинок распознать не удалось — подождать столько секунд и всё равно нажать «Отправить»
  upload_fallback_wait_sec: 8
  # Сколько ждать, что ВК принял картинки, прежде чем попробовать другой способ прикрепления
  attach_check_sec: 8
  # Вся отправка — не дольше стольких секунд; потом ошибка, снимок и сведения в папке logs
  send_timeout_sec: 90
  # «Экономить память»: страница ВК создаётся только когда нужна (отправка, раздел «ВКонтакте»)
  # и сразу закрывается; один процесс страниц, без видеокарты. Флаги — после перезапуска программы
  save_memory: true
  # 2.2.0: проверка доставки — после «Отправить» сообщение с 2 картинками должно появиться в беседе
  # (смотрим только на уже открытую страницу, без лишних запросов). Не появилось за delivery_wait_sec —
  # одна повторная отправка (только если история на странице распознаётся — иначе можно задвоить);
  # не появилось и тогда — «Нужно ваше действие».
  delivery_check: true
  delivery_wait_sec: 30
  # Сколько снимков страницы с ошибками хранить в папке logs
  keep_error_shots: 20
  # Признак входа — cookie сайта
  login_cookies: [remixsid, remixnsid]
  # Части адреса, по которым узнаём: блокировка/проверка страницы, страница входа, капча
  url_blocked: ["/blocked", "/checkpoint", "act=blocked", "/restore"]
  url_login: ["/login", "id.vk.com/auth", "act=login", "/join"]
  url_captcha: ["captcha", "/challenge"]
  # Селекторы элементов страницы ВК (CSS, text="…", text=/…/i, role=button[name="…"], …:has-text("…")).
  # Для каждого — список вариантов, берётся первый найденный. Если ВК сменит дизайн — поправьте здесь.
  # attachment_preview, upload_progress, attachment_remove ищутся только в области ввода сообщения.
  selectors:
    composer:
      - '[data-testid="vkme_composer_input"]'
      - '[contenteditable="true"][role="textbox"]'
      - '.ComposerInput [contenteditable="true"]'
      - '.im_editable[contenteditable="true"]'
      - 'div[contenteditable="true"]'
      - 'textarea[placeholder*="ообщение"]'
      - 'textarea'
    file_input:
      - 'input[type="file"][data-testid="vkme_composer_attach_input"]'
      - 'input[type="file"][accept*="image"]'
      - 'input[type="file"]'
    attach_button:
      - '[data-testid="vkme_composer_attach_button"]'
      - '[aria-label="Загрузить файл"]'
      - '[aria-label="Прикрепить"]'
      - '[aria-label*="рикрепить"]'
      - '[aria-label="Attach"]'
      - 'button[aria-label*="ttach"]'
    attach_photo_item:
      - 'text="Фото или видео"'
      - 'text="Фотография"'
      - 'text="Фото"'
      - 'text="Photo or video"'
    attachment_preview:
      - '[data-testid="vkme_composer_attach_item"]'
      - '[class*="ttach"] img'
      - '[class*="AttachPhoto"]'
      - '[class*="ttachments"] [class*="hoto"]'
      - '[class*="ttach"] [style*="background-image"]'
      - '.page_preview_photo'
      - 'img[src^="blob:"]'
    upload_progress:
      - '[role="progressbar"]'
      - '[class*="rogress"]'
      - '[class*="pinner"]'
    attachment_remove:
      - '[data-testid="vkme_composer_attach_remove"]'
      - '[aria-label="Удалить"]'
      - '[aria-label="Удалить вложение"]'
      - '[aria-label="Remove"]'
      - '[class*="ttach"] [class*="emove"]'
      - '[class*="ttach"] [class*="elete"]'
    send_button:
      - '[data-testid="vkme_composer_send"]'
      - '[aria-label="Отправить сообщение"]'
      - '[class*="ConvoComposer__sendButton"]'
      - 'role=button[name="Отправить"]'
      - '[aria-label="Отправить"]'
      - '[aria-label="Send"]'
      - 'role=button[name="Send"]'
    history_photos:
      - '.AttachPhotos__link img.PhotoItem__img'
      - '[class*="ConvoHistory"] img[src*="userapi"]'
      - '[class*="ConvoMessage"] img[src*="userapi"]'
      - '.im-mess-stack img[src*="userapi"]'
      - '.im-mess .page_post_thumb_wrap'
    outgoing_message:
      - '[class*="ConvoMessage--out"]'
      - '[class*="Message--out"]'
      - '.im-mess--out'
    upload_error:
      - 'text=/Не удалось загрузить|Ошибка загрузки/i'
    captcha:
      - 'img[src*="captcha"]'
      - 'iframe[src*="captcha"]'
      - '[class*="aptcha"] input'
      - 'text=/Я не робот|Введите код с картинки|Подтвердите, что вы не робот/i'
    blocked_text:
      - 'text=/Страница заблокирована|страница была заблокирована|Ваша страница взломана|Страница временно заморожена|подозрительная активность/i'
    login_form:
      - 'input[name="login"]'
      - '#index_email'
      - '[data-testid="enter-another-way"]'
      - 'button:has-text("Войти")'
      - 'text="Войти другим способом"'
    logged_in:
      - '#top_profile_link'
      - '[data-testid="header-profile-menu-button"]'
      - '#l_msg'
      - 'a[href="/im"]'
      - 'a[href^="/im?"]'
      - 'a[href^="/im/"]'
      - 'nav [href*="/feed"]'
      - 'a[href="/feed"]'
      - 'a[href="/friends"]'
      - '[data-testid*="profile-menu"]'
      - '[aria-label="Профиль"]'
      - '#l_pr'
      - '#l_nwsf'
    profile_name:
      - '.top_profile_name'
      - '[data-testid="header-profile-menu-button"] img[alt]'
      - '#top_profile_link img[alt]'
      - '[data-testid*="profile-menu"] img[alt]'
      - '[aria-label="Профиль"] img[alt]'
    chat_list_item:
      - 'a[href*="/im/convo/"]'
      - 'a[href*="im?sel="]'
      - 'a[href*="sel="]'
    chat_search:
      - 'input[placeholder*="Поиск"]'
      - 'input[type="search"]'
      - 'input[placeholder*="Search"]'
    chat_not_found:
      - 'text=/Беседа не найдена|Чат не найден|Вы не состоите в этой беседе|нет доступа к беседе/i'

schedule:
  # Включить ежечасный запуск
  enabled: true
  # Минута часа для запуска (0 = ровно в 0:00, 1:00, 2:00 ...)
  minute: 0
  # За сколько минут до отправки заранее открыть беседу ВК в фоне (0 — не открывать заранее, до 15).
  # Одна загрузка страницы — та же, что нужна для отправки; если вход слетел, вы узнаете об этом заранее.
  prewarm_minutes: 5
  # Попыток в час при ошибке (не больше 2) и пауза между ними в секундах (не меньше 60): скрины нужны
  # не позже 5 минут после часа, поэтому повтор — быстро
  attempts: 2
  retry_interval_sec: 60
  # Если компьютер "проснулся" позже, чем через столько секунд после нужного времени, — пропустить запуск
  max_delay_sec: 600
  # После съёмки вернуть окно, которое было активным до неё
  restore_foreground: true
  # Если один из источников так и не удалось снять — отправить то, что получилось
  send_partial: true

# ---------------------------------------------------------------------
#  Обратный отсчёт перед съёмкой: полупрозрачное окошко «Съём скриншотов через 0:59» в правом нижнем
#  углу экрана (над часами). Это окно самой программы, не уведомление Windows: «Не беспокоить» его не
#  прячет. Фокус не забирает, щелчки мыши проходят сквозь него, на скриншоты не попадает.
#  Изменения в окне «Настройки» действуют сразу, без перезапуска.
# ---------------------------------------------------------------------
countdown:
  # За сколько секунд до блокировки мыши и клавиатуры показать отсчёт: 0…60 (0 — не показывать)
  seconds: 60
  # Непрозрачность окошка в процентах (30…100)
  opacity: 75
  # 3.0.13: кнопки «Снять сейчас» и «Снять позже» в окошке предупреждения. «Снять позже» откладывает
  # съёмку на 1 минуту — не чаще раза в час. false — окошко как раньше, без кнопок
  buttons: true

# ---------------------------------------------------------------------
#  3.0.13: ручной съём сочетанием клавиш — работает только с ЧЧ:50 до ЧЧ:10 (вокруг минуты съёма).
#  С :50 до :59 снимок идёт за следующий час, с :00 до :10 — за текущий, если он ещё не отправлен.
#  Плановая отправка не дублируется: час закрывается, только когда ВК подтвердил доставку.
# ---------------------------------------------------------------------
manual_shot:
  enabled: true
  hotkey: Shift+Alt+2

# ---------------------------------------------------------------------
#  Блокировка мыши и клавиатуры на время съёмки Oasys и iVMS-4200 (отправка в ВК идёт в фоне и
#  ничего не блокирует). Ctrl+Alt+Del работает всегда.
# ---------------------------------------------------------------------
input_lock:
  enabled: true
  # Сочетание клавиш, которое сразу снимает блокировку (съёмка продолжится)
  hotkey: Ctrl+Alt+Q
  # Блокировать ввод заранее за столько секунд до съёмки (0…15): за это время программа выводит
  # Oasys вперёд и открывает «Карту клуба», чтобы она успела загрузиться
  early_sec: 5
  # Блокировка снимается сама не позже чем через столько секунд (5…30, больше 30 не бывает никогда)
  watchdog_sec: 30

# ---------------------------------------------------------------------
#  Проверка Oasys: окно отвечает, оно на переднем плане, видна «Карта клуба», картинка устоялась.
#  Проверяется ещё до отправки; если Oasys не загрузился — он переснимается один раз (блокировка —
#  только на время пересъёмки). Не загрузился и тогда — в ВК уходит то, что есть (без пометок в
#  подписи), а в окне и журнале — «Oasys не загрузился — снимок может быть неактуален».
# ---------------------------------------------------------------------
oasys_check:
  enabled: true
  # Ждать загрузку Oasys до стольких секунд (3…30); внутри — не больше одного повтора переключения
  timeout_sec: 10

# ---------------------------------------------------------------------
#  Окно брони Oasys (3.0.7): перед снимком Oasys программа ищет окно Oasys, заголовок которого начинается
#  с title_prefix (может быть свёрнуто). Есть — выводит вперёд, фотографирует ТОЛЬКО его (на «Главной»,
#  в ВК не уходит), закрывает и снимает Oasys как обычно. Нет — сразу обычный снимок.
# ---------------------------------------------------------------------
oasys_booking:
  enabled: true
  title_prefix: "ServiceReserv"

# ---------------------------------------------------------------------
#  Видео на паузу на время съёма (по умолчанию выключено; музыка играет дальше). Через системные элементы
#  управления мультимедиа Windows: на паузу ставится только видео, которое сейчас играет, после снимков
#  (когда мышь и клавиатура разблокированы) — включается обратно только оно. Не получилось — съёмка
#  идёт как обычно, запись только в журнале.
# ---------------------------------------------------------------------
media_pause:
  enabled: false
  # После снимков включать обратно то, что было поставлено на паузу
  resume: true

# ---------------------------------------------------------------------
#  Уборка старых файлов — раз в день (и один раз через 2 минуты после запуска программы).
#  Удаляются только файлы программы в папках screenshots и logs. Файлы текущей отправки
#  и последней (в том числе ожидающей повтора) не трогаются никогда. Скриншоты неудачных
#  отправок и файлы для разбора (logs/vk_*) хранятся 3 дня, папка logs — не больше 50 МБ.
# ---------------------------------------------------------------------
cleanup:
  enabled: true
  # Во сколько убирать (ЧЧ:ММ). Если время попадает на подготовку или отправку — сдвигается на :30
  time: "12:30"
  # Сколько часов хранить обычные скриншоты
  keep_hours: 24

storage:
  # Папка для скриншотов и сколько последних файлов хранить (не больше; 0 — без ограничения по числу)
  screenshots_dir: screenshots
  keep_last: 300
  # Файл журнала
  log_file: logs/club-screens.log
  # Формат картинок: png или jpg
  image_format: png
  jpeg_quality: 92

app:
  # Название клуба (показывается в окне, можно вставить в подпись как {club})
  club_name: ""
  # Мастер первой настройки пройден (false — мастер откроется при запуске)
  setup_done: false
  # Запускать свёрнутым (в трей)
  start_minimized: false
  # Сворачивать в область уведомлений (трей) при закрытии окна
  use_tray: true
  # Тема оформления: system — как в Windows (светлая или тёмная), light — светлая, dark — тёмная,
  # contrast — высокий контраст
  theme: system
  # Цвет акцента (кнопки, выделение): blue, violet, teal, orange
  accent: blue
  # (устарело) не используется
  skip_template_wizard: false
  # Версия настроек (для переноса со старых версий; не меняйте)
  config_version: "2.1.1"

# ---------------------------------------------------------------------
#  Источники скриншотов. Выполняются по порядку; картинки идут в сообщение
#  в том же порядке. Типы шагов:
#   activate_window          — вывести окно на передний план (развернуть из свёрнутого)
#   maximize / restore       — развернуть на весь экран / восстановить размер
#   wait: seconds            — пауза
#   click_xy: x, y           — клик; units: fraction (доля окна 0..1) или pixels;
#                              origin: window | monitor | screen
#   click_image: template    — найти картинку-шаблон на экране и кликнуть по центру;
#                              confidence (0..1), region: window|monitor|screen,
#                              fallback: шаг или список шагов, если шаблон не найден
#   press: key               — нажать клавишу (esc, f11, enter ...)
#   hotkey: keys: [ctrl, s]  — сочетание клавиш
#   ensure_image_visible     — если шаблон НЕ виден, выполнить шаги if_missing;
#                              on_missing_template: run|skip — что делать, если файла шаблона нет
#   screenshot: mode         — window (окно программы) | monitor (монитор; monitor: window
#                              или номер 1, 2 ...) | fullscreen (все мониторы)
#  exit_steps — шаги, которые выполняются всегда после источника (например, Esc).
# ---------------------------------------------------------------------
# ---- 2.2.0 ----
updates:
  # Раз в сутки проверять новую версию на GitHub (публичный репозиторий, без токенов и входа).
  # Устанавливается только по кнопке «Установить» и никогда — во время съёма.
  auto_check: true
  repo: "arujiyami/GeteroFemboySoftware_creenam"
  last_check: ""

sent_check:
  # 2.2.2 / 3.0.2: «Проверять в :05, :07 и :10, что скрины на месте». Через 5, 7 и 10 минут после
  # планового съёма программа смотрит саму беседу ВК: есть ли своё сообщение с двумя скринами за этот час
  # (сама повторно не отправляет). Если нет — большое красное окно поверх всех
  # (своё, не уведомление Windows; на скрины не попадает). По умолчанию выключено.
  enabled: false
  sound: true
  # 3.0.2: минуты часа для проверок (1–59, до 15 штук; идут по времени, порядок в списке не важен)
  minutes: [5, 7, 10]

dup_guard:
  # 2.2.4: защита от двойной отправки. Если программа увидела, что её сообщение ушло (поле ввода
  # очистилось), час отмечается как отправленный навсегда — даже если сообщение потом удалили.
  # «Не повторять, если в этот час уже отправлял вручную»: ручная отправка кнопками программы тоже
  # закрывает час (без повтора и без тревоги в :05).
  skip_if_manual: true
  # Перед повтором и перед тревогой в :05 — посмотреть беседу: своё сообщение за этот час с теми же
  # двумя скринами (2 широкие картинки, похожие на последние снимки Oasys и iVMS) = уже отправлено.
  chat_check: true

summary:
  # Утренняя сводка «За ночь отправлено 9 из 10…» — уходит вместе с ближайшей обычной отправкой
  # после указанного времени (или отдельным коротким сообщением). По умолчанию выключена.
  enabled: false
  time: "09:00"

offline_queue:
  # Нет интернета — снимки копятся и уходят, когда связь вернётся (старые первыми, с подписью времени)
  enabled: true
  # Не больше стольких съёмов в очереди (лишние — самые старые — выкидываются из очереди)
  max_cycles: 12

light_mode:
  # Лёгкий режим (3.0.3: по умолчанию выключен и сам не включается): on — включён галочкой
  # в «Настройках»; off — выключен. Меньше кэша браузера, браузер закрывается сразу, снимки сжимаются.
  mode: "off"
  ram_percent: 85

tagged:
  # 3.0.3: отдельный аккаунт ВК для программы + подпись-тег часа к каждому сообщению (вкладка
  # «Аккаунт программы» в «Настройках»). Выключено по умолчанию.
  enabled: false
  # Тег часа: {hour} — 7:00, {time} — 07:00, {date} — 31.10.2026
  caption: "Камеры за {hour}"
  # Если снято позже late_after_min минут после часа — дописывается к тегу ({shot} — время съёмки)
  late_suffix: " (снято в {shot})"
  late_after_min: 5
  # Необязательно: адрес профиля программы (id123 или короткое имя) — проверка, что вошли именно в него
  account_id: ""

watchdog:
  # Сторож: отдельный крошечный процесс перезапускает программу, если она упала или зависла
  enabled: true
  hang_sec: 300

camera:
  # 3.0.15: программа камер — ivms (iVMS-4200, как раньше), trassir (TRASSIR Client) или generic
  # (любая программа: окно ищется по части названия generic_title, действия — записанные щелчки)
  mode: ivms
  generic_title: ""

sources:
  - name: Oasys
    kind: oasys
    enabled: true
    window:
      # Окно ищется по процессу OASys.Admin.exe ИЛИ по слову «oasys» в заголовке (регистр не важен);
      # берётся самое большое видимое окно. Если не находится — «Настройки» → «Источники» →
      # «Выбрать окно из списка».
      title_regex: "(?i)oasys"
      process_regex: "(?i)^oasys\\.admin\\.exe$"
      exclude_title_regex: "(?i)(chrome|firefox|яндекс|yandex|edge|opera|вконтакте|telegram|клуб-скриншоты|скриншоты клуба)"
    steps:
      - type: activate_window
      - type: maximize
      - type: wait
        seconds: 1.5
      - type: ensure_image_visible
        template: templates/oasys_karta_kluba_header.png
        hint: "Заголовок «Карта клуба» вверху слева в окне Oasys"
        # wizard: required | optional | hidden — показывать ли шаблон в мастере настройки
        wizard: hidden
        confidence: 0.8
        region: window
        on_missing_template: run
        if_missing:
          - type: click_image
            template: templates/oasys_karta_kluba_button.png
            hint: "Кнопка «Карта клуба» на левой панели Oasys (вторая иконка сверху)"
            confidence: 0.8
            region: window
            fallback:
              type: click_xy
              x: 0.019
              y: 0.14
              units: fraction
          - type: wait
            seconds: 2
      # Oasys действительно загрузился (см. oasys_check): отвечает, активен, видна «Карта клуба»
      - type: wait_ready
        template: templates/oasys_karta_kluba_header.png
        wizard: hidden
        confidence: 0.8
        region: window
        retries: 1
        retry_steps:
          - type: click_image
            template: templates/oasys_karta_kluba_button.png
            confidence: 0.8
            region: window
            fallback:
              type: click_xy
              x: 0.019
              y: 0.14
              units: fraction
          - type: wait
            seconds: 1
      # Весь монитор, на котором окно Oasys (вместе с панелью задач Windows)
      - type: screenshot
        mode: monitor
        monitor: window
    exit_steps: []

  - name: iVMS-4200
    kind: ivms
    enabled: true
    # 2.2.5: «Пресет вида iVMS» — название вида в Resource → Custom View (пусто — не выбирать)
    view_preset: cam
    window:
      # Процесс iVMS-4200.Framework.C.exe (или заголовок «iVMS-4200»), самое большое окно
      title_regex: "(?i)ivms-4200"
      process_regex: "(?i)^ivms-4200"
      exclude_title_regex: "(?i)(chrome|firefox|яндекс|yandex|edge|opera|вконтакте|telegram|клуб-скриншоты|скриншоты клуба)"
    steps:
      - type: activate_window
      - type: maximize
      - type: wait
        seconds: 1.5
      - type: click_image
        template: templates/ivms_main_view_tab.png
        hint: "Вкладка «Main View» вверху окна iVMS-4200"
        wizard: optional
        confidence: 0.8
        region: window
        fallback:
          type: click_xy
          x: 0.17
          y: 0.047
          units: fraction
      - type: wait
        seconds: 1
      # 2.2.5: выбрать пресет вида (Resource → Custom View → «Пресет вида iVMS», двойной щелчок), чтобы
      # вернуть правильную раскладку камер, если кто-то оставил одну камеру на весь экран.
      # Ищется по названию (UI Automation), затем по запомненной картинке, затем по запасным координатам.
      - type: select_view
        settle_sec: 3
        fallback:
          - type: click_xy
            x: 84
            y: 88
            units: pixels
          - type: wait
            seconds: 0.5
          - type: click_xy
            x: 103
            y: 200
            units: pixels
            double: true
      - type: click_image
        template: templates/ivms_fullscreen_button.png
        hint: "Кнопка «Full Screen» (четыре уголка) в правом нижнем углу iVMS-4200"
        confidence: 0.85
        region: window
        fallback:
          type: click_xy
          x: 0.958
          y: 0.912
          units: fraction
      - type: wait
        seconds: 5
      - type: screenshot
        mode: monitor
        monitor: window
    exit_steps:
      - type: press
        key: esc
      - type: wait
        seconds: 1
'''

DEFAULTS = yaml.safe_load(DEFAULT_CONFIG_YAML)
HEADER = DEFAULT_CONFIG_YAML.split("\n\nvk:")[0] + "\n\n"


def base_dir():
    """Папка программы (рядом с exe или корень проекта)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def resolve_path(path, root=None):
    if not path:
        return path
    path = os.path.expandvars(os.path.expanduser(str(path)))
    if os.path.isabs(path):
        return path
    return os.path.normpath(os.path.join(root or base_dir(), path))


def deep_merge(base, override):
    """Рекурсивно объединяет словари; списки и значения из override заменяют базовые."""
    result = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def normalize_step(step):
    """Шаг можно записать строкой ("maximize") или словарём."""
    if isinstance(step, str):
        return {"type": step}
    if isinstance(step, dict) and "type" not in step and len(step) == 1:
        (k, v), = step.items()
        if isinstance(v, dict):
            return dict(v, type=k)
        return {"type": k}
    return dict(step)


def _walk_steps(steps):
    for step in steps or []:
        step = normalize_step(step)
        yield step
        yield from _walk_steps(step.get("if_missing"))
        yield from _walk_steps(step.get("retry_steps"))
        fb = step.get("fallback")
        if fb:
            yield from _walk_steps(fb if isinstance(fb, list) else [fb])


def iter_all_steps(source):
    yield from _walk_steps(source.get("steps"))
    yield from _walk_steps(source.get("exit_steps"))


def validate(cfg):
    """Возвращает список ошибок (пустой — всё хорошо)."""
    errors = []
    vk = cfg.get("vk", {})
    if vk.get("sender") not in ("browser", "group_api"):
        errors.append("vk.sender должен быть browser или group_api")
    elif vk.get("sender") == "group_api" and not vk.get("group_token"):
        errors.append("vk.sender: group_api — укажите vk.group_token (ключ доступа сообщества)")
    vb = cfg.get("vk_browser") or {}
    if not isinstance(vb.get("selectors") or {}, dict):
        errors.append("vk_browser.selectors должен быть словарём «ключ: [селекторы]»")
    try:
        int(vk.get("peer_id") or 0)
    except (TypeError, ValueError):
        errors.append("vk.peer_id должен быть числом")
    sm = (cfg.get("sent_check") or {}).get("minutes")
    if sm is not None and (not isinstance(sm, list) or not sm or len(sm) > 15 or not all(
            isinstance(x, int) and not isinstance(x, bool) and 1 <= x <= 59 for x in sm)):
        errors.append("sent_check.minutes — список от 1 до 15 минут часа (1–59)")
    minute = cfg.get("schedule", {}).get("minute", 0)
    if not isinstance(minute, int) or not 0 <= minute <= 59:
        errors.append("schedule.minute должен быть от 0 до 59")
    pw = cfg.get("schedule", {}).get("prewarm_minutes", 5)
    if not isinstance(pw, int) or not 0 <= pw <= 15:
        errors.append("schedule.prewarm_minutes должен быть от 0 до 15")
    cd = cfg.get("countdown") or {}
    sec = cd.get("seconds", 60)
    if isinstance(sec, bool) or not isinstance(sec, int) or not 0 <= sec <= 60:
        errors.append("countdown.seconds должен быть от 0 до 60 секунд (0 — без отсчёта)")
    op = cd.get("opacity", 75)
    if isinstance(op, bool) or not isinstance(op, int) or not 30 <= op <= 100:
        errors.append("countdown.opacity должен быть от 30 до 100 (%)")
    lk = cfg.get("input_lock") or {}
    try:
        parse_hotkey(lk.get("hotkey", DEFAULT_HOTKEY))
    except ValueError as e:
        errors.append(f"input_lock.hotkey: {e}")
    wd = lk.get("watchdog_sec", 30)
    if isinstance(wd, bool) or not isinstance(wd, int) or not 5 <= wd <= 30:
        errors.append("input_lock.watchdog_sec должен быть от 5 до 30")
    es = lk.get("early_sec", 5)
    if isinstance(es, bool) or not isinstance(es, int) or not 0 <= es <= 15:
        errors.append("input_lock.early_sec должен быть от 0 до 15 секунд")
    oc = cfg.get("oasys_check") or {}
    ot = oc.get("timeout_sec", 10)
    if isinstance(ot, bool) or not isinstance(ot, int) or not 3 <= ot <= 30:
        errors.append("oasys_check.timeout_sec должен быть от 3 до 30 секунд")
    mp = cfg.get("media_pause")
    if mp is not None and not isinstance(mp, dict):
        errors.append("media_pause должен быть разделом с enabled и resume")
    elif mp:
        for k in ("enabled", "resume"):
            if k in mp and not isinstance(mp[k], bool):
                errors.append(f"media_pause.{k} должен быть true или false")
    cl = cfg.get("cleanup") or {}
    try:
        parse_cleanup_time(cl.get("time", "12:30"))
    except ValueError as e:
        errors.append(f"cleanup.time: {e}")
    kh = cl.get("keep_hours", 24)
    if not isinstance(kh, int) or not 1 <= kh <= 24 * 30:
        errors.append("cleanup.keep_hours должен быть от 1 до 720 часов")
    names = set()
    for i, src in enumerate(cfg.get("sources") or []):
        name = src.get("name") or f"#{i + 1}"
        if name in names:
            errors.append(f"Повторяется имя источника: {name}")
        names.add(name)
        win = src.get("window") or {}
        if not (win.get("title_regex") or win.get("process_regex")):
            errors.append(f"{name}: укажите window.title_regex или window.process_regex")
        has_shot = False
        for step in iter_all_steps(src):
            t = step.get("type")
            if t not in STEP_TYPES:
                errors.append(f"{name}: неизвестный тип шага «{t}»")
            if t in ("click_image", "ensure_image_visible") and not step.get("template"):
                errors.append(f"{name}: шаг {t} без template")
            if t == "screenshot":
                has_shot = True
        if not has_shot:
            errors.append(f"{name}: нет шага screenshot")
    return errors


def load_config(path):
    """Читает config.yaml; если файла нет — создаёт его с настройками по умолчанию."""
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(DEFAULT_CONFIG_YAML)
        return copy.deepcopy(DEFAULTS)
    with open(path, "r", encoding="utf-8-sig") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError("config.yaml: ожидается словарь настроек")
    return deep_merge(DEFAULTS, data)


def save_config(cfg, path):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(HEADER)
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False, default_flow_style=False)
    os.replace(tmp, path)


def template_list(cfg, root=None):
    """Все шаблоны из настроек: [(источник, путь, подсказка, существует)]."""
    out, seen = [], set()
    for src in cfg.get("sources") or []:
        for step in iter_all_steps(src):
            tpl = step.get("template")
            if tpl and tpl not in seen:
                seen.add(tpl)
                full = resolve_path(tpl, root)
                out.append((src.get("name", ""), tpl, step.get("hint", ""), os.path.exists(full)))
    return out


def is_configured(cfg):
    """Пройден ли мастер первой настройки (есть вход в ВК и беседа)."""
    vk = cfg.get("vk") or {}
    if vk.get("sender") == "group_api":
        login = bool(vk.get("group_token"))
    else:
        login = bool(vk.get("login_ok"))
    chat = bool(vk.get("peer_id") or vk.get("chat_search_title"))
    return bool(cfg.get("app", {}).get("setup_done") and login and chat)


OLD_WINDOW_DEFAULTS = {
    # имя источника: (старые заголовки по умолчанию, новые настройки окна)
    "oasys": ({"(?i)oasys", "oasys", "Oasys", "OASys"},
              {"title_regex": "(?i)oasys", "process_regex": r"(?i)^oasys\.admin\.exe$"}),
    "ivms-4200": ({"iVMS-4200", "(?i)iVMS-4200", "(?i)ivms-4200"},
                  {"title_regex": "(?i)ivms-4200", "process_regex": "(?i)^ivms-4200"}),
}


def _migrate_window(src):
    """Старые настройки поиска окна (только заголовок, с учётом регистра) → новые (процесс ИЛИ заголовок)."""
    key = str(src.get("name", "")).strip().lower()
    if key not in OLD_WINDOW_DEFAULTS:
        return []
    old_titles, new = OLD_WINDOW_DEFAULTS[key]
    win = src.setdefault("window", {})
    if win.get("process_regex") or win.get("title_regex", "") not in old_titles:
        return []  # настроено вручную — не трогаем
    win.update(new)
    return [f"{src.get('name')}: окно теперь ищется и по имени процесса, без учёта регистра"]


def _migrate_oasys_shot(src):
    """2.1.1: снимок Oasys — весь монитор (с панелью задач), а не только окно."""
    if str(src.get("name", "")).strip().lower() != "oasys":
        return []
    shots = [st for st in src.get("steps") or [] if isinstance(st, dict) and st.get("type") == "screenshot"]
    if len(shots) == 1 and str(shots[0].get("mode", "window")) == "window":
        shots[0]["mode"] = "monitor"
        shots[0]["monitor"] = "window"
        return ["Oasys: теперь снимается весь монитор с окном Oasys — вместе с панелью задач"]
    return []


def _merge_login_selectors(vb):
    """2.1.3: дописать в свои селекторы vk_browser.selectors.logged_in признаки входа нового дизайна ВК.
    Свои селекторы остаются, порядок не меняется; повторный запуск ничего не дублирует."""
    from .vk_browser import NEW_LOGGED_IN_SELECTORS
    sel = vb.get("selectors")
    if not isinstance(sel, dict) or not sel.get("logged_in"):
        return []  # своих нет — и так берутся значения по умолчанию
    cur = sel["logged_in"]
    cur = [cur] if isinstance(cur, str) else list(cur)
    add = [x for x in NEW_LOGGED_IN_SELECTORS if x not in cur]
    if not add:
        return []
    sel["logged_in"] = cur + add
    return [f"Добавлены признаки входа для нового дизайна ВК ({len(add)} шт.)"]


def _migrate_notifications(cfg):
    """2.1.4: уведомления Windows за 5 и 1 минуту (notifications) → свой обратный отсчёт (countdown).
    Выключенные уведомления → выключенный отсчёт; свои значения countdown не трогаются."""
    if "notifications" not in cfg:
        return []
    old = cfg.pop("notifications")
    cd = cfg.get("countdown")
    if not isinstance(cd, dict):
        cd = cfg["countdown"] = {}
    from .scheduler import DEFAULT_COUNTDOWN_OPACITY, DEFAULT_COUNTDOWN_SEC, countdown_opacity, countdown_seconds
    cd["seconds"] = countdown_seconds(cd.get("seconds", DEFAULT_COUNTDOWN_SEC))
    cd["opacity"] = countdown_opacity(cd.get("opacity", DEFAULT_COUNTDOWN_OPACITY))
    if isinstance(old, dict) and old.get("enabled", True) is False:
        cd["enabled"] = False       # уведомления были выключены — отсчёт тоже не показываем
    else:
        cd.setdefault("enabled", True)
    return ["Уведомления Windows за 5 и 1 минуту заменены обратным отсчётом за "
            f"{cd['seconds']} с в углу экрана" + ("" if cd["enabled"] else " (выключен, как и уведомления)")]


CONFIG_VERSION = "3.0.2"


def _version_tuple(v):
    out = []
    for part in str(v or "0").split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def _migrate_countdown_215(cfg):
    """2.1.5: длина отсчёта — ползунок 0…60 с, флажка «включено» больше нет: enabled: false → 0,
    больше 60 → 60. Повторный запуск ничего не меняет."""
    cd = cfg.get("countdown")
    if not isinstance(cd, dict):
        return []
    notes = []
    from .scheduler import COUNTDOWN_MAX_SEC, DEFAULT_COUNTDOWN_SEC
    enabled = cd.pop("enabled", None)
    try:
        sec = int(round(float(cd.get("seconds", DEFAULT_COUNTDOWN_SEC))))
    except (TypeError, ValueError):
        sec = DEFAULT_COUNTDOWN_SEC
    if enabled is False:
        if sec != 0:
            notes.append("Обратный отсчёт был выключен — теперь это «0 секунд» на ползунке")
        sec = 0
    elif sec > COUNTDOWN_MAX_SEC:
        notes.append(f"Обратный отсчёт теперь не длиннее {COUNTDOWN_MAX_SEC} секунд (было {sec})")
        sec = COUNTDOWN_MAX_SEC
    elif sec < 0:
        sec = 0
    cd["seconds"] = sec
    return notes


def _migrate_lock_215(cfg):
    """2.1.5: сторож блокировки — не больше 30 секунд."""
    lk = cfg.get("input_lock")
    if not isinstance(lk, dict):
        return []
    try:
        wd = int(lk.get("watchdog_sec", 30))
    except (TypeError, ValueError):
        wd = 30
    if wd > 30:
        lk["watchdog_sec"] = 30
        return [f"Блокировка мыши и клавиатуры теперь снимается сама не позже чем через 30 секунд (было {wd})"]
    return []


def _wait_ready_step():
    """Шаг проверки «Карты клуба» из настроек по умолчанию (копия)."""
    for src in DEFAULTS.get("sources") or []:
        for st in src.get("steps") or []:
            if isinstance(st, dict) and st.get("type") == "wait_ready":
                return copy.deepcopy(st)
    return {"type": "wait_ready"}


def _migrate_oasys_ready(src):
    """2.1.5: в шаги Oasys перед снимком добавляется проверка загрузки (wait_ready)."""
    if str(src.get("name", "")).strip().lower() != "oasys":
        return []
    steps = src.get("steps")
    if not isinstance(steps, list) or any(normalize_step(st).get("type") == "wait_ready" for st in steps):
        return []
    for i, st in enumerate(steps):
        if normalize_step(st).get("type") == "screenshot":
            steps.insert(i, _wait_ready_step())
            return ["Oasys: перед снимком теперь проверяется, что «Карта клуба» загрузилась"]
    return []


IVMS_VIEW_FALLBACK = [{"type": "click_xy", "x": 84, "y": 88, "units": "pixels"}, {"type": "wait", "seconds": 0.5},
                      {"type": "click_xy", "x": 103, "y": 200, "units": "pixels", "double": True}]


def _migrate_ivms_view(src):
    """2.2.5: в шаги iVMS после «Main View» добавляется выбор пресета вида (select_view). Записанный
    сценарий (recorded) не трогается."""
    if src.get("kind") != "ivms" or src.get("recorded"):
        return []
    steps = src.get("steps")
    if not isinstance(steps, list) or any(normalize_step(st).get("type") == "select_view" for st in steps):
        return []
    src.setdefault("view_preset", "cam")
    step = {"type": "select_view", "settle_sec": 3, "fallback": [dict(x) for x in IVMS_VIEW_FALLBACK]}
    at = None
    for i, st in enumerate(steps):
        st = normalize_step(st)
        if "main_view" in str(st.get("template", "")):
            at = i + 1
            if at < len(steps) and normalize_step(steps[at]).get("type") == "wait":
                at += 1
            break
    if at is None:
        for i, st in enumerate(steps):
            st = normalize_step(st)
            if "fullscreen" in str(st.get("template", "")) or st.get("type") == "screenshot":
                at = i
                break
    if at is None:
        return []
    steps.insert(at, step)
    return [f"Версия 2.2.5: iVMS — перед снимком выбирается пресет вида «{src.get('view_preset')}» "
            "(Resource → Custom View); пусто в «Пресет вида iVMS» — не выбирать"]


def _migrate_sent_check_302(cfg):
    """3.0.2: одна проверка в :05 (check_after_min) → список минут sent_check.minutes (по умолчанию 5, 7, 10)."""
    from .sentcheck import CHECK_OFFSETS, normalize_minutes
    sc = cfg.get("sent_check")
    if not isinstance(sc, dict):
        return []
    old = sc.pop("check_after_min", None)
    if "minutes" in sc:
        fixed = normalize_minutes(sc["minutes"])
        if fixed != sc["minutes"]:
            sc["minutes"] = fixed
            return ["sent_check.minutes исправлен: " + ", ".join(f":{m:02d}" for m in fixed)]
        return []
    base = list(CHECK_OFFSETS)
    if old not in (None, 5):
        base = normalize_minutes([old] + base)
    sc["minutes"] = base
    return ["Версия 3.0.2: проверка, что скрины на месте, теперь в " + ", ".join(f":{m:02d}" for m in base)
            + " (минуты меняются в «Настройках»)"]


def _migrate_ack_wait_308(vb):
    """3.0.8: ожидание подтверждения ВК после «Отправить» — 40 с вместо 20 (только если стояло старое 20)."""
    try:
        old = float(vb.get("ack_wait_sec"))
    except (TypeError, ValueError):
        return []
    if old != 20:
        return []
    vb["ack_wait_sec"] = 40
    return ["Ожидание подтверждения ВК после «Отправить» увеличено с 20 до 40 секунд (3.0.8)"]


def migrate(cfg):
    """Переход со старых версий. Меняет cfg на месте, возвращает список сообщений для журнала.
    Главное: токен ПОЛЬЗОВАТЕЛЯ (вход через стороннее приложение) больше не используется и стирается."""
    notes = []
    vk = cfg.setdefault("vk", {})
    token = vk.pop("token", None)
    ttype = vk.pop("token_type", None)
    if token and ttype == "group":
        if not vk.get("group_token"):
            vk["group_token"] = token
        vk["sender"] = "group_api"
        notes.append("Токен сообщества перенесён в vk.group_token (отправка через сообщество)")
    elif token:
        vk["sender"] = "browser"
        vk["login_ok"] = False
        vk["account_name"] = ""
        cfg.setdefault("app", {})["setup_done"] = False
        notes.append("Старый токен пользователя ВК удалён из config.yaml: теперь отправка идёт через окно "
                     "браузера программы. Войдите в ВК заново в мастере настройки (шаг «Вход ВК»).")
    elif ttype is not None:
        notes.append("Устаревшая настройка vk.token_type удалена")
    vb = cfg.get("vk_browser")
    if isinstance(vb, dict):
        gone = [k for k in ("channel", "window", "headless") if k in vb]
        for k in gone:
            vb.pop(k)
        if gone:
            notes.append("Браузер ВК теперь встроен в окно программы — настройки отдельного браузера "
                         f"({', '.join(gone)}) удалены")
        old_waits = {"page_timeout_sec": (45, 30), "upload_timeout_sec": (120, 45), "verify_timeout_sec": (30, 20),
                     "upload_fallback_wait_sec": (10, 8)}
        changed = [k for k, (was, now) in old_waits.items() if vb.get(k) == was]
        for k in changed:
            vb[k] = old_waits[k][1]
        if changed:
            notes.append("Ожидания при отправке в ВК сокращены (вся отправка — не дольше 90 секунд)")
        notes += _migrate_ack_wait_308(vb)
        notes += _merge_login_selectors(vb)
    app = cfg.setdefault("app", {})
    ver = _version_tuple(app.get("config_version"))
    for src in cfg.get("sources") or []:
        notes += _migrate_window(src)
        if ver < (2, 1, 1):
            notes += _migrate_oasys_shot(src)
        if ver < (2, 1, 5):
            notes += _migrate_oasys_ready(src)
        if not src.get("kind"):
            from .sources import guess_kind
            src["kind"] = guess_kind(src)
            notes.append(f"Версия 2.2.0: «{src.get('name', 'программа')}» — тип программы определён автоматически")
        if ver < (2, 2, 5):
            notes += _migrate_ivms_view(src)
    notes += _migrate_sent_check_302(cfg)
    lm = cfg.setdefault("light_mode", {})
    if str(lm.get("mode", "")).lower() not in ("on", "off"):   # 3.0.3: «auto» и пусто → выключен
        lm["mode"] = "off"
    tg = cfg.setdefault("tagged", {})          # 3.0.3: режим «аккаунт программы + тег часа», выключен
    for k, v in (("enabled", False), ("caption", "Камеры за {hour}"), ("late_suffix", " (снято в {shot})"),
                 ("late_after_min", 5), ("account_id", "")):
        tg.setdefault(k, v)
    app["config_version"] = CONFIG_VERSION
    from . import cammode
    cammode.sync(cfg)   # 3.0.15: режим программы камер (старые конфиги — iVMS, без изменений)
    notes += _migrate_notifications(cfg)
    notes += _migrate_countdown_215(cfg)
    notes += _migrate_lock_215(cfg)
    mp = cfg.get("media_pause")
    if not isinstance(mp, dict):
        cfg["media_pause"] = {"enabled": False, "resume": True}   # 2.1.6: новая настройка, выключена
    else:
        mp.setdefault("enabled", False)
        mp.setdefault("resume", True)
    sched = cfg.setdefault("schedule", {})
    if int(sched.get("attempts", 2) or 1) > 2:
        sched["attempts"] = 2
        notes.append("Попыток в час теперь не больше 2")
    ri = int(sched.get("retry_interval_sec", 60) or 0)
    if ri < 60 or ri == 180:   # 3.0.3: прежнее значение по умолчанию 180 → 60 (повтор в пределах 5 минут)
        sched["retry_interval_sec"] = 60
        notes.append("Пауза между попытками — 1 минута (повтор успевает до ЧЧ:05)")
    return notes


def wizard_templates(source, root=None):
    """Шаблоны источника для мастера: [(путь, подсказка, обязательный, существует)]."""
    out, seen = [], set()
    for step in iter_all_steps(source):
        tpl = step.get("template")
        mode = str(step.get("wizard", "required")).lower()
        if not tpl or tpl in seen or mode == "hidden":
            continue
        seen.add(tpl)
        out.append((tpl, step.get("hint", ""), mode != "optional", os.path.exists(resolve_path(tpl, root))))
    out.sort(key=lambda t: not t[2])
    return out
