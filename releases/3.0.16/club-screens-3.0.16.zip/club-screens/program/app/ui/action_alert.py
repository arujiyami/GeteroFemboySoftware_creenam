# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.16: «Нужно ваше действие» — своё окошко в правом нижнем углу, такое же, как предупреждение о
блокировке мыши и клавиатуры (то же место, тот же вид), с текстом, миниатюрами отправленных картинок
(если есть) и кнопкой «Закрыть». Не уведомление Windows, ввод не блокирует, фокус не забирает.

Окошко блокировки главнее: пока оно на экране, идёт съёмка или отправка, предупреждение ждёт (а если уже
было показано — прячется и вернётся потом). Во время съёмки оно спрятано и исключено из снимков экрана.
Одно событие — одно окошко: повтор того же события не показывается."""
import logging
import os
import sys

from PySide6.QtCore import QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QGuiApplication, QPainter, QPainterPath, QPixmap
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from .countdown import MARGIN, PAD_X, PAD_Y, RADIUS, win_click_through

log = logging.getLogger("club")

CLOSE_TEXT = "Закрыть"
TITLE = "Нужно ваше действие"
THUMB_W, THUMB_H = 160, 90
TEXT_W = 340


class AlertQueue:
    """Логика без Qt: очередь событий, «один раз на событие», ожидание, пока занято окошко блокировки."""

    def __init__(self, blocked, show, hide):
        self.blocked, self._show, self._hide = blocked, show, hide
        self.seen = set()
        self.pending = []          # [(key, text, thumbs)]
        self.current = None        # показано (или спрятано на время блокировки) сейчас
        self.visible = False

    def post(self, key, text, thumbs=()):
        """False — это событие уже было (повтор не показываем)."""
        if not text or key in self.seen:
            return False
        self.seen.add(key)
        self.pending.append((key, text, list(thumbs or [])))
        self.pump()
        return True

    def pump(self):
        """Вызывать часто (таймер) и при смене состояния: показывает/прячет по приоритету блокировки."""
        if self.blocked():
            if self.visible:
                self.visible = False
                self._hide()
            return
        if self.current is None and self.pending:
            self.current = self.pending.pop(0)
        if self.current is not None and not self.visible:
            self.visible = True
            self._show(self.current[1], self.current[2])

    def close(self):
        """Кнопка «Закрыть»: это событие закрыто; следующее (если есть) — после паузы pump()."""
        self.current = None
        if self.visible:
            self.visible = False
            self._hide()
        self.pump()


class ActionAlertWindow(QWidget):
    """Окошко с текстом, миниатюрами и кнопкой «Закрыть». Вид и место — как у окошка блокировки."""

    FLAGS = (Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool
             | Qt.WindowType.WindowDoesNotAcceptFocus | Qt.WindowType.NoDropShadowWindowHint)

    def __init__(self, on_close=None):
        super().__init__(None, self.FLAGS)
        for attr in (Qt.WidgetAttribute.WA_TranslucentBackground, Qt.WidgetAttribute.WA_ShowWithoutActivating,
                     Qt.WidgetAttribute.WA_NoSystemBackground):
            self.setAttribute(attr, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setWindowTitle(TITLE)
        self.on_close = on_close
        self.excluded = False
        f = QFont("Segoe UI" if sys.platform == "win32" else "DejaVu Sans")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(PAD_X, PAD_Y, PAD_X, PAD_Y)
        lay.setSpacing(6)
        self.title = QLabel(TITLE, self)
        tf = QFont(f)
        tf.setPointSizeF(12)
        tf.setBold(True)
        self.title.setFont(tf)
        self.title.setStyleSheet("color:#ffb74d;background:transparent;")
        self.text = QLabel(self)
        sf = QFont(f)
        sf.setPointSizeF(9.5)
        self.text.setFont(sf)
        self.text.setWordWrap(True)
        self.text.setFixedWidth(TEXT_W)
        self.text.setStyleSheet("color:white;background:transparent;")
        self.thumbs = QWidget(self)
        self.thumbs_row = QHBoxLayout(self.thumbs)
        self.thumbs_row.setContentsMargins(0, 0, 0, 0)
        self.thumbs_row.setSpacing(6)
        self.btn = QPushButton(CLOSE_TEXT, self)
        self.btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn.setFixedHeight(28)
        self.btn.setStyleSheet("QPushButton{background:rgba(255,255,255,40);color:white;border:1px solid "
                               "rgba(255,255,255,90);border-radius:6px;padding:2px 14px;}"
                               "QPushButton:hover{background:rgba(255,255,255,70);}")
        self.btn.clicked.connect(self._close)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(self.btn)
        for w in (self.title, self.text, self.thumbs):
            lay.addWidget(w)
        lay.addLayout(row)

    def set_content(self, text, thumbs=()):
        self.text.setText(text)
        while self.thumbs_row.count():
            it = self.thumbs_row.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        n = 0
        for p in list(thumbs or [])[:2]:
            pm = QPixmap(p) if p and os.path.isfile(p) else QPixmap()
            if pm.isNull():
                continue
            lb = QLabel(self.thumbs)
            lb.setPixmap(pm.scaled(THUMB_W, THUMB_H, Qt.AspectRatioMode.KeepAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation))
            self.thumbs_row.addWidget(lb)
            n += 1
        self.thumbs.setVisible(bool(n))
        self.adjustSize()

    def show_alert(self, text, thumbs=()):
        self.set_content(text, thumbs)
        hwnd = int(self.winId())
        _, self.excluded = win_click_through(hwnd, interactive=True)   # не на снимках, без фокуса
        self.place()
        self.show()
        log.info("Окошко «%s» показано: %s", TITLE, text)

    def place(self):
        """То же место, что у окошка блокировки: правый нижний угол рабочей области основного экрана."""
        scr = QGuiApplication.primaryScreen()
        if scr is None:
            return
        g = scr.availableGeometry()
        self.move(g.right() - self.width() - MARGIN + 1, g.bottom() - self.height() - MARGIN + 1)

    def _close(self):
        self.hide()
        if self.on_close:
            self.on_close()

    def paintEvent(self, _):  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(r, RADIUS, RADIUS)
        p.fillPath(path, QColor(18, 22, 30, 235))
        p.setPen(QColor(255, 183, 77))
        p.drawPath(path)
        p.end()


class ActionAlerts:
    """Связка очереди и окошка для главного окна. blocked() — True, пока главнее окошко блокировки."""

    def __init__(self, blocked):
        self.win = None
        self.q = AlertQueue(blocked, self._show, self._hide)
        self.timer = QTimer()
        self.timer.setInterval(500)
        self.timer.timeout.connect(self.q.pump)
        self.timer.start()

    def _ensure(self):
        if self.win is None:
            self.win = ActionAlertWindow(on_close=self.q.close)
        return self.win

    def _show(self, text, thumbs):
        self._ensure().show_alert(text, thumbs)

    def _hide(self):
        if self.win is not None:
            self.win.hide()

    def post(self, key, text, thumbs=()):
        return self.q.post(key, text, thumbs)

    def hide_now(self):
        """Перед съёмкой: спрятать сразу (не ждать таймера)."""
        if self.q.visible:
            self.q.visible = False
            self._hide()
