# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.15: программа камер — iVMS-4200 (как раньше), TRASSIR или любая другая (по названию окна).

Режим хранится в cfg["camera"]["mode"]. Источник камер в cfg["sources"] — один (kind ivms/trassir/generic).
При смене режима прежний источник (вместе с записанными щелчками) откладывается в
cfg["camera"]["saved"][режим] и возвращается, если режим выбрать снова. Режим iVMS по умолчанию —
у существующих установок ничего не меняется."""
import copy
import re

CAMERA_KINDS = ("ivms", "trassir", "generic")
DEFAULT_MODE = "ivms"

# Подписи для настроек (по-человечески)
MODE_LABELS = {
    "ivms": "iVMS-4200 (Hikvision)",
    "trassir": "TRASSIR",
    "generic": "Другая программа — окно по названию",
}
MODE_HINTS = {
    "ivms": "Как раньше: вкладка Main View, вид камер, полный экран, на вопрос о сохранении — Cancel.",
    "trassir": "Окно TRASSIR Client выводится вперёд и снимается весь его монитор. TRASSIR сам показывает "
               "камеры на весь экран; если нужно что-то нажать (раскладка, вкладка) — запишите щелчки.",
    "generic": "Окно ищется по части названия (как в заголовке окна). Действия — только записанные щелчки; "
               "проверки iVMS выключены.",
}

# TRASSIR Client 4.x (t1client-vc142e.exe, Qt): заголовок «TRASSIR-4.9.15.0-…». Панель управления — узкая
# полоска вверху экрана того же процесса, поэтому берётся самое большое окно (монитор с камерами).
TRASSIR_WINDOW = {
    "title_regex": "(?i)^trassir",
    "process_regex": "(?i)^t1client",
    "exclude_title_regex": "(?i)(chrome|firefox|яндекс|yandex|edge|opera|вконтакте|telegram|"
                           "клуб-скриншоты|скриншоты клуба|настройки)",
}
EXCLUDE_BROWSERS = TRASSIR_WINDOW["exclude_title_regex"]


def mode_of(cfg):
    m = str(((cfg or {}).get("camera") or {}).get("mode") or DEFAULT_MODE).lower()
    return m if m in CAMERA_KINDS else DEFAULT_MODE


def generic_title(cfg):
    return str(((cfg or {}).get("camera") or {}).get("generic_title") or "").strip()


def title_regex_for(title):
    """Часть названия окна → регулярное выражение (без учёта регистра, буквально)."""
    title = (title or "").strip()
    return "(?i)" + re.escape(title) if title else ""


def _shot_steps():
    return [{"type": "wait", "seconds": 1},
            {"type": "screenshot", "mode": "monitor", "monitor": "window", "park_cursor": True}]


def default_source(mode, cfg=None):
    """Встроенный источник камер для режима (без записанных щелчков)."""
    if mode == "ivms":
        from .config import DEFAULTS
        for d in DEFAULTS.get("sources") or []:
            if d.get("kind") == "ivms":
                return copy.deepcopy(d)
    if mode == "trassir":
        # Не «развернуть»: монитор TRASSIR и так на весь экран, а развёртывание узкой панели всё испортит.
        return {"name": "TRASSIR", "kind": "trassir", "enabled": True,
                "window": dict(TRASSIR_WINDOW),
                "steps": [{"type": "activate_window"}, {"type": "wait", "seconds": 1.5}] + _shot_steps(),
                "exit_steps": []}
    title = generic_title(cfg)
    return {"name": title or "Камеры", "kind": "generic", "enabled": True,
            "window": {"title_regex": title_regex_for(title), "process_regex": "",
                       "exclude_title_regex": "(?i)(клуб-скриншоты|скриншоты клуба)"},
            "steps": [{"type": "activate_window"}, {"type": "maximize"}, {"type": "wait", "seconds": 1}]
            + _shot_steps(),
            "exit_steps": []}


def builtin_steps(kind, cfg=None):
    if kind in ("trassir", "generic"):
        return copy.deepcopy(default_source(kind, cfg)["steps"])
    return None


def camera_index(cfg):
    for i, src in enumerate((cfg or {}).get("sources") or []):
        if src.get("kind") in CAMERA_KINDS:
            return i
    return None


def set_generic_title(cfg, title):
    """Название окна для режима «Другая программа»; обновляет источник, если он сейчас выбран."""
    cam = cfg.setdefault("camera", {})
    cam["generic_title"] = (title or "").strip()
    i = camera_index(cfg)
    if i is not None and cfg["sources"][i].get("kind") == "generic":
        src = cfg["sources"][i]
        src.setdefault("window", {})["title_regex"] = title_regex_for(title)
        src["window"]["process_regex"] = ""
        if title:
            src["name"] = cam["generic_title"]


def set_mode(cfg, mode):
    """Переключить режим. → True, если источник камер поменялся."""
    mode = mode if mode in CAMERA_KINDS else DEFAULT_MODE
    cam = cfg.setdefault("camera", {})
    saved = cam.setdefault("saved", {})
    sources = cfg.setdefault("sources", [])
    i = camera_index(cfg)
    cur = sources[i] if i is not None else None
    old = cur.get("kind") if cur else None
    cam["mode"] = mode
    if old == mode:
        return False
    if cur is not None:
        saved[old] = copy.deepcopy(cur)
    new = copy.deepcopy(saved.pop(mode, None) or default_source(mode, cfg))
    if cur is not None:
        new["enabled"] = cur.get("enabled", True)
        sources[i] = new
    else:
        sources.append(new)
    if mode == "generic":
        set_generic_title(cfg, generic_title(cfg))
    return True


def sync(cfg):
    """После загрузки: режим совпадает с источником камер (старые конфиги — iVMS, ничего не меняется)."""
    cam = cfg.setdefault("camera", {})
    i = camera_index(cfg)
    if "mode" not in cam or cam.get("mode") not in CAMERA_KINDS:
        cam["mode"] = cfg["sources"][i]["kind"] if i is not None else DEFAULT_MODE
        return
    if i is not None and cfg["sources"][i].get("kind") != cam["mode"]:
        set_mode(cfg, cam["mode"])


def check(cfg):
    """Понятная проблема настройки режима или ""."""
    if mode_of(cfg) == "generic" and not generic_title(cfg):
        return "Не указано название окна программы камер (Настройки → Программа камер)"
    return ""


def window_warning(kind, rect, monitor):
    """Окно слишком маленькое относительно монитора (например, у TRASSIR нашлась только панель) → текст."""
    if kind not in ("trassir", "generic") or not rect or not monitor:
        return ""
    w, h = rect[2], rect[3]
    if w < 0.4 * monitor[2] or h < 0.4 * monitor[3]:
        return (f"окно программы камер маленькое ({w}×{h}) — снимается весь монитор; откройте камеры "
                "на весь экран")
    return ""
