# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.13: «Снять сейчас» / «Снять позже» в окошке предупреждения, ручной съём сочетанием (Ctrl+Alt+S)
с :50 до :10, за какой час идёт съём, замок «час занят», отметка часа только по подтверждению ВК + номеру."""
import copy
import os
import shutil
import tempfile
import threading
import unittest
from datetime import datetime, timedelta
from unittest import mock

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from app import __version__, dupcheck, hourdone, msgids, quickshot  # noqa: E402
from app.config import DEFAULTS  # noqa: E402
from app.scheduler import HourlyScheduler  # noqa: E402

PEER, OTHER = 2000000777, 2000000888
D = datetime(2026, 11, 3)


def t(h, m, s=0):
    return D.replace(hour=h, minute=m, second=s)


class Window(unittest.TestCase):
    def test_boundaries(self):
        self.assertIsNone(quickshot.slot_for(t(10, 49, 59), 0))
        self.assertEqual(quickshot.slot_for(t(10, 50, 0), 0), t(11, 0))
        self.assertEqual(quickshot.slot_for(t(10, 59, 59), 0), t(11, 0))
        self.assertEqual(quickshot.slot_for(t(11, 0, 0), 0), t(11, 0))
        self.assertEqual(quickshot.slot_for(t(11, 10, 0), 0), t(11, 0))
        self.assertIsNone(quickshot.slot_for(t(11, 10, 1), 0))

    def test_midnight_and_other_minute(self):
        self.assertEqual(quickshot.slot_for(t(23, 55), 0), D + timedelta(days=1))
        self.assertEqual(quickshot.slot_for(t(10, 10), 15), t(10, 15))     # минута съёма 15: окно :05–:25
        self.assertEqual(quickshot.slot_for(t(10, 25), 15), t(10, 15))
        self.assertIsNone(quickshot.slot_for(t(10, 4, 59), 15))

    def test_hotkey_outside_window_does_nothing(self):
        self.assertEqual(quickshot.decide(t(10, 30), 0), (quickshot.OUTSIDE, None))
        self.assertIn(":50", quickshot.outside_text(0))

    def test_done_and_busy(self):
        self.assertEqual(quickshot.decide(t(11, 5), 0, done_by="program"), (quickshot.DONE, t(11, 0)))
        self.assertEqual(quickshot.decide(t(10, 55), 0, busy=True), (quickshot.BUSY, t(11, 0)))
        self.assertEqual(quickshot.decide(t(10, 55), 0), (quickshot.RUN, t(11, 0)))

    def test_defaults(self):
        self.assertEqual(quickshot.settings(DEFAULTS), (True, "Shift+Alt+2"))
        self.assertTrue(quickshot.buttons_enabled(DEFAULTS))
        self.assertFalse(quickshot.buttons_enabled({"countdown": {"buttons": False}}))
        self.assertEqual(quickshot.settings({"manual_shot": {"hotkey": "мусор"}})[1], "Shift+Alt+2")

    def test_version(self):
        self.assertEqual(__version__, "3.0.16")


class Postpone(unittest.TestCase):
    def make(self, now):
        clock = {"t": now}
        sch = HourlyScheduler(lambda target: None, lambda: {"minute": 0}, now=lambda: clock["t"],
                              countdown=lambda target: None, countdown_seconds=lambda: 60,
                              early_seconds=lambda: 5)
        sch._plan({"minute": 0})
        p = mock.patch.object(HourlyScheduler, "running", new_callable=mock.PropertyMock, return_value=True)
        p.start()
        self.addCleanup(p.stop)
        return sch, clock

    def test_postpone_once(self):
        sch, clock = self.make(t(10, 58))
        self.assertFalse(sch.postpone())                     # предупреждения ещё нет
        clock["t"] = t(10, 59, 20)
        self.assertTrue(sch.can_postpone())
        self.assertTrue(sch.postpone())
        self.assertEqual(sch.next_target, t(11, 1))
        self.assertEqual(sch.slot, t(11, 0))                 # снимок — за 11:00
        clock["t"] = t(11, 0, 20)
        self.assertFalse(sch.can_postpone())
        self.assertFalse(sch.postpone())                     # второй раз — нельзя
        self.assertEqual(sch.next_target, t(11, 1))

    def test_shoot_now(self):
        sch, clock = self.make(t(10, 59, 30))
        self.assertTrue(sch.shoot_now())
        self.assertEqual(sch.start_at(), t(10, 59, 30))
        self.assertEqual(sch.slot, t(11, 0))

    def test_buttons_inactive_without_warning(self):
        sch, clock = self.make(t(10, 30))
        self.assertFalse(sch.shoot_now())
        self.assertFalse(sch.postpone())

    def test_guard_once_per_hour(self):
        g = quickshot.PostponeGuard()
        self.assertTrue(g.use(t(10, 59), t(11, 0)))
        self.assertFalse(g.use(t(11, 0, 30), t(11, 0)))
        self.assertFalse(g.allowed(t(11, 10), t(12, 0)))
        self.assertTrue(g.allowed(t(11, 59), t(12, 0)))


class VK:
    """API-режим: send_photos возвращает номер сообщения."""
    def __init__(self, fail=0, check=None, block=None):
        self.calls, self.fail, self.check, self.block = 0, fail, check, block

    def send_photos(self, peer, paths, message):
        self.calls += 1
        if self.check:
            self.check()
        if self.block:
            self.block.wait(20)
        if self.fail:
            self.fail -= 1
            raise RuntimeError("сеть недоступна")
        return 500 + self.calls


class Jobs(unittest.TestCase):
    def make(self, vk, now, root=None):
        from app.job import JobRunner
        from tests.test_steps_job import FakeBackend
        if root is None:
            root = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, root, True)
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["caption"] = "{time}"
        cfg["vk"]["peer_id"] = PEER
        cfg["schedule"]["attempts"] = 2
        cfg["schedule"]["manual_wait_sec"] = 30
        clock = {"t": now}
        job = JobRunner(lambda: cfg, lambda: FakeBackend(), vk_factory=lambda c: vk, root=root,
                        now=lambda: clock["t"], sleep=lambda s: None)
        job.online = lambda: True
        job.hour_already_sent = lambda *a, **k: False       # беседу (браузер) в этих тестах не открываем
        return job, root, cfg, clock

    def test_press_seconds_before_00_counts_next_hour(self):
        vk = VK()
        job, root, cfg, clock = self.make(vk, t(10, 59, 57))
        self.assertTrue(job.run_cycle(True, manual=True, for_hour=quickshot.slot_for(clock["t"], 0)))
        self.assertTrue(hourdone.done(root, t(11, 0), cfg))
        self.assertIsNone(hourdone.done(root, t(10, 0), cfg))
        self.assertEqual(msgids.get(root, t(11, 0), peer=PEER)["mid"], "501")
        clock["t"] = t(11, 0)
        self.assertTrue(job.run_cycle(True, capture_at=t(11, 0), for_hour=t(11, 0)))   # :00 — пропуск
        self.assertEqual(vk.calls, 1)

    def test_not_marked_at_start(self):
        seen = []
        vk = VK(check=lambda: seen.append(hourdone.done(root_box[0], t(11, 0), None)))
        root_box = []
        job, root, cfg, clock = self.make(vk, t(10, 55))
        root_box.append(root)
        job.run_cycle(True, manual=True, for_hour=t(11, 0))
        self.assertEqual(seen, [None])
        self.assertIsNone(job.inprogress)

    def test_failed_manual_then_00_retry(self):
        vk = VK(fail=1)
        job, root, cfg, clock = self.make(vk, t(10, 55))
        self.assertFalse(job.run_cycle(True, manual=True, for_hour=t(11, 0)))
        self.assertIsNone(hourdone.done(root, t(11, 0), cfg))
        self.assertEqual(vk.calls, 1)                     # ручной — одна попытка
        clock["t"] = t(11, 0)
        self.assertTrue(job.run_cycle(True, capture_at=t(11, 0), for_hour=t(11, 0)))
        self.assertEqual(vk.calls, 2)
        self.assertTrue(hourdone.done(root, t(11, 0), cfg))

    def test_max_two_automatic_attempts(self):
        vk = VK(fail=5)
        job, root, cfg, clock = self.make(vk, t(11, 0))
        self.assertFalse(job.run_cycle(True, capture_at=t(11, 0), for_hour=t(11, 0)))
        self.assertEqual(vk.calls, 2)

    def test_restart_mid_run(self):
        # программу закрыли во время ручного съёма: отметки нет, замок был только в памяти
        vk = VK()
        job, root, cfg, clock = self.make(vk, t(10, 56))
        job.inprogress = t(11, 0)
        self.assertIsNone(hourdone.done(root, t(11, 0), cfg))
        job2, _, _, clock2 = self.make(vk, t(11, 0), root=root)
        self.assertIsNone(job2.busy_hour())
        self.assertTrue(job2.run_cycle(True, capture_at=t(11, 0), for_hour=t(11, 0)))
        self.assertEqual(vk.calls, 1)

    def test_00_waits_for_manual_then_skips(self):
        go = threading.Event()
        vk = VK(block=go)
        job, root, cfg, clock = self.make(vk, t(10, 59, 50))
        th = threading.Thread(target=lambda: job.run_cycle(True, manual=True, for_hour=t(11, 0)))
        th.start()
        for _ in range(200):
            if vk.calls:
                break
            threading.Event().wait(0.02)
        self.assertEqual(job.busy_hour(), t(11, 0))
        res = {}
        th2 = threading.Thread(target=lambda: res.setdefault(
            "ok", job.run_cycle(True, capture_at=t(11, 0), for_hour=t(11, 0))))
        th2.start()
        threading.Event().wait(0.3)
        self.assertTrue(th2.is_alive())                   # ждёт ручной съём, а не снимает второй раз
        go.set()
        th.join(20)
        th2.join(20)
        self.assertTrue(res["ok"])
        self.assertEqual(vk.calls, 1)

    def test_unconfirmed_send_does_not_close_hour(self):
        class NoId(VK):
            def send_photos(self, peer, paths, message):
                self.calls += 1
                return "verified"                         # без номера сообщения
        vk = NoId()
        job, root, cfg, clock = self.make(vk, t(10, 55))
        job.run_cycle(True, manual=True, for_hour=t(11, 0))
        self.assertIsNone(hourdone.done(root, t(11, 0), cfg))


class EarlyMessageCheck(unittest.TestCase):
    def setUp(self):
        from tests.test_v3012 import shot
        self.d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.d, True)
        self.paths = [shot(self.d, "o.png", 1280, 960, (1, 2, 3)), shot(self.d, "i.png", 1280, 960, (4, 5, 6))]

    @staticmethod
    def nodl(url):
        raise AssertionError("по номеру картинки не качаются")

    def test_05_check_accepts_early_message_by_id(self):
        msgids.save(self.d, t(11, 0), "data-cmid=42", True, peer=PEER)     # отправлено в 10:55 за 11:00
        mid = msgids.get(self.d, t(11, 0), peer=PEER)
        page = {"msgs": [{"own": True, "t": 1, "mid": "data-cmid=42", "imgs": []}]}
        st, why = dupcheck.find_status(page, self.paths, t(11, 0), t(11, 5), download=self.nodl, mid=mid)
        self.assertEqual(st, dupcheck.FOUND, why)

    def test_other_hour_or_chat_not_accepted(self):
        msgids.save(self.d, t(11, 0), "data-cmid=42", True, peer=PEER)
        self.assertIsNone(msgids.get(self.d, t(12, 0), peer=PEER))
        self.assertIsNone(msgids.get(self.d, t(11, 0), peer=OTHER))

    def test_foreign_message_not_accepted(self):
        page = {"msgs": [{"own": False, "t": 1, "mid": "data-cmid=9", "imgs": []}]}
        st, _ = dupcheck.find_status(page, self.paths, t(11, 0), t(11, 5), download=self.nodl, mid=None)
        self.assertNotEqual(st, dupcheck.FOUND)


class Banner(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from PySide6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication([])

    def test_checkbox_off_same_as_before(self):
        from PySide6.QtWidgets import QPushButton
        from app.ui.countdown import CountdownOverlay
        off = CountdownOverlay(opacity=75, interactive=False)
        self.assertEqual(off.findChildren(QPushButton), [])
        on = CountdownOverlay(opacity=75, interactive=True)
        texts = sorted(b.text() for b in on.findChildren(QPushButton))
        self.assertEqual(texts, sorted([CountdownOverlay.__module__ and
                                        __import__("app.ui.countdown", fromlist=["x"]).NOW_TEXT,
                                        __import__("app.ui.countdown", fromlist=["x"]).LATER_TEXT]))

    def test_later_disabled_when_used(self):
        from PySide6.QtWidgets import QPushButton
        from app.ui import countdown as cd
        on = cd.CountdownOverlay(opacity=75, interactive=True)
        on.set_buttons(lambda: None, lambda: None, False)
        later = [b for b in on.findChildren(QPushButton) if b.text() == cd.LATER_TEXT][0]
        self.assertFalse(later.isEnabled())


if __name__ == "__main__":
    unittest.main()


class DefaultHotkey(unittest.TestCase):
    def test_shift_alt_2_main_row(self):
        from app.globalhotkey import MOD_ALT, MOD_NOREPEAT, MOD_SHIFT, win_mods
        hk = quickshot.parse(quickshot.DEFAULT_HOTKEY)
        self.assertEqual(hk.vk, 0x32)                                   # VK_2, верхний ряд (не VK_NUMPAD2)
        self.assertEqual(win_mods(hk), MOD_SHIFT | MOD_ALT | MOD_NOREPEAT)
        self.assertEqual(quickshot.fmt(hk), "Shift+Alt+2")

    def test_shifted_symbol_is_digit(self):
        for text in ("Alt+Shift+@", 'Shift+Alt+"', "Shift+Alt+2"):
            self.assertEqual(quickshot.parse(text).vk, 0x32, text)

    def test_no_conflict_with_unlock_default(self):
        from app.inputlock import DEFAULT_HOTKEY, parse_hotkey
        self.assertNotEqual(parse_hotkey(DEFAULT_HOTKEY), quickshot.parse(quickshot.DEFAULT_HOTKEY))

    def test_settings_default_button_and_conflict(self):
        from PySide6.QtWidgets import QApplication
        QApplication.instance() or QApplication([])
        from PySide6.QtGui import QKeySequence
        seq = QKeySequence(quickshot.DEFAULT_HOTKEY).toString(QKeySequence.SequenceFormat.PortableText)
        self.assertEqual(quickshot.parse(seq).vk, 0x32)
