# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.16: «Нужно ваше действие» — своё окошко как у блокировки; один раз на событие; блокировка главнее."""
import os
import tempfile
import threading
import unittest
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtGui import QColor, QGuiApplication, QImage  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app.ui.action_alert import CLOSE_TEXT, ActionAlertWindow, AlertQueue  # noqa: E402
from app.ui.countdown import MARGIN, CountdownOverlay  # noqa: E402

app = QApplication.instance() or QApplication([])


class Q:
    def __init__(self):
        self.block = False
        self.log = []
        self.q = AlertQueue(lambda: self.block, lambda t, th: self.log.append(("show", t, tuple(th))),
                            lambda: self.log.append(("hide",)))


class Queue(unittest.TestCase):
    def test_once_per_event(self):
        t = Q()
        self.assertTrue(t.q.post("e1", "не те картинки"))
        self.assertFalse(t.q.post("e1", "не те картинки"))
        self.assertEqual(t.log, [("show", "не те картинки", ())])

    def test_waits_while_lock_visible(self):
        t = Q()
        t.block = True
        t.q.post("e1", "текст")
        t.q.pump()
        self.assertEqual(t.log, [])               # ждёт, пока окошко блокировки/съёмка
        t.block = False
        t.q.pump()
        self.assertEqual(t.log, [("show", "текст", ())])

    def test_hides_when_lock_appears_and_returns(self):
        t = Q()
        t.q.post("e1", "текст", ["a.png"])
        t.block = True
        t.q.pump()
        t.q.pump()
        self.assertEqual(t.log[-1], ("hide",))
        self.assertFalse(t.q.visible)
        t.block = False
        t.q.pump()
        self.assertEqual(t.log[-1], ("show", "текст", ("a.png",)))
        self.assertEqual(sum(1 for x in t.log if x[0] == "hide"), 1)

    def test_close_then_next(self):
        t = Q()
        t.q.post("e1", "один")
        t.q.post("e2", "два")
        self.assertEqual([x for x in t.log if x[0] == "show"], [("show", "один", ())])
        t.q.close()
        self.assertEqual(t.log[-1], ("show", "два", ()))
        t.q.close()
        t.q.pump()
        self.assertIsNone(t.q.current)
        t.q.post("e1", "один")                    # закрытое событие не возвращается
        self.assertEqual(t.log[-1], ("hide",))


class Window(unittest.TestCase):
    def test_same_corner_as_lock_window_and_no_focus(self):
        tmp = tempfile.mkdtemp()
        img = os.path.join(tmp, "x.png")
        im = QImage(320, 180, QImage.Format.Format_RGB32)
        im.fill(QColor(10, 20, 30))
        im.save(img)
        closed = []
        w = ActionAlertWindow(on_close=lambda: closed.append(1))
        w.show_alert("03.11 07:00 — в отправленном сообщении не те картинки — проверьте беседу", [img, img, "нет.png"])
        app.processEvents()
        self.assertTrue(w.isVisible())
        self.assertEqual(w.thumbs_row.count(), 2)
        self.assertEqual(w.btn.text(), CLOSE_TEXT)
        g = QGuiApplication.primaryScreen().availableGeometry()
        self.assertEqual(w.geometry().right(), g.right() - MARGIN)
        self.assertEqual(w.geometry().bottom(), g.bottom() - MARGIN)
        cd = CountdownOverlay(interactive=True)
        cd._place()
        self.assertEqual(cd.geometry().right(), w.geometry().right())   # то же место, что блокировка
        self.assertTrue(w.windowFlags() & w.FLAGS & w.windowFlags())
        from PySide6.QtCore import Qt
        self.assertTrue(w.windowFlags() & Qt.WindowType.WindowDoesNotAcceptFocus)
        self.assertTrue(w.windowFlags() & Qt.WindowType.WindowStaysOnTopHint)
        self.assertFalse(w.windowFlags() & Qt.WindowType.WindowTransparentForInput)   # «Закрыть» нажимается
        w.btn.click()
        self.assertFalse(w.isVisible())
        self.assertEqual(closed, [1])
        w.show_alert("без картинок")
        self.assertFalse(w.thumbs.isVisibleTo(w))
        w.hide()


class Priority(unittest.TestCase):
    def _main(self, **kw):
        from app.ui.main_window import MainWindow
        cd = SimpleNamespace(active=False, isVisible=lambda: False)
        m = SimpleNamespace(countdown=None, busy=False, _capturing=False, job=SimpleNamespace(lock=threading.Lock()))
        for k, v in kw.items():
            setattr(m, k, v)
        if kw.get("cd_active"):
            cd.active = True
            m.countdown = cd
        return MainWindow._action_alert_blocked(m), m

    def test_blocked_by_lock_window_capture_send(self):
        from app.ui.main_window import MainWindow
        self.assertFalse(self._main()[0])
        self.assertTrue(self._main(cd_active=True)[0])
        self.assertTrue(self._main(busy=True)[0])
        self.assertTrue(self._main(_capturing=True)[0])
        _, m = self._main()
        m.job.lock.acquire()
        self.assertTrue(MainWindow._action_alert_blocked(m))
        m.job.lock.release()

    def test_capture_hides_alert_immediately(self):
        from app.ui.action_alert import ActionAlerts
        from app.ui.main_window import MainWindow
        state = {"cap": False}
        al = ActionAlerts(lambda: state["cap"])
        al.post("e", "текст")
        self.assertTrue(al.win.isVisible())
        m = SimpleNamespace(action_alerts=al, _capturing=False, hide_countdown=lambda: None, sent_alert=None,
                            isVisible=lambda: False, _hidden_for_capture=False)
        MainWindow._exclude(m, True)
        state["cap"] = m._capturing
        self.assertFalse(al.win.isVisible())
        al.q.pump()
        self.assertFalse(al.win.isVisible())     # пока идёт съёмка — не возвращается
        MainWindow._exclude(m, False)
        state["cap"] = m._capturing
        al.q.pump()
        self.assertTrue(al.win.isVisible())
        al.timer.stop()
        al.win.hide()


if __name__ == "__main__":
    unittest.main()
