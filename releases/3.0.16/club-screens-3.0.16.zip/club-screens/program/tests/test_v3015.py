# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.15: программа камер — iVMS-4200 (как раньше), TRASSIR или другая программа по названию окна."""
import copy
import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from app import __version__, cammode, recorder  # noqa: E402
from app.config import DEFAULTS, migrate  # noqa: E402
from app.steps import StepRunner, WindowNotFound  # noqa: E402
from tests.test_steps_job import FakeBackend  # noqa: E402


def cfg():
    return copy.deepcopy(DEFAULTS)


def runner(backend):
    return StepRunner(backend, resolve_path=lambda p: p, sleep=lambda s: None)


class Moves(FakeBackend):
    def move_cursor(self, x, y):
        self.actions.append(("move", x, y))


class Modes(unittest.TestCase):
    def test_version(self):
        self.assertEqual(__version__, "3.0.16")

    def test_default_is_ivms_and_unchanged(self):
        c = cfg()
        before = copy.deepcopy(c["sources"])
        self.assertEqual(cammode.mode_of(c), "ivms")
        cammode.sync(c)
        self.assertEqual(c["sources"], before)

    def test_old_config_without_camera_section_stays_ivms(self):
        c = cfg()
        c.pop("camera")
        c["app"]["config_version"] = "3.0.2"
        before = copy.deepcopy(c["sources"])
        migrate(c)
        self.assertEqual(c["camera"]["mode"], "ivms")
        self.assertEqual(c["sources"], before)

    def test_switch_to_trassir_and_back_keeps_recording(self):
        c = cfg()
        i = cammode.camera_index(c)
        c["sources"][i]["recorded"] = True
        c["sources"][i]["steps"] = [{"type": "click_xy", "x": 1, "y": 2, "units": "pixels"}]
        self.assertTrue(cammode.set_mode(c, "trassir"))
        src = c["sources"][i]
        self.assertEqual(src["kind"], "trassir")
        self.assertEqual(src["window"]["process_regex"], "(?i)^t1client")
        self.assertNotIn("maximize", [s["type"] for s in src["steps"]])
        self.assertEqual(len([s for s in c["sources"] if s.get("kind") in cammode.CAMERA_KINDS]), 1)
        cammode.set_mode(c, "ivms")
        self.assertTrue(c["sources"][i]["recorded"])
        self.assertEqual(c["sources"][i]["steps"][0]["x"], 1)

    def test_generic_title_is_literal(self):
        c = cfg()
        cammode.set_mode(c, "generic")
        cammode.set_generic_title(c, "Камеры (1+2)")
        src = c["sources"][cammode.camera_index(c)]
        self.assertEqual(src["kind"], "generic")
        self.assertEqual(src["name"], "Камеры (1+2)")
        import re
        self.assertTrue(re.search(src["window"]["title_regex"], "Мои камеры (1+2) — плеер"))
        self.assertEqual(cammode.check(c), "")

    def test_generic_without_title_is_error_not_any_window(self):
        c = cfg()
        cammode.set_mode(c, "generic")
        self.assertIn("название окна", cammode.check(c))
        with self.assertRaises(WindowNotFound):
            runner(FakeBackend()).run_source(c["sources"][cammode.camera_index(c)])

    def test_trassir_capture_monitor_and_cursor_parked_no_ivms_cancel(self):
        c = cfg()
        cammode.set_mode(c, "trassir")
        b = Moves(windows=("Oasys", "TRASSIR-4.9.15.0-1321842"))
        imgs = runner(b).run_source(c["sources"][cammode.camera_index(c)])
        self.assertEqual(len(imgs), 1)
        self.assertIn(("grab", (-1920, 0, 1920, 1080)), b.actions)   # весь монитор окна
        self.assertTrue(any(a[0] == "move" for a in b.actions))     # курсор убран
        self.assertFalse(any(a[0] in ("click", "press", "max") for a in b.actions))

    def test_generic_any_aspect_monitor(self):
        c = cfg()
        cammode.set_mode(c, "generic")
        cammode.set_generic_title(c, "Player")

        class Tall(Moves):
            def monitor_rect(self, h):
                return (1920, 0, 1080, 1920)
        b = Tall(windows=("Player",))
        img = runner(b).run_source(c["sources"][cammode.camera_index(c)])[0]
        self.assertEqual(img.size, (1080, 1920))
        self.assertIn(("max", 1), b.actions)

    def test_reset_returns_mode_builtin_steps(self):
        c = cfg()
        cammode.set_mode(c, "trassir")
        src = c["sources"][cammode.camera_index(c)]
        recorder.mark_saved(src, [{"type": "click_xy", "x": 5, "y": 5}])
        recorder.reset(src, lambda p: "/nonexistent/" + p)
        self.assertEqual(src["steps"], cammode.default_source("trassir")["steps"])

    def test_small_window_warning(self):
        self.assertTrue(cammode.window_warning("trassir", (954, 0, 54, 20), (0, 0, 1920, 1080)))
        self.assertEqual(cammode.window_warning("trassir", (0, 0, 1920, 1080), (0, 0, 1920, 1080)), "")
        self.assertEqual(cammode.window_warning("ivms", (0, 0, 10, 10), (0, 0, 1920, 1080)), "")

    def test_labels_human(self):
        for t in cammode.MODE_LABELS.values():
            self.assertNotIn("кнопка", t.lower())
        src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app", "ui",
                                "settings.py"), encoding="utf-8").read()
        self.assertIn('"Программа камер"', src)

    def test_settings_combo_switches(self):
        import tempfile
        from PySide6.QtWidgets import QApplication
        QApplication.instance() or QApplication([])
        from app.ui.settings import SettingsPage
        from tests.test_live_settings import StubMain
        c = cfg()
        page = SettingsPage(StubMain(c, os.path.join(tempfile.mkdtemp(), "config.yaml")))
        cfg_ = page.cfg
        self.assertEqual(page.cam_mode.currentData(), "ivms")
        self.assertTrue(page.cam_title_row.isHidden())
        page.cam_mode.setCurrentIndex(2)
        self.assertEqual(cfg_["camera"]["mode"], "generic")
        self.assertFalse(page.cam_title_row.isHidden())
        page.cam_title.setText("Видео")
        page._cam_title_changed()
        self.assertEqual(cfg_["sources"][cammode.camera_index(cfg_)]["name"], "Видео")
        page.cam_mode.setCurrentIndex(1)
        self.assertEqual(cfg_["sources"][cammode.camera_index(cfg_)]["kind"], "trassir")
        page.cam_mode.setCurrentIndex(0)
        self.assertEqual(cfg_["sources"][cammode.camera_index(cfg_)]["kind"], "ivms")

if __name__ == "__main__":
    unittest.main()
