# Original-Author: Владислав С.
# Created: 2026-11-03
"""3.0.15: после ошибки загрузки ушли две картинки iVMS вместо Oasys + iVMS.
ВК показал превью в другом порядке (iVMS первым), у загруженного превью отпечатка нет (картинка с
сервера ВК), у превью с ошибкой — есть (Oasys). Раньше превью без отпечатка подписывалось «по порядку
прикрепления» (Oasys) — и Oasys считался на месте, хотя это был iVMS."""
import unittest

import tests.test_v305_upload as base
from tests.test_v305_upload import NAMES, UPage


class NoFpPage(UPage):
    """Отпечатки есть только у незагруженных превью (blob), у загруженных — None (чужой сервер)."""

    def call(self, fn, a):
        if fn == "att_state":
            self.calls.append(fn)
            return {"items": self.att_items(),
                    "fps": [None if s == "ok" else fp for s, fp in zip(self.items, self.fps)]}
        return super().call(fn, a)


class ReattachIds(unittest.TestCase):
    sent_both = base.UploadReattach.sent_both

    def run_logged(self, plan, reverse=False):
        import tests.test_v305_upload as m
        old = m.UPage
        m.UPage = NoFpPage
        try:
            return base.UploadReattach.run_logged(self, plan, reverse)
        finally:
            m.UPage = old

    def test_reversed_error_on_oasys_sends_oasys_and_ivms(self):
        page, d, err, warn = self.run_logged(
            lambda f, n: "error" if f == NAMES[0] and n == 1 else "ok", reverse=True)
        self.assertIsNone(err)
        self.sent_both(page)                       # не две iVMS
        self.assertEqual(page.tries[NAMES[0]], 2)  # заново прикреплён именно Oasys
        self.assertEqual(page.tries[NAMES[1]], 1)

    def test_same_order_still_targeted(self):
        page, d, err, warn = self.run_logged(lambda f, n: "error" if f == NAMES[0] and n == 1 else "ok")
        self.assertIsNone(err)
        self.sent_both(page)
        self.assertEqual(page.tries, {NAMES[0]: 2, NAMES[1]: 1})


if __name__ == "__main__":
    unittest.main()
