# Original-Author: Владислав С.
# Created: 2026-10-30
"""2.2.5: окно «Записать сценарий съёмки» — запись, список шагов (порядок, удаление, паузы), пробный запуск."""
import copy
import logging
import os

from PySide6.QtWidgets import (QDialog, QHBoxLayout, QInputDialog, QListWidget, QMessageBox, QPushButton,
                               QVBoxLayout)

from .. import recorder
from ..config import base_dir, resolve_path
from ..friendly import humanize
from ..steps import StepRunner
from .common import label

log = logging.getLogger("club")


class RecorderDialog(QDialog):
    def __init__(self, parent, main, src):
        super().__init__(parent)
        self.main, self.src = main, src
        self.rec = None
        self.saved = False
        self.steps = copy.deepcopy(src.get("steps") or []) if src.get("recorded") else []
        self.setWindowTitle(f"Сценарий съёмки: {src.get('name', '')}")
        self.resize(640, 520)
        lay = QVBoxLayout(self)
        lay.addWidget(label(
            f"1. Откройте {src.get('name', 'программу')} как обычно. 2. Нажмите «Начать запись» — окно программы "
            f"выйдет вперёд. 3. Сделайте щелчки и клавиши, которые приводят окно к нужному виду (без снимка). "
            f"4. Нажмите {recorder.STOP_TEXT}. Щелчки запоминаются от угла окна, вокруг каждого — маленькая "
            "картинка для надёжности. Записанный сценарий заменяет стандартные шаги этой программы и хранится "
            "только на этом компьютере.", "hint"))
        self.status = label("", "hint")
        lay.addWidget(self.status)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for text, fn in (("Начать запись", self.start), ("Вверх", lambda: self.move(-1)),
                         ("Вниз", lambda: self.move(1)), ("Удалить", self.delete), ("+ Пауза", self.add_wait),
                         ("Изменить паузу", self.edit_wait)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)
        row = QHBoxLayout()
        for text, fn in (("Пробный запуск", self.test_run), ("Сохранить", self.save),
                         ("Вернуть стандартные шаги", self.restore_default), ("Закрыть", self.reject)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)
        self.refresh()

    # ---------- список ----------
    def refresh(self, sel=None):
        self.list.clear()
        for st in self.steps:
            self.list.addItem(recorder.describe(st if isinstance(st, dict) else {"type": st}))
        if sel is not None and self.steps:
            self.list.setCurrentRow(max(0, min(sel, len(self.steps) - 1)))

    def move(self, d):
        i = self.list.currentRow()
        j = i + d
        if 0 <= i < len(self.steps) and 0 <= j < len(self.steps):
            self.steps[i], self.steps[j] = self.steps[j], self.steps[i]
            self.refresh(j)

    def delete(self):
        i = self.list.currentRow()
        if 0 <= i < len(self.steps):
            del self.steps[i]
            self.refresh(i)

    def add_wait(self):
        i = self.list.currentRow()
        self.steps.insert(i + 1 if i >= 0 else len(self.steps), {"type": "wait", "seconds": 1.0})
        self.refresh(i + 1)

    def edit_wait(self):
        i = self.list.currentRow()
        if not (0 <= i < len(self.steps)) or not isinstance(self.steps[i], dict) \
                or self.steps[i].get("type") != "wait":
            QMessageBox.information(self, "Пауза", "Выберите в списке строку «Пауза»")
            return
        v, ok = QInputDialog.getDouble(self, "Пауза", "Секунд:", float(self.steps[i].get("seconds", 1)), 0.1, 30, 1)
        if ok:
            self.steps[i]["seconds"] = round(v, 1)
            self.refresh(i)

    # ---------- запись ----------
    def start(self):
        from .capture import find_source_window
        name = self.src.get("name", "")
        folder = resolve_path(os.path.join("recordings", recorder.safe_name(name)))

        def begin():
            be = self.main.backend_factory()
            hwnd = find_source_window(be, self.src)
            if not hwnd:
                raise RuntimeError(f"{name}: окно не найдено — откройте программу")
            be.activate(hwnd)
            be.maximize(hwnd)
            rec = recorder.Recorder(be, hwnd, folder, on_stop=lambda: self.main.gui(self.finished))
            if not rec.start():
                raise RuntimeError("Не удалось начать запись (перехват мыши и клавиатуры не включился)")
            return rec

        def ok(rec):
            self.rec = rec
            self.status.setText(f"● Идёт запись… Остановить: {recorder.STOP_TEXT}")
            self.showMinimized()

        self.status.setText("⏳ Готовлю запись…")
        self.main.run_bg(begin, ok, lambda e: self.status.setText("✖ " + humanize(e, name)))

    def finished(self):
        rec, self.rec = self.rec, None
        if rec is None:
            return
        rec.stop()
        root = base_dir()
        got = rec.steps(rel=lambda p: os.path.relpath(p, root).replace(os.sep, "/"))
        self.steps = recorder.scenario(got, self.src.get("steps"))
        n = sum(1 for s in got if s.get("type") != "wait")
        self.status.setText(f"✔ Записано действий: {n}" + (f" (щелчков вне окна пропущено: {rec.ignored})"
                                                              if rec.ignored else "")
                            + ". Проверьте «Пробный запуск», затем «Сохранить».")
        log.info("Сценарий «%s» записан: %d действий", self.src.get("name"), n)
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self.refresh()

    # ---------- проба и сохранение ----------
    def test_run(self):
        if not self.steps:
            return
        src = dict(copy.deepcopy(self.src), steps=copy.deepcopy(self.steps))
        from .settings import show_images

        def run():
            be = self.main.backend_factory()
            prev = be.foreground()
            self.main._capture_hook(True)
            try:
                return StepRunner(be, resolve_path).run_source(src)
            finally:
                be.set_foreground(prev)
                self.main._capture_hook(False)
        self.main.run_bg(run, lambda imgs: show_images(self, f"пробный запуск {src.get('name')}", imgs),
                         source=src.get("name"))

    def save(self):
        if not self.steps:
            return
        if not self.src.get("recorded"):
            self.src["default_steps"] = copy.deepcopy(self.src.get("steps") or [])
        self.src["steps"] = copy.deepcopy(self.steps)
        self.src["recorded"] = True
        self.saved = True
        log.info("Сценарий «%s» сохранён (%d шагов)", self.src.get("name"), len(self.steps))
        self.accept()

    def restore_default(self):
        if not self.src.get("recorded"):
            QMessageBox.information(self, "Сценарий", "Сейчас и так стандартные шаги")
            return
        self.src["steps"] = copy.deepcopy(self.src.get("default_steps") or [])
        self.src.pop("recorded", None)
        self.src.pop("default_steps", None)
        self.saved = True
        log.info("Сценарий «%s»: возвращены стандартные шаги", self.src.get("name"))
        self.accept()

    def closeEvent(self, e):  # noqa: N802
        if self.rec:
            self.rec.stop()
            self.rec = None
        super().closeEvent(e)
