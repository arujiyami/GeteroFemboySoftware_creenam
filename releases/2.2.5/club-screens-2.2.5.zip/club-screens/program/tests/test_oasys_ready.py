# Original-Author: Владислав С.
# Created: 2026-10-28
"""2.1.5: проверка, что Oasys действительно загрузился, и блокировка ввода заранее.

Без Windows: окна, «зависание» (IsHungAppWindow), передний план и хуки ввода — подделки."""
import copy
import os
import tempfile
import unittest
from datetime import datetime, timedelta

from PIL import Image

from app import readiness
from app.config import DEFAULTS, migrate
from app.job import JobRunner, caption_with_notes
from app.readiness import (NOT_READY_NOTE, R_BACKGROUND, R_BLANK, R_GONE, R_HUNG, image_problem,
                           ready_settings, wait_until_ready)
from tests.test_steps_job import FakeBackend, FakeVK

OASYS = 1


class Clock:
    """Общие часы: пауза двигает и monotonic, и «сейчас» (datetime)."""

    def __init__(self, start=datetime(2026, 10, 28, 2, 59, 55)):
        self.t = 0.0
        self.start = start

    def mono(self):
        return self.t

    def now(self):
        return self.start + timedelta(seconds=self.t)

    def sleep(self, sec):
        self.t += max(0.0, float(sec or 0))


class Hook:
    def __init__(self, backend):
        self.b = backend

    def start(self):
        self.b.log.append(("lock", self.b.clock.t if self.b.clock else 0))
        return True

    def stop(self):
        self.b.log.append(("unlock", self.b.clock.t if self.b.clock else 0))


class ReadyBackend(FakeBackend):
    """hung_until / bg_until — сколько проверок (или «навсегда») Oasys зависший / не на переднем плане."""

    def __init__(self, hung_checks=0, bg=False, gone=False, clock=None, lock=True, **kw):
        super().__init__(**kw)
        self.hung_checks = hung_checks
        self.bg = bg
        self.gone = gone
        self.clock = clock
        self.log = []
        self.hung_calls = 0
        if lock:
            self.input_hook_factory = lambda on_mouse, on_key: Hook(self)

    def window_exists(self, h):
        return not (self.gone and h == OASYS)

    def is_hung(self, h):
        if h != OASYS:
            return False
        self.hung_calls += 1
        return self.hung_checks == "always" or self.hung_calls <= self.hung_checks

    def foreground(self):
        return None if self.bg else self.fg

    def grab(self, rect):
        img = super().grab(rect)
        if rect != (0, 0, 1000, 500):                 # снимок экрана (не проверка готовности)
            self.log.append(("shot", "Oasys" if self.fg == OASYS else "iVMS", self.clock.t if self.clock else 0))
        return img

    def click(self, x, y, double=False):
        super().click(x, y, double)
        self.log.append(("click", x, y))

    def kinds(self):
        return [e[0] if e[0] != "shot" else "shot:" + e[1] for e in self.log if e[0] != "click"]


class WaitUntilReady(unittest.TestCase):
    def run_wait(self, b, timeout=10, retry=None, template=None):
        c = Clock()
        b.fg = OASYS
        return wait_until_ready(b, OASYS, lambda: (0, 0, 1000, 500), timeout, template, retry=retry,
                                clock=c.mono, sleep=c.sleep), c

    def test_success_needs_stable_frame(self):
        res, c = self.run_wait(ReadyBackend())
        self.assertTrue(res.ok, res)
        self.assertEqual(res.polls, 2)              # первый кадр — «ещё меняется», второй такой же — готов
        self.assertLess(c.t, 1.5)

    def test_hung_times_out_with_one_retry(self):
        calls = []
        res, c = self.run_wait(ReadyBackend(hung_checks="always"), retry=lambda: calls.append(1))
        self.assertFalse(res.ok)
        self.assertEqual(res.reason, R_HUNG)
        self.assertEqual(res.retries, 1)
        self.assertEqual(calls, [1])                # не больше одного повтора переключения
        self.assertTrue(10 <= c.t <= 10.6, c.t)     # не дольше срока

    def test_recovers_after_hang(self):
        res, _ = self.run_wait(ReadyBackend(hung_checks=4))
        self.assertTrue(res.ok)

    def test_background_window(self):
        res, _ = self.run_wait(ReadyBackend(bg=True), timeout=3)
        self.assertEqual((res.ok, res.reason), (False, R_BACKGROUND))

    def test_window_gone_stops_at_once(self):
        res, c = self.run_wait(ReadyBackend(gone=True))
        self.assertEqual((res.ok, res.reason), (False, R_GONE))
        self.assertEqual(c.t, 0)

    def test_blank_screen_not_ready(self):
        b = ReadyBackend()
        b.blank = True
        res, _ = self.run_wait(b, timeout=3)
        self.assertEqual((res.ok, res.reason), (False, R_BLANK))

    def test_template_must_be_visible(self):
        d = tempfile.mkdtemp()
        tpl = os.path.join(d, "oasys_karta_kluba_header.png")
        Image.new("RGB", (10, 10)).save(tpl)
        b = ReadyBackend()
        res, _ = self.run_wait(b, timeout=3, template=tpl)
        self.assertFalse(res.ok)
        self.assertIn("Карта клуба", res.reason)
        b = ReadyBackend(found={"oasys_karta_kluba_header.png": (5, 5)})
        res, _ = self.run_wait(b, timeout=3, template=tpl)
        self.assertTrue(res.ok)

    def test_timeout_clamped_3_30(self):
        res, c = self.run_wait(ReadyBackend(hung_checks="always"), timeout=999)
        self.assertTrue(30 <= c.t <= 30.6, c.t)
        res, c = self.run_wait(ReadyBackend(hung_checks="always"), timeout=0)
        self.assertTrue(3 <= c.t <= 3.6, c.t)

    def test_settings(self):
        self.assertEqual(ready_settings(DEFAULTS), (True, 10))
        self.assertEqual(ready_settings({"oasys_check": {"enabled": False, "timeout_sec": 99}}), (False, 30))
        self.assertEqual(ready_settings({}), (True, 10))

    def test_image_problem(self):
        good = Image.new("RGB", (100, 50))
        good.paste((200, 200, 200), (0, 0, 50, 50))
        self.assertEqual(image_problem(good), "")
        self.assertEqual(image_problem(Image.new("RGB", (100, 50))), R_BLANK)
        self.assertTrue(image_problem(None))
        self.assertEqual(image_problem(good, "/нет/такого/шаблона.png"), "")    # шаблона нет — не проверяем


class JobFlow(unittest.TestCase):
    """Плановый запуск: блокировка за 5 с до съёмки → снимок Oasys в ЧЧ:00 → iVMS → разблокировка →
    проверка → (если нужно) пересъёмка Oasys с блокировкой только на это время."""

    def make(self, backend, capture_in=5.0, patch=None):
        self.clock = backend.clock = Clock()
        root = tempfile.mkdtemp()
        cfg = copy.deepcopy(DEFAULTS)
        cfg["vk"]["caption"] = "{time}"
        cfg["vk"]["peer_id"] = 2000000001
        for sec, vals in (patch or {}).items():
            cfg[sec].update(vals)
        self.cfg = cfg
        self.vk = FakeVK()
        job = JobRunner(lambda: cfg, lambda: backend, vk_factory=lambda c: self.vk, root=root,
                        now=self.clock.now, sleep=self.clock.sleep)
        self.warned = []
        job.on_warning = lambda name, text: self.warned.append((name, text))
        self.target = self.clock.now() + timedelta(seconds=capture_in)
        return job

    def test_success_lock_before_capture_release_after_ivms(self):
        b = ReadyBackend()
        job = self.make(b)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(b.kinds(), ["lock", "shot:Oasys", "shot:iVMS", "unlock"])
        lock_t = b.log[0][1]
        oasys_t = [e for e in b.log if e[:2] == ("shot", "Oasys")][0][2]
        self.assertEqual(lock_t, 0)                          # блокировка — сразу, за 5 с до снимка
        self.assertAlmostEqual(oasys_t, 5.0, delta=0.01)     # снимок Oasys — ровно в ЧЧ:00, не раньше
        self.assertEqual(job.warnings, {})
        self.assertEqual(self.warned, [])
        self.assertEqual(self.vk.sent[0][2], "03:00")        # время в подписи — назначенное
        self.assertFalse(job.input_locked)

    def test_always_locks_even_if_oasys_ready_at_once(self):
        b = ReadyBackend()
        job = self.make(b, capture_in=0)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(b.kinds()[0], "lock")

    def test_hung_oasys_recapture_release_and_note(self):
        b = ReadyBackend(hung_checks="always")
        job = self.make(b)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        k = b.kinds()
        # первая сессия: блок → Oasys → iVMS → разблок; пересъёмка: блок → (не дождались) разблок → снимок
        self.assertEqual(k, ["lock", "shot:Oasys", "shot:iVMS", "unlock", "lock", "unlock", "shot:Oasys"])
        locks = [e for e in b.log if e[0] in ("lock", "unlock")]
        relock, unlock2 = locks[2][1], locks[3][1]
        # переключение окна (~4 с паузами шагов) + ожидание не дольше 10 с; сторож (30 с) не понадобился
        self.assertTrue(10 <= unlock2 - relock <= 16, (relock, unlock2))
        self.assertEqual(b.hung_calls > 0, True)
        clicks = [e for e in b.log if e == ("click", 19, 70)]     # кнопка «Карта клуба» (запасные координаты)
        # первый проход: 1 переключение; пересъёмка: переключение + не больше одного повтора
        self.assertEqual(len(clicks), 3)
        self.assertIn("Oasys", job.warnings)
        self.assertTrue(job.warnings["Oasys"].startswith(NOT_READY_NOTE))
        self.assertEqual(self.warned[0][0], "Oasys")
        peer, files, msg = self.vk.sent[0]
        self.assertEqual(len(files), 2)            # iVMS всё равно снят и отправлен
        self.assertIn("⚠ " + NOT_READY_NOTE, msg)
        self.assertEqual(job.last_result["warnings"], job.warnings)
        self.assertFalse(job.input_locked)

    def test_slow_oasys_ok_after_recapture(self):
        b = ReadyBackend(hung_checks=12)            # первые 12 проверок (~6 с) «не отвечает»
        job = self.make(b)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(b.kinds(), ["lock", "shot:Oasys", "shot:iVMS", "unlock", "lock", "shot:Oasys", "unlock"])
        self.assertEqual(job.warnings, {})
        self.assertNotIn("⚠", self.vk.sent[0][2])
        self.assertEqual(len(self.vk.sent[0][1]), 2)
        shots = os.listdir(os.path.join(job.root, "screenshots")) if os.path.isdir(
            os.path.join(job.root, "screenshots")) else None
        if shots is not None:
            self.assertEqual(len([s for s in shots if "Oasys" in s]), 1)   # прежний снимок заменён

    def test_background_oasys_note(self):
        b = ReadyBackend(bg=True)
        job = self.make(b)
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertIn(R_BACKGROUND, job.warnings["Oasys"])

    def test_check_disabled_no_recapture(self):
        b = ReadyBackend(hung_checks="always")
        job = self.make(b, patch={"oasys_check": {"enabled": False}})
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertEqual(b.kinds(), ["lock", "shot:Oasys", "shot:iVMS", "unlock"])
        self.assertEqual(job.warnings, {})

    def test_lock_disabled(self):
        b = ReadyBackend(hung_checks="always")
        job = self.make(b, patch={"input_lock": {"enabled": False}})
        self.assertTrue(job.run_cycle(True, capture_at=self.target))
        self.assertNotIn("lock", b.kinds())
        self.assertIn("Oasys", job.warnings)

    def test_manual_run_locks_too(self):
        b = ReadyBackend()
        job = self.make(b)
        self.assertTrue(job.run_cycle(True, manual=True))
        self.assertEqual(b.kinds(), ["lock", "shot:Oasys", "shot:iVMS", "unlock"])

    def test_caption_with_notes(self):
        self.assertEqual(caption_with_notes("03:00", {}), "03:00")
        self.assertEqual(caption_with_notes("03:00", {"Oasys": NOT_READY_NOTE + " (x)"}),
                         "03:00\n⚠ " + NOT_READY_NOTE)          # причина — в журнале и в окне, не в ВК


class MigrationWaitReady(unittest.TestCase):
    def test_inserted_once_before_screenshot(self):
        cfg = copy.deepcopy(DEFAULTS)
        cfg.setdefault("app", {})["config_version"] = "2.1.4"
        steps = cfg["sources"][0]["steps"]
        cfg["sources"][0]["steps"] = [s for s in steps if s.get("type") != "wait_ready"]
        migrate(cfg)
        types = [s["type"] for s in cfg["sources"][0]["steps"]]
        self.assertEqual(types.count("wait_ready"), 1)
        self.assertLess(types.index("wait_ready"), types.index("screenshot"))
        cfg.setdefault("app", {})["config_version"] = "2.1.4"
        migrate(cfg)
        self.assertEqual([s["type"] for s in cfg["sources"][0]["steps"]].count("wait_ready"), 1)
        self.assertEqual(cfg["app"]["config_version"], "2.2.5")
        self.assertEqual(cfg["input_lock"]["early_sec"], 5)
        self.assertEqual(cfg["oasys_check"], {"enabled": True, "timeout_sec": 10})


if __name__ == "__main__":
    unittest.main()
