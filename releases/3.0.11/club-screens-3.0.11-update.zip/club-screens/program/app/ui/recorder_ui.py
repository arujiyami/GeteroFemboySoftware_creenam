# Original-Author: Владислав С.
# Created: 2026-10-30
"""2.2.5: окно «Записать сценарий съёмки» — запись, список шагов (порядок, удаление, паузы), пробный запуск."""
import copy
import logging
import os

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QComboBox, QDialog, QFrame, QHBoxLayout, QInputDialog, QLabel, QListWidget,
                               QMessageBox, QPushButton, QVBoxLayout, QWidget)

from .. import recorder
from ..config import base_dir, resolve_path
from ..friendly import humanize
from ..steps import StepRunner
from .common import exclude_from_capture, label

log = logging.getLogger("club")


class RecordingPanel(QWidget):
    """3.0.1: маленькая панель поверх всех окон: «Идёт запись · N шагов · 0:12» + «Стоп» / «Отмена».
    Щелчки по ней не записываются, на снимки она не попадает."""

    def __init__(self, on_stop, on_cancel):
        super().__init__(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint
                         | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.WindowDoesNotAcceptFocus)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setObjectName("recPanel")
        self.setStyleSheet("#recPanel{background:#2b2b2b;border:2px solid #d9534f;border-radius:8px}"
                           "QLabel{color:white;font-weight:bold;padding:0 6px}"
                           "QPushButton{padding:4px 12px}")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        self.text = QLabel("● Идёт запись")
        lay.addWidget(self.text)
        for t, fn in (("Стоп", on_stop), ("Отмена", on_cancel)):
            b = QPushButton(t)
            b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            b.clicked.connect(fn)
            lay.addWidget(b)
        self.rects = []

    def set_state(self, n, sec):
        self.text.setText(f"● Идёт запись · {n} шагов · {int(sec) // 60}:{int(sec) % 60:02d}")

    def place(self):
        self.adjustSize()
        scr = self.screen().availableGeometry() if self.screen() else None
        if scr is not None:
            self.move(scr.x() + (scr.width() - self.width()) // 2, scr.y() + 4)
        self.update_rects()

    def update_rects(self):
        """Прямоугольник панели в физических пикселях (как координаты перехватчика), с запасом."""
        g = self.frameGeometry()
        r = self.devicePixelRatioF() or 1.0
        self.rects = [(int(g.x() * r) - 4, int(g.y() * r) - 4, int(g.width() * r) + 8, int(g.height() * r) + 8)]


class RecorderDialog(QDialog):
    def __init__(self, parent, main, src, fresh=False, auto_test=True, alt_hint=False):
        super().__init__(parent)
        self.alt_index = None        # 3.0.8: идёт запись второго вида для этого шага
        self.main, self.src = main, src
        self.rec = None
        self.saved = False
        self.session = None          # папка новой записи (до «Сохранить»)
        self.auto_test = auto_test
        self.steps = copy.deepcopy(src.get("steps") or []) if src.get("recorded") and not fresh else []
        self.setWindowTitle(f"Сценарий съёмки: {src.get('name', '')}")
        self.resize(640, 520)
        lay = QVBoxLayout(self)
        lay.addWidget(label(recorder.HOWTO, "hint"))
        lay.addWidget(label("Щелчки запоминаются от угла окна, вокруг каждого — маленькая картинка для надёжности. "
                            "Записанный сценарий заменяет стандартные шаги этой программы и хранится только "
                            "на этом компьютере.", "muted"))
        self.status = label("", "hint")
        lay.addWidget(self.status)
        row = QHBoxLayout()
        row.addWidget(QLabel("Запасная клавиша «Стоп»:"))
        self.stop_key = QComboBox()
        for k in recorder.ALT_STOP_CHOICES:
            self.stop_key.addItem(recorder.stop_key_text(k), k)
        cur = self._rec_cfg().get("stop_key", recorder.DEFAULT_ALT_STOP)
        self.stop_key.setCurrentIndex(max(0, self.stop_key.findData(cur)))
        self.stop_key.currentIndexChanged.connect(
            lambda _i: self._rec_cfg(True).__setitem__("stop_key", self.stop_key.currentData()))
        row.addWidget(self.stop_key)
        row.addStretch(1)
        lay.addLayout(row)
        self.panel = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        for text, fn in (("Начать запись", self.start), ("Вверх", lambda: self.move(-1)),
                         ("Вниз", lambda: self.move(1)), ("Удалить", self.delete), ("+ Пауза", self.add_wait),
                         ("Изменить паузу", self.edit_wait)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)
        row = QHBoxLayout()
        self.alt_btn = QPushButton("Записать второй вид")
        self.alt_btn.setToolTip("Необязательно. Запомнить, как выглядит выбранная кнопка или строка вида во втором "
                                "состоянии (iVMS: «cam  Editing...», если камеры переставили). Программа будет "
                                "искать обе картинки, вслепую по координатам не щёлкнет, а на вопрос iVMS о "
                                "несохранённых изменениях нажмёт «Cancel».")
        self.alt_btn.clicked.connect(self.record_alt)
        row.addWidget(self.alt_btn)
        self.cancel_btn = QPushButton("Записать Cancel")
        self.cancel_btn.setToolTip(recorder.CANCEL_HOWTO)
        self.cancel_btn.clicked.connect(self.record_cancel)
        row.addWidget(self.cancel_btn)
        self.cancel_state = label(recorder.cancel_state_text(self.src, resolve_path), "muted")
        row.addWidget(self.cancel_state)
        self.alt_hint = label(recorder.ALT_HOWTO if alt_hint else "", "hint")
        row.addStretch(1)
        lay.addLayout(row)
        lay.addWidget(self.alt_hint)
        row = QHBoxLayout()
        for text, fn in (("Пробный запуск", self.test_run), ("Сохранить", self.save),
                         ("Вернуть стандартные шаги", self.restore_default), ("Закрыть", self.reject)):
            b = QPushButton(text)
            b.clicked.connect(fn)
            row.addWidget(b)
        lay.addLayout(row)
        self.refresh()
        if alt_hint:
            g = recorder.guess_view_step(self.steps)
            if g is not None:
                self.list.setCurrentRow(g)

    # ---------- список ----------
    def refresh(self, sel=None):
        self.list.clear()
        for st in self.steps:
            self.list.addItem(recorder.describe(st if isinstance(st, dict) else {"type": st}))
        if sel is not None and self.steps:
            self.list.setCurrentRow(max(0, min(sel, len(self.steps) - 1)))

    def move(self, d):
        i = self.list.currentRow()
        j = i + d
        if 0 <= i < len(self.steps) and 0 <= j < len(self.steps):
            self.steps[i], self.steps[j] = self.steps[j], self.steps[i]
            self.refresh(j)

    def delete(self):
        i = self.list.currentRow()
        if 0 <= i < len(self.steps):
            del self.steps[i]
            self.refresh(i)

    def add_wait(self):
        i = self.list.currentRow()
        self.steps.insert(i + 1 if i >= 0 else len(self.steps), {"type": "wait", "seconds": 1.0})
        self.refresh(i + 1)

    def edit_wait(self):
        i = self.list.currentRow()
        if not (0 <= i < len(self.steps)) or not isinstance(self.steps[i], dict) \
                or self.steps[i].get("type") != "wait":
            QMessageBox.information(self, "Пауза", "Выберите в списке строку «Пауза»")
            return
        v, ok = QInputDialog.getDouble(self, "Пауза", "Секунд:", float(self.steps[i].get("seconds", 1)), 0.1, 30, 1)
        if ok:
            self.steps[i]["seconds"] = round(v, 1)
            self.refresh(i)

    def _rec_cfg(self, create=False):
        cfg = getattr(self.main, "cfg", None)
        if not isinstance(cfg, dict):
            return {}
        if create:
            return cfg.setdefault("recorder", {})
        return cfg.get("recorder") or {}

    # ---------- запись ----------
    def _panel_rects(self):
        return list(self.panel.rects) if self.panel else []

    def _show_panel(self):
        self.panel = RecordingPanel(self.stop_recording, self.cancel_recording)
        exclude_from_capture(self.panel, True)
        self.panel.set_state(0, 0)
        self.panel.show()
        self.panel.place()
        self.timer.start(1000)
        if self.main is not None:
            self.main.active_recorder = self.rec
            act = getattr(self.main, "tray_stop_rec", None)
            if act is not None:
                act.setVisible(True)

    def _hide_panel(self):
        self.timer.stop()
        if self.panel:
            self.panel.hide()
            self.panel.deleteLater()
            self.panel = None
        if self.main is not None:
            self.main.active_recorder = None
            act = getattr(self.main, "tray_stop_rec", None)
            if act is not None:
                act.setVisible(False)

    def _tick(self):
        rec = self.rec
        if rec is None:
            return
        if self.panel:
            self.panel.set_state(rec.count, rec.elapsed())
            self.panel.update_rects()
        rec.tick()          # 2 минуты без действий → остановка

    def stop_recording(self):
        if self.rec:
            self.rec.finish("button")

    def cancel_recording(self):
        rec, self.rec = self.rec, None
        if rec is None:
            return
        rec.cancel()
        self._hide_panel()
        if self.session:
            recorder.remove_tree(self.session)
            self.session = None
        self.status.setText("Запись отменена — сценарий не изменён.")
        log.info("Запись сценария «%s» отменена", self.src.get("name"))
        self.showNormal()
        self.raise_()

    def start(self):
        from .capture import find_source_window
        name = self.src.get("name", "")
        if self.session:
            recorder.remove_tree(self.session)
        self.session = folder = resolve_path(recorder.new_session_folder(name))
        alt = self.stop_key.currentData()

        def begin():
            be = self.main.backend_factory()
            hwnd = find_source_window(be, self.src)
            if not hwnd:
                raise RuntimeError(f"{name}: окно не найдено — откройте программу")
            be.activate(hwnd)
            be.maximize(hwnd)
            rec = recorder.Recorder(be, hwnd, folder, on_stop=lambda: self.main.gui(self.finished),
                                    alt_stop=alt, exclude=self._panel_rects)
            if not rec.start():
                raise RuntimeError("Не удалось начать запись (перехват мыши и клавиатуры не включился)")
            return rec

        def ok(rec):
            self.rec = rec
            self.status.setText(f"● Идёт запись… Остановить: «Стоп» на панели, "
                                f"{recorder.stop_key_text(alt)} или {recorder.STOP_TEXT}")
            self._show_panel()
            self.showMinimized()

        self.status.setText("⏳ Готовлю запись…")
        self.main.run_bg(begin, ok, lambda e: self.status.setText("✖ " + humanize(e, name)))

    # ---------- 3.0.8: второй вид кнопки ----------
    def record_alt(self):
        i = self.list.currentRow()
        if not (0 <= i < len(self.steps)) or not isinstance(self.steps[i], dict) \
                or self.steps[i].get("type") != "click_image":
            g = recorder.guess_view_step(self.steps)
            if g is None:
                QMessageBox.information(self, "Второй вид", "Сначала запишите сценарий — пока в нём нет щелчков по iVMS")
                return
            i = g
            self.list.setCurrentRow(i)
        self.alt_hint.setText(recorder.ALT_HOWTO)
        if QMessageBox.question(
                self, "Второй вид",
                f"Шаг: {recorder.describe(self.steps[i])}\n\nВ iVMS у вида сейчас есть «Editing...»? "
                "После «Да» окно iVMS выйдет вперёд — один раз щёлкните по строке вида.") \
                != QMessageBox.StandardButton.Yes:
            return
        from .capture import find_source_window
        name = self.src.get("name", "")
        folder = resolve_path(os.path.join(recorder.recordings_root(name), "alt_tmp"))
        alt = self.stop_key.currentData()

        def begin():
            be = self.main.backend_factory()
            hwnd = find_source_window(be, self.src)
            if not hwnd:
                raise RuntimeError(f"{name}: окно не найдено — откройте программу")
            be.activate(hwnd)
            be.maximize(hwnd)
            rec = recorder.Recorder(be, hwnd, folder, on_stop=lambda: self.main.gui(self.alt_finished),
                                    alt_stop=alt, exclude=self._panel_rects, max_clicks=1)
            if not rec.start():
                raise RuntimeError("Не удалось начать запись (перехват мыши и клавиатуры не включился)")
            return rec

        def ok(rec):
            self.rec, self.alt_index = rec, i
            self.status.setText("● Щёлкните один раз по строке вида в iVMS…")
            self._show_panel()
            self.showMinimized()

        self.main.run_bg(begin, ok, lambda e: self.status.setText("✖ " + humanize(e, name)))

    def record_cancel(self):
        """3.0.9: запомнить картинку кнопки Cancel окна-вопроса iVMS (один щелчок по ней)."""
        if QMessageBox.question(self, "Cancel", recorder.CANCEL_HOWTO + "\n\nВопрос iVMS сейчас на экране?") \
                != QMessageBox.StandardButton.Yes:
            return
        from .capture import find_source_window
        name = self.src.get("name", "")
        folder = resolve_path(os.path.join(recorder.recordings_root(name), "cancel_tmp"))
        alt = self.stop_key.currentData()

        def begin():
            be = self.main.backend_factory()
            hwnd = find_source_window(be, self.src)
            if not hwnd:
                raise RuntimeError(f"{name}: окно не найдено — откройте программу")
            # окно не разворачиваю и не активирую: окно-вопрос уже сверху; щелчок принимается по всему экрану
            rec = recorder.Recorder(be, hwnd, folder, on_stop=lambda: self.main.gui(self.alt_finished),
                                    alt_stop=alt, exclude=self._panel_rects, max_clicks=1)
            if not rec.start():
                raise RuntimeError("Не удалось начать запись (перехват мыши и клавиатуры не включился)")
            rec.rect = (-100000, -100000, 200000, 200000)   # окно-вопрос может быть вне окна iVMS
            return rec

        def ok(rec):
            self.rec, self.alt_index = rec, "cancel"
            self.status.setText("● Щёлкните один раз по Cancel в окне iVMS…")
            self._show_panel()
            self.showMinimized()

        self.main.run_bg(begin, ok, lambda e: self.status.setText("✖ " + humanize(e, name)))

    def alt_finished(self):
        rec, self.rec = self.rec, None
        i, self.alt_index = self.alt_index, None
        if rec is None or i is None:
            return
        if i == "cancel":
            rec.stop()
            self._hide_panel()
            self.showNormal()
            self.raise_()
            rec.steps()
            crop = next(iter(rec.crops.values()), None)
            if not crop or not os.path.isfile(crop):
                self.status.setText("✖ Щелчок не записан — попробуйте ещё раз")
                return
            rel = recorder.attach_cancel(self.src, crop, resolve_path)
            recorder.remove_tree(os.path.dirname(crop))
            log.info("Сценарий «%s»: записана кнопка Cancel (%s)", self.src.get("name"), rel)
            self.cancel_state.setText(recorder.cancel_state_text(self.src, resolve_path))
            self.status.setText("✔ Cancel записан. Нажмите «Сохранить».")
            return
        rec.stop()
        self._hide_panel()
        self.showNormal()
        self.raise_()
        rec.steps()                              # дождаться картинки щелчка
        crop = next(iter(rec.crops.values()), None)
        step = self.steps[i]
        if not crop or not os.path.isfile(crop):
            self.status.setText("✖ Щелчок не записан — попробуйте ещё раз")
            return
        root = base_dir()
        dst = recorder.attach_alt(step, crop, resolve_path(step["template"]),
                                  lambda p: os.path.relpath(p, root).replace(os.sep, "/"))
        recorder.remove_tree(os.path.dirname(crop))
        log.info("Сценарий «%s»: записан второй вид шага %d (%s)", self.src.get("name"), i + 1,
                 os.path.basename(dst))
        self.status.setText("✔ Второй вид записан. Нажмите «Сохранить». Потом в iVMS дважды щёлкните по виду "
                            "и нажмите Cancel — камеры вернутся на место.")
        self.refresh(i)

    def finished(self):
        if self.alt_index is not None:
            return self.alt_finished()
        rec, self.rec = self.rec, None
        if rec is None:
            return
        rec.stop()
        self._hide_panel()
        root = base_dir()
        got = rec.steps(rel=lambda p: os.path.relpath(p, root).replace(os.sep, "/"))
        self.steps = recorder.scenario(got, self.src.get("steps"))
        n = sum(1 for s in got if s.get("type") != "wait")
        why = " (2 минуты без действий — запись остановлена)" if rec.reason == "idle" else ""
        self.status.setText(f"✔ Записано действий: {n}{why}" + (f" (щелчков вне окна пропущено: {rec.ignored})"
                                                              if rec.ignored else "")
                            + ". Проверьте «Пробный запуск», затем «Сохранить».")
        log.info("Сценарий «%s» записан: %d действий", self.src.get("name"), n)
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self.refresh()
        if self.auto_test and got:
            self.test_run()

    # ---------- проба и сохранение ----------
    def test_run(self):
        if not self.steps:
            return
        src = dict(copy.deepcopy(self.src), steps=copy.deepcopy(self.steps))
        from .settings import show_images

        def run():
            be = self.main.backend_factory()
            prev = be.foreground()
            self.main._capture_hook(True)
            try:
                return StepRunner(be, resolve_path).run_source(src)
            finally:
                be.set_foreground(prev)
                self.main._capture_hook(False)
        self.main.run_bg(run, lambda imgs: show_images(self, f"пробный запуск {src.get('name')}", imgs),
                         source=src.get("name"))

    def save(self):
        if not self.steps:
            if self.src.get("cancel_template"):      # записали только кнопку Cancel
                self.saved = True
                self.accept()
            return
        recorder.mark_saved(self.src, self.steps)
        if self.session:      # прошлые записи этой программы больше не нужны
            recorder.keep_only(resolve_path(recorder.recordings_root(self.src.get("name", ""))), self.session)
            self.session = None
        self.saved = True
        log.info("Сценарий «%s» сохранён (%d шагов)", self.src.get("name"), len(self.steps))
        self.accept()

    def restore_default(self):
        if not self.src.get("recorded"):
            QMessageBox.information(self, "Сценарий", "Сейчас и так стандартный сценарий")
            return
        recorder.reset(self.src, resolve_path)
        self.session = None
        self.saved = True
        log.info("Сценарий «%s»: возвращён стандартный", self.src.get("name"))
        self.accept()

    def done(self, r):  # noqa: D401  — отмена: новая несохранённая запись удаляется, старая остаётся
        if self.rec:
            self.rec.cancel()
            self.rec = None
        self._hide_panel()
        if self.session and not self.saved:
            recorder.remove_tree(self.session)
            self.session = None
        super().done(r)

    def closeEvent(self, e):  # noqa: N802
        if self.rec:
            self.rec.stop()
            self.rec = None
        super().closeEvent(e)
