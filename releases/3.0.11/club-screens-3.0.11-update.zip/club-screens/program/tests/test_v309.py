# Original-Author: Владислав С.
# Created: 2026-11-01
"""3.0.9: окно-вопрос iVMS после ЛЮБОГО двойного щелчка, кнопка Cancel по картинке, Esc, стоп щелчков;
картинки записи крупнее и снимаются до реакции программы; сценарий камер в основных настройках."""
import os
import tempfile
import unittest

from PIL import Image

from app import __version__, recorder
from app.steps import Context, StepRunner


class Be:
    def __init__(self, found=(), dialog="none", after_esc=None):
        self.found = dict(found)
        self.clicks, self.keys, self.calls = [], [], 0
        self.dialog, self.after_esc = dialog, after_esc

    def window_rect(self, hwnd):
        return (0, 0, 1920, 1040)

    def virtual_screen(self):
        return (0, 0, 1920, 1080)

    def locate(self, path, rect, conf):
        return self.found.get(os.path.basename(path))

    def click(self, x, y, double=False):
        self.clicks.append((x, y, double))

    def press(self, k):
        self.keys.append(k)
        if self.after_esc:
            self.dialog = self.after_esc

    def process_windows(self, hwnd):
        return {hwnd}

    def cancel_new_dialog(self, hwnd, before, wait):
        self.calls += 1
        return self.dialog


class Dialog309(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        for n in ("step02.png", "cancel.png"):
            open(os.path.join(self.dir, n), "wb").close()

    def run_steps(self, be, steps, src=None):
        r = StepRunner(be, lambda p: os.path.join(self.dir, p), sleep=lambda s: None)
        ctx = Context(src or {"name": "iVMS-4200", "kind": "ivms"})
        ctx.hwnd = 7
        r.run_steps(steps, ctx)
        return ctx

    VIEW = {"type": "click_image", "template": "step02.png", "double": True,
            "fallback": {"type": "click_xy", "x": 123, "y": 203, "units": "pixels", "double": True}}
    FULL = {"type": "click_xy", "x": 1849, "y": 986, "units": "pixels"}

    def test_version(self):
        self.assertEqual(__version__, "3.0.11")

    def test_double_click_without_alt_checks_dialog(self):
        be = Be({"step02.png": (120, 198)}, dialog="cancelled")
        self.run_steps(be, [self.VIEW, self.FULL])
        self.assertGreaterEqual(be.calls, 1)
        self.assertEqual(be.clicks, [(120, 198, True), (1849, 986, False)])

    def test_fallback_double_click_checks_dialog(self):
        be = Be(dialog="cancelled")
        self.run_steps(be, [self.VIEW])
        self.assertGreaterEqual(be.calls, 1)

    def test_cancel_by_template(self):
        be = Be({"step02.png": (120, 198), "cancel.png": (900, 600)}, dialog="no_cancel")
        ctx = self.run_steps(be, [self.VIEW, self.FULL],
                             {"name": "iVMS-4200", "kind": "ivms", "cancel_template": "cancel.png"})
        self.assertEqual(be.clicks, [(120, 198, True), (900, 600, False), (1849, 986, False)])
        self.assertEqual(ctx.warnings, [])

    def test_esc_closes(self):
        be = Be({"step02.png": (120, 198)}, dialog="no_cancel", after_esc="none")
        ctx = self.run_steps(be, [self.VIEW, self.FULL])
        self.assertEqual(be.keys, ["esc"])
        self.assertIn((1849, 986, False), be.clicks)
        self.assertFalse(ctx.dialog_blocked)

    def test_dialog_stuck_no_fullscreen_click(self):
        be = Be({"step02.png": (120, 198)}, dialog="no_cancel")
        ctx = self.run_steps(be, [self.VIEW, self.FULL])
        self.assertTrue(ctx.dialog_blocked)
        self.assertNotIn((1849, 986, False), be.clicks)      # на полноэкранный режим не жмёт
        self.assertIn("Cancel", ctx.warnings[0])

    def test_plain_source_single_click_no_check(self):
        be = Be({"step02.png": (120, 198)})
        self.run_steps(be, [dict(self.VIEW, double=False)], {"name": "Oasys"})
        self.assertEqual(be.calls, 0)


class Recorder309(unittest.TestCase):
    def test_crop_bigger_and_detail(self):
        self.assertGreaterEqual(recorder.CROP[0], 160)
        self.assertFalse(recorder.crop_has_detail(Image.new("RGB", (200, 60), (37, 37, 37))))
        im = Image.new("RGB", (200, 60), (37, 37, 37))
        for x in range(20, 120):
            im.putpixel((x, 30), (255, 255, 255))
        im2 = im.resize((200, 60))
        for y in range(20, 40):
            for x in range(20, 120):
                im2.putpixel((x, y), (255, 255, 255))
        self.assertTrue(recorder.crop_has_detail(im2))

    def test_crop_taken_synchronously(self):
        grabbed = []

        class B:
            def window_rect(self, h):
                return (0, 0, 1000, 800)

            def grab(self, r):
                grabbed.append(r)
                im = Image.new("RGB", (r[2], r[3]))
                for x in range(r[2] // 2):
                    im.putpixel((x, 5), (255, 255, 255))
                return im
        d = tempfile.mkdtemp()
        rec = recorder.Recorder(B(), 1, d)
        rec.rect = (0, 0, 1000, 800)
        rec.on_mouse(0x0201, 0, 300, 200)
        self.assertEqual(len(grabbed), 1)          # снято сразу, в перехватчике
        self.assertEqual(grabbed[0][2:], recorder.CROP)
        self.assertTrue(os.path.isfile(rec.crops[0]))

    def test_attach_cancel(self):
        d = tempfile.mkdtemp()
        crop = os.path.join(d, "c.png")
        Image.new("RGB", (10, 10)).save(crop)
        src = {"name": "iVMS-4200"}
        rel = recorder.attach_cancel(src, crop, lambda p: os.path.join(d, p))
        self.assertEqual(src["cancel_template"], rel)
        self.assertTrue(rel.startswith("templates/"))
        self.assertIn("Cancel записан", recorder.cancel_state_text(src, lambda p: os.path.join(d, p)))


class SettingsBasic309(unittest.TestCase):
    def test_cameras_in_basic(self):
        src = open(os.path.join(os.path.dirname(__file__), "..", "app", "ui", "settings.py"), encoding="utf-8").read()
        main = src[src.index("def _build_main"):src.index("def _sec_look")]
        self.assertIn("_sec_cameras", main)
        sources = src[src.index("def _build_sources"):src.index("CAPTURE_WIDGETS")]
        self.assertNotIn("Второй вид (Editing)", sources)


if __name__ == "__main__":
    unittest.main()
