# Original-Author: Владислав С.
# Created: 2026-10-31
"""3.0.3: проверка беседы смотрит до 8 сообщений с фото; повторное чтение недорисованной беседы."""
import unittest
from datetime import datetime

from app import dupcheck, vk_browser


class Window(unittest.TestCase):
    def test_own_message_pushed_up_by_others_still_seen(self):
        own = {"own": True, "t": 7 * 60, "imgs": [{"w": 16, "h": 9, "src": "http://a"}] * 2}
        other = {"own": False, "t": 7 * 60 + 3, "imgs": [{"w": 3, "h": 4, "src": "http://b"}]}
        page = {"msgs": [own] + [other] * 6}
        cands, _ = dupcheck.candidates(page, datetime(2026, 10, 31, 7, 0), datetime(2026, 10, 31, 7, 11))
        self.assertEqual(len(cands), 1)


class Reread(unittest.TestCase):
    def test_rereads_until_own_visible(self):
        reads = [{"own": True, "msgs": [{"own": False}]},
                 {"own": True, "msgs": [{"own": True}, {"own": False}, {"own": False}]}]
        fl = vk_browser.Flows.__new__(vk_browser.Flows)

        def open_chat(*a, **k):
            return
            yield

        def js(name, **k):
            return reads.pop(0) if reads else {"msgs": []}
            yield

        fl.open_chat, fl.js = open_chat, js
        g = fl.hour_photos(1)
        try:
            while True:
                next(g)
        except StopIteration as e:
            r = e.value
        self.assertEqual(len(r["msgs"]), 3)


class LightOff(unittest.TestCase):
    def test_auto_migrates_off_and_never_auto(self):
        from app import config, lightmode
        cfg = {"light_mode": {"mode": "auto"}}
        config.migrate(cfg)
        self.assertEqual(cfg["light_mode"]["mode"], "off")
        self.assertFalse(lightmode.is_active({"light_mode": {"mode": "auto"}}, 99))
        self.assertTrue(lightmode.is_active({"light_mode": {"mode": "on"}}, 10))
        cfg = {"light_mode": {"mode": "on"}}
        config.migrate(cfg)
        self.assertEqual(cfg["light_mode"]["mode"], "on")


if __name__ == "__main__":
    unittest.main()


def _run(g):
    try:
        while True:
            next(g)
    except StopIteration as e:
        return e.value


class OwnDelivery(unittest.TestCase):
    def _fl(self, page):
        fl = vk_browser.Flows.__new__(vk_browser.Flows)

        def js(name, **k):
            return page
            yield
        fl.js = js
        return fl

    def test_own_message_with_all_images_confirms(self):
        page = {"msgs": [{"own": True, "t": 420, "imgs": [{}, {}]}]}
        self.assertTrue(_run(self._fl(page).own_new_message(2, 420)))

    def test_old_or_foreign_or_partial_not_confirmed(self):
        for m in ({"own": True, "t": 360, "imgs": [{}, {}]}, {"own": False, "t": 420, "imgs": [{}, {}]},
                  {"own": True, "t": 420, "imgs": [{}]}):
            self.assertFalse(_run(self._fl({"msgs": [m]}).own_new_message(2, 420)))


class CatchUp(unittest.TestCase):
    def _sched(self, now, calls):
        from app.scheduler import HourlyScheduler
        sc = HourlyScheduler(lambda: None, lambda: {}, now=lambda: now, catch_up=calls.append)
        sc.skipped = []
        return sc

    def test_missed_slot_caught_once(self):
        calls = []
        sc = self._sched(datetime(2026, 10, 31, 7, 12), calls)
        slot = datetime(2026, 10, 31, 7, 0)
        sc._maybe_catch_up(slot, {})
        sc._maybe_catch_up(slot, {})
        self.assertEqual(calls, [slot])

    def test_late_caught_old_hours_only_logged_skipped_never(self):
        calls = []
        sc = self._sched(datetime(2026, 10, 31, 7, 50), calls)
        sc._maybe_catch_up(datetime(2026, 10, 31, 5, 0), {})     # ночью ПК был выключен — только в журнал
        sc._maybe_catch_up(datetime(2026, 10, 31, 6, 0), {})
        sc._maybe_catch_up(datetime(2026, 10, 31, 7, 0), {})     # текущий час — догоняется при любом опоздании
        sc.skipped = [datetime(2026, 10, 31, 7, 30)]
        sc._maybe_catch_up(datetime(2026, 10, 31, 7, 30), {})
        self.assertEqual(calls, [datetime(2026, 10, 31, 7, 0)])


class Reliability(unittest.TestCase):
    def test_scheduler_health(self):
        import threading
        from app.scheduler import HourlyScheduler, STALL_SEC
        sc = HourlyScheduler(lambda: None, lambda: {})
        self.assertTrue(sc.healthy())
        t = threading.Thread(target=lambda: None)
        t.start(); t.join()
        sc._thread = t
        self.assertFalse(sc.healthy())          # поток умер сам
        ev = threading.Event()
        t = threading.Thread(target=ev.wait); t.start()
        sc._thread, sc._tick = t, 0.0
        self.assertFalse(sc.healthy(clock=lambda: STALL_SEC + 1))
        self.assertTrue(sc.healthy(clock=lambda: 10))
        ev.set(); t.join()

    def test_update_bat_rolls_back_and_never_pauses(self):
        import tempfile
        from app import updater
        with tempfile.TemporaryDirectory() as d:
            text = open(updater.write_apply_bat(d, "x.zip", 1, "3.0.3"), encoding="utf-8").read()
        self.assertIn("started.ok", text)
        self.assertIn("backup_prev", text)
        self.assertNotIn("pause", text)

    def test_missing_hidden_template_is_info(self):
        from app import steps
        src = open(steps.__file__, encoding="utf-8").read()
        self.assertIn('step.get("wizard") == "hidden"', src)


def _img(seed, path=None):
    import numpy as np
    from PIL import Image
    rng = np.random.default_rng(seed)
    a = (rng.random((18, 32)) * 255).astype("uint8")
    im = Image.fromarray(a).resize((320, 180))
    if path:
        im.save(path)
    return im


class Tagged(unittest.TestCase):
    CFG = {"tagged": {"enabled": True}, "schedule": {"minute": 0}}

    def test_caption_on_time_and_late(self):
        from app import tagged
        slot = datetime(2026, 10, 31, 7, 0)
        self.assertEqual(tagged.caption_for(self.CFG, slot, datetime(2026, 10, 31, 7, 2)), "Камеры за 7:00")
        self.assertEqual(tagged.caption_for(self.CFG, slot, datetime(2026, 10, 31, 7, 23)),
                         "Камеры за 7:00 (снято в 7:23)")
        self.assertEqual(tagged.slot_for(datetime(2026, 10, 31, 7, 40)), slot)
        self.assertFalse(tagged.enabled({}))

    def test_tag_match_not_confused(self):
        from app import tagged
        self.assertTrue(tagged.has_tag("Камеры за 07:00 (снято в 7:23)", "Камеры за 7:00"))
        self.assertFalse(tagged.has_tag("Камеры за 17:00", "Камеры за 7:00"))
        self.assertFalse(tagged.has_tag("", "Камеры за 7:00"))
        self.assertEqual(tagged.normalize_account("https://vk.com/Club_PC"), "club_pc")

    def test_candidates_by_tag(self):
        img = {"w": 16, "h": 9, "src": "http://a"}
        since, now = datetime(2026, 10, 31, 7, 0), datetime(2026, 10, 31, 7, 50)
        late = {"own": True, "t": 7 * 60 + 40, "imgs": [img, img], "text": "Камеры за 7:00 (снято в 7:40)",
                "own_id": "prog"}
        notag = dict(late, text="")
        other = dict(late, own_id="someone")
        c, _ = dupcheck.candidates({"msgs": [late]}, since, now, hour_tag="Камеры за 7:00", account="prog")
        self.assertEqual(len(c), 1)
        c, why = dupcheck.candidates({"msgs": [notag]}, since, now, hour_tag="Камеры за 7:00")
        self.assertEqual(c, [])
        self.assertIn("нет тега часа", why[0])
        c, why = dupcheck.candidates({"msgs": [other]}, since, now, hour_tag="Камеры за 7:00", account="prog")
        self.assertIn("не в тот аккаунт", why[0])

    def test_job_caption(self):
        from app.job import JobRunner
        j = JobRunner.__new__(JobRunner)
        j.late_for = datetime(2026, 10, 31, 7, 0)
        j.now = lambda: datetime(2026, 10, 31, 7, 23)
        self.assertEqual(j._tag_caption(self.CFG, j.now(), "x"), "Камеры за 7:00 (снято в 7:23)\nx")
        self.assertEqual(j._tag_caption({}, j.now(), "x"), "x")

    def test_config_default_off(self):
        from app import config
        cfg = {}
        config.migrate(cfg)
        self.assertFalse(cfg["tagged"]["enabled"])


class ContentCheck(unittest.TestCase):
    def test_same_pictures_confirmed_wrong_rejected(self):
        import io
        import os
        import tempfile
        d = tempfile.mkdtemp()
        paths = [os.path.join(d, "a.png"), os.path.join(d, "b.png")]
        _img(1, paths[0]); _img(2, paths[1])

        def data(seed):
            b = io.BytesIO(); _img(seed).save(b, "JPEG", quality=60); return b.getvalue()
        store = {"u1": data(1), "u2": data(2), "u3": data(3)}
        mk = lambda *u: [{"w": 320, "h": 180, "src": x} for x in u]   # noqa: E731
        self.assertTrue(dupcheck.content_match(paths, mk("u2", "u1"), store.get)[0])
        self.assertFalse(dupcheck.content_match(paths, mk("u1", "u3"), store.get)[0])
        self.assertFalse(dupcheck.content_match(paths, mk("u1"), store.get)[0])
        self.assertIsNone(dupcheck.content_match(paths, mk("u1", "nope"),
                                                 lambda u: (_ for _ in ()).throw(OSError()))[0])

    def test_sender_marks_mismatch(self):
        s = vk_browser.BrowserVKSender(None, {})
        msg = {"imgs": [{"w": 320, "h": 180, "src": "x"}]}
        self.assertEqual(s.check_content("verified", ["a", "b"], msg), "mismatch")
        self.assertEqual(s.check_content("verified", ["a"], None), "verified")


class KeepMaximized(unittest.TestCase):
    def test_not_left_minimized(self):
        import sys
        import types
        from app import backend_win
        from unittest import mock
        wc = types.SimpleNamespace(SW_RESTORE=9, SW_SHOW=5, SW_MAXIMIZE=3)
        calls = []

        class U:
            def IsIconic(self, h):
                return True          # окно свернулось после попыток

            def ShowWindow(self, h, cmd):
                calls.append(cmd)
        b = backend_win.WinBackend.__new__(backend_win.WinBackend) if hasattr(backend_win, "WinBackend") else None
        if b is None:
            self.skipTest("нет WinBackend")
        b.u32 = U()
        b._set_foreground = lambda h: True
        with mock.patch.dict(sys.modules, {"win32con": wc}), mock.patch.object(backend_win.time, "sleep"):
            b.activate(1)
        self.assertEqual(calls[-1], 3)


class Takeover(unittest.TestCase):
    def test_hung_pid_and_errdoc(self):
        import os
        import tempfile
        from app import errdoc, watchdog
        d = tempfile.mkdtemp()
        watchdog.beat(watchdog.hb_path(d), pid=4242, now=1000)
        self.assertEqual(watchdog.hung_pid(d, 300, now=1200, alive=lambda p: True), 0)
        self.assertEqual(watchdog.hung_pid(d, 300, now=1400, alive=lambda p: True), 4242)
        self.assertEqual(watchdog.hung_pid(d, 300, now=1400, alive=lambda p: False), 0)
        p = errdoc.ensure(os.path.join(d, "logs"))
        self.assertIn("ВОЗМОЖНЫЕ ОШИБКИ", open(p, encoding="utf-8").read())


class TaggedTab(unittest.TestCase):
    def test_tab_loads_and_saves(self):
        import copy
        import os
        import tempfile
        from app.config import DEFAULTS
        from PySide6.QtWidgets import QApplication
        QApplication.instance() or QApplication([])
        from tests.test_live_settings import StubMain
        from app.ui.settings import SettingsPage
        cfg = copy.deepcopy(DEFAULTS)
        page = SettingsPage(StubMain(cfg, os.path.join(tempfile.mkdtemp(), "config.yaml")))
        page.load()
        self.assertFalse(page.tg_enabled.isChecked())
        self.assertEqual(page.tabs.count(), 3)
        page.tg_enabled.setChecked(True)
        page.tg_caption.setText("Камеры за {hour}")
        page.tg_account.setText("vk.com/prog")
        page._tg_preview()
        self.assertIn("Камеры за", page.tg_preview.text())
        page._apply_general()
        tg = page.main.cfg["tagged"] if hasattr(page, "main") else cfg["tagged"]
        self.assertTrue(tg["enabled"])
        self.assertEqual(tg["account_id"], "vk.com/prog")
